#!/usr/bin/env python3
"""Convert a GEO supplementary directory with many per-sample MTX/TSV triples into one .h5ad.

Designed for series like GSE140510/GSE140511 where each sample is distributed as:
  <sample>_barcodes.tsv.gz
  <sample>_genes.tsv.gz or <sample>_features.tsv.gz
  <sample>_matrix.mtx.gz

Example
-------
python prepare_geo_mtx_series_to_h5ad.py \
  --input-dir data_raw/GSE140510_RAW \
  --output data_processed/GSE140510_mouse_combined.h5ad \
  --sample-suffixes WT1,WT2,WT3,Trem2_KO1,Trem2_KO2,Trem2_KO3,WT_5XFAD1,WT_5XFAD2,WT_5XFAD3,Trem2_KO_5XFAD1,Trem2_KO_5XFAD2,Trem2_KO_5XFAD3
"""
from __future__ import annotations

import argparse
import gzip
import re
from pathlib import Path

import anndata as ad
import pandas as pd
import scanpy as sc


def detect_gene_file(input_dir: Path, prefix: str) -> Path | None:
    for suffix in ["_genes.tsv.gz", "_features.tsv.gz", "_genes.tsv", "_features.tsv"]:
        p = input_dir / f"{prefix}{suffix}"
        if p.exists():
            return p
    return None


def open_table(path: Path):
    if path.suffix == ".gz":
        return gzip.open(path, "rt")
    return open(path, "r")


def read_10x_triplet(matrix_path: Path, barcodes_path: Path, genes_path: Path) -> ad.AnnData:
    adata = sc.read_mtx(matrix_path).T

    with open_table(barcodes_path) as f:
        barcodes = [line.strip().split("\t")[0] for line in f if line.strip()]
    with open_table(genes_path) as f:
        rows = [line.strip().split("\t") for line in f if line.strip()]

    # genes.tsv often has: gene_id, gene_symbol; features.tsv may have a 3rd type column.
    gene_ids = [r[0] for r in rows]
    gene_names = [r[1] if len(r) > 1 else r[0] for r in rows]

    adata.obs_names = barcodes
    adata.var_names = gene_names
    adata.var["gene_ids"] = gene_ids
    adata.var_names_make_unique()
    return adata


def main() -> int:
    parser = argparse.ArgumentParser(description="Combine GEO per-sample MTX triples into one h5ad.")
    parser.add_argument("--input-dir", required=True, help="Directory containing *_matrix.mtx.gz, *_barcodes.tsv.gz, *_genes.tsv.gz files.")
    parser.add_argument("--output", required=True, help="Output .h5ad file.")
    parser.add_argument("--sample-suffixes", help="Optional comma-separated list of exact sample names to include, e.g. WT1,WT2,WT_5XFAD1")
    parser.add_argument("--project-name", default="geo_series", help="Project name to store in uns metadata.")
    args = parser.parse_args()

    input_dir = Path(args.input_dir)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)

    requested = None
    if args.sample_suffixes:
        requested = {x.strip() for x in args.sample_suffixes.split(",") if x.strip()}

    matrix_files = sorted(input_dir.glob("*_matrix.mtx*"))
    if not matrix_files:
        raise FileNotFoundError(f"No matrix files found in {input_dir}")

    adatas = []
    sample_table = []

    for matrix_path in matrix_files:
        prefix = re.sub(r"_matrix\.mtx(\.gz)?$", "", matrix_path.name)
        sample_name = prefix
        if requested is not None and sample_name not in requested:
            continue

        barcodes_path = None
        for suffix in ["_barcodes.tsv.gz", "_barcodes.tsv"]:
            candidate = input_dir / f"{prefix}{suffix}"
            if candidate.exists():
                barcodes_path = candidate
                break
        genes_path = detect_gene_file(input_dir, prefix)
        if not barcodes_path or not genes_path:
            print(f"Skipping {prefix}: missing barcodes or genes/features file")
            continue

        print(f"Reading sample: {sample_name}")
        adata = read_10x_triplet(matrix_path, barcodes_path, genes_path)
        adata.obs["sample_id"] = sample_name
        adata.obs_names = [f"{sample_name}__{bc}" for bc in adata.obs_names]
        adata.obs_names_make_unique()
        adata.var_names_make_unique()
        adatas.append(adata)
        sample_table.append({"sample_id": sample_name, "n_cells": adata.n_obs, "n_genes": adata.n_vars})

    if not adatas:
        raise RuntimeError("No samples were successfully loaded.")

    print(f"Concatenating {len(adatas)} samples...")
    combined = ad.concat(adatas, join="outer", merge="same", label="batch", keys=[a.obs['sample_id'].iloc[0] for a in adatas], fill_value=0)
    combined.uns["project_name"] = args.project_name

    combined.write_h5ad(output, compression="gzip")
    pd.DataFrame(sample_table).to_csv(output.with_suffix(".samples.csv"), index=False)
    print(f"Saved combined h5ad: {output}")
    print(f"Saved sample table: {output.with_suffix('.samples.csv')}")
    print(f"Shape: {combined.shape}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
