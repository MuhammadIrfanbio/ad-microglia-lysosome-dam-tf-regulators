#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
ZNF335/Zfp335 CLEAN FINAL module analysis V3

Purpose
-------
This version corrects the problems seen in the previous output:

1. Removes the circular TF_ZNF335_context module.
2. Excludes ZNF335/Zfp335 from candidate-gene ranking.
3. Uses only one Olah object by default.
4. Uses a clean final dataset manifest by default instead of recursively analyzing many duplicate/broken .h5ad files.
5. Improves Ensembl-ID handling: candidate plots display the queried gene symbol, not the Ensembl var_name.
6. Avoids full AnnData copying during ML, preventing SEAAD memory errors.
7. Produces both cell-level and donor/sample-level outputs.
8. Generates cleaner 900 ppi figures using diverging heatmaps centered at zero.
9. Writes all results to a fresh timestamped run folder.

Default working directory:
    F:\AD\Mam San

Default selected objects:
    SEAAD    -> seaad_microglia_subset.h5ad
    Olah     -> olah_live_human_microglia.h5ad
    GSE98969 -> gse98969_work_fixed\processed\GSE98969_combined.h5ad
    GSE140510-> data_processed\GSE140510_mouse_combined.h5ad

Important
---------
If GSE140510_mouse_combined or GSE98969_combined are not microglia-only, the script will warn.
Final biological interpretation should prioritize sample/donor-level pseudobulk correlations.
"""

import argparse
import gc
import os
import re
import sys
import shutil
import traceback
from pathlib import Path
from datetime import datetime

import numpy as np
import pandas as pd

from scipy import sparse
from scipy.stats import mannwhitneyu, spearmanr

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm

try:
    import anndata as ad
    import scanpy as sc
    ANNDATA_OK = True
except Exception:
    ad = None
    sc = None
    ANNDATA_OK = False

try:
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.linear_model import LogisticRegression
    from sklearn.model_selection import StratifiedKFold, cross_val_score
    from sklearn.preprocessing import StandardScaler
    SKLEARN_OK = True
except Exception:
    SKLEARN_OK = False


# =============================================================================
# Curated non-circular modules
# =============================================================================
# ZNF335/Zfp335 is deliberately NOT included in any module.
# The module formerly named TF_ZNF335_context is removed.

MODULES = {
    # Core lipid modules requested by user
    "LIPID_DAM_lipid_associated_microglia": [
        "APOE", "TREM2", "TYROBP", "LPL", "CST7", "AXL", "ITGAX"
    ],
    "LIPID_uptake_phagocytosis": [
        "CD36", "LRP1", "TREM2", "LPL", "MERTK", "AXL"
    ],
    "LIPID_cholesterol_efflux_transport": [
        "ABCA1", "ABCG1", "APOE", "APOC1", "CLU"
    ],
    "LIPID_droplet_storage": [
        "PLIN2", "SOAT1", "SOAT2", "DGAT1", "DGAT2", "ACAT2"
    ],
    "LIPID_cholesterol_synthesis_SREBP": [
        "SREBF2", "HMGCR", "HMGCS1", "MVK", "MVD", "FDPS", "FDFT1", "SQLE", "LSS", "DHCR7", "DHCR24", "LDLR"
    ],
    "LIPID_nuclear_receptor_regulation": [
        "NR1H3", "NR1H2", "RXRA", "RXRB", "PPARG", "PPARA", "PPARD", "RARA", "RARB"
    ],

    # Expanded lipid pathways
    "LIPID_cholesterol_import_trafficking": [
        "LDLR", "LRP1", "SCARB1", "CD36", "NPC1", "NPC2", "LIPA", "OSBPL1A", "OSBPL2", "STARD3"
    ],
    "LIPID_cholesterol_esterification": [
        "SOAT1", "SOAT2", "ACAT2", "LIPA", "NCEH1", "LIPE"
    ],
    "LIPID_fatty_acid_uptake_transport": [
        "CD36", "SLC27A1", "SLC27A3", "SLC27A4", "SLC27A5", "FABP3", "FABP4", "FABP5", "LPL"
    ],
    "LIPID_fatty_acid_synthesis": [
        "ACLY", "ACACA", "ACACB", "FASN", "SCD", "ELOVL1", "ELOVL5", "ELOVL6", "SREBF1"
    ],
    "LIPID_beta_oxidation_FAO": [
        "CPT1A", "CPT1B", "CPT2", "ACOX1", "ACOX3", "ACADVL", "ACADM", "ACADS", "HADHA", "HADHB", "PPARA"
    ],
    "LIPID_triglyceride_synthesis_lipolysis": [
        "GPAM", "AGPAT1", "AGPAT2", "DGAT1", "DGAT2", "PNPLA2", "LIPE", "MGLL", "PLIN2", "PLIN3"
    ],
    "LIPID_phospholipid_remodeling": [
        "PLA2G4A", "PLA2G6", "LPCAT1", "LPCAT2", "LPCAT3", "LPCAT4", "MBOAT7", "CEPT1", "CHPT1"
    ],
    "LIPID_sphingolipid_ceramide": [
        "SPTLC1", "SPTLC2", "CERS2", "CERS4", "CERS5", "CERS6", "SGMS1", "SGMS2", "ASAH1", "SMPD1", "SMPD2", "DEGS1"
    ],
    "LIPID_eicosanoid_prostaglandin": [
        "PLA2G4A", "PTGS1", "PTGS2", "PTGES", "PTGES2", "PTGER2", "PTGER4", "ALOX5", "ALOX12", "ALOX15", "TBXAS1"
    ],
    "LIPID_oxysterol_LXR_axis": [
        "NR1H3", "NR1H2", "ABCA1", "ABCG1", "APOE", "APOC1", "SREBF1", "MYLIP", "CH25H", "CYP27A1"
    ],
    "LIPID_myelin_lipid_clearance": [
        "TREM2", "APOE", "LPL", "LGALS3", "CTSB", "CTSD", "LIPA", "NPC1", "NPC2", "PLIN2", "CD68", "AXL", "MERTK"
    ],
    "LIPID_ferroptosis_lipid_peroxidation": [
        "GPX4", "SLC7A11", "ACSL4", "LPCAT3", "ALOX5", "ALOX12", "ALOX15", "FTH1", "FTL", "TFRC", "NFE2L2", "HMOX1"
    ],

    # Microglial states and pathways
    "MICRO_homeostatic_identity": [
        "P2RY12", "TMEM119", "CX3CR1", "CSF1R", "SALL1", "GPR34", "SELPLG", "OLFML3", "TGFBR1"
    ],
    "MICRO_DAM_stage1_like": [
        "APOE", "TYROBP", "B2M", "CTSB", "CTSD", "LPL", "AXL"
    ],
    "MICRO_DAM_stage2_TREM2_dependent": [
        "TREM2", "LPL", "CST7", "ITGAX", "CD9", "GPNMB", "CLEC7A", "SPP1", "AXL"
    ],
    "MICRO_TREM2_APOE_axis": [
        "TREM2", "APOE", "TYROBP", "LPL", "AXL", "LGALS3", "GPNMB", "CD9", "SPP1"
    ],
    "MICRO_phagosome_efferocytosis": [
        "MERTK", "AXL", "TYROBP", "TREM2", "LAMP1", "LAMP2", "CD68", "ITGAM", "ITGAX", "FCGR1A", "FCGR2A", "FCGR3A"
    ],
    "MICRO_lysosome_phagosome": [
        "CTSB", "CTSD", "CTSS", "CTSZ", "LAMP1", "LAMP2", "CD68", "HEXA", "HEXB", "LIPA", "NPC1", "NPC2", "ATP6V0D1", "ATP6V1B2"
    ],
    "MICRO_autophagy_mitophagy": [
        "BECN1", "ATG5", "ATG7", "MAP1LC3B", "SQSTM1", "OPTN", "TBK1", "PINK1", "PRKN", "BNIP3", "BNIP3L"
    ],
    "MICRO_complement": [
        "C1QA", "C1QB", "C1QC", "C3", "C4A", "C4B", "CFB", "CFD", "CR1", "ITGAM", "ITGB2"
    ],
    "MICRO_antigen_presentation_MHC": [
        "HLA-DRA", "HLA-DRB1", "HLA-DPA1", "HLA-DPB1", "HLA-DQA1", "HLA-DQB1", "CD74", "B2M", "TAP1", "TAP2"
    ],
    "MICRO_interferon_response": [
        "STAT1", "IRF7", "IRF9", "ISG15", "IFIT1", "IFIT2", "IFIT3", "MX1", "OAS1", "OAS2", "IFI44L", "CXCL10"
    ],
    "MICRO_NFkB_inflammatory_cytokine": [
        "NFKB1", "NFKBIA", "RELA", "TNF", "IL1B", "IL6", "CXCL8", "CCL2", "CCL3", "CCL4", "PTGS2", "NOS2"
    ],
    "MICRO_inflammasome": [
        "NLRP3", "PYCARD", "CASP1", "IL1B", "IL18", "GSDMD", "TXNIP", "NEK7"
    ],
    "MICRO_chemokine_migration": [
        "CCL2", "CCL3", "CCL4", "CCL5", "CXCL10", "CX3CR1", "CCR5", "CCR2", "CXCR4", "ITGAM", "ITGB2"
    ],
    "MICRO_proliferation_cell_cycle": [
        "MKI67", "TOP2A", "PCNA", "STMN1", "TYMS", "HMGB2", "UBE2C", "BIRC5", "CDK1", "CCNB1"
    ],
    "MICRO_oxidative_stress_NRF2": [
        "NFE2L2", "KEAP1", "HMOX1", "NQO1", "GCLC", "GCLM", "SOD1", "SOD2", "PRDX1", "PRDX6", "TXN", "TXNRD1"
    ],
    "MICRO_ER_stress_UPR": [
        "HSPA5", "XBP1", "ATF4", "ATF6", "DDIT3", "ERN1", "EIF2AK3", "DNAJB9", "HERPUD1", "PDIA3"
    ],

    # Metabolic state
    "METAB_glycolysis": [
        "HK1", "HK2", "GPI", "PFKP", "ALDOA", "GAPDH", "PGK1", "PGAM1", "ENO1", "PKM", "LDHA", "SLC2A1"
    ],
    "METAB_TCA_cycle": [
        "CS", "ACO2", "IDH3A", "IDH3B", "OGDH", "DLST", "SUCLG1", "SDHA", "SDHB", "FH", "MDH2"
    ],
    "METAB_OXPHOS_mitochondrial": [
        "NDUFA1", "NDUFA2", "NDUFB8", "NDUFS1", "SDHA", "UQCRC1", "UQCRC2", "COX4I1", "COX5A", "ATP5F1A", "ATP5F1B"
    ],
    "METAB_mTOR_AMPK_nutrient_sensing": [
        "MTOR", "RPTOR", "RICTOR", "AKT1", "TSC1", "TSC2", "RHEB", "PRKAA1", "PRKAA2", "STK11", "ULK1"
    ],

    # TF/regulator modules WITHOUT ZNF335
    "TF_myeloid_core": [
        "SPI1", "IRF8", "CEBPB", "MAFB", "RUNX1", "MEF2C", "SALL1"
    ],
    "TF_interferon_regulators": [
        "STAT1", "STAT2", "IRF1", "IRF7", "IRF9"
    ],
    "TF_lysosomal_biogenesis": [
        "TFEB", "TFE3", "MITF", "ZKSCAN3"
    ],
    "TF_lipid_nuclear_receptors": [
        "NR1H3", "NR1H2", "RXRA", "PPARG", "PPARA", "PPARD", "SREBF1", "SREBF2"
    ],
}

ZNF_ALIASES = {"ZNF335", "ZFP335", "Znf335", "Zfp335", "znf335", "zfp335"}
ZNF_CANONICAL = {"ZNF335", "ZFP335"}
ZNF_ENSEMBL_HINTS = {"ENSG00000198026"}  # human ZNF335; mouse IDs are matched by symbol if .var has symbols


# =============================================================================
# Logging
# =============================================================================

def stamp():
    return datetime.now().strftime("%Y%m%d_%H%M%S")

def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def safe_print(x):
    try:
        print(x, flush=True)
    except Exception:
        pass

def make_logger(log_file):
    log_file = Path(log_file)
    def _log(msg):
        line = f"[{now()}] {msg}"
        safe_print(line)
        try:
            with open(log_file, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except Exception:
            safe_print("[LOGGER WARNING] Could not write to log file.")
    return _log

def safe_name(x, max_len=140):
    y = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(x))
    return (y[:max_len].strip("_") or "unnamed")


# =============================================================================
# Input selection
# =============================================================================

def default_final_manifest(root):
    root = Path(root)
    candidates = [
        ("GSE140510", root / "data_processed" / "GSE140510_mouse_combined.h5ad", "mouse", "warning_if_not_microglia_only"),
        ("GSE98969", root / "gse98969_work_fixed" / "processed" / "GSE98969_combined.h5ad", "mouse", "warning_if_not_microglia_only"),
        ("Olah", root / "olah_live_human_microglia.h5ad", "human", "preferred_single_olah"),
        ("SEAAD_subset", root / "seaad_microglia_subset.h5ad", "human", "preferred_small_seaad"),
    ]
    rows = []
    for dataset, path, species, note in candidates:
        rows.append({"dataset_label": dataset, "path": str(path), "species": species, "note": note, "exists": path.exists()})
    return pd.DataFrame(rows)

def find_recursive_files(root):
    root = Path(root)
    files = sorted(root.rglob("*.h5ad"))
    bad = ["ZNF335_all_modules_900ppi", "ZNF335_lipid_module_filter", "__pycache__"]
    out = []
    for p in files:
        s = str(p)
        if any(b in s for b in bad):
            continue
        out.append({"dataset_label": safe_name(p.stem), "path": str(p), "species": "unknown", "note": "recursive_scan", "exists": True})
    return pd.DataFrame(out)


# =============================================================================
# Reading and gene mapping
# =============================================================================

def read_h5ad_robust(path, log, copy_to_temp=False, temp_dir=None):
    if not ANNDATA_OK:
        raise ImportError("scanpy/anndata is not available.")
    path = Path(path)
    read_path = path
    if copy_to_temp:
        temp_dir = Path(temp_dir)
        temp_dir.mkdir(parents=True, exist_ok=True)
        dst = temp_dir / path.name
        log(f"Copying to temporary file before reading: {dst}")
        try:
            shutil.copy2(path, dst)
            read_path = dst
        except Exception as e:
            log(f"Temporary copy failed, reading original: {repr(e)}")
            read_path = path

    errors = []
    for reader_name, reader in [("scanpy.read_h5ad", sc.read_h5ad), ("anndata.read_h5ad", ad.read_h5ad)]:
        try:
            return reader(read_path)
        except Exception as e:
            errors.append(f"{reader_name}: {repr(e)}")
    raise RuntimeError("Could not read h5ad: " + " | ".join(errors))

def get_axis(adata, use_raw=True):
    if use_raw and getattr(adata, "raw", None) is not None:
        try:
            return adata.raw.X, adata.raw.var, list(adata.raw.var_names), "raw"
        except Exception:
            pass
    return adata.X, adata.var, list(adata.var_names), "X"

def normalize_symbol(x):
    if x is None:
        return None
    s = str(x).strip()
    if s == "" or s.lower() in {"nan", "none", "na"}:
        return None
    if s.upper().startswith(("ENSG", "ENSMUSG")):
        s = s.split(".")[0]
    return s.upper()

def build_lookup(var_df, var_names):
    """
    lookup maps symbol/ID -> list of matches:
        {"idx": int, "var_name": str, "symbol_source": str, "symbol_value": str}
    """
    lookup = {}
    def add(key, idx, source, value):
        k = normalize_symbol(key)
        if not k:
            return
        lookup.setdefault(k, [])
        lookup[k].append({
            "idx": idx,
            "var_name": str(var_names[idx]),
            "symbol_source": source,
            "symbol_value": str(value)
        })

    for idx, name in enumerate(var_names):
        add(name, idx, "var_names", name)

    preferred_cols = [
        "gene_symbol", "gene_symbols", "symbol", "symbols", "gene_name", "gene_names",
        "feature_name", "feature_names", "hgnc_symbol", "mgi_symbol",
        "external_gene_name", "gene", "genes", "Gene", "Symbol", "GeneSymbol"
    ]
    cols = []
    for c in preferred_cols:
        if c in var_df.columns:
            cols.append(c)
    for c in var_df.columns:
        lc = str(c).lower()
        if c not in cols and any(k in lc for k in ["symbol", "gene_name", "feature", "hgnc", "mgi"]):
            cols.append(c)

    for col in cols:
        try:
            vals = list(var_df[col].values)
            for idx, val in enumerate(vals):
                add(val, idx, col, val)
        except Exception:
            continue

    # Collapse to first index for each key.
    first = {}
    for k, hits in lookup.items():
        # Prefer non-var_names hit if var_names are Ensembl IDs.
        chosen = hits[0]
        for h in hits:
            if h["symbol_source"] != "var_names":
                chosen = h
                break
        first[k] = chosen
    return first, cols

def matrix_for_genes(adata, genes, use_raw=True, rows=None):
    X, var_df, var_names, layer = get_axis(adata, use_raw=use_raw)
    lookup, symbol_cols = build_lookup(var_df, var_names)

    records = []
    seen_idx = set()
    for g in genes:
        key = normalize_symbol(g)
        if key in lookup:
            rec = dict(lookup[key])
            if rec["idx"] in seen_idx:
                continue
            seen_idx.add(rec["idx"])
            rec["query_gene"] = str(g)
            rec["display_gene"] = str(g).upper()
            records.append(rec)

    if not records:
        return None, [], layer, symbol_cols

    idx = [r["idx"] for r in records]

    # Select columns first to avoid full matrix copy.
    try:
        M = X[:, idx]
        if rows is not None:
            M = M[rows, :]
    except Exception:
        # Fallback for unusual backed/sparse cases.
        if rows is not None:
            M = X[rows, :][:, idx]
        else:
            M = X[:, idx]

    if sparse.issparse(M):
        M = M.toarray()
    else:
        M = np.asarray(M)

    M = M.astype(np.float32, copy=False)
    M[~np.isfinite(M)] = 0.0
    return M, records, layer, symbol_cols

def vector_for_gene(adata, gene, use_raw=True):
    M, records, layer, cols = matrix_for_genes(adata, [gene], use_raw=use_raw)
    if M is None:
        return None, None, layer, cols
    return np.asarray(M[:, 0]).ravel(), records[0], layer, cols

def choose_znf(adata, use_raw=True):
    for g in ["ZNF335", "ZFP335", "Znf335", "Zfp335", "znf335", "zfp335"]:
        v, rec, layer, cols = vector_for_gene(adata, g, use_raw=use_raw)
        if v is not None:
            return g, rec, v, layer, cols
    # Last chance: human Ensembl ID
    for g in list(ZNF_ENSEMBL_HINTS):
        v, rec, layer, cols = vector_for_gene(adata, g, use_raw=use_raw)
        if v is not None:
            rec["display_gene"] = "ZNF335"
            return "ZNF335", rec, v, layer, cols
    X, var_df, var_names, layer = get_axis(adata, use_raw=use_raw)
    _, cols = build_lookup(var_df, var_names)
    return None, None, None, layer, cols


# =============================================================================
# Filtering and stats
# =============================================================================

def maybe_filter_microglia(adata, disable=False):
    if disable:
        return adata, "no_filter_requested", False

    preferred = [
        "author_cell_type", "cell_type", "celltype", "cell type", "CellType",
        "cell_type_fine", "subclass", "class", "annotation", "annotations",
        "major_cell_type", "major_type", "cell_ontology_class", "CA_subclass_label",
        "cell.type", "broad_cell_type"
    ]
    cols = []
    for c in preferred:
        if c in adata.obs.columns:
            cols.append(c)
    for c in adata.obs.columns:
        lc = str(c).lower()
        if c not in cols and any(k in lc for k in ["cell", "annot", "class", "type", "subclass"]):
            cols.append(c)

    for col in cols:
        try:
            vals = adata.obs[col].astype(str).str.lower()
            mask = (
                vals.str.contains("microglia", regex=False)
                | vals.str.contains("microglial", regex=False)
                | vals.str.fullmatch("mg")
            )
            if mask.sum() >= 50 and 0.01 <= mask.mean() <= 0.99:
                return adata[mask].copy(), f"filtered_by_{col}", True
        except Exception:
            continue

    return adata, "assumed_microglia_or_microglia_file_no_celltype_column", False

def zscore_cols(M):
    M = np.asarray(M, dtype=np.float32)
    mu = np.nanmean(M, axis=0)
    sd = np.nanstd(M, axis=0)
    sd[sd == 0] = 1.0
    return (M - mu) / sd

def score_module(adata, genes, use_raw=True):
    M, records, layer, cols = matrix_for_genes(adata, genes, use_raw=use_raw)
    if M is None:
        return np.full(adata.n_obs, np.nan, dtype=np.float32), [], layer, cols
    score = np.nanmean(zscore_cols(M), axis=1)
    return score, records, layer, cols

def define_groups(znf_vec, min_group=25, high_q=0.75, low_q=0.25):
    z = np.asarray(znf_vec, dtype=float)
    z[~np.isfinite(z)] = 0.0
    positive = z > 0
    det = float(positive.mean())

    if positive.sum() >= min_group and det < 0.20:
        high = positive
        low = ~positive
        method = "sparse_TF_positive_vs_zero"
    else:
        qh = np.nanquantile(z, high_q)
        ql = np.nanquantile(z, low_q)
        high = z >= qh
        low = z <= ql
        method = f"quantile_Q{high_q}_vs_Q{low_q}"
        if qh == ql and positive.sum() >= min_group:
            high = positive
            low = ~positive
            method = "collapsed_quantile_positive_vs_zero"

    if high.sum() < min_group or low.sum() < min_group:
        method += "_WARNING_small_group"
    return high, low, det, method

def bh_fdr(pvals):
    p = np.asarray(pvals, dtype=float)
    out = np.full(p.shape, np.nan)
    valid = np.isfinite(p)
    pv = p[valid]
    if len(pv) == 0:
        return out
    order = np.argsort(pv)
    ranked = pv[order]
    n = len(ranked)
    q = ranked * n / (np.arange(n) + 1)
    q = np.minimum.accumulate(q[::-1])[::-1]
    q = np.clip(q, 0, 1)
    tmp = np.empty(n)
    tmp[order] = q
    out[valid] = tmp
    return out

def cohen_d(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    x = x[np.isfinite(x)]
    y = y[np.isfinite(y)]
    if len(x) < 2 or len(y) < 2:
        return np.nan
    vx = np.var(x, ddof=1)
    vy = np.var(y, ddof=1)
    pooled = np.sqrt(((len(x)-1)*vx + (len(y)-1)*vy) / max((len(x)+len(y)-2), 1))
    if pooled == 0 or not np.isfinite(pooled):
        return 0.0
    return float((np.mean(x) - np.mean(y)) / pooled)

def cliffs_delta(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    x = x[np.isfinite(x)]
    y = y[np.isfinite(y)]
    if len(x) == 0 or len(y) == 0:
        return np.nan
    try:
        U = mannwhitneyu(x, y, alternative="two-sided").statistic
        return float((2 * U) / (len(x) * len(y)) - 1)
    except Exception:
        return np.nan

def safe_spearman(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    ok = np.isfinite(x) & np.isfinite(y)
    if ok.sum() < 3:
        return np.nan, np.nan
    if np.nanstd(x[ok]) == 0 or np.nanstd(y[ok]) == 0:
        return np.nan, np.nan
    try:
        return spearmanr(x[ok], y[ok])
    except Exception:
        return np.nan, np.nan

def detect_sample_column(obs):
    preferred = [
        "donor", "donor_id", "Donor", "individual", "subject", "sample", "sample_id",
        "Sample", "orig.ident", "orig_ident", "library", "batch", "patient", "case",
        "specimen", "biosample", "mouse", "animal", "replicate", "sample_name"
    ]
    for col in preferred:
        if col in obs.columns:
            try:
                n = obs[col].nunique(dropna=True)
                if 2 <= n <= 500:
                    return col
            except Exception:
                pass
    for col in obs.columns:
        try:
            n = obs[col].nunique(dropna=True)
            if 2 <= n <= 500 and str(obs[col].dtype) in ["category", "object", "string"]:
                return col
        except Exception:
            continue
    return None

def detect_qc_columns(obs):
    possible = [
        "n_counts", "total_counts", "n_genes", "n_genes_by_counts",
        "pct_counts_mt", "percent_mito", "pct_mito"
    ]
    return [c for c in possible if c in obs.columns]


# =============================================================================
# ML ranking, memory-safe
# =============================================================================

def downsample_rows(high, low, max_cells=20000, seed=7):
    rng = np.random.default_rng(seed)
    high_idx = np.where(high)[0]
    low_idx = np.where(low)[0]

    if len(high_idx) + len(low_idx) <= max_cells:
        chosen = np.concatenate([high_idx, low_idx])
    else:
        half = max_cells // 2
        n_high = min(len(high_idx), half)
        n_low = min(len(low_idx), max_cells - n_high)
        if n_low > len(low_idx):
            n_low = len(low_idx)
            n_high = min(len(high_idx), max_cells - n_low)
        chosen = np.concatenate([
            rng.choice(high_idx, size=n_high, replace=False),
            rng.choice(low_idx, size=n_low, replace=False)
        ])
    chosen = np.sort(chosen)
    y = high[chosen].astype(int)
    return chosen, y

def ml_importance(adata, genes, high, low, use_raw=True, max_cells=20000):
    if not SKLEARN_OK:
        return {}, {}, np.nan, np.nan, 0

    rows, y = downsample_rows(high, low, max_cells=max_cells)
    if len(np.unique(y)) < 2 or min(np.bincount(y)) < 10:
        return {}, {}, np.nan, np.nan, len(rows)

    M, records, layer, cols = matrix_for_genes(adata, genes, use_raw=use_raw, rows=rows)
    if M is None or len(records) < 2:
        return {}, {}, np.nan, np.nan, len(rows)

    X = np.asarray(M, dtype=np.float32)
    X[~np.isfinite(X)] = 0.0
    try:
        X = StandardScaler().fit_transform(X)
    except Exception:
        pass

    display_genes = [r["display_gene"] for r in records]

    rf_imp = {}
    lasso_coef = {}
    rf_auc = np.nan
    lasso_auc = np.nan

    try:
        cv = StratifiedKFold(n_splits=3, shuffle=True, random_state=7)
        rf = RandomForestClassifier(
            n_estimators=300,
            random_state=7,
            class_weight="balanced",
            n_jobs=-1,
            min_samples_leaf=3
        )
        rf_auc = float(np.mean(cross_val_score(rf, X, y, cv=cv, scoring="roc_auc")))
        rf.fit(X, y)
        rf_imp = dict(zip(display_genes, rf.feature_importances_))
    except Exception:
        pass

    try:
        cv = StratifiedKFold(n_splits=3, shuffle=True, random_state=7)
        lr = LogisticRegression(
            penalty="l1",
            solver="liblinear",
            class_weight="balanced",
            random_state=7,
            max_iter=2000
        )
        lasso_auc = float(np.mean(cross_val_score(lr, X, y, cv=cv, scoring="roc_auc")))
        lr.fit(X, y)
        lasso_coef = dict(zip(display_genes, np.ravel(lr.coef_)))
    except Exception:
        pass

    return rf_imp, lasso_coef, rf_auc, lasso_auc, len(rows)


# =============================================================================
# Figures
# =============================================================================

def clean_label(x):
    return str(x).replace("_", " ")

def diverging_norm(values):
    vals = np.asarray(values, dtype=float)
    vals = vals[np.isfinite(vals)]
    if len(vals) == 0:
        return None
    vmax = max(abs(np.nanmin(vals)), abs(np.nanmax(vals)), 0.1)
    return TwoSlopeNorm(vmin=-vmax, vcenter=0.0, vmax=vmax)

def save_full_heatmap(comp_df, dataset, fig_dir, dpi=900):
    if comp_df.empty:
        return
    df = comp_df.copy()
    vals = df["cohen_d_high_minus_low"].values.reshape(-1, 1)
    norm = diverging_norm(vals)

    fig_h = max(7, 0.24 * df.shape[0] + 2.2)
    fig, ax = plt.subplots(figsize=(6.2, fig_h))
    im = ax.imshow(vals, aspect="auto", cmap="coolwarm", norm=norm)
    ax.set_yticks(np.arange(df.shape[0]))
    ax.set_yticklabels([clean_label(m) for m in df["module"]], fontsize=7)
    ax.set_xticks([0])
    ax.set_xticklabels(["Cohen's d\nZNF-high minus ZNF-low"], fontsize=9)
    ax.set_title(f"{dataset}: non-circular module effects", fontsize=11)
    for i, v in enumerate(df["cohen_d_high_minus_low"].values):
        if np.isfinite(v):
            ax.text(0, i, f"{v:.2f}", ha="center", va="center", fontsize=6)
    fig.colorbar(im, ax=ax, fraction=0.05, pad=0.03)
    fig.tight_layout()
    fig.savefig(fig_dir / f"{dataset}_clean_all_module_heatmap_900ppi.png", dpi=dpi)
    plt.close(fig)

def save_focused_bar(comp_df, dataset, fig_dir, dpi=900, top_k=15):
    if comp_df.empty:
        return
    df = comp_df.copy()
    df["abs_effect"] = df["cohen_d_high_minus_low"].abs()
    df = df.sort_values("abs_effect", ascending=False).head(top_k)
    df = df.sort_values("cohen_d_high_minus_low", ascending=True)

    fig_h = max(4.8, 0.34 * df.shape[0] + 1.6)
    fig, ax = plt.subplots(figsize=(8.2, fig_h))
    ax.barh(np.arange(df.shape[0]), df["cohen_d_high_minus_low"].values)
    ax.axvline(0, color="black", linewidth=0.8)
    ax.set_yticks(np.arange(df.shape[0]))
    ax.set_yticklabels([clean_label(m) for m in df["module"]], fontsize=8)
    ax.set_xlabel("Cohen's d: ZNF-high minus ZNF-low")
    ax.set_title(f"{dataset}: top non-circular module shifts", fontsize=11)
    fig.tight_layout()
    fig.savefig(fig_dir / f"{dataset}_clean_top_module_bar_900ppi.png", dpi=dpi)
    plt.close(fig)

def save_candidate_plot(top_df, dataset, fig_dir, dpi=900, max_genes=30):
    df = top_df[top_df["dataset"] == dataset].copy()
    if df.empty:
        return
    df["label"] = df["gene_display"].astype(str) + " | " + df["module"].map(clean_label)
    df = df.sort_values("candidate_score_abs", ascending=True).tail(max_genes)

    fig_h = max(5, 0.29 * df.shape[0] + 1.6)
    fig, ax = plt.subplots(figsize=(9, fig_h))
    ax.barh(np.arange(df.shape[0]), df["candidate_score_abs"].values)
    ax.set_yticks(np.arange(df.shape[0]))
    ax.set_yticklabels(df["label"].values, fontsize=7)
    ax.set_xlabel("Composite candidate score, target gene excluded")
    ax.set_title(f"{dataset}: top non-target candidate genes", fontsize=11)
    fig.tight_layout()
    fig.savefig(fig_dir / f"{dataset}_clean_top_candidate_genes_900ppi.png", dpi=dpi)
    plt.close(fig)

def save_cross_dataset_heatmap(comp_df, fig_dir, dpi=900):
    if comp_df.empty:
        return
    piv = comp_df.pivot_table(
        index="module", columns="dataset", values="cohen_d_high_minus_low", aggfunc="mean"
    )
    # Order modules by mean absolute effect.
    order = piv.abs().mean(axis=1).sort_values(ascending=False).index
    piv = piv.loc[order]
    vals = piv.values
    norm = diverging_norm(vals)

    fig_h = max(8, 0.26 * piv.shape[0] + 2.2)
    fig_w = max(7, 1.25 * piv.shape[1] + 3)
    fig, ax = plt.subplots(figsize=(fig_w, fig_h))
    im = ax.imshow(vals, aspect="auto", cmap="coolwarm", norm=norm)
    ax.set_yticks(np.arange(piv.shape[0]))
    ax.set_yticklabels([clean_label(m) for m in piv.index], fontsize=7)
    ax.set_xticks(np.arange(piv.shape[1]))
    ax.set_xticklabels(piv.columns, rotation=45, ha="right", fontsize=8)
    ax.set_title("Cross-dataset non-circular ZNF335/Zfp335 module effects", fontsize=11)
    fig.colorbar(im, ax=ax, fraction=0.03, pad=0.02)
    fig.tight_layout()
    fig.savefig(fig_dir / "ALL_DATASETS_clean_non_circular_module_heatmap_900ppi.png", dpi=dpi)
    plt.close(fig)

def save_sample_correlation_heatmap(sample_df, fig_dir, dpi=900):
    if sample_df.empty:
        return
    piv = sample_df.pivot_table(
        index="module", columns="dataset", values="sample_level_spearman_rho", aggfunc="mean"
    )
    order = piv.abs().mean(axis=1).sort_values(ascending=False).index
    piv = piv.loc[order]
    vals = piv.values
    norm = diverging_norm(vals)

    fig_h = max(8, 0.26 * piv.shape[0] + 2.2)
    fig_w = max(7, 1.25 * piv.shape[1] + 3)
    fig, ax = plt.subplots(figsize=(fig_w, fig_h))
    im = ax.imshow(vals, aspect="auto", cmap="coolwarm", norm=norm)
    ax.set_yticks(np.arange(piv.shape[0]))
    ax.set_yticklabels([clean_label(m) for m in piv.index], fontsize=7)
    ax.set_xticks(np.arange(piv.shape[1]))
    ax.set_xticklabels(piv.columns, rotation=45, ha="right", fontsize=8)
    ax.set_title("Sample/donor-level ZNF335/Zfp335 module correlations", fontsize=11)
    fig.colorbar(im, ax=ax, fraction=0.03, pad=0.02)
    fig.tight_layout()
    fig.savefig(fig_dir / "ALL_DATASETS_sample_level_module_correlation_heatmap_900ppi.png", dpi=dpi)
    plt.close(fig)


# =============================================================================
# Main processing
# =============================================================================

def process_dataset(row, args, run_dir, fig_dir, log):
    dataset_label = safe_name(row["dataset_label"])
    path = Path(row["path"])

    log(f"Reading {dataset_label}: {path}")
    if not path.exists():
        log(f"SKIPPED missing file: {path}")
        return {"object": {"dataset": dataset_label, "path": str(path), "status": "missing"}}

    try:
        adata = read_h5ad_robust(path, log, copy_to_temp=args.copy_to_temp, temp_dir=run_dir / "_temp_read")
    except Exception as e:
        log(f"SKIPPED unreadable file: {path}")
        log(f"Reason: {repr(e)}")
        return {"object": {"dataset": dataset_label, "path": str(path), "status": "unreadable", "error": repr(e)}}

    original_n = int(adata.n_obs)

    try:
        adata, filter_note, microglia_confirmed = maybe_filter_microglia(adata, disable=args.no_filter_microglia)
    except Exception as e:
        filter_note = f"filter_failed_assumed_all_cells: {repr(e)}"
        microglia_confirmed = False

    log(f"{dataset_label}: n_obs {original_n} -> {adata.n_obs}; filter: {filter_note}")

    if int(adata.n_obs) < args.min_cells:
        log(f"{dataset_label}: skipped, too few cells.")
        return {"object": {"dataset": dataset_label, "path": str(path), "status": "too_few_cells", "n_obs_after_filter": int(adata.n_obs)}}

    znf_query, znf_rec, znf_vec, znf_layer, symbol_cols = choose_znf(adata, use_raw=not args.no_raw)
    if znf_vec is None:
        log(f"{dataset_label}: skipped, ZNF335/Zfp335 not found. Symbol columns checked: {symbol_cols}")
        return {
            "object": {
                "dataset": dataset_label, "path": str(path), "status": "no_znf",
                "n_obs_after_filter": int(adata.n_obs),
                "symbol_columns_checked": ";".join(map(str, symbol_cols))
            }
        }

    high, low, det, group_method = define_groups(
        znf_vec, min_group=args.min_group, high_q=args.high_quantile, low_q=args.low_quantile
    )
    log(f"{dataset_label}: ZNF gene={znf_rec['display_gene']} var={znf_rec['var_name']}; detection={det:.4f}; high={high.sum()}; low={low.sum()}; method={group_method}")

    # QC columns and sample column.
    sample_col = detect_sample_column(adata.obs)
    qc_cols = detect_qc_columns(adata.obs)

    # Module scoring.
    module_scores = {}
    presence_rows = []
    for module, genes in MODULES.items():
        score, records, layer, cols = score_module(adata, genes, use_raw=not args.no_raw)
        module_scores[module] = score
        found_display = [r["display_gene"] for r in records]
        found_var = [r["var_name"] for r in records]
        found_set = set(found_display)
        missing = [g for g in genes if str(g).upper() not in found_set]
        presence_rows.append({
            "dataset": dataset_label,
            "path": str(path),
            "module": module,
            "n_input_genes": len(genes),
            "n_found_genes": len(records),
            "found_gene_symbols_for_display": ";".join(found_display),
            "found_var_names": ";".join(found_var),
            "missing_genes": ";".join(missing),
            "expression_layer": layer,
            "symbol_columns_used": ";".join(map(str, cols)),
        })

    score_df = pd.DataFrame(module_scores, index=adata.obs_names)
    score_df["ZNF_expression"] = znf_vec
    score_df["ZNF_group"] = "middle"
    score_df.loc[high, "ZNF_group"] = "ZNF_high"
    score_df.loc[low, "ZNF_group"] = "ZNF_low"

    # Cell-level comparisons.
    comp_rows = []
    for module in MODULES:
        x = score_df.loc[high, module].values
        y = score_df.loc[low, module].values
        try:
            p = mannwhitneyu(x[np.isfinite(x)], y[np.isfinite(y)], alternative="two-sided").pvalue
        except Exception:
            p = np.nan
        rho, rp = safe_spearman(znf_vec, score_df[module].values)
        d = cohen_d(x, y)
        comp_rows.append({
            "dataset": dataset_label,
            "path": str(path),
            "module": module,
            "ZNF_gene_display": znf_rec["display_gene"],
            "ZNF_var_name": znf_rec["var_name"],
            "ZNF_detection_fraction": det,
            "group_method": group_method,
            "n_cells": int(adata.n_obs),
            "n_ZNF_high": int(high.sum()),
            "n_ZNF_low": int(low.sum()),
            "mean_ZNF_high": float(np.nanmean(x)),
            "mean_ZNF_low": float(np.nanmean(y)),
            "mean_difference_high_minus_low": float(np.nanmean(x) - np.nanmean(y)),
            "cohen_d_high_minus_low": d,
            "cliffs_delta_high_vs_low": cliffs_delta(x, y),
            "mannwhitney_p": p,
            "spearman_ZNF_vs_module_rho": rho,
            "spearman_ZNF_vs_module_p": rp,
            "direction": "higher_in_ZNF_high" if np.isfinite(d) and d > 0 else ("lower_in_ZNF_high_inverse" if np.isfinite(d) and d < 0 else "not_available"),
        })

    comp_df = pd.DataFrame(comp_rows)
    if not comp_df.empty:
        comp_df["mannwhitney_fdr_within_dataset"] = bh_fdr(comp_df["mannwhitney_p"].values)
        comp_df["spearman_fdr_within_dataset"] = bh_fdr(comp_df["spearman_ZNF_vs_module_p"].values)

    # Sample-level pseudobulk correlations.
    sample_rows = []
    pseudobulk_df = pd.DataFrame()
    if sample_col is not None:
        tmp = score_df.copy()
        tmp[sample_col] = adata.obs[sample_col].astype(str).values
        # Include QC means if present.
        for q in qc_cols:
            try:
                tmp[q] = pd.to_numeric(adata.obs[q].values, errors="coerce")
            except Exception:
                pass
        mean_cols = ["ZNF_expression"] + list(MODULES.keys()) + [q for q in qc_cols if q in tmp.columns]
        pseudobulk_df = tmp.groupby(sample_col)[mean_cols].mean().reset_index().rename(columns={sample_col: "sample_id"})
        pseudobulk_df.insert(0, "dataset", dataset_label)

        for module in MODULES:
            rho, p = safe_spearman(pseudobulk_df["ZNF_expression"].values, pseudobulk_df[module].values)
            sample_rows.append({
                "dataset": dataset_label,
                "path": str(path),
                "sample_column": sample_col,
                "n_samples": int(pseudobulk_df.shape[0]),
                "module": module,
                "sample_level_spearman_rho": rho,
                "sample_level_spearman_p": p,
                "sample_level_direction": "positive" if np.isfinite(rho) and rho > 0 else ("inverse" if np.isfinite(rho) and rho < 0 else "not_available"),
            })

    sample_df = pd.DataFrame(sample_rows)
    if not sample_df.empty:
        sample_df["sample_level_fdr_within_dataset"] = bh_fdr(sample_df["sample_level_spearman_p"].values)

    # Gene ranking, target excluded.
    all_genes = sorted(set([g for genes in MODULES.values() for g in genes]))
    all_genes = [g for g in all_genes if normalize_symbol(g) not in ZNF_CANONICAL]

    rf_all, lasso_all, rf_auc_all, lasso_auc_all, ml_n = ml_importance(
        adata, all_genes, high, low, use_raw=not args.no_raw, max_cells=args.max_ml_cells
    )

    gene_rows = []
    for module, genes in MODULES.items():
        module_genes = [g for g in genes if normalize_symbol(g) not in ZNF_CANONICAL]
        rf_mod, lasso_mod, rf_auc_mod, lasso_auc_mod, ml_n_mod = ml_importance(
            adata, module_genes, high, low, use_raw=not args.no_raw, max_cells=args.max_ml_cells
        )
        M, records, layer, cols = matrix_for_genes(adata, module_genes, use_raw=not args.no_raw)
        if M is None:
            continue

        for j, rec in enumerate(records):
            gene_disp = rec["display_gene"]
            if normalize_symbol(gene_disp) in ZNF_CANONICAL or normalize_symbol(rec["var_name"]) in ZNF_ENSEMBL_HINTS:
                continue

            gv = M[:, j]
            x = gv[high]
            y = gv[low]
            try:
                p = mannwhitneyu(x[np.isfinite(x)], y[np.isfinite(y)], alternative="two-sided").pvalue
            except Exception:
                p = np.nan
            rho, rp = safe_spearman(znf_vec, gv)
            d = cohen_d(x, y)

            imp = max(float(rf_all.get(gene_disp, 0.0)), float(rf_mod.get(gene_disp, 0.0)))
            coef = lasso_mod.get(gene_disp, lasso_all.get(gene_disp, 0.0))

            gene_rows.append({
                "dataset": dataset_label,
                "path": str(path),
                "module": module,
                "gene_display": gene_disp,
                "gene_var_name": rec["var_name"],
                "gene_symbol_source": rec["symbol_source"],
                "ZNF_gene_display": znf_rec["display_gene"],
                "n_ZNF_high": int(high.sum()),
                "n_ZNF_low": int(low.sum()),
                "mean_ZNF_high": float(np.nanmean(x)),
                "mean_ZNF_low": float(np.nanmean(y)),
                "mean_difference_high_minus_low": float(np.nanmean(x) - np.nanmean(y)),
                "cohen_d_high_minus_low": d,
                "cliffs_delta_high_vs_low": cliffs_delta(x, y),
                "detection_ZNF_high": float(np.mean(x > 0)) if len(x) else np.nan,
                "detection_ZNF_low": float(np.mean(y > 0)) if len(y) else np.nan,
                "mannwhitney_p": p,
                "spearman_ZNF_vs_gene_rho": rho,
                "spearman_ZNF_vs_gene_p": rp,
                "RF_importance": imp,
                "LASSO_logistic_coef": coef,
                "RF_AUC_module": rf_auc_mod,
                "RF_AUC_all_genes": rf_auc_all,
                "LASSO_AUC_module": lasso_auc_mod,
                "LASSO_AUC_all_genes": lasso_auc_all,
                "ML_cells_used": ml_n,
                "direction": "higher_in_ZNF_high" if np.isfinite(d) and d > 0 else ("lower_in_ZNF_high_inverse" if np.isfinite(d) and d < 0 else "not_available"),
            })

    gene_df = pd.DataFrame(gene_rows)
    if not gene_df.empty:
        gene_df["mannwhitney_fdr_within_dataset"] = bh_fdr(gene_df["mannwhitney_p"].values)
        gene_df["spearman_fdr_within_dataset"] = bh_fdr(gene_df["spearman_ZNF_vs_gene_p"].values)

        for col in ["cohen_d_high_minus_low", "spearman_ZNF_vs_gene_rho", "RF_importance", "LASSO_logistic_coef"]:
            vals = pd.to_numeric(gene_df[col], errors="coerce").values
            med = np.nanmedian(vals)
            mad = np.nanmedian(np.abs(vals - med))
            if not np.isfinite(mad) or mad == 0:
                mad = np.nanstd(vals)
            if not np.isfinite(mad) or mad == 0:
                scaled = np.abs(vals)
            else:
                scaled = np.abs((vals - med) / mad)
            gene_df[col + "_abs_scaled"] = scaled

        gene_df["candidate_score_abs"] = (
            gene_df["cohen_d_high_minus_low_abs_scaled"].fillna(0)
            + gene_df["spearman_ZNF_vs_gene_rho_abs_scaled"].fillna(0)
            + gene_df["RF_importance_abs_scaled"].fillna(0)
            + gene_df["LASSO_logistic_coef_abs_scaled"].fillna(0)
        )

    # Figures for this dataset.
    try:
        save_full_heatmap(comp_df, dataset_label, fig_dir, dpi=args.dpi)
        save_focused_bar(comp_df, dataset_label, fig_dir, dpi=args.dpi, top_k=args.figure_top_modules)
    except Exception as e:
        log(f"{dataset_label}: figure generation failed: {repr(e)}")

    warning = ""
    if not microglia_confirmed and int(adata.n_obs) > args.large_unconfirmed_warning:
        warning = "WARNING: microglia-only status not confirmed by metadata; high cell count suggests checking this object before manuscript interpretation."

    obj_summary = {
        "dataset": dataset_label,
        "path": str(path),
        "status": "processed",
        "species": row.get("species", "unknown"),
        "note": row.get("note", ""),
        "n_obs_original": original_n,
        "n_obs_after_filter": int(adata.n_obs),
        "n_vars": int(adata.n_vars),
        "microglia_filter_note": filter_note,
        "microglia_filter_confirmed": microglia_confirmed,
        "microglia_warning": warning,
        "ZNF_gene_display": znf_rec["display_gene"],
        "ZNF_var_name": znf_rec["var_name"],
        "ZNF_detection_fraction": det,
        "n_ZNF_high": int(high.sum()),
        "n_ZNF_low": int(low.sum()),
        "group_method": group_method,
        "sample_column_detected": sample_col,
        "qc_columns_detected": ";".join(qc_cols),
        "symbol_columns_checked": ";".join(map(str, symbol_cols)),
        "ZNF_expression_layer": znf_layer,
        "ML_max_cells": args.max_ml_cells,
    }

    if warning:
        log(f"{dataset_label}: {warning}")

    try:
        del adata
        gc.collect()
    except Exception:
        pass

    return {
        "object": obj_summary,
        "presence": pd.DataFrame(presence_rows),
        "cell_comp": comp_df,
        "sample_corr": sample_df,
        "pseudobulk": pseudobulk_df,
        "gene_rank": gene_df,
    }


# =============================================================================
# Output
# =============================================================================

def top_candidates(gene_df, n=2):
    if gene_df.empty:
        return pd.DataFrame()
    rows = []
    for (dataset, module), sub in gene_df.groupby(["dataset", "module"], dropna=False):
        sub = sub.sort_values("candidate_score_abs", ascending=False)
        rows.append(sub.head(n))
    return pd.concat(rows, ignore_index=True) if rows else pd.DataFrame()

def module_priority_summary(comp_df, sample_df):
    if comp_df.empty:
        return pd.DataFrame()
    rows = []
    for module, sub in comp_df.groupby("module"):
        effects = pd.to_numeric(sub["cohen_d_high_minus_low"], errors="coerce")
        rhos = pd.to_numeric(sub["spearman_ZNF_vs_module_rho"], errors="coerce")
        ssub = sample_df[sample_df["module"] == module] if not sample_df.empty else pd.DataFrame()
        srhos = pd.to_numeric(ssub["sample_level_spearman_rho"], errors="coerce") if not ssub.empty else pd.Series(dtype=float)
        rows.append({
            "module": module,
            "n_datasets_cell_level": sub["dataset"].nunique(),
            "mean_cell_cohen_d": float(np.nanmean(effects)),
            "mean_abs_cell_cohen_d": float(np.nanmean(np.abs(effects))),
            "positive_cell_effect_fraction": float(np.nanmean(effects > 0)),
            "inverse_cell_effect_fraction": float(np.nanmean(effects < 0)),
            "mean_cell_spearman_rho": float(np.nanmean(rhos)),
            "mean_abs_cell_spearman_rho": float(np.nanmean(np.abs(rhos))),
            "n_datasets_sample_level": ssub["dataset"].nunique() if not ssub.empty else 0,
            "mean_sample_spearman_rho": float(np.nanmean(srhos)) if len(srhos) else np.nan,
            "mean_abs_sample_spearman_rho": float(np.nanmean(np.abs(srhos))) if len(srhos) else np.nan,
        })
    out = pd.DataFrame(rows)
    if out.empty:
        return out
    out["priority_score"] = (
        out["mean_abs_cell_cohen_d"].fillna(0)
        + out["mean_abs_cell_spearman_rho"].fillna(0)
        + out["mean_abs_sample_spearman_rho"].fillna(0)
        + out["n_datasets_cell_level"].fillna(0) / max(out["n_datasets_cell_level"].max(), 1)
    )
    return out.sort_values("priority_score", ascending=False)

def write_csv(df, path):
    if df is None:
        return
    df.to_csv(path, index=False)

def write_excel(tables, path, log):
    try:
        with pd.ExcelWriter(path, engine="openpyxl") as writer:
            for sheet, df in tables.items():
                name = safe_name(sheet, 31)
                if df is None or df.empty:
                    pd.DataFrame({"note": ["No rows produced."]}).to_excel(writer, sheet_name=name, index=False)
                else:
                    df.to_excel(writer, sheet_name=name, index=False)
    except Exception as e:
        log(f"Excel writing failed: {repr(e)}")
        fallback = Path(path).with_suffix("")
        fallback.mkdir(parents=True, exist_ok=True)
        for sheet, df in tables.items():
            if df is not None and not df.empty:
                write_csv(df, fallback / f"{safe_name(sheet)}.csv")

def main():
    parser = argparse.ArgumentParser(description="Clean final ZNF335/Zfp335 module analysis V3")
    parser.add_argument("--root", default=r"F:\AD\Mam San")
    parser.add_argument("--out_base", default=None)
    parser.add_argument("--final_manifest", action="store_true", help="Use clean default four-dataset manifest. Recommended.")
    parser.add_argument("--recursive", action="store_true", help="Scan recursively. Not recommended for final manuscript analysis.")
    parser.add_argument("--manifest_csv", default=None, help="Optional custom manifest with columns dataset_label,path,species,note.")
    parser.add_argument("--copy_to_temp", action="store_true")
    parser.add_argument("--no_raw", action="store_true")
    parser.add_argument("--no_filter_microglia", action="store_true")
    parser.add_argument("--min_cells", type=int, default=100)
    parser.add_argument("--min_group", type=int, default=25)
    parser.add_argument("--high_quantile", type=float, default=0.75)
    parser.add_argument("--low_quantile", type=float, default=0.25)
    parser.add_argument("--top_n", type=int, default=2)
    parser.add_argument("--max_ml_cells", type=int, default=20000)
    parser.add_argument("--dpi", type=int, default=900)
    parser.add_argument("--figure_top_modules", type=int, default=15)
    parser.add_argument("--large_unconfirmed_warning", type=int, default=30000)
    args = parser.parse_args()

    root = Path(args.root)
    out_base = Path(args.out_base) if args.out_base else root / "results" / "ZNF335_clean_final_900ppi"
    run_dir = out_base / f"run_{stamp()}"
    fig_dir = run_dir / "figures_900ppi_clean"
    run_dir.mkdir(parents=True, exist_ok=True)
    fig_dir.mkdir(parents=True, exist_ok=True)

    log = make_logger(run_dir / "00_run_log.txt")
    log("Starting ZNF335/Zfp335 CLEAN FINAL analysis V3")
    log(f"Root: {root}")
    log(f"Run directory: {run_dir}")
    log(f"Python: {sys.version}")
    log(f"anndata_scanpy_available: {ANNDATA_OK}")
    log(f"sklearn_available: {SKLEARN_OK}")
    log("Circular TF_ZNF335_context module removed.")
    log("ZNF335/Zfp335 excluded from candidate ranking.")

    if args.manifest_csv:
        manifest = pd.read_csv(args.manifest_csv)
        if "exists" not in manifest.columns:
            manifest["exists"] = manifest["path"].apply(lambda p: Path(p).exists())
    elif args.recursive and not args.final_manifest:
        manifest = find_recursive_files(root)
    else:
        manifest = default_final_manifest(root)

    manifest.to_csv(run_dir / "01_manifest_used.csv", index=False)
    log(f"Manifest contains {manifest.shape[0]} file(s).")

    all_objects = []
    all_presence = []
    all_cell = []
    all_sample = []
    all_pseudo = []
    all_gene = []

    for _, row in manifest.iterrows():
        try:
            res = process_dataset(row, args, run_dir, fig_dir, log)
        except Exception as e:
            log(f"UNEXPECTED ERROR for {row.get('path','unknown')}: {repr(e)}")
            log(traceback.format_exc())
            res = {"object": {"dataset": row.get("dataset_label", "unknown"), "path": row.get("path", ""), "status": "unexpected_error", "error": repr(e)}}

        all_objects.append(res.get("object", {}))
        for key, bucket in [
            ("presence", all_presence),
            ("cell_comp", all_cell),
            ("sample_corr", all_sample),
            ("pseudobulk", all_pseudo),
            ("gene_rank", all_gene),
        ]:
            df = res.get(key, pd.DataFrame())
            if isinstance(df, pd.DataFrame) and not df.empty:
                bucket.append(df)

    objects_df = pd.DataFrame(all_objects)
    presence_df = pd.concat(all_presence, ignore_index=True) if all_presence else pd.DataFrame()
    cell_df = pd.concat(all_cell, ignore_index=True) if all_cell else pd.DataFrame()
    sample_df = pd.concat(all_sample, ignore_index=True) if all_sample else pd.DataFrame()
    pseudo_df = pd.concat(all_pseudo, ignore_index=True) if all_pseudo else pd.DataFrame()
    gene_df = pd.concat(all_gene, ignore_index=True) if all_gene else pd.DataFrame()
    top_df = top_candidates(gene_df, n=args.top_n)
    priority_df = module_priority_summary(cell_df, sample_df)

    # Write outputs.
    write_csv(objects_df, run_dir / "02_processed_objects_summary.csv")
    write_csv(presence_df, run_dir / "03_module_gene_presence.csv")
    write_csv(cell_df, run_dir / "04_cell_level_module_comparisons_non_circular.csv")
    write_csv(sample_df, run_dir / "05_sample_level_module_correlations.csv")
    write_csv(pseudo_df, run_dir / "06_pseudobulk_module_scores_by_sample.csv")
    write_csv(gene_df, run_dir / "07_gene_level_candidate_ranking_target_excluded.csv")
    write_csv(top_df, run_dir / "08_top_1to2_candidates_per_module_target_excluded.csv")
    write_csv(priority_df, run_dir / "09_module_priority_summary.csv")

    write_excel(
        {
            "processed_objects": objects_df,
            "module_gene_presence": presence_df,
            "cell_module_comparisons": cell_df,
            "sample_module_correlations": sample_df,
            "pseudobulk_scores": pseudo_df,
            "gene_candidate_ranking": gene_df,
            "top_candidates": top_df,
            "module_priority_summary": priority_df,
        },
        run_dir / "ZNF335_clean_final_results.xlsx",
        log
    )

    # Combined figures.
    try:
        save_cross_dataset_heatmap(cell_df, fig_dir, dpi=args.dpi)
        save_sample_correlation_heatmap(sample_df, fig_dir, dpi=args.dpi)
        if not top_df.empty:
            for ds in sorted(top_df["dataset"].dropna().unique()):
                save_candidate_plot(top_df, ds, fig_dir, dpi=args.dpi, max_genes=30)
    except Exception as e:
        log(f"Final figure generation failed: {repr(e)}")

    # Interpretation guide.
    guide = run_dir / "INTERPRETATION_GUIDE_CLEAN_FINAL.txt"
    with open(guide, "w", encoding="utf-8") as f:
        f.write(
            "ZNF335/Zfp335 clean final interpretation guide\n"
            "=============================================\n\n"
            "Key corrections in V3:\n"
            "1. TF_ZNF335_context removed to avoid circular scoring.\n"
            "2. ZNF335/Zfp335 excluded from candidate ranking.\n"
            "3. One Olah object is used by default.\n"
            "4. Gene labels use query gene symbols when Ensembl var_names are present.\n"
            "5. Memory-safe ML uses a capped subset of high/low cells.\n\n"
            "How to interpret direction:\n"
            "- Positive Cohen's d: module/gene higher in ZNF335/Zfp335-high cells.\n"
            "- Negative Cohen's d: module/gene lower in ZNF335/Zfp335-high cells; possible inverse coupling.\n\n"
            "Most reliable layer:\n"
            "- Prefer sample_level_module_correlations over raw cell-level results for manuscript claims.\n"
            "- Cell-level results are useful for screening but can be biased by TF detection, RNA content, and batch.\n\n"
            "Microglia warning:\n"
            "- If processed_objects shows a microglia warning, confirm that the file is microglia-only before interpreting biology.\n\n"
            "Experimental shortlist:\n"
            "- Use top_candidates together with module_priority_summary.\n"
            "- Choose 1-2 genes per biologically prioritized module, not all genes.\n"
        )

    log("Finished CLEAN FINAL analysis.")
    log(f"Main workbook: {run_dir / 'ZNF335_clean_final_results.xlsx'}")
    log(f"Clean 900 ppi figures: {fig_dir}")
    log(f"Top candidates: {run_dir / '08_top_1to2_candidates_per_module_target_excluded.csv'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
