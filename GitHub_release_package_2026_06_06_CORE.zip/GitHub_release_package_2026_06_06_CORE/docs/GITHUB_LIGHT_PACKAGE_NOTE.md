# GitHub light package

Generated: 2026-06-06 20:57:59

This is the GitHub-friendly version of the reproducibility package. It keeps all scripts, compact source tables, manifests, requirements, reference exports, and documentation.

Large binary files and large CSVs are listed in `docs/LARGE_FILES_NOT_INCLUDED_IN_LIGHT_PACKAGE.csv`. Put those files in Zenodo/OSF/Figshare or attach them as GitHub release assets. Do not commit them directly unless using Git LFS.

Full local package:
`F:\AD\Mam San\results\Sand_regulatory_program_manuscript_package_final_v2\Final\GitHub_release_package_2026_06_06`

Excluded file threshold:
`>10 MB`, plus large manuscript/figure binaries over 5 MB.
