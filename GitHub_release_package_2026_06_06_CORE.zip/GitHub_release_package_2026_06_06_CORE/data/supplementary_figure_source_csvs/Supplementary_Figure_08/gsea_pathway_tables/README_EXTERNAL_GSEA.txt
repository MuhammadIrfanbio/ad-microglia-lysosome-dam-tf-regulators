External Enrichr preranked GSEA outputs
======================================

Main outputs:
- tables/gsea_prerank_external_all_libraries.csv
- tables/gsea_focus_terms_lysosome_dam_inflammation.csv
- figures/top_terms_<library>_900dpi.png
- tables/overlap_summary_<library>.csv

This script uppercases genes before matching to external human-style Enrichr libraries.
