#!/usr/bin/env python3
"""
Extract panel-ready CSV source data for Figure 4:
Mouse conservation and Trem2-dependent remodeling of disease-associated microglia.

This script reads the latest fixed mouse microglia objects in F:\\AD\\Mam San and
writes one or more exact CSVs for each panel A-G. It does not draw the figure;
it creates clean source tables for a later 900 ppi/vector figure script.

Outputs:
  results/publication_figures/figure4_mouse_conservation_source_data/

Run:
  C:\\ProgramData\\miniforge3\\python.exe extract_figure4_mouse_conservation_panel_csvs.py
"""

from __future__ import annotations

import gzip
import io
import json
import re
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd
from scipy import sparse, stats

try:
    import anndata as ad
except ImportError as exc:  # pragma: no cover
    raise SystemExit(
        "This script needs anndata/h5py. Use C:\\ProgramData\\miniforge3\\python.exe."
    ) from exc


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results" / "publication_figures" / "figure4_mouse_conservation_source_data"
OUT.mkdir(parents=True, exist_ok=True)

GSE98969_H5AD = (
    ROOT
    / "results"
    / "gse98969_microglia_fixed"
    / "objects"
    / "gse98969_microglia_fixed_microglia_final.h5ad"
)
GSE140510_H5AD = (
    ROOT
    / "results"
    / "gse140510_mouse_microglia_fixed"
    / "objects"
    / "gse140510_mouse_microglia_fixed_microglia_final.h5ad"
)
GSE98969_DESIGN = (
    ROOT
    / "gse98969_work_fixed"
    / "downloads"
    / "GSE98969_experimental_design_f.txt.gz"
)
FIG2_PALETTE = (
    ROOT
    / "results"
    / "publication_figures"
    / "figure2_seaad_discovery_source_data"
    / "state_palette_used_across_figures.csv"
)

STATE_ORDER = [
    "homeostatic_like",
    "transitional_like",
    "lysosome_high",
    "dam_like",
    "interferon_like",
    "proliferative_like",
]

STATE_LABEL = {
    "homeostatic_like": "Homeostatic-like",
    "transitional_like": "Transitional-like",
    "lysosome_high": "Lysosome-high",
    "dam_like": "DAM/phagocytic-like",
    "interferon_like": "Interferon-like",
    "proliferative_like": "Proliferative-like",
}

GROUP_ORDER_140510 = ["WT", "5xFAD", "Trem2_KO", "Trem2_KO_5xFAD"]
GROUP_ORDER_98969 = ["WT", "5xFAD"]

GROUP_COLORS = {
    "WT": "#B9BDC6",
    "5xFAD": "#C92525",
    "Trem2_KO": "#2166AC",
    "Trem2_KO_5xFAD": "#6A3D9A",
}

MODULES_CORE = [
    ("homeostatic_score", "Homeostatic score"),
    ("lysosome_score", "Lysosome score"),
    ("dam_phagocytic_score", "DAM/phagocytosis score"),
]

MODULES_CONTRAST = [
    ("homeostatic_score", "Homeostatic score"),
    ("lysosome_score", "Lysosome score"),
    ("dam_phagocytic_score", "DAM/phagocytosis score"),
    ("lipid_score", "Lipid score"),
    ("interferon_score", "Interferon score"),
    ("proliferative_score", "Proliferative score"),
]

LIPID_GENES = ["Apoe", "Trem2", "Tyrobp", "Lpl", "Cst7", "Itgax", "Axl", "Gpnmb"]

PANELF_GENE_GROUPS = [
    ("Homeostatic signature", ["P2ry12", "Tmem119", "Cx3cr1", "Csf1r"]),
    ("DAM/phagocytic signature", ["Apoe", "Trem2", "Tyrobp", "Axl", "Itgax", "Gpnmb", "Lpl"]),
    ("Lysosomal/phagocytic signature", ["Ctsb", "Ctsd", "Ctsl", "Lamp1", "Lamp2", "Cd68", "Cst7"]),
    ("Candidate upstream genes", ["Bace1", "Zfp335"]),
]


def require_file(path: Path) -> None:
    if not path.exists():
        raise FileNotFoundError(path)


def dense(X) -> np.ndarray:
    if sparse.issparse(X):
        return X.toarray()
    return np.asarray(X)


def zscore_series(x: pd.Series) -> pd.Series:
    x = pd.to_numeric(x, errors="coerce").astype(float)
    sd = x.std(ddof=0)
    if not np.isfinite(sd) or sd == 0:
        return pd.Series(np.zeros(len(x)), index=x.index)
    return (x - x.mean()) / sd


def zscore_matrix_by_row(mat: pd.DataFrame) -> pd.DataFrame:
    centered = mat.sub(mat.mean(axis=1), axis=0)
    sd = mat.std(axis=1, ddof=0).replace(0, np.nan)
    return centered.div(sd, axis=0).fillna(0.0)


def bh_adjust(pvals: Iterable[float]) -> np.ndarray:
    p = np.asarray(list(pvals), dtype=float)
    n = len(p)
    out = np.full(n, np.nan)
    finite = np.isfinite(p)
    if finite.sum() == 0:
        return out
    idx = np.where(finite)[0]
    order = idx[np.argsort(p[idx])]
    ranked = p[order]
    adj = np.empty(len(ranked), dtype=float)
    prev = 1.0
    for i in range(len(ranked) - 1, -1, -1):
        rank = i + 1
        prev = min(prev, ranked[i] * len(ranked) / rank)
        adj[i] = prev
    out[order] = np.minimum(adj, 1.0)
    return out


def hedges_g(x: Iterable[float], y: Iterable[float]) -> float:
    x = np.asarray(list(x), dtype=float)
    y = np.asarray(list(y), dtype=float)
    x = x[np.isfinite(x)]
    y = y[np.isfinite(y)]
    if len(x) < 2 or len(y) < 2:
        return np.nan
    vx = x.var(ddof=1)
    vy = y.var(ddof=1)
    pooled = np.sqrt(((len(x) - 1) * vx + (len(y) - 1) * vy) / (len(x) + len(y) - 2))
    if not np.isfinite(pooled) or pooled == 0:
        return np.nan
    d = (x.mean() - y.mean()) / pooled
    correction = 1 - (3 / (4 * (len(x) + len(y)) - 9))
    return float(d * correction)


def p_to_star(p: float) -> str:
    if not np.isfinite(p):
        return "NA"
    if p < 1e-4:
        return "****"
    if p < 1e-3:
        return "***"
    if p < 1e-2:
        return "**"
    if p < 5e-2:
        return "*"
    return "ns"


def read_gse98969_design() -> pd.DataFrame:
    require_file(GSE98969_DESIGN)
    lines = []
    found_header = False
    with gzip.open(GSE98969_DESIGN, "rt", encoding="utf-8", errors="replace") as handle:
        for line in handle:
            if line.startswith("Well_ID\tSeq_batch_ID"):
                found_header = True
            if found_header:
                lines.append(line)
    if not lines:
        raise ValueError(f"Could not find tabular header in {GSE98969_DESIGN}")
    design = pd.read_csv(io.StringIO("".join(lines)), sep="\t")
    design = design.rename(columns={"Amp_batch_ID": "amp_batch_id", "Well_ID": "cell_barcode"})
    design["gse98969_mouse_id"] = design["Mouse_ID"].astype(str)
    design["gse98969_batch_desc"] = design["Batch_desc"].astype(str)
    design["analysis_group"] = design["gse98969_mouse_id"].map(
        {
            "C57BL/6": "WT",
            "5XFAD": "5xFAD",
            "Trem2KO": "Trem2_KO",
            "Trem2KO_5XFAD": "Trem2_KO_5xFAD",
        }
    ).fillna("Other")
    keep = [
        "cell_barcode",
        "amp_batch_id",
        "analysis_group",
        "gse98969_mouse_id",
        "gse98969_batch_desc",
        "Number_of_cells",
    ]
    return design[keep].drop_duplicates("cell_barcode")


def infer_gse140510_group(sample_id: str) -> str:
    s = str(sample_id).upper()
    if "TREM2_KO_5XFAD" in s:
        return "Trem2_KO_5xFAD"
    if "5XFAD" in s:
        return "5xFAD"
    if "TREM2_KO" in s:
        return "Trem2_KO"
    if re.search(r"(^|_)WT(_|$)", s):
        return "WT"
    return "Unknown"


def load_state_palette() -> pd.DataFrame:
    if FIG2_PALETTE.exists():
        pal = pd.read_csv(FIG2_PALETTE)
        pal = pal.rename(columns={"state_hint": "state", "label": "state_label", "color_hex": "color_hex"})
        pal = pal[["state", "state_label", "color_hex"]]
    else:
        pal = pd.DataFrame(
            [
                ("homeostatic_like", "Homeostatic-like", "#006D77"),
                ("transitional_like", "Transitional-like", "#B8870B"),
                ("lysosome_high", "Lysosome-high", "#D95F02"),
                ("dam_like", "DAM/phagocytic-like", "#B22222"),
                ("interferon_like", "Interferon-like", "#542788"),
                ("proliferative_like", "Proliferative-like", "#B23A7A"),
            ],
            columns=["state", "state_label", "color_hex"],
        )
    pal["state_order"] = pal["state"].map({s: i for i, s in enumerate(STATE_ORDER)})
    pal.sort_values("state_order").to_csv(OUT / "figure4_state_palette_preserved_from_figure2.csv", index=False)
    pd.DataFrame(
        [{"analysis_group": g, "color_hex": GROUP_COLORS[g], "group_order": i} for i, g in enumerate(GROUP_ORDER_140510)]
    ).to_csv(OUT / "figure4_group_palette.csv", index=False)
    return pal


def add_lipid_score(adata: ad.AnnData, obs: pd.DataFrame) -> pd.DataFrame:
    present = [g for g in LIPID_GENES if g in adata.var_names]
    obs = obs.copy()
    if not present:
        obs["lipid_score"] = np.nan
        return obs
    expr = pd.DataFrame(dense(adata[:, present].X), index=adata.obs_names, columns=present)
    z = expr.apply(zscore_series, axis=0)
    obs["lipid_score"] = z.mean(axis=1).reindex(obs.index).values
    return obs


def write_umap_and_score_tables(
    adata: ad.AnnData,
    obs: pd.DataFrame,
    dataset: str,
    group_order: list[str],
    panel_umap_name: str,
    panel_scores_name: str | None = None,
    filter_groups: list[str] | None = None,
) -> pd.DataFrame:
    keep = np.ones(len(obs), dtype=bool)
    if filter_groups is not None:
        keep = obs["analysis_group"].isin(filter_groups).values
    coords = pd.DataFrame(adata.obsm["X_umap"], index=adata.obs_names, columns=["UMAP_1", "UMAP_2"])
    base = obs.loc[keep, ["sample_id", "analysis_group", "state_hint"]].copy()
    base.insert(0, "cell_id", base.index)
    base.insert(1, "dataset", dataset)
    base = base.join(coords, how="left")
    base["state_label"] = base["state_hint"].map(STATE_LABEL)
    base["state_order"] = base["state_hint"].map({s: i for i, s in enumerate(STATE_ORDER)})
    base["group_order"] = base["analysis_group"].map({g: i for i, g in enumerate(group_order)})
    base.sort_values(["group_order", "sample_id", "state_order", "cell_id"]).to_csv(OUT / panel_umap_name, index=False)
    if panel_scores_name is not None:
        score_cols = [c for c, _ in MODULES_CORE if c in obs.columns]
        score = base[["cell_id", "dataset", "sample_id", "analysis_group", "UMAP_1", "UMAP_2"]].merge(
            obs.loc[base["cell_id"], score_cols].reset_index(names="cell_id"),
            on="cell_id",
            how="left",
        )
        score.to_csv(OUT / panel_scores_name, index=False)
    return base


def write_gse140510_state_proportions(obs: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    counts = pd.crosstab(obs["sample_id"], obs["state_hint"])
    for state in STATE_ORDER:
        if state not in counts.columns:
            counts[state] = 0
    counts = counts[STATE_ORDER]
    props = counts.div(counts.sum(axis=1), axis=0).fillna(0.0)
    meta = (
        obs[["sample_id", "analysis_group"]]
        .drop_duplicates()
        .assign(group_order=lambda d: d["analysis_group"].map({g: i for i, g in enumerate(GROUP_ORDER_140510)}))
        .sort_values(["group_order", "sample_id"])
    )
    counts = counts.loc[meta["sample_id"]]
    props = props.loc[meta["sample_id"]]
    counts_out = counts.reset_index().merge(meta, on="sample_id", how="left")
    props_out = props.reset_index().merge(meta, on="sample_id", how="left")
    counts_out.to_csv(OUT / "panelD_gse140510_state_counts_by_sample_wide.csv", index=False)
    props_out.to_csv(OUT / "panelD_gse140510_state_proportions_by_sample_wide.csv", index=False)
    long = props_out.melt(
        id_vars=["sample_id", "analysis_group", "group_order"],
        value_vars=STATE_ORDER,
        var_name="state_hint",
        value_name="proportion",
    )
    long["state_label"] = long["state_hint"].map(STATE_LABEL)
    long["state_order"] = long["state_hint"].map({s: i for i, s in enumerate(STATE_ORDER)})
    long.sort_values(["group_order", "sample_id", "state_order"]).to_csv(
        OUT / "panelD_gse140510_state_proportions_by_sample_long.csv", index=False
    )
    return props, meta


def write_gse140510_group_state_stats(props: pd.DataFrame, meta: pd.DataFrame) -> None:
    long = (
        props.reset_index()
        .merge(meta, on="sample_id", how="left")
        .melt(
            id_vars=["sample_id", "analysis_group", "group_order"],
            value_vars=STATE_ORDER,
            var_name="state_hint",
            value_name="proportion",
        )
    )
    long["state_label"] = long["state_hint"].map(STATE_LABEL)
    long["state_order"] = long["state_hint"].map({s: i for i, s in enumerate(STATE_ORDER)})
    long.to_csv(OUT / "panelE_gse140510_state_proportions_by_group_long.csv", index=False)
    summary = (
        long.groupby(["analysis_group", "group_order", "state_hint", "state_label", "state_order"], observed=True)[
            "proportion"
        ]
        .agg(n_samples="count", mean="mean", median="median", sd="std")
        .reset_index()
    )
    summary["sem"] = summary["sd"] / np.sqrt(summary["n_samples"].clip(lower=1))
    summary.sort_values(["state_order", "group_order"]).to_csv(
        OUT / "panelE_gse140510_state_proportion_group_summary.csv", index=False
    )

    rows = []
    comparisons = [
        ("5xFAD", "WT"),
        ("Trem2_KO_5xFAD", "Trem2_KO"),
        ("Trem2_KO_5xFAD", "5xFAD"),
    ]
    for state in STATE_ORDER:
        sub = long[long["state_hint"] == state]
        group_values = [sub.loc[sub["analysis_group"] == g, "proportion"].values for g in GROUP_ORDER_140510]
        group_values = [x for x in group_values if len(x) > 0]
        if len(group_values) >= 2:
            try:
                omnibus_p = stats.kruskal(*group_values).pvalue
            except ValueError:
                omnibus_p = np.nan
        else:
            omnibus_p = np.nan
        for a, b in comparisons:
            x = sub.loc[sub["analysis_group"] == a, "proportion"].values
            y = sub.loc[sub["analysis_group"] == b, "proportion"].values
            p = np.nan
            if len(x) and len(y):
                try:
                    p = stats.mannwhitneyu(x, y, alternative="two-sided").pvalue
                except ValueError:
                    p = np.nan
            rows.append(
                {
                    "state_hint": state,
                    "state_label": STATE_LABEL[state],
                    "comparison": f"{a} vs {b}",
                    "group_1": a,
                    "group_2": b,
                    "n_group_1": len(x),
                    "n_group_2": len(y),
                    "mean_group_1": np.nanmean(x) if len(x) else np.nan,
                    "mean_group_2": np.nanmean(y) if len(y) else np.nan,
                    "delta_mean_group1_minus_group2": (np.nanmean(x) - np.nanmean(y)) if len(x) and len(y) else np.nan,
                    "hedges_g_group1_minus_group2": hedges_g(x, y),
                    "mannwhitney_p": p,
                    "kruskal_omnibus_p_for_state": omnibus_p,
                }
            )
    tests = pd.DataFrame(rows)
    tests["mannwhitney_fdr_bh"] = bh_adjust(tests["mannwhitney_p"])
    tests["significance"] = tests["mannwhitney_fdr_bh"].map(p_to_star)
    tests.to_csv(OUT / "panelE_gse140510_state_proportion_pairwise_stats.csv", index=False)


def write_panel_f_pseudobulk(adata: ad.AnnData, obs: pd.DataFrame) -> None:
    genes = []
    ann_rows = []
    for group_order, (group, group_genes) in enumerate(PANELF_GENE_GROUPS):
        for gene_order, gene in enumerate(group_genes):
            if gene in adata.var_names and gene not in genes:
                genes.append(gene)
                ann_rows.append(
                    {
                        "gene": gene,
                        "gene_group": group,
                        "gene_group_order": group_order,
                        "gene_order_within_group": gene_order,
                    }
                )
    pd.DataFrame(ann_rows).to_csv(OUT / "panelF_gse140510_marker_gene_annotation.csv", index=False)

    sample_meta = (
        obs[["sample_id", "analysis_group"]]
        .drop_duplicates()
        .assign(group_order=lambda d: d["analysis_group"].map({g: i for i, g in enumerate(GROUP_ORDER_140510)}))
        .sort_values(["group_order", "sample_id"])
    )
    sample_meta["n_microglia"] = sample_meta["sample_id"].map(obs["sample_id"].value_counts())
    sample_meta.to_csv(OUT / "panelF_gse140510_pseudobulk_sample_metadata.csv", index=False)

    expr = pd.DataFrame(dense(adata[:, genes].X), index=adata.obs_names, columns=genes)
    expr["sample_id"] = obs["sample_id"].values
    pb = expr.groupby("sample_id")[genes].mean()
    pb = pb.loc[sample_meta["sample_id"]]
    pb.to_csv(OUT / "panelF_gse140510_pseudobulk_marker_expression_mean_by_sample.csv")
    z = zscore_matrix_by_row(pb.T)
    z.to_csv(OUT / "panelF_gse140510_pseudobulk_marker_expression_gene_zscore_matrix.csv")
    long = (
        z.reset_index(names="gene")
        .melt(id_vars="gene", var_name="sample_id", value_name="gene_zscore")
        .merge(pd.DataFrame(ann_rows), on="gene", how="left")
        .merge(sample_meta, on="sample_id", how="left")
    )
    long.to_csv(OUT / "panelF_gse140510_pseudobulk_marker_expression_gene_zscore_long.csv", index=False)


def write_panel_g_module_contrasts(obs: pd.DataFrame) -> None:
    sample_scores = (
        obs.groupby(["sample_id", "analysis_group"], observed=True)[[m for m, _ in MODULES_CONTRAST if m in obs.columns]]
        .mean()
        .reset_index()
    )
    sample_scores["group_order"] = sample_scores["analysis_group"].map({g: i for i, g in enumerate(GROUP_ORDER_140510)})
    sample_scores.sort_values(["group_order", "sample_id"]).to_csv(
        OUT / "panelG_gse140510_sample_level_module_scores.csv", index=False
    )

    contrasts = [
        ("5xFAD_vs_WT", "5xFAD", "WT"),
        ("Trem2_KO_5xFAD_vs_Trem2_KO", "Trem2_KO_5xFAD", "Trem2_KO"),
        ("Trem2_KO_5xFAD_vs_5xFAD", "Trem2_KO_5xFAD", "5xFAD"),
    ]
    rows = []
    for contrast_order, (contrast, a, b) in enumerate(contrasts):
        for module_order, (module, label) in enumerate(MODULES_CONTRAST):
            if module not in sample_scores.columns:
                continue
            x = sample_scores.loc[sample_scores["analysis_group"] == a, module].values
            y = sample_scores.loc[sample_scores["analysis_group"] == b, module].values
            p = np.nan
            if len(x) and len(y):
                try:
                    p = stats.mannwhitneyu(x, y, alternative="two-sided").pvalue
                except ValueError:
                    p = np.nan
            effect = hedges_g(x, y)
            rows.append(
                {
                    "contrast": contrast,
                    "contrast_order": contrast_order,
                    "group_1": a,
                    "group_2": b,
                    "module": module,
                    "module_label": label,
                    "module_order": module_order,
                    "n_group_1": len(x),
                    "n_group_2": len(y),
                    "mean_group_1": np.nanmean(x) if len(x) else np.nan,
                    "mean_group_2": np.nanmean(y) if len(y) else np.nan,
                    "effect_size_hedges_g_group1_minus_group2": effect,
                    "mannwhitney_p": p,
                    "direction": "increase" if np.isfinite(effect) and effect > 0 else ("decrease" if np.isfinite(effect) and effect < 0 else "no_change"),
                }
            )
    out = pd.DataFrame(rows)
    out["fdr_bh_within_contrast"] = np.nan
    for contrast in out["contrast"].unique():
        mask = out["contrast"] == contrast
        out.loc[mask, "fdr_bh_within_contrast"] = bh_adjust(out.loc[mask, "mannwhitney_p"])
    out["significance"] = out["fdr_bh_within_contrast"].map(p_to_star)
    out.to_csv(OUT / "panelG_gse140510_trem2_dependence_module_contrasts.csv", index=False)


def main() -> None:
    require_file(GSE98969_H5AD)
    require_file(GSE140510_H5AD)
    load_state_palette()

    print("Loading GSE98969 fixed microglia object...")
    gse98969 = ad.read_h5ad(GSE98969_H5AD)
    obs98969 = gse98969.obs.copy()
    obs98969["sample_id"] = obs98969["sample_id"].astype(str)
    design = read_gse98969_design()
    obs98969 = obs98969.merge(design, on="cell_barcode", how="left", suffixes=("", "_design"))
    obs98969.index = gse98969.obs_names
    if "analysis_group_design" in obs98969.columns:
        obs98969["analysis_group"] = obs98969["analysis_group_design"].fillna(obs98969["analysis_group"])
        obs98969 = obs98969.drop(columns=["analysis_group_design"])
    obs98969["analysis_group"] = obs98969["analysis_group"].fillna("Unknown")
    obs98969 = add_lipid_score(gse98969, obs98969)
    obs98969[["sample_id", "cell_barcode", "analysis_group", "gse98969_mouse_id", "gse98969_batch_desc"]].drop_duplicates().to_csv(
        OUT / "gse98969_cell_to_design_metadata.csv", index=False
    )
    write_umap_and_score_tables(
        gse98969,
        obs98969,
        dataset="GSE98969",
        group_order=GROUP_ORDER_98969,
        panel_umap_name="panelA_gse98969_5xfad_wt_umap_states.csv",
        panel_scores_name="panelB_gse98969_5xfad_wt_umap_module_scores.csv",
        filter_groups=GROUP_ORDER_98969,
    )
    obs98969["analysis_group"].value_counts().rename_axis("analysis_group").reset_index(name="n_cells").to_csv(
        OUT / "gse98969_cells_by_design_group_all_microglia.csv", index=False
    )

    print("Loading GSE140510 fixed microglia object...")
    gse140510 = ad.read_h5ad(GSE140510_H5AD)
    obs140510 = gse140510.obs.copy()
    obs140510["sample_id"] = obs140510["sample_id"].astype(str)
    obs140510["analysis_group"] = obs140510["sample_id"].map(infer_gse140510_group)
    obs140510 = add_lipid_score(gse140510, obs140510)
    write_umap_and_score_tables(
        gse140510,
        obs140510,
        dataset="GSE140510",
        group_order=GROUP_ORDER_140510,
        panel_umap_name="panelC_gse140510_umap_states.csv",
        panel_scores_name=None,
        filter_groups=GROUP_ORDER_140510,
    )
    props, sample_meta = write_gse140510_state_proportions(obs140510)
    write_gse140510_group_state_stats(props, sample_meta)
    write_panel_f_pseudobulk(gse140510, obs140510)
    write_panel_g_module_contrasts(obs140510)

    manifest = {
        "output_dir": str(OUT),
        "inputs": {
            "gse98969_h5ad": str(GSE98969_H5AD),
            "gse140510_h5ad": str(GSE140510_H5AD),
            "gse98969_design": str(GSE98969_DESIGN),
            "state_palette": str(FIG2_PALETTE) if FIG2_PALETTE.exists() else "built-in fallback",
        },
        "panel_csvs": {
            "A": "panelA_gse98969_5xfad_wt_umap_states.csv",
            "B": "panelB_gse98969_5xfad_wt_umap_module_scores.csv",
            "C": "panelC_gse140510_umap_states.csv",
            "D": [
                "panelD_gse140510_state_counts_by_sample_wide.csv",
                "panelD_gse140510_state_proportions_by_sample_wide.csv",
                "panelD_gse140510_state_proportions_by_sample_long.csv",
            ],
            "E": [
                "panelE_gse140510_state_proportions_by_group_long.csv",
                "panelE_gse140510_state_proportion_group_summary.csv",
                "panelE_gse140510_state_proportion_pairwise_stats.csv",
            ],
            "F": [
                "panelF_gse140510_pseudobulk_marker_expression_mean_by_sample.csv",
                "panelF_gse140510_pseudobulk_marker_expression_gene_zscore_matrix.csv",
                "panelF_gse140510_pseudobulk_marker_expression_gene_zscore_long.csv",
                "panelF_gse140510_marker_gene_annotation.csv",
                "panelF_gse140510_pseudobulk_sample_metadata.csv",
            ],
            "G": [
                "panelG_gse140510_sample_level_module_scores.csv",
                "panelG_gse140510_trem2_dependence_module_contrasts.csv",
            ],
        },
        "notes": [
            "GSE98969 panel A/B tables are filtered to cells joined to GEO design groups WT or 5xFAD.",
            "GSE140510 groups are inferred from sample_id strings in the fixed object.",
            "lipid_score is computed from available lipid/DAM genes because it is not stored in the fixed mouse objects.",
            "Panel E and G statistics are sample-level, not cell-level.",
        ],
    }
    (OUT / "figure4_mouse_conservation_source_data_manifest.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8"
    )
    (OUT / "README.txt").write_text(
        "\n".join(
            [
                "Figure 4 mouse conservation source-data CSVs.",
                f"Output directory: {OUT}",
                "Panel A: GSE98969 WT/5xFAD UMAP state coordinates.",
                "Panel B: GSE98969 WT/5xFAD UMAP module-score coordinates.",
                "Panel C: GSE140510 UMAP state coordinates.",
                "Panel D: GSE140510 sample-level state counts/proportions.",
                "Panel E: GSE140510 group-level state proportion summaries and sample-level tests.",
                "Panel F: GSE140510 sample-level pseudobulk marker expression matrix and annotations.",
                "Panel G: GSE140510 sample-level module contrasts for Trem2 dependence.",
                "State palette is preserved from Figure 2 when available.",
            ]
        ),
        encoding="utf-8",
    )
    print(f"Wrote Figure 4 source CSVs to: {OUT}")


if __name__ == "__main__":
    main()
