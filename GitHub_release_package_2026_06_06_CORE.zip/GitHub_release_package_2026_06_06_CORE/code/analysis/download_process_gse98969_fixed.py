#!/usr/bin/env python3
"""
download_process_gse98969_fixed.py

Corrected parser for GSE98969 GEO supplementary files.

Assumes each GSM*.txt(.gz) file is a matrix with:
- header row: cell/barcode IDs
- first column: gene names
- remaining columns: counts per cell

Outputs:
  gse98969_work_fixed/
    downloads/
    extracted/
    processed/
      GSE98969_combined.h5ad
      GSE98969_cell_metadata.csv
      GSE98969_parse_report.json
"""

import argparse
import gzip
import json
import logging
import re
import tarfile
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
import requests
from scipy import sparse

RAW_URL = "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE98nnn/GSE98969/suppl/GSE98969_RAW.tar"
DESIGN_URL = "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE98nnn/GSE98969/suppl/GSE98969_experimental_design_f.txt.gz"

def setup_logger(outdir: Path) -> logging.Logger:
    outdir.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("gse98969_fixed")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
    sh = logging.StreamHandler()
    sh.setFormatter(fmt)
    logger.addHandler(sh)
    fh = logging.FileHandler(outdir / "gse98969_fixed.log", mode="w", encoding="utf-8")
    fh.setFormatter(fmt)
    logger.addHandler(fh)
    return logger

def download_file(url: str, dest: Path, chunk_size: int = 1024 * 1024):
    if dest.exists() and dest.stat().st_size > 0:
        return
    dest.parent.mkdir(parents=True, exist_ok=True)
    with requests.get(url, stream=True, timeout=60) as r:
        r.raise_for_status()
        total = int(r.headers.get("content-length", 0))
        got = 0
        with open(dest, "wb") as f:
            for chunk in r.iter_content(chunk_size=chunk_size):
                if not chunk:
                    continue
                f.write(chunk)
                got += len(chunk)
                if total:
                    pct = got * 100 / total
                    print(f"\rDownloading {dest.name}: {pct:5.1f}% ", end="", flush=True)
    print()

def safe_extract(tar_path: Path, outdir: Path):
    outdir.mkdir(parents=True, exist_ok=True)
    with tarfile.open(tar_path, "r") as tar:
        tar.extractall(outdir)

def infer_group_from_sample(s: str) -> str:
    s = str(s)
    low = s.lower()
    if "trem2" in low and ("5xfad" in low or "fad" in low or "ad" in low):
        return "Trem2_KO_AD"
    if "5xfad" in low or "fad" in low or "_ad" in low or low.endswith("ad"):
        return "AD_model"
    if "wt" in low or "ctrl" in low or "control" in low:
        return "WT_or_control"
    return "Unknown"

def read_design(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    with gzip.open(path, "rt", encoding="utf-8", errors="ignore") as f:
        try:
            return pd.read_csv(f, sep="\t")
        except Exception:
            f.seek(0)
            return pd.read_csv(f, sep=None, engine="python")

def parse_matrix_file(path: Path, logger: logging.Logger) -> ad.AnnData:
    # Use python engine to tolerate ragged header/data mismatch.
    compression = "gzip" if path.suffix == ".gz" else None
    df = pd.read_csv(
        path,
        sep="\t",
        header=0,
        index_col=0,
        compression=compression,
        engine="python",
    )

    # Clean weird empty columns if present
    df = df.loc[:, ~df.columns.astype(str).str.match(r"^Unnamed")]
    df.index = df.index.astype(str).str.strip()
    df = df[~df.index.isna()]
    df = df[df.index != ""]
    # numeric conversion
    df = df.apply(pd.to_numeric, errors="coerce").fillna(0)
    # collapse duplicate genes
    if df.index.duplicated().any():
        df = df.groupby(df.index).sum()

    sample_id = re.sub(r"\.txt(\.gz)?$", "", path.name, flags=re.IGNORECASE)
    # rows = genes, cols = cells => transpose to cells x genes
    cell_names = [f"{sample_id}__{str(c)}" for c in df.columns.astype(str)]
    obs = pd.DataFrame(index=cell_names)
    obs["sample_id"] = sample_id
    obs["analysis_group"] = infer_group_from_sample(sample_id)
    obs["cell_barcode"] = [str(c) for c in df.columns.astype(str)]

    var = pd.DataFrame(index=df.index.astype(str))
    X = sparse.csr_matrix(df.T.values)
    adata = ad.AnnData(X=X, obs=obs, var=var)
    adata.layers["counts"] = adata.X.copy()
    return adata

def main():
    ap = argparse.ArgumentParser(description="Download and parse GSE98969 GEO supplementary matrices into one h5ad")
    ap.add_argument("--outdir", default="gse98969_work_fixed")
    args = ap.parse_args()

    root = Path(args.outdir)
    downloads = root / "downloads"
    extracted = root / "extracted"
    processed = root / "processed"
    downloads.mkdir(parents=True, exist_ok=True)
    processed.mkdir(parents=True, exist_ok=True)
    logger = setup_logger(root)

    raw_tar = downloads / "GSE98969_RAW.tar"
    design_gz = downloads / "GSE98969_experimental_design_f.txt.gz"

    logger.info("Downloading GEO supplementary files")
    download_file(RAW_URL, raw_tar)
    download_file(DESIGN_URL, design_gz)

    logger.info("Extracting GEO RAW tar")
    safe_extract(raw_tar, extracted)

    files = sorted([p for p in extracted.rglob("GSM*.txt*") if p.is_file()])
    logger.info("Found %d candidate matrix files", len(files))
    parsed = []
    failed = []

    for p in files:
        try:
            logger.info("Parsing %s", p.name)
            a = parse_matrix_file(p, logger)
            parsed.append(a)
        except Exception as e:
            failed.append({"file": str(p), "reason": repr(e)})

    if not parsed:
        raise RuntimeError("No sample matrix files were successfully parsed.")

    logger.info("Concatenating %d parsed sample objects", len(parsed))
    combined = ad.concat(parsed, join="outer", merge="same", index_unique=None)
    combined.var_names_make_unique()

    out_h5ad = processed / "GSE98969_combined.h5ad"
    out_meta = processed / "GSE98969_cell_metadata.csv"
    out_report = processed / "GSE98969_parse_report.json"

    combined.write(out_h5ad)
    combined.obs.to_csv(out_meta)
    out_report.write_text(
        json.dumps(
            {
                "n_cells": int(combined.n_obs),
                "n_genes": int(combined.n_vars),
                "parsed_files": len(parsed),
                "failed_files": failed[:200],
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    logger.info("Saved h5ad: %s", out_h5ad)
    logger.info("Saved metadata: %s", out_meta)
    logger.info("Done")

if __name__ == "__main__":
    main()
