True Bayesian HGT external-validation result files.
Design: train final Bayesian HGT models on SEA-AD; test on Olah, GSE98969, and GSE140510.
Labels: remodeled vs homeostatic/transitional from each dataset's existing state_hint annotations.
Mouse features: mapped to human canonical gene family names with explicit mouse ortholog symbols.
Output directory: F:\AD\Mam San\results\bayesian_hgt_true_external_validation