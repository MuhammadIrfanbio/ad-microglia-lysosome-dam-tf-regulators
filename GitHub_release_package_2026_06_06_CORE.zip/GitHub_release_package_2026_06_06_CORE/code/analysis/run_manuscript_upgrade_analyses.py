#!/usr/bin/env python3
"""
run_manuscript_upgrade_analyses.py

One-command manuscript-upgrade driver for the Zfp335/ZNF335-Bace1/BACE1 AD microglia project.

Runs:
  1) 900-dpi state-continuum module-trend helper figures for available microglia datasets
  2) all-available upstream comparison using compare_upstream_screens.py
  3) all-available meta-summary using meta_summary_across_datasets.py
  4) 900-dpi meta-summary figures
  5) orthogonal mouse pseudobulk DE/signature-direction analysis for GSE140510

Designed for your current folder:
  D:\Mam San

Run:
  conda activate D:\conda_envs\zfp335
  cd /d "D:\Mam San"
  python run_manuscript_upgrade_analyses.py

Optional full trajectory subprocess:
  python run_manuscript_upgrade_analyses.py --run-transition-subprocess
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Optional

import anndata as ad
import numpy as np
import pandas as pd
import scanpy as sc
import scipy.sparse as sp
from scipy.stats import mannwhitneyu
import matplotlib.pyplot as plt


DATASETS = {
    "gse140510": {
        "species": "mouse",
        "micro_dir": r"results\gse140510_mouse_microglia_fixed",
        "upstream_dir": r"results\gse140510_upstream_screen",
        "h5ad": r"results\gse140510_mouse_microglia_fixed\objects\gse140510_mouse_microglia_fixed_microglia_final.h5ad",
        "sample_col": "sample_id",
    },
    "gse98969": {
        "species": "mouse",
        "micro_dir": r"results\gse98969_microglia_fixed",
        "upstream_dir": r"results\gse98969_upstream_screen",
        "h5ad": r"results\gse98969_microglia_fixed\objects\gse98969_microglia_fixed_microglia_final.h5ad",
        "sample_col": "sample_id",
    },
    "olah": {
        "species": "human",
        "micro_dir": r"results\olah_microglia_fixed",
        "upstream_dir": r"results\olah_upstream_screen",
        "h5ad": r"results\olah_microglia_fixed\objects\olah_microglia_fixed_microglia_final.h5ad",
        "sample_col": "donor_id",
    },
    "seaad": {
        "species": "human",
        "micro_dir": r"results\seaad_microglia_fixed",
        "upstream_dir": r"results\seaad_upstream_screen",
        "h5ad": r"results\seaad_microglia_fixed\objects\seaad_microglia_fixed_microglia_final.h5ad",
        "sample_col": "external_donor_name_label",
        "group_col": "full_genotype_label",
    },
}

GENESETS = {
    "mouse": {
        "lysosome": ["Ctsb", "Ctsd", "Lamp1", "Lamp2", "Cd68", "Hexa", "Hexb", "Atp6v1b2", "Atp6v0d1"],
        "dam_phagocytic": ["Apoe", "Trem2", "Tyrobp", "Cst7", "Lpl", "Itgax", "Axl", "Gpnmb", "Fcer1g"],
        "homeostatic": ["P2ry12", "Tmem119", "Cx3cr1", "Csf1r", "Selplg"],
    },
    "human": {
        "lysosome": ["CTSB", "CTSD", "LAMP1", "LAMP2", "CD68", "HEXA", "HEXB", "ATP6V1B2", "ATP6V0D1"],
        "dam_phagocytic": ["APOE", "TREM2", "TYROBP", "CST7", "LPL", "ITGAX", "AXL", "GPNMB", "FCER1G"],
        "homeostatic": ["P2RY12", "TMEM119", "CX3CR1", "CSF1R", "SELPLG"],
    },
}

STATE_ORDER = [
    "homeostatic_like",
    "transitional_like",
    "lysosome_high",
    "dam_like",
    "interferon_like",
    "proliferative_like",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run manuscript-upgrade analyses and 900-dpi helper figures.")
    parser.add_argument("--output-dir", default=r"results\manuscript_upgrade")
    parser.add_argument("--dpi", type=int, default=900)
    parser.add_argument(
        "--run-transition-subprocess",
        action="store_true",
        help="Also run microglia_transition_analysis.py for each dataset if available.",
    )
    parser.add_argument("--skip-de", action="store_true")
    return parser.parse_args()


def mkdirs(root: Path) -> None:
    for sub in ["logs", "figures", "tables", "de", "transition", "meta"]:
        (root / sub).mkdir(parents=True, exist_ok=True)


def log_write(logfile: Path, text: str) -> None:
    print(text)
    with open(logfile, "a", encoding="utf-8") as handle:
        handle.write(text.rstrip() + "\n")


def run_cmd(cmd: List[str], logfile: Path, cwd: Optional[Path] = None) -> bool:
    log_write(logfile, "\nRUN: " + " ".join(cmd))
    try:
        proc = subprocess.run(
            cmd,
            cwd=str(cwd) if cwd else None,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        )
        log_write(logfile, proc.stdout)
        if proc.returncode != 0:
            log_write(logfile, f"FAILED with code {proc.returncode}")
            return False
        return True
    except Exception as exc:
        log_write(logfile, f"FAILED to execute: {exc!r}")
        return False


def existing_datasets() -> Dict[str, Dict]:
    found: Dict[str, Dict] = {}
    for name, info in DATASETS.items():
        if Path(info["h5ad"]).exists() and Path(info["micro_dir"]).exists() and Path(info["upstream_dir"]).exists():
            found[name] = info
    return found


def find_first_csv(tables_dir: Path, suffix: str) -> Optional[Path]:
    matches = list(tables_dir.glob(f"*{suffix}"))
    return matches[0] if matches else None


def infer_group_from_sample(sample: str) -> str:
    sample = str(sample)
    if "Trem2_KO_5XFAD" in sample:
        return "Trem2_KO_5XFAD"
    if "WT_5XFAD" in sample:
        return "WT_5XFAD"
    if "Trem2_KO" in sample:
        return "Trem2_KO"
    if "_WT_" in sample or sample.endswith("_WT") or "WT" in sample:
        return "WT"
    return "Unknown"


def matrix_sum(mat) -> np.ndarray:
    if sp.issparse(mat):
        return np.asarray(mat.sum(axis=0)).ravel()
    return np.asarray(mat.sum(axis=0)).ravel()


def pseudobulk_by_sample(adata: ad.AnnData, sample_col: str) -> pd.DataFrame:
    mat = adata.layers["counts"] if "counts" in adata.layers else adata.X
    samples = adata.obs[sample_col].astype(str)
    rows = []
    for sample in samples.unique():
        idx = np.where(samples.values == sample)[0]
        rows.append(pd.Series(matrix_sum(mat[idx, :]), index=adata.var_names, name=sample))
    return pd.DataFrame(rows)


def logcpm(counts: pd.DataFrame) -> pd.DataFrame:
    lib = counts.sum(axis=1).replace(0, np.nan)
    return np.log1p(counts.div(lib, axis=0) * 1_000_000)


def bh_adjust(pvals: np.ndarray) -> np.ndarray:
    pvals = np.asarray(pvals, dtype=float)
    n = len(pvals)
    order = np.argsort(pvals)
    adjusted = np.empty(n, dtype=float)
    prev = 1.0
    for rank, idx in enumerate(order[::-1], start=1):
        val = min(prev, pvals[idx] * n / (n - rank + 1))
        adjusted[idx] = val
        prev = val
    return adjusted


def run_de_for_comparison(
    adata: ad.AnnData,
    sample_col: str,
    group_col: str,
    case_label: str,
    control_label: str,
    species: str,
    outdir: Path,
    dpi: int,
) -> None:
    raise RuntimeError(
        "run_manuscript_upgrade_analyses.py contains a legacy Mann-Whitney/logCPM pseudobulk DE helper. "
        "Publication-grade DE/GSEA must be produced with q1_multiomics_context_pipeline_gsea_fixed.py "
        "using count-model DE and metadata-manifest validation."
    )
    tables = outdir / "tables"
    figs = outdir / "figures"
    tables.mkdir(parents=True, exist_ok=True)
    figs.mkdir(parents=True, exist_ok=True)

    if group_col not in adata.obs.columns:
        adata.obs[group_col] = adata.obs[sample_col].astype(str).map(infer_group_from_sample)

    pb_counts = pseudobulk_by_sample(adata, sample_col=sample_col)
    pb_logcpm = logcpm(pb_counts)
    pb_counts.to_csv(tables / "pseudobulk_counts.csv")
    pb_logcpm.to_csv(tables / "pseudobulk_logcpm.csv")

    sample_meta = (
        adata.obs[[sample_col, group_col]]
        .drop_duplicates()
        .rename(columns={sample_col: "sample_id"})
        .set_index("sample_id")
        .reindex(pb_logcpm.index)
    )
    sample_meta.to_csv(tables / "sample_metadata.csv")

    case_samples = sample_meta.index[sample_meta[group_col].astype(str) == case_label].tolist()
    control_samples = sample_meta.index[sample_meta[group_col].astype(str) == control_label].tolist()

    if not case_samples or not control_samples:
        (tables / "SKIPPED.txt").write_text(
            f"Skipped: found {len(case_samples)} case samples and {len(control_samples)} control samples.\n"
            f"case_label={case_label}; control_label={control_label}\n",
            encoding="utf-8",
        )
        return

    rows = []
    for gene in pb_logcpm.columns:
        x = pb_logcpm.loc[case_samples, gene].dropna().values
        y = pb_logcpm.loc[control_samples, gene].dropna().values
        if len(x) == 0 or len(y) == 0:
            continue
        try:
            _, pval = mannwhitneyu(x, y, alternative="two-sided")
        except Exception:
            pval = np.nan
        rows.append(
            {
                "gene": gene,
                "mean_case_logcpm": float(np.mean(x)),
                "mean_control_logcpm": float(np.mean(y)),
                "delta_mean_logcpm": float(np.mean(x) - np.mean(y)),
                "p_value": float(pval) if pd.notna(pval) else np.nan,
            }
        )

    de = pd.DataFrame(rows).sort_values("p_value")
    de["p_adj_bh"] = bh_adjust(de["p_value"].fillna(1.0).values)
    de.to_csv(tables / "pseudobulk_de_results.csv", index=False)
    de.sort_values("delta_mean_logcpm", ascending=False).head(50).to_csv(tables / "top_up_genes.csv", index=False)
    de.sort_values("delta_mean_logcpm", ascending=True).head(50).to_csv(tables / "top_down_genes.csv", index=False)

    sig_rows = []
    for sig_name, genes in GENESETS[species].items():
        present = [gene for gene in genes if gene in pb_logcpm.columns]
        if not present:
            continue
        case_mean = float(pb_logcpm.loc[case_samples, present].mean().mean())
        ctrl_mean = float(pb_logcpm.loc[control_samples, present].mean().mean())
        sig_rows.append(
            {
                "signature": sig_name,
                "n_genes_present": len(present),
                "case_label": case_label,
                "control_label": control_label,
                "mean_case_logcpm": case_mean,
                "mean_control_logcpm": ctrl_mean,
                "delta_case_minus_control": case_mean - ctrl_mean,
            }
        )
    sig = pd.DataFrame(sig_rows)
    sig.to_csv(tables / "signature_direction_summary.csv", index=False)

    if not sig.empty:
        plt.figure(figsize=(7, 4))
        plt.bar(sig["signature"], sig["delta_case_minus_control"])
        plt.axhline(0, linewidth=0.8)
        plt.ylabel(f"{case_label} - {control_label}\nmean signature logCPM")
        plt.title(f"Orthogonal pseudobulk signature direction\n{case_label} vs {control_label}")
        plt.xticks(rotation=25, ha="right")
        plt.tight_layout()
        plt.savefig(figs / "signature_direction_barplot_900dpi.png", dpi=dpi, bbox_inches="tight")
        plt.close()

    if not de.empty:
        plotdf = de.copy()
        plotdf["neg_log10_p"] = -np.log10(plotdf["p_value"].replace(0, np.nan))
        max_finite = plotdf["neg_log10_p"].replace([np.inf, -np.inf], np.nan).max()
        plotdf["neg_log10_p"] = plotdf["neg_log10_p"].replace([np.inf, -np.inf], np.nan).fillna(max_finite)
        plt.figure(figsize=(7, 5))
        plt.scatter(plotdf["delta_mean_logcpm"], plotdf["neg_log10_p"], s=8, alpha=0.6)
        plt.axvline(0, linewidth=0.8)
        plt.xlabel("Delta mean logCPM")
        plt.ylabel("-log10(p value)")
        plt.title(f"Pseudobulk DE summary\n{case_label} vs {control_label}")
        key_genes = (
            GENESETS[species]["lysosome"][:3]
            + GENESETS[species]["dam_phagocytic"][:4]
            + GENESETS[species]["homeostatic"][:4]
        )
        for gene in key_genes:
            sub = plotdf[plotdf["gene"] == gene]
            if not sub.empty:
                x = float(sub["delta_mean_logcpm"].iloc[0])
                y = float(sub["neg_log10_p"].iloc[0])
                plt.text(x, y, gene, fontsize=7)
        plt.tight_layout()
        plt.savefig(figs / "pseudobulk_de_volcano_helper_900dpi.png", dpi=dpi, bbox_inches="tight")
        plt.close()


def plot_transition_from_tables(dataset: str, micro_dir: Path, outdir: Path, dpi: int) -> bool:
    med_csv = find_first_csv(micro_dir / "tables", "median_scores_by_state.csv")
    if med_csv is None:
        return False
    med = pd.read_csv(med_csv)
    med = med[med["state_hint"].isin(STATE_ORDER)].copy()
    med["state_hint"] = pd.Categorical(med["state_hint"], categories=STATE_ORDER, ordered=True)
    med = med.sort_values("state_hint")
    score_cols = [
        col
        for col in ["homeostatic_score", "lysosome_score", "dam_phagocytic_score", "interferon_score", "proliferative_score"]
        if col in med.columns
    ]
    if not score_cols:
        return False
    outdir.mkdir(parents=True, exist_ok=True)
    med.to_csv(outdir / f"{dataset}_transition_scores_used.csv", index=False)
    plt.figure(figsize=(9, 5))
    for col in score_cols:
        plt.plot(med["state_hint"].astype(str), med[col], marker="o", label=col)
    plt.axhline(0, linewidth=0.8)
    plt.xlabel("Ordered microglial state continuum")
    plt.ylabel("Median module score")
    plt.title(f"{dataset}: microglial state-continuum module trends")
    plt.xticks(rotation=25, ha="right")
    plt.legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(outdir / f"{dataset}_transition_module_trends_900dpi.png", dpi=dpi, bbox_inches="tight")
    plt.close()
    return True


def run_meta_summary(root: Path, datasets: Dict[str, Dict], logfile: Path) -> bool:
    script = Path("meta_summary_across_datasets.py")
    if not script.exists():
        log_write(logfile, "SKIP meta-summary: meta_summary_across_datasets.py not found")
        return False
    cmd = [sys.executable, str(script)]
    for name, info in datasets.items():
        cmd.extend(["--spec", f"{name}::{info['micro_dir']}::{info['upstream_dir']}"])
    cmd.extend(["--output-dir", str(root / "meta" / "meta_summary_all_available")])
    return run_cmd(cmd, logfile)


def run_upstream_comparison(root: Path, datasets: Dict[str, Dict], logfile: Path) -> bool:
    script = Path("compare_upstream_screens.py")
    if not script.exists():
        log_write(logfile, "SKIP upstream comparison: compare_upstream_screens.py not found")
        return False
    cmd = [sys.executable, str(script), "--run-dirs"]
    cmd.extend([info["upstream_dir"] for info in datasets.values()])
    cmd.extend(["--outdir", str(root / "meta" / "upstream_comparison_all_available")])
    return run_cmd(cmd, logfile)


def plot_meta_figures(meta_dir: Path, outfig: Path, dpi: int) -> bool:
    tables = meta_dir / "tables"
    state_csv = tables / "state_proportion_meta_summary.csv"
    upstream_csv = tables / "upstream_sign_detectability_matrix.csv"
    if not state_csv.exists() or not upstream_csv.exists():
        return False

    state = pd.read_csv(state_csv)
    upstream = pd.read_csv(upstream_csv)

    state_piv = state.pivot(index="dataset", columns="state_hint", values="proportion").fillna(0)
    ordered_cols = [col for col in STATE_ORDER if col in state_piv.columns]
    ordered_cols += [col for col in state_piv.columns if col not in ordered_cols]
    state_piv = state_piv[ordered_cols]

    plt.figure(figsize=(9, max(4, 0.7 * len(state_piv))))
    plt.imshow(state_piv.values, aspect="auto")
    plt.yticks(range(len(state_piv.index)), state_piv.index.tolist())
    plt.xticks(range(len(state_piv.columns)), state_piv.columns.tolist(), rotation=35, ha="right")
    plt.colorbar(label="State proportion")
    for i in range(state_piv.shape[0]):
        for j in range(state_piv.shape[1]):
            plt.text(j, i, f"{state_piv.iloc[i, j]:.2f}", ha="center", va="center", fontsize=7)
    plt.title("Cross-dataset microglial state proportions")
    plt.tight_layout()
    plt.savefig(outfig / "state_proportion_meta_summary_900dpi.png", dpi=dpi, bbox_inches="tight")
    plt.close()

    cols = [
        "regulator_pct_nonzero",
        "bace1_pct_nonzero",
        "zfp_bace1_spearman_rho",
        "regulator_vs_lysosome_rho",
        "regulator_vs_dam_rho",
        "bace1_vs_lysosome_rho",
        "bace1_vs_dam_rho",
    ]
    cols = [col for col in cols if col in upstream.columns]
    mat = upstream.set_index("dataset")[cols].astype(float)
    plt.figure(figsize=(10, max(4, 0.7 * len(mat))))
    plt.imshow(mat.values, aspect="auto")
    plt.yticks(range(len(mat.index)), mat.index.tolist())
    plt.xticks(range(len(mat.columns)), mat.columns.tolist(), rotation=35, ha="right")
    plt.colorbar(label="Value")
    for i in range(mat.shape[0]):
        for j in range(mat.shape[1]):
            val = mat.iloc[i, j]
            fmt = f"{val:.2f}" if abs(val) < 10 else f"{val:.1f}"
            plt.text(j, i, fmt, ha="center", va="center", fontsize=7)
    plt.title("Upstream detectability and module-correlation matrix")
    plt.tight_layout()
    plt.savefig(outfig / "upstream_sign_detectability_matrix_900dpi.png", dpi=dpi, bbox_inches="tight")
    plt.close()
    return True


def run_transition_subprocess(root: Path, datasets: Dict[str, Dict], logfile: Path) -> None:
    script = Path("microglia_transition_analysis.py")
    if not script.exists():
        log_write(logfile, "SKIP transition subprocess: microglia_transition_analysis.py not found")
        return
    for name, info in datasets.items():
        cmd = [
            sys.executable,
            str(script),
            "--input-h5ad",
            info["h5ad"],
            "--output-dir",
            str(root / "transition" / name),
            "--species",
            info["species"],
            "--state-column",
            "state_hint",
            "--root-state",
            "homeostatic_like",
        ]
        run_cmd(cmd, logfile)


def main() -> None:
    args = parse_args()
    root = Path(args.output_dir)
    mkdirs(root)
    logfile = root / "logs" / "run.log"
    if logfile.exists():
        logfile.unlink()

    datasets = existing_datasets()
    log_write(logfile, f"Found datasets: {', '.join(datasets.keys()) if datasets else 'none'}")
    if not datasets:
        log_write(logfile, "No expected microglia h5ad files found. Check paths in DATASETS.")
        return

    log_write(logfile, "\n=== 900-dpi state-continuum helper plots from median score tables ===")
    for name, info in datasets.items():
        ok = plot_transition_from_tables(name, Path(info["micro_dir"]), root / "figures" / "transition_helpers", args.dpi)
        log_write(logfile, f"{name}: state-continuum helper plot {'OK' if ok else 'SKIPPED'}")

    if args.run_transition_subprocess:
        log_write(logfile, "\n=== Full transition subprocess analyses ===")
        run_transition_subprocess(root, datasets, logfile)

    log_write(logfile, "\n=== Upstream comparison ===")
    run_upstream_comparison(root, datasets, logfile)

    log_write(logfile, "\n=== Meta-summary ===")
    run_meta_summary(root, datasets, logfile)

    log_write(logfile, "\n=== 900-dpi meta figures ===")
    meta_ok = plot_meta_figures(root / "meta" / "meta_summary_all_available", root / "figures", args.dpi)
    log_write(logfile, f"Meta figures {'OK' if meta_ok else 'SKIPPED'}")

    if not args.skip_de and "gse140510" in datasets:
        log_write(logfile, "\n=== Orthogonal pseudobulk DE: GSE140510 ===")
        adata = sc.read_h5ad(datasets["gse140510"]["h5ad"])
        sample_col = datasets["gse140510"]["sample_col"]
        if sample_col not in adata.obs.columns:
            log_write(logfile, f"SKIP GSE140510 DE: sample column {sample_col} missing")
        else:
            if "analysis_group" not in adata.obs.columns:
                adata.obs["analysis_group"] = adata.obs[sample_col].astype(str).map(infer_group_from_sample)
            group_counts = adata.obs[[sample_col, "analysis_group"]].drop_duplicates()["analysis_group"].value_counts()
            group_counts.to_csv(root / "de" / "gse140510_group_counts.csv")
            log_write(logfile, "GSE140510 groups:\n" + group_counts.to_string())
            for case, control in [("WT_5XFAD", "WT"), ("Trem2_KO_5XFAD", "WT_5XFAD"), ("Trem2_KO", "WT")]:
                out = root / "de" / f"gse140510_{case}_vs_{control}"
                run_de_for_comparison(
                    adata=adata,
                    sample_col=sample_col,
                    group_col="analysis_group",
                    case_label=case,
                    control_label=control,
                    species="mouse",
                    outdir=out,
                    dpi=args.dpi,
                )
                log_write(logfile, f"DE completed/skipped: {case} vs {control}")

    readme = root / "README_outputs.txt"
    readme.write_text(
        "Manuscript upgrade outputs\n"
        "==========================\n\n"
        "Key folders/files:\n"
        "- figures/transition_helpers: 900-dpi state-continuum trend panels from median state scores\n"
        "- figures/state_proportion_meta_summary_900dpi.png\n"
        "- figures/upstream_sign_detectability_matrix_900dpi.png\n"
        "- de/gse140510_*: pseudobulk DE/signature-direction orthogonal validation\n"
        "- meta/meta_summary_all_available/tables: cross-dataset state and upstream matrices\n"
        "- meta/upstream_comparison_all_available: upstream comparison narrative\n\n"
        "Recommended manuscript panels:\n"
        "1) transition_helpers/gse140510_transition_module_trends_900dpi.png as an exemplar state continuum, not a causal transition\n"
        "2) de/gse140510_WT_5XFAD_vs_WT/figures/signature_direction_barplot_900dpi.png as orthogonal support\n"
        "3) state_proportion_meta_summary_900dpi.png + upstream_sign_detectability_matrix_900dpi.png as meta-summary panels\n",
        encoding="utf-8",
    )
    log_write(logfile, f"\nDONE. Outputs written to: {root}")
    log_write(logfile, f"Read: {readme}")


if __name__ == "__main__":
    main()
