#!/usr/bin/env python
"""
Transcription-regulator extension analysis for the AD microglia manuscript.

This script is designed to be run from a Miniforge/conda environment and to
extend the existing analysis, not start a new project. It reuses the raw/source
files and final microglia h5ad objects already present under F:\\AD\\Mam San.

Suggested Miniforge setup:

    conda create -n tf-reg-extension -c conda-forge python=3.10 anndata h5py scipy pandas numpy
    conda activate tf-reg-extension
    python tf_regulator_extension_analysis.py --mam-san-root "F:\\AD\\Mam San"

Optional loom export for downstream pySCENIC:

    conda install -c conda-forge -c bioconda loompy scanpy
    python tf_regulator_extension_analysis.py --mam-san-root "F:\\AD\\Mam San" --export-scenic-inputs

Main outputs:
    01_raw_gse140510_10x_tf_detection.csv
    02_raw_gse98969_matrix_tf_detection.csv
    03_source_h5ad_tf_detection.csv
    04_final_h5ad_tf_detection.csv
    05_final_state_tf_mean_expression.csv
    06_marker_table_tf_state_summary.csv
    07_sample_level_tf_module_correlations.csv
    08_tf_detection_matrix_final.csv
    09_scenic_extension_manifest.csv
    10_reviewer_summary.txt
"""

from __future__ import annotations

import argparse
import csv
import gzip
import math
import os
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import anndata as ad
import numpy as np
import pandas as pd
from scipy import sparse
from scipy.stats import spearmanr


TF_ROWS = [
    {
        "family": "PU.1/SPI1",
        "category": "myeloid_core",
        "human": ["SPI1"],
        "mouse": ["Spi1", "Sfpi1"],
        "comment": "Core myeloid lineage regulator; note mouse alias differs by dataset.",
    },
    {
        "family": "IRF8",
        "category": "myeloid_core",
        "human": ["IRF8"],
        "mouse": ["Irf8"],
        "comment": "Microglial/myeloid identity and inflammatory-state regulator.",
    },
    {
        "family": "CEBPB",
        "category": "myeloid_inflammatory",
        "human": ["CEBPB"],
        "mouse": ["Cebpb"],
        "comment": "Myeloid inflammatory and activation-associated regulator.",
    },
    {
        "family": "MAFB",
        "category": "myeloid_homeostatic",
        "human": ["MAFB"],
        "mouse": ["Mafb"],
        "comment": "Myeloid differentiation/homeostatic-state regulator.",
    },
    {
        "family": "RUNX1",
        "category": "myeloid_activation",
        "human": ["RUNX1"],
        "mouse": ["Runx1"],
        "comment": "Hematopoietic/myeloid regulator with activation-state relevance.",
    },
    {
        "family": "STAT1",
        "category": "interferon",
        "human": ["STAT1"],
        "mouse": ["Stat1"],
        "comment": "Strong candidate for interferon-like microglial state activity.",
    },
    {
        "family": "IRF7",
        "category": "interferon",
        "human": ["IRF7"],
        "mouse": ["Irf7"],
        "comment": "Interferon-response regulator; often sparse but state-informative.",
    },
    {
        "family": "TFEB",
        "category": "lysosomal_biogenesis",
        "human": ["TFEB"],
        "mouse": ["Tfeb"],
        "comment": "Lysosomal-biogenesis regulator; not available in all datasets.",
    },
    {
        "family": "TFE3",
        "category": "lysosomal_biogenesis",
        "human": ["TFE3"],
        "mouse": ["Tfe3"],
        "comment": "MiT/TFE-family lysosomal-stress regulator; not available in all datasets.",
    },
    {
        "family": "MITF",
        "category": "lysosomal_biogenesis",
        "human": ["MITF"],
        "mouse": ["Mitf"],
        "comment": "MiT/TFE-family regulator; interpret in microglia cautiously.",
    },
    {
        "family": "ZNF335/Zfp335",
        "category": "exploratory_regulator",
        "human": ["ZNF335"],
        "mouse": ["Zfp335"],
        "comment": "Exploratory candidate; expression evidence is low-detection in final objects.",
    },
]


@dataclass(frozen=True)
class DatasetConfig:
    name: str
    label: str
    species: str
    source_h5ad: Path
    final_h5ad: Path
    marker_csv: Path
    default_sample_column: str


STATE_CANDIDATES = [
    "microglia_state",
    "state_label",
    "state_hint",
    "harmonized_state",
    "cell_state",
    "state",
    "program_state",
    "annotation_state",
    "leiden_state",
    "leiden",
]

SAMPLE_CANDIDATES = [
    "sample_id",
    "sample_name",
    "donor_id",
    "external_donor_name_label",
    "donor",
    "individual",
    "subject",
    "orig.ident",
]

MODULE_SCORE_CANDIDATES = [
    "regulator_score",
    "bace1_node_score",
    "lysosome_score",
    "dam_phagocytic_score",
    "homeostatic_score",
    "interferon_score",
    "proliferative_score",
]


def log(message: str) -> None:
    print(message, flush=True)


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def dataset_configs(root: Path) -> list[DatasetConfig]:
    return [
        DatasetConfig(
            name="seaad",
            label="SEA-AD human microglia",
            species="human",
            source_h5ad=root / "SEAAD_human_microglia.h5ad",
            final_h5ad=root
            / "results"
            / "seaad_microglia_fixed"
            / "objects"
            / "seaad_microglia_fixed_microglia_final.h5ad",
            marker_csv=root
            / "results"
            / "seaad_microglia_fixed"
            / "tables"
            / "seaad_microglia_fixed_microglia_state_markers.csv",
            default_sample_column="sample_name",
        ),
        DatasetConfig(
            name="olah",
            label="Olah human microglia",
            species="human",
            source_h5ad=root / "olah_live_human_microglia_symbols.h5ad",
            final_h5ad=root
            / "results"
            / "olah_microglia_fixed"
            / "objects"
            / "olah_microglia_fixed_microglia_final.h5ad",
            marker_csv=root
            / "results"
            / "olah_microglia_fixed"
            / "tables"
            / "olah_microglia_fixed_microglia_state_markers.csv",
            default_sample_column="donor_id",
        ),
        DatasetConfig(
            name="gse98969",
            label="GSE98969 mouse microglia",
            species="mouse",
            source_h5ad=root / "gse98969_work_fixed" / "processed" / "GSE98969_combined.h5ad",
            final_h5ad=root
            / "results"
            / "gse98969_microglia_fixed"
            / "objects"
            / "gse98969_microglia_fixed_microglia_final.h5ad",
            marker_csv=root
            / "results"
            / "gse98969_microglia_fixed"
            / "tables"
            / "gse98969_microglia_fixed_microglia_state_markers.csv",
            default_sample_column="sample_id",
        ),
        DatasetConfig(
            name="gse140510",
            label="GSE140510 mouse microglia",
            species="mouse",
            source_h5ad=root / "data_processed" / "GSE140510_mouse_combined.h5ad",
            final_h5ad=root
            / "results"
            / "gse140510_mouse_microglia_fixed"
            / "objects"
            / "gse140510_mouse_microglia_fixed_microglia_final.h5ad",
            marker_csv=root
            / "results"
            / "gse140510_mouse_microglia_fixed"
            / "tables"
            / "gse140510_mouse_microglia_fixed_microglia_state_markers.csv",
            default_sample_column="sample_id",
        ),
    ]


def panel_for_species(species: str) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for row in TF_ROWS:
        for gene in row[species]:
            rows.append(
                {
                    "family": row["family"],
                    "category": row["category"],
                    "gene": gene,
                    "comment": row["comment"],
                }
            )
    return rows


def all_genes_for_species(species: str) -> list[str]:
    return [row["gene"] for row in panel_for_species(species)]


def matrix_to_dense(x) -> np.ndarray:
    if sparse.issparse(x):
        return x.toarray()
    return np.asarray(x)


def count_nonzero_vector(x) -> int:
    if sparse.issparse(x):
        return int(x.nnz)
    return int(np.count_nonzero(np.asarray(x)))


def safe_float(value) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return math.nan


def infer_column(columns: Iterable[str], preferred: str | None, candidates: list[str]) -> str | None:
    columns = list(columns)
    if preferred and preferred in columns:
        return preferred
    for col in candidates:
        if col in columns:
            return col
    lower = {c.lower(): c for c in columns}
    for col in candidates:
        if col.lower() in lower:
            return lower[col.lower()]
    return None


def h5ad_detection(path: Path, dataset: DatasetConfig, object_level: str) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame(
            [
                {
                    "dataset": dataset.name,
                    "dataset_label": dataset.label,
                    "species": dataset.species,
                    "object_level": object_level,
                    "path": str(path),
                    "family": row["family"],
                    "category": row["category"],
                    "gene": row["gene"],
                    "present": False,
                    "n_cells": 0,
                    "n_genes_total": 0,
                    "nonzero_cells": 0,
                    "detection_pct": math.nan,
                    "note": "file_missing",
                }
                for row in panel_for_species(dataset.species)
            ]
        )

    log(f"Reading {object_level} h5ad detection: {path}")
    adata = ad.read_h5ad(path, backed="r")
    var_names = set(map(str, adata.var_names))
    rows = []
    for row in panel_for_species(dataset.species):
        gene = row["gene"]
        present = gene in var_names
        nonzero = 0
        pct = math.nan
        note = ""
        if present:
            try:
                x = adata[:, [gene]].X
                nonzero = count_nonzero_vector(x)
                pct = 100.0 * nonzero / adata.n_obs if adata.n_obs else math.nan
            except Exception as exc:  # pragma: no cover - defensive for backed edge cases
                note = f"detection_error:{type(exc).__name__}:{str(exc)[:120]}"
        rows.append(
            {
                "dataset": dataset.name,
                "dataset_label": dataset.label,
                "species": dataset.species,
                "object_level": object_level,
                "path": str(path),
                "family": row["family"],
                "category": row["category"],
                "gene": gene,
                "present": present,
                "n_cells": int(adata.n_obs),
                "n_genes_total": int(adata.n_vars),
                "nonzero_cells": int(nonzero),
                "detection_pct": pct,
                "note": note,
            }
        )
    adata.file.close()
    return pd.DataFrame(rows)


def read_10x_features(features_path: Path) -> tuple[list[str], dict[str, list[int]]]:
    genes: list[str] = []
    gene_to_indices: dict[str, list[int]] = {}
    with gzip.open(features_path, "rt", encoding="utf-8", errors="ignore") as handle:
        for idx, line in enumerate(handle, start=1):
            parts = line.rstrip("\n").split("\t")
            names = []
            if parts:
                names.append(parts[0])
            if len(parts) > 1:
                names.append(parts[1])
            gene_name = parts[1] if len(parts) > 1 else parts[0]
            genes.append(gene_name)
            for name in names:
                gene_to_indices.setdefault(name, []).append(idx)
    return genes, gene_to_indices


def read_mtx_nonzero_by_rows(matrix_path: Path, target_rows: set[int]) -> tuple[int, int, dict[int, int]]:
    """Return n_genes, n_cells, and nonzero-cell counts for selected 1-based rows."""
    row_to_cells: dict[int, set[int]] = {row: set() for row in target_rows}
    with gzip.open(matrix_path, "rt", encoding="utf-8", errors="ignore") as handle:
        dims = None
        for line in handle:
            if line.startswith("%"):
                continue
            dims = line.strip().split()
            break
        if not dims or len(dims) < 3:
            raise ValueError(f"Could not read Matrix Market dimensions from {matrix_path}")
        n_genes, n_cells, _ = map(int, dims[:3])
        for line in handle:
            if not line.strip():
                continue
            i_str, j_str, value_str = line.split()[:3]
            i = int(i_str)
            if i not in target_rows:
                continue
            value = float(value_str)
            if value != 0:
                row_to_cells[i].add(int(j_str))
    return n_genes, n_cells, {row: len(cells) for row, cells in row_to_cells.items()}


def summarize_gse140510_raw_10x(root: Path) -> pd.DataFrame:
    raw_dir = root / "data_raw" / "GSE140510_RAW"
    dataset = "gse140510"
    species = "mouse"
    panel = panel_for_species(species)
    rows = []

    features_paths = sorted(raw_dir.glob("*_features.tsv.gz"))
    if not features_paths:
        return pd.DataFrame()

    for features_path in features_paths:
        sample = features_path.name.replace("_features.tsv.gz", "")
        matrix_path = raw_dir / f"{sample}_matrix.mtx.gz"
        barcodes_path = raw_dir / f"{sample}_barcodes.tsv.gz"
        log(f"Checking raw 10x TF detection: {sample}")
        _, gene_to_indices = read_10x_features(features_path)

        target_rows: set[int] = set()
        gene_to_rows: dict[str, list[int]] = {}
        for tf in panel:
            indices = gene_to_indices.get(tf["gene"], [])
            gene_to_rows[tf["gene"]] = indices
            target_rows.update(indices)

        n_genes = 0
        n_cells = 0
        nonzero_by_row: dict[int, int] = {}
        matrix_note = ""
        if matrix_path.exists() and target_rows:
            n_genes, n_cells, nonzero_by_row = read_mtx_nonzero_by_rows(matrix_path, target_rows)
        elif matrix_path.exists():
            # Read dimensions even when no target rows are present.
            n_genes, n_cells, nonzero_by_row = read_mtx_nonzero_by_rows(matrix_path, set())
        else:
            matrix_note = "matrix_missing"
            if barcodes_path.exists():
                with gzip.open(barcodes_path, "rt", encoding="utf-8", errors="ignore") as handle:
                    n_cells = sum(1 for _ in handle)

        for tf in panel:
            indices = gene_to_rows[tf["gene"]]
            nonzero = sum(nonzero_by_row.get(idx, 0) for idx in indices)
            rows.append(
                {
                    "dataset": dataset,
                    "dataset_label": "GSE140510 mouse raw 10x",
                    "species": species,
                    "sample": sample,
                    "family": tf["family"],
                    "category": tf["category"],
                    "gene": tf["gene"],
                    "present_in_features": bool(indices),
                    "feature_row_indices": ";".join(map(str, indices)),
                    "n_cells": n_cells,
                    "n_genes_total": n_genes,
                    "nonzero_cells": nonzero,
                    "detection_pct": 100.0 * nonzero / n_cells if n_cells else math.nan,
                    "note": matrix_note,
                }
            )
    return pd.DataFrame(rows)


def summarize_gse98969_raw_matrices(root: Path) -> pd.DataFrame:
    raw_dir = root / "gse98969_work_fixed" / "extracted"
    paths = sorted(raw_dir.glob("GSM*.txt.gz"))
    species = "mouse"
    panel = panel_for_species(species)
    target_set = {tf["gene"] for tf in panel}
    panel_by_gene = {tf["gene"]: tf for tf in panel}

    aggregate = {
        gene: {
            "files_with_row": 0,
            "total_cells": 0,
            "nonzero_cells": 0,
            "per_file_pct": [],
            "samples_present": [],
        }
        for gene in target_set
    }

    sample_rows = []
    if not paths:
        return pd.DataFrame()

    for path in paths:
        sample = path.name.replace(".txt.gz", "")
        log(f"Checking GSE98969 raw matrix TF rows: {sample}")
        sample_seen: set[str] = set()
        with gzip.open(path, "rt", encoding="utf-8", errors="ignore") as handle:
            try:
                header = next(handle).rstrip("\n").split("\t")
            except StopIteration:
                continue
            n_cells = len(header)
            for line in handle:
                gene, sep, values_text = line.partition("\t")
                if not sep or gene not in target_set:
                    continue
                values = values_text.rstrip("\n").split("\t")
                nonzero = sum(1 for value in values if value not in {"", "0", "0.0"})
                sample_seen.add(gene)
                aggregate[gene]["files_with_row"] += 1
                aggregate[gene]["total_cells"] += n_cells
                aggregate[gene]["nonzero_cells"] += nonzero
                aggregate[gene]["per_file_pct"].append(100.0 * nonzero / n_cells if n_cells else math.nan)
                aggregate[gene]["samples_present"].append(sample)
                tf = panel_by_gene[gene]
                sample_rows.append(
                    {
                        "dataset": "gse98969",
                        "dataset_label": "GSE98969 mouse raw extracted matrices",
                        "species": species,
                        "sample": sample,
                        "family": tf["family"],
                        "category": tf["category"],
                        "gene": gene,
                        "present_in_matrix": True,
                        "n_cells": n_cells,
                        "nonzero_cells": nonzero,
                        "detection_pct": 100.0 * nonzero / n_cells if n_cells else math.nan,
                    }
                )

        missing = target_set - sample_seen
        for gene in missing:
            tf = panel_by_gene[gene]
            sample_rows.append(
                {
                    "dataset": "gse98969",
                    "dataset_label": "GSE98969 mouse raw extracted matrices",
                    "species": species,
                    "sample": sample,
                    "family": tf["family"],
                    "category": tf["category"],
                    "gene": gene,
                    "present_in_matrix": False,
                    "n_cells": n_cells,
                    "nonzero_cells": 0,
                    "detection_pct": math.nan,
                }
            )

    summary_rows = []
    for gene, stats in aggregate.items():
        tf = panel_by_gene[gene]
        total_cells = int(stats["total_cells"])
        nonzero_cells = int(stats["nonzero_cells"])
        pcts = [x for x in stats["per_file_pct"] if not math.isnan(x)]
        summary_rows.append(
            {
                "dataset": "gse98969",
                "dataset_label": "GSE98969 mouse raw extracted matrices",
                "species": species,
                "sample": "ALL_RAW_MATRICES",
                "family": tf["family"],
                "category": tf["category"],
                "gene": gene,
                "present_in_matrix": stats["files_with_row"] > 0,
                "files_with_row": stats["files_with_row"],
                "n_files_total": len(paths),
                "n_cells": total_cells,
                "nonzero_cells": nonzero_cells,
                "detection_pct": 100.0 * nonzero_cells / total_cells if total_cells else math.nan,
                "median_file_detection_pct": float(np.median(pcts)) if pcts else math.nan,
                "max_file_detection_pct": float(np.max(pcts)) if pcts else math.nan,
            }
        )

    return pd.concat([pd.DataFrame(sample_rows), pd.DataFrame(summary_rows)], ignore_index=True)


def expression_frame(adata, genes: list[str]) -> pd.DataFrame:
    present = [gene for gene in genes if gene in set(map(str, adata.var_names))]
    if not present:
        return pd.DataFrame(index=adata.obs_names)
    x = matrix_to_dense(adata[:, present].X)
    return pd.DataFrame(x, index=adata.obs_names, columns=present)


def final_state_expression(dataset: DatasetConfig) -> pd.DataFrame:
    if not dataset.final_h5ad.exists():
        return pd.DataFrame()
    log(f"Summarizing TF expression by state: {dataset.name}")
    adata = ad.read_h5ad(dataset.final_h5ad, backed="r")
    genes = all_genes_for_species(dataset.species)
    expr = expression_frame(adata, genes)
    obs = adata.obs.copy()
    state_col = infer_column(obs.columns, None, STATE_CANDIDATES)
    if state_col is None:
        obs["all_cells"] = "all_cells"
        state_col = "all_cells"

    panel_by_gene = {tf["gene"]: tf for tf in panel_for_species(dataset.species)}
    rows = []
    if not expr.empty:
        grouped = obs[state_col].astype(str)
        for gene in expr.columns:
            tf = panel_by_gene[gene]
            tmp = pd.DataFrame({"state": grouped.values, "expr": expr[gene].values})
            stats = tmp.groupby("state")["expr"].agg(["count", "mean", "median"]).reset_index()
            for _, row in stats.iterrows():
                state_mask = tmp["state"] == row["state"]
                rows.append(
                    {
                        "dataset": dataset.name,
                        "dataset_label": dataset.label,
                        "species": dataset.species,
                        "state_column": state_col,
                        "state": row["state"],
                        "family": tf["family"],
                        "category": tf["category"],
                        "gene": gene,
                        "n_cells": int(row["count"]),
                        "mean_expression": float(row["mean"]),
                        "median_expression": float(row["median"]),
                        "state_detection_pct": float(100.0 * np.count_nonzero(tmp.loc[state_mask, "expr"]) / row["count"]),
                    }
                )
    adata.file.close()
    return pd.DataFrame(rows)


def marker_table_summary(dataset: DatasetConfig) -> pd.DataFrame:
    panel = panel_for_species(dataset.species)
    if not dataset.marker_csv.exists():
        return pd.DataFrame(
            [
                {
                    "dataset": dataset.name,
                    "dataset_label": dataset.label,
                    "species": dataset.species,
                    "family": tf["family"],
                    "category": tf["category"],
                    "gene": tf["gene"],
                    "marker_rows": 0,
                    "note": "marker_csv_missing",
                }
                for tf in panel
            ]
        )

    log(f"Summarizing marker-table TF state associations: {dataset.name}")
    markers = pd.read_csv(dataset.marker_csv)
    if "names" not in markers.columns:
        return pd.DataFrame()

    rows = []
    for tf in panel:
        gene = tf["gene"]
        subset = markers.loc[markers["names"].astype(str) == gene].copy()
        if subset.empty:
            rows.append(
                {
                    "dataset": dataset.name,
                    "dataset_label": dataset.label,
                    "species": dataset.species,
                    "family": tf["family"],
                    "category": tf["category"],
                    "gene": gene,
                    "marker_rows": 0,
                    "n_positive_fdr_states": 0,
                    "positive_fdr_states": "",
                    "top_positive_state": "",
                    "top_positive_logfoldchange": math.nan,
                    "top_positive_padj": math.nan,
                    "largest_abs_effect_state": "",
                    "largest_abs_logfoldchange": math.nan,
                    "largest_abs_padj": math.nan,
                    "note": "gene_not_in_marker_table",
                }
            )
            continue

        subset["logfoldchanges_num"] = subset["logfoldchanges"].map(safe_float)
        subset["pvals_adj_num"] = subset["pvals_adj"].map(safe_float)
        positive = subset.loc[(subset["logfoldchanges_num"] > 0) & (subset["pvals_adj_num"] < 0.05)]

        top_positive_state = ""
        top_positive_lfc = math.nan
        top_positive_padj = math.nan
        if not positive.empty:
            best_pos = positive.sort_values(["logfoldchanges_num", "pvals_adj_num"], ascending=[False, True]).iloc[0]
            top_positive_state = str(best_pos.get("group", ""))
            top_positive_lfc = float(best_pos["logfoldchanges_num"])
            top_positive_padj = float(best_pos["pvals_adj_num"])

        abs_subset = subset.assign(abs_lfc=subset["logfoldchanges_num"].abs())
        abs_subset = abs_subset.sort_values("abs_lfc", ascending=False)
        best_abs = abs_subset.iloc[0]

        rows.append(
            {
                "dataset": dataset.name,
                "dataset_label": dataset.label,
                "species": dataset.species,
                "family": tf["family"],
                "category": tf["category"],
                "gene": gene,
                "marker_rows": int(len(subset)),
                "n_positive_fdr_states": int(len(positive)),
                "positive_fdr_states": ";".join(map(str, positive.get("group", pd.Series(dtype=str)).tolist())),
                "top_positive_state": top_positive_state,
                "top_positive_logfoldchange": top_positive_lfc,
                "top_positive_padj": top_positive_padj,
                "largest_abs_effect_state": str(best_abs.get("group", "")),
                "largest_abs_logfoldchange": float(best_abs["logfoldchanges_num"]),
                "largest_abs_padj": float(best_abs["pvals_adj_num"]),
                "note": "",
            }
        )
    return pd.DataFrame(rows)


def sample_level_correlations(dataset: DatasetConfig) -> pd.DataFrame:
    if not dataset.final_h5ad.exists():
        return pd.DataFrame()
    log(f"Computing sample-level TF/module correlations: {dataset.name}")
    adata = ad.read_h5ad(dataset.final_h5ad, backed="r")
    obs = adata.obs.copy()
    sample_col = infer_column(obs.columns, dataset.default_sample_column, SAMPLE_CANDIDATES)
    if sample_col is None:
        obs["all_cells"] = "all_cells"
        sample_col = "all_cells"

    module_cols = [col for col in MODULE_SCORE_CANDIDATES if col in obs.columns]
    if not module_cols:
        adata.file.close()
        return pd.DataFrame()

    genes = all_genes_for_species(dataset.species)
    expr = expression_frame(adata, genes)
    adata.file.close()
    if expr.empty:
        return pd.DataFrame()

    panel_by_gene = {tf["gene"]: tf for tf in panel_for_species(dataset.species)}
    sample_values = obs[[sample_col] + module_cols].copy()
    sample_values[sample_col] = sample_values[sample_col].astype(str)
    sample_values = pd.concat([sample_values.reset_index(drop=True), expr.reset_index(drop=True)], axis=1)
    grouped = sample_values.groupby(sample_col).mean(numeric_only=True)

    rows = []
    for gene in expr.columns:
        tf = panel_by_gene[gene]
        for module_col in module_cols:
            pair = grouped[[gene, module_col]].dropna()
            n = int(len(pair))
            rho = math.nan
            pvalue = math.nan
            if n >= 3 and pair[gene].nunique() > 1 and pair[module_col].nunique() > 1:
                rho, pvalue = spearmanr(pair[gene], pair[module_col])
            rows.append(
                {
                    "dataset": dataset.name,
                    "dataset_label": dataset.label,
                    "species": dataset.species,
                    "sample_column": sample_col,
                    "n_samples": n,
                    "family": tf["family"],
                    "category": tf["category"],
                    "gene": gene,
                    "module_score": module_col,
                    "spearman_rho": rho,
                    "spearman_pvalue": pvalue,
                    "interpretation": interpret_correlation(gene, module_col, rho, n),
                }
            )
    return pd.DataFrame(rows)


def interpret_correlation(gene: str, module_col: str, rho: float, n: int) -> str:
    if n < 3 or math.isnan(rho):
        return "not_enough_sample_variation"
    abs_rho = abs(rho)
    if abs_rho >= 0.7:
        strength = "strong"
    elif abs_rho >= 0.4:
        strength = "moderate"
    elif abs_rho >= 0.2:
        strength = "weak"
    else:
        strength = "minimal"
    direction = "positive" if rho > 0 else "negative"
    return f"{strength}_{direction}_sample_level_association_with_{module_col}"


def detection_matrix(final_detection: pd.DataFrame) -> pd.DataFrame:
    if final_detection.empty:
        return pd.DataFrame()
    tmp = final_detection.copy()
    tmp["gene_label"] = tmp["family"] + " [" + tmp["gene"] + "]"
    return tmp.pivot_table(
        index=["dataset", "dataset_label"],
        columns="gene_label",
        values="detection_pct",
        aggfunc="first",
    ).reset_index()


def scenic_manifest(configs: list[DatasetConfig], out_dir: Path) -> pd.DataFrame:
    rows = []
    for cfg in configs:
        dataset_out = out_dir / "scenic_inputs" / cfg.name
        loom_path = dataset_out / f"{cfg.name}.expr.loom"
        metadata_path = dataset_out / f"{cfg.name}.metadata.csv"
        rows.append(
            {
                "dataset": cfg.name,
                "dataset_label": cfg.label,
                "species": cfg.species,
                "input_h5ad": str(cfg.final_h5ad),
                "suggested_loom": str(loom_path),
                "suggested_metadata_csv": str(metadata_path),
                "target_tf_genes": ",".join(all_genes_for_species(cfg.species)),
                "suggested_pyscenic_command": (
                    "Use run_pyscenic_miniforge.ps1 with "
                    f"-Species {cfg.species} -DatasetName {cfg.name} -InputH5ad \"{cfg.final_h5ad}\""
                ),
            }
        )
    return pd.DataFrame(rows)


def export_scenic_inputs(configs: list[DatasetConfig], out_dir: Path) -> None:
    for cfg in configs:
        dataset_out = out_dir / "scenic_inputs" / cfg.name
        ensure_dir(dataset_out)
        loom_path = dataset_out / f"{cfg.name}.expr.loom"
        metadata_path = dataset_out / f"{cfg.name}.metadata.csv"
        log(f"Exporting SCENIC input loom: {cfg.name}")
        try:
            adata = ad.read_h5ad(cfg.final_h5ad)
            if "counts" in adata.layers:
                adata.X = adata.layers["counts"].copy()
            elif adata.raw is not None:
                adata = adata.raw.to_adata()
            adata.var_names_make_unique()
            adata.obs_names_make_unique()
            adata.write_loom(loom_path, write_obsm_varm=False)
            adata.obs.to_csv(metadata_path)
        except Exception as exc:
            log(f"WARNING: could not export loom for {cfg.name}: {type(exc).__name__}: {exc}")


def write_reviewer_summary(
    out_path: Path,
    raw_gse140510: pd.DataFrame,
    raw_gse98969: pd.DataFrame,
    source_detection: pd.DataFrame,
    final_detection: pd.DataFrame,
    marker_summary: pd.DataFrame,
) -> None:
    lines = []
    lines.append("Transcription-regulator extension: reviewer-style summary")
    lines.append("")
    lines.append("Scope:")
    lines.append(
        "This analysis tests whether a focused panel of transcription regulators is present, detectable, "
        "state-associated, and suitable for a compact regulon extension of the existing AD microglia analysis."
    )
    lines.append("")
    lines.append("Focused TF/regulator panel:")
    for row in TF_ROWS:
        lines.append(f"- {row['family']} ({row['category']}): {row['comment']}")
    lines.append("")

    if not raw_gse140510.empty:
        raw_summary = (
            raw_gse140510.groupby("gene")["present_in_features"]
            .agg(["sum", "count"])
            .reset_index()
            .sort_values("gene")
        )
        lines.append("Raw GSE140510 10x files:")
        for _, row in raw_summary.iterrows():
            lines.append(f"- {row['gene']}: present in {int(row['sum'])}/{int(row['count'])} feature files")
        lines.append("")

    if not raw_gse98969.empty:
        all_rows = raw_gse98969.loc[raw_gse98969.get("sample", "") == "ALL_RAW_MATRICES"]
        if not all_rows.empty:
            lines.append("Raw GSE98969 extracted matrices:")
            for _, row in all_rows.sort_values("gene").iterrows():
                det = row.get("detection_pct", math.nan)
                det_text = "NA" if math.isnan(det) else f"{det:.2f}%"
                files = int(row.get("files_with_row", 0))
                total = int(row.get("n_files_total", 0))
                lines.append(f"- {row['gene']}: row present in {files}/{total} matrices; aggregate detection {det_text}")
            lines.append("")

    if not final_detection.empty:
        lines.append("Final analysis objects:")
        for dataset, sub in final_detection.groupby("dataset"):
            present = sub.loc[sub["present"], "gene"].tolist()
            sparse_genes = sub.loc[(sub["present"]) & (sub["detection_pct"] < 5), "gene"].tolist()
            lines.append(f"- {dataset}: present genes: {', '.join(present) if present else 'none'}")
            if sparse_genes:
                lines.append(f"  Low-detection genes (<5% cells): {', '.join(sparse_genes)}")
        lines.append("")

    if not marker_summary.empty:
        lines.append("State-marker support:")
        for dataset, sub in marker_summary.groupby("dataset"):
            supported = sub.loc[sub.get("n_positive_fdr_states", 0) > 0, "gene"].tolist()
            lines.append(
                f"- {dataset}: positive FDR<0.05 state associations for "
                f"{', '.join(supported) if supported else 'none of the focused panel'}"
            )
        lines.append("")

    lines.append("Unbiased conclusion:")
    lines.append(
        "The datasets support a transcription-regulator extension, especially for interferon and myeloid "
        "state regulators. The evidence does not yet justify reframing the manuscript around master regulators. "
        "The strongest conservative claim is that candidate TF expression and regulon activity can be used as "
        "an orthogonal layer to refine the existing microglial program model."
    )
    lines.append("")
    lines.append("Recommended manuscript integration:")
    lines.append(
        "Add this as one supplementary figure or one extension panel: TF detectability, TF expression by state, "
        "sample-level TF-module correlations, and optional pySCENIC AUCell activity for recovered regulons."
    )

    out_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run focused transcription-regulator extension analyses on the existing AD microglia datasets."
    )
    parser.add_argument(
        "--mam-san-root",
        default=r"F:\AD\Mam San",
        help="Root folder containing the original Mam San analysis files.",
    )
    parser.add_argument(
        "--out",
        default=None,
        help="Output directory. Defaults to <mam-san-root>/results/tf_regulator_extension.",
    )
    parser.add_argument(
        "--skip-raw-matrix-checks",
        action="store_true",
        help="Skip raw 10x/GSE98969 matrix detection checks and only use h5ad/results objects.",
    )
    parser.add_argument(
        "--export-scenic-inputs",
        action="store_true",
        help="Export final h5ad objects to loom and metadata CSV for downstream pySCENIC.",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv or sys.argv[1:])
    root = Path(args.mam_san_root)
    out_dir = Path(args.out) if args.out else root / "results" / "tf_regulator_extension"
    ensure_dir(out_dir)

    configs = dataset_configs(root)
    missing = [str(cfg.final_h5ad) for cfg in configs if not cfg.final_h5ad.exists()]
    if missing:
        log("WARNING: missing final h5ad files:")
        for path in missing:
            log(f"  - {path}")

    raw_gse140510 = pd.DataFrame()
    raw_gse98969 = pd.DataFrame()
    if not args.skip_raw_matrix_checks:
        raw_gse140510 = summarize_gse140510_raw_10x(root)
        raw_gse140510.to_csv(out_dir / "01_raw_gse140510_10x_tf_detection.csv", index=False)

        raw_gse98969 = summarize_gse98969_raw_matrices(root)
        raw_gse98969.to_csv(out_dir / "02_raw_gse98969_matrix_tf_detection.csv", index=False)
    else:
        log("Skipping raw matrix checks by request.")

    source_detection = pd.concat(
        [h5ad_detection(cfg.source_h5ad, cfg, "source_h5ad") for cfg in configs],
        ignore_index=True,
    )
    source_detection.to_csv(out_dir / "03_source_h5ad_tf_detection.csv", index=False)

    final_detection = pd.concat(
        [h5ad_detection(cfg.final_h5ad, cfg, "final_microglia_h5ad") for cfg in configs],
        ignore_index=True,
    )
    final_detection.to_csv(out_dir / "04_final_h5ad_tf_detection.csv", index=False)

    state_expression = pd.concat([final_state_expression(cfg) for cfg in configs], ignore_index=True)
    state_expression.to_csv(out_dir / "05_final_state_tf_mean_expression.csv", index=False)

    marker_summary = pd.concat([marker_table_summary(cfg) for cfg in configs], ignore_index=True)
    marker_summary.to_csv(out_dir / "06_marker_table_tf_state_summary.csv", index=False)

    correlations = pd.concat([sample_level_correlations(cfg) for cfg in configs], ignore_index=True)
    correlations.to_csv(out_dir / "07_sample_level_tf_module_correlations.csv", index=False)

    det_matrix = detection_matrix(final_detection)
    det_matrix.to_csv(out_dir / "08_tf_detection_matrix_final.csv", index=False)

    manifest = scenic_manifest(configs, out_dir)
    manifest.to_csv(out_dir / "09_scenic_extension_manifest.csv", index=False)

    if args.export_scenic_inputs:
        export_scenic_inputs(configs, out_dir)

    write_reviewer_summary(
        out_dir / "10_reviewer_summary.txt",
        raw_gse140510,
        raw_gse98969,
        source_detection,
        final_detection,
        marker_summary,
    )

    log("")
    log(f"Done. Wrote TF-regulator extension outputs to: {out_dir}")
    log("Start with 10_reviewer_summary.txt, then inspect 04/06/07 for figure-ready evidence.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
