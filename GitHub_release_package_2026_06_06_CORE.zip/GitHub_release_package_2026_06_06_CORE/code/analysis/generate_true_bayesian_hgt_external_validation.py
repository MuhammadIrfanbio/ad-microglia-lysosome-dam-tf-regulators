#!/usr/bin/env python3
"""
Train the final true Bayesian HGT model on SEA-AD and externally validate it
on Olah, GSE98969, and GSE140510 microglia.

This script is a second-stage companion to:
  generate_true_bayesian_hgt_results.py

It reuses the same feature definitions, Bayesian HGT architecture, MC-dropout
posterior prediction, and remodeled-state target definition. The difference is
the validation design:

  1. Train final models on SEA-AD microglia.
  2. Map the same gene/program/context feature schema into external datasets.
  3. Predict remodeled-state labels for external cells.
  4. Write AUROC, AUPRC, F1, and balanced accuracy CSVs for Panel C.

Run:
  "C:\\ProgramData\\miniforge3\\python.exe" "F:\\AD\\Mam San\\generate_true_bayesian_hgt_external_validation.py" --epochs 120 --mc-samples 50

Fast smoke test:
  "C:\\ProgramData\\miniforge3\\python.exe" "F:\\AD\\Mam San\\generate_true_bayesian_hgt_external_validation.py" --epochs 5 --mc-samples 5 --max-train-cells 800 --max-external-cells 1500
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

if sys.platform.startswith("win"):
    # Miniforge can be called from a different active conda environment. Make
    # the DLL search path behave like activated Miniforge before importing torch.
    os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
    py_root = Path(sys.executable).resolve().parent
    dll_dirs = [
        py_root / "Library" / "bin",
        py_root / "DLLs",
        py_root / "Lib" / "site-packages" / "torch" / "lib",
    ]
    for dll_dir in reversed([d for d in dll_dirs if d.exists()]):
        os.environ["PATH"] = str(dll_dir) + os.pathsep + os.environ.get("PATH", "")
    if (py_root / "Lib" / "site-packages" / "torch" / "lib").exists() and os.environ.get("BAYESIAN_HGT_DLL_REEXEC") != "1":
        os.environ["BAYESIAN_HGT_DLL_REEXEC"] = "1"
        raise SystemExit(subprocess.call([sys.executable, str(Path(__file__).resolve()), *sys.argv[1:]], env=os.environ))
    for dll_dir in dll_dirs:
        if dll_dir.exists():
            try:
                os.add_dll_directory(str(dll_dir))
            except (AttributeError, OSError):
                pass

try:
    import torch
    import anndata as ad
    import numpy as np
    import pandas as pd
except ImportError as exc:
    raise SystemExit(
        "This script needs the Miniforge environment with torch/anndata/pandas.\n"
        'Run with: "C:\\ProgramData\\miniforge3\\python.exe" '
        '"F:\\AD\\Mam San\\generate_true_bayesian_hgt_external_validation.py" --epochs 120 --mc-samples 50'
    ) from exc

import generate_true_bayesian_hgt_results as hgt


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results" / "bayesian_hgt_true_external_validation"
OUT.mkdir(parents=True, exist_ok=True)

EXTERNAL_DATASETS = {
    "olah": {
        "label": "Olah live human microglia",
        "species": "human",
        "h5ad": ROOT / "results" / "olah_microglia_fixed" / "objects" / "olah_microglia_fixed_microglia_final.h5ad",
        "sample_col": "donor_id",
        "region_col": "tissue",
        "sex_col": "sex",
    },
    "gse98969": {
        "label": "GSE98969 mouse AD model",
        "species": "mouse",
        "h5ad": ROOT / "results" / "gse98969_microglia_fixed" / "objects" / "gse98969_microglia_fixed_microglia_final.h5ad",
        "sample_col": "sample_id",
        "region_col": "analysis_group",
        "sex_col": None,
    },
    "gse140510": {
        "label": "GSE140510 Trem2-linked mouse model",
        "species": "mouse",
        "h5ad": ROOT / "results" / "gse140510_mouse_microglia_fixed" / "objects" / "gse140510_mouse_microglia_fixed_microglia_final.h5ad",
        "sample_col": "sample_id",
        "region_col": "batch",
        "sex_col": None,
    },
}

MOUSE_ORTHOLOG = {
    "BACE1": "Bace1",
    "ZNF335": "Zfp335",
    "APOE": "Apoe",
    "TREM2": "Trem2",
    "TYROBP": "Tyrobp",
    "LPL": "Lpl",
    "CTSB": "Ctsb",
    "CTSD": "Ctsd",
    "LAMP1": "Lamp1",
    "LAMP2": "Lamp2",
    "CD68": "Cd68",
    "CST7": "Cst7",
    "P2RY12": "P2ry12",
    "TMEM119": "Tmem119",
    "CX3CR1": "Cx3cr1",
    "CSF1R": "Csf1r",
    "ISG15": "Isg15",
    "IFIT3": "Ifit3",
    "ITGAX": "Itgax",
    "AXL": "Axl",
    "GPNMB": "Gpnmb",
}


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="External validation for true Bayesian HGT model")
    p.add_argument("--epochs", type=int, default=120)
    p.add_argument("--patience", type=int, default=18)
    p.add_argument("--batch-size", type=int, default=256)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--weight-decay", type=float, default=1e-4)
    p.add_argument("--dropout", type=float, default=0.25)
    p.add_argument("--d-model", type=int, default=64)
    p.add_argument("--n-heads", type=int, default=4)
    p.add_argument("--n-layers", type=int, default=2)
    p.add_argument("--mc-samples", type=int, default=50)
    p.add_argument("--seed", type=int, default=7)
    p.add_argument("--max-train-cells", type=int, default=None, help="Optional SEA-AD downsampling for smoke tests")
    p.add_argument("--max-external-cells", type=int, default=None, help="Optional per-dataset downsampling for smoke tests")
    p.add_argument("--models", nargs="+", default=["gene_program_no_context", "full_bayesian_hgt"], help="Model keys to train/evaluate")
    p.add_argument("--cpu", action="store_true", help="Force CPU even if CUDA exists")
    return p.parse_args()


def dense(X) -> np.ndarray:
    return hgt.dense(X)


def resolve_gene(adata: ad.AnnData, canonical_gene: str, species: str) -> str | None:
    names = set(map(str, adata.var_names))
    candidates = [canonical_gene]
    if species == "mouse":
        candidates.insert(0, MOUSE_ORTHOLOG.get(canonical_gene, canonical_gene.capitalize()))
    else:
        candidates.extend([canonical_gene.upper(), canonical_gene.capitalize()])
    for gene in candidates:
        if gene in names:
            return gene
    return None


def external_expression_matrix(adata: ad.AnnData, canonical_genes: list[str], species: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    expr = pd.DataFrame(index=adata.obs_names)
    coverage_rows = []
    for canonical in canonical_genes:
        actual = resolve_gene(adata, canonical, species)
        if actual is None:
            expr[canonical] = 0.0
            coverage_rows.append(
                {
                    "canonical_gene": canonical,
                    "mapped_gene": "",
                    "present": False,
                    "detection_pct_nonzero": 0.0,
                    "mean_expression": 0.0,
                }
            )
            continue
        values = dense(adata[:, [actual]].X).ravel().astype(float)
        expr[canonical] = values
        coverage_rows.append(
            {
                "canonical_gene": canonical,
                "mapped_gene": actual,
                "present": True,
                "detection_pct_nonzero": float((values > 0).mean() * 100),
                "mean_expression": float(np.mean(values)),
            }
        )
    return expr[canonical_genes].astype(float), pd.DataFrame(coverage_rows)


def make_external_feature_table(dataset_key: str, spec: dict, max_cells: int | None, seed: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    path = Path(spec["h5ad"])
    if not path.exists():
        raise FileNotFoundError(path)
    adata = ad.read_h5ad(path)
    obs = adata.obs.copy()
    obs["cell_id"] = adata.obs_names.astype(str)
    sample_col = spec.get("sample_col")
    obs["donor_id"] = obs[sample_col].astype(str) if sample_col in obs.columns else dataset_key + "_sample"
    obs["state_hint"] = obs["state_hint"].astype(str)
    obs["target"] = obs["state_hint"].isin(hgt.STATE_POSITIVE).astype(int)
    obs["target_label"] = np.where(obs["target"] == 1, "remodeled", "homeostatic_or_transitional")

    for col in hgt.PROGRAM_COLS:
        if col not in obs.columns:
            obs[col] = 0.0
        obs[col] = pd.to_numeric(obs[col], errors="coerce").fillna(0.0).astype(float)

    sex_col = spec.get("sex_col")
    region_col = spec.get("region_col")
    obs["donor_sex_label"] = obs[sex_col].astype(str) if sex_col and sex_col in obs.columns else "unknown"
    obs["age_label"] = "unknown"
    obs["age_numeric"] = 0.0
    obs["region_label"] = obs[region_col].astype(str) if region_col and region_col in obs.columns else dataset_key

    expr, coverage = external_expression_matrix(adata, hgt.GENE_FAMILIES, spec["species"])
    expr.columns = [f"gene::{c}" for c in expr.columns]

    data = pd.concat(
        [
            obs[["cell_id", "donor_id", "state_hint", "target", "target_label", "age_numeric"] + hgt.CONTEXT_COLS + hgt.PROGRAM_COLS],
            expr,
        ],
        axis=1,
    )
    data.insert(0, "dataset", dataset_key)
    data.insert(1, "dataset_label", spec["label"])
    if max_cells and len(data) > max_cells:
        # Preserve the external label balance as much as possible in smoke tests.
        data = (
            data.groupby("target", group_keys=False)
            .apply(lambda x: x.sample(min(len(x), max(1, int(max_cells * len(x) / len(data)))), random_state=seed))
            .sample(frac=1, random_state=seed)
        )
        if len(data) > max_cells:
            data = data.sample(max_cells, random_state=seed)
    coverage.insert(0, "dataset", dataset_key)
    coverage.insert(1, "dataset_label", spec["label"])
    coverage.insert(2, "species", spec["species"])
    return data.reset_index(drop=True), coverage


def train_final_model(train_df: pd.DataFrame, spec: hgt.FeatureSpec, args: argparse.Namespace, device: torch.device):
    tr_idx, val_idx = hgt.split_train_validation(train_df, args.seed)
    builder = hgt.HGTFeatureBuilder(spec).fit(train_df.iloc[tr_idx])
    tr_s, tr_t, _ = builder.transform(train_df.iloc[tr_idx])
    val_s, val_t, _ = builder.transform(train_df.iloc[val_idx])
    model = hgt.train_model(
        tr_s,
        tr_t,
        train_df.iloc[tr_idx]["target"].astype(int).values,
        val_s,
        val_t,
        train_df.iloc[val_idx]["target"].astype(int).values,
        args,
        device,
    )
    return builder, model, len(tr_s), len(val_s)


def evaluate_external_dataset(
    dataset_key: str,
    ext_df: pd.DataFrame,
    model_key: str,
    builder: hgt.HGTFeatureBuilder,
    model: hgt.BayesianHGTClassifier,
    args: argparse.Namespace,
    device: torch.device,
) -> tuple[list[dict], pd.DataFrame, list[dict], pd.DataFrame]:
    scalar, type_ids, _ = builder.transform(ext_df)
    prob, lo, hi = hgt.mc_predict(model, scalar, type_ids, args.mc_samples, args.batch_size, device)
    y = ext_df["target"].astype(int).values
    metrics = hgt.metric_rows(y, prob)
    metric_rows = []
    for metric, value in metrics.items():
        metric_rows.append(
            {
                "analysis": "true Bayesian HGT external validation",
                "train_dataset": "SEA-AD",
                "test_dataset": dataset_key,
                "test_dataset_label": ext_df["dataset_label"].iloc[0],
                "model_key": model_key,
                "metric": metric,
                "value": value,
                "n_test_cells": int(len(ext_df)),
                "n_test_samples": int(ext_df["donor_id"].nunique()),
                "n_positive_remodeled": int(y.sum()),
                "pct_positive_remodeled": float(y.mean() * 100),
            }
        )
    pred = ext_df[["dataset", "dataset_label", "cell_id", "donor_id", "state_hint", "target", "target_label"]].copy()
    pred["model_key"] = model_key
    pred["predicted_probability"] = prob
    pred["credible_interval_lower_95"] = lo
    pred["credible_interval_upper_95"] = hi
    pred["credible_interval_width_95"] = hi - lo
    pred["predictive_uncertainty_entropy"] = hgt.entropy(prob)
    pred["predicted_label"] = (prob >= 0.5).astype(int)
    pred["correct_prediction"] = pred["predicted_label"] == pred["target"]

    ece, curve = hgt.expected_calibration_error(y, prob)
    ece_rows = [
        {
            "analysis": "true Bayesian HGT external validation",
            "train_dataset": "SEA-AD",
            "test_dataset": dataset_key,
            "test_dataset_label": ext_df["dataset_label"].iloc[0],
            "model_key": model_key,
            "expected_calibration_error": ece,
            "n_test_cells": int(len(ext_df)),
        }
    ]
    curve.insert(0, "model_key", model_key)
    curve.insert(0, "test_dataset_label", ext_df["dataset_label"].iloc[0])
    curve.insert(0, "test_dataset", dataset_key)
    curve.insert(0, "train_dataset", "SEA-AD")
    return metric_rows, pred, ece_rows, curve


def main() -> None:
    args = parse_args()
    hgt.set_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() and not args.cpu else "cpu")

    train_df = hgt.load_seaad(max_cells=args.max_train_cells, seed=args.seed)
    specs = {spec.name: spec for spec in hgt.make_feature_specs() if spec.name in set(args.models)}
    if not specs:
        raise SystemExit(f"No valid models selected. Valid models: {[s.name for s in hgt.make_feature_specs()]}")

    model_rows = []
    trained = {}
    for model_key, spec in specs.items():
        print(f"Training final {model_key} on SEA-AD...")
        builder, model, n_train, n_val = train_final_model(train_df, spec, args, device)
        trained[model_key] = (builder, model)
        model_rows.append(
            {
                "model_key": model_key,
                "n_train_cells": n_train,
                "n_validation_cells": n_val,
                "n_total_seaad_cells": len(train_df),
                "n_total_seaad_samples": int(train_df["donor_id"].nunique()),
            }
        )

    metric_rows = []
    pred_tables = []
    ece_rows = []
    curve_tables = []
    coverage_tables = []
    dataset_summary_rows = []

    for dataset_key, dataset_spec in EXTERNAL_DATASETS.items():
        print(f"Loading external dataset {dataset_key}...")
        ext_df, coverage = make_external_feature_table(dataset_key, dataset_spec, args.max_external_cells, args.seed)
        coverage_tables.append(coverage)
        dataset_summary_rows.append(
            {
                "dataset": dataset_key,
                "dataset_label": dataset_spec["label"],
                "species": dataset_spec["species"],
                "h5ad": str(dataset_spec["h5ad"]),
                "n_cells": len(ext_df),
                "n_samples": int(ext_df["donor_id"].nunique()),
                "n_positive_remodeled": int(ext_df["target"].sum()),
                "pct_positive_remodeled": float(ext_df["target"].mean() * 100),
                "state_counts": json.dumps(ext_df["state_hint"].value_counts().to_dict()),
            }
        )
        for model_key, (builder, model) in trained.items():
            print(f"  Predicting {dataset_key} with {model_key}...")
            rows, pred, ece, curve = evaluate_external_dataset(dataset_key, ext_df, model_key, builder, model, args, device)
            metric_rows.extend(rows)
            pred_tables.append(pred)
            ece_rows.extend(ece)
            curve_tables.append(curve)

    metrics = pd.DataFrame(metric_rows)
    predictions = pd.concat(pred_tables, ignore_index=True) if pred_tables else pd.DataFrame()
    coverage = pd.concat(coverage_tables, ignore_index=True) if coverage_tables else pd.DataFrame()
    curves = pd.concat(curve_tables, ignore_index=True) if curve_tables else pd.DataFrame()

    metrics.to_csv(OUT / "true_bayesian_hgt_external_validation_metrics_long.csv", index=False)
    metrics[metrics["metric"].isin(["AUROC", "AUPRC", "F1", "Balanced accuracy"])].to_csv(
        OUT / "true_bayesian_hgt_external_validation_panelC_metrics.csv",
        index=False,
    )
    (
        metrics.pivot_table(
            index=["test_dataset", "test_dataset_label", "model_key"],
            columns="metric",
            values="value",
            aggfunc="first",
        )
        .reset_index()
        .to_csv(OUT / "true_bayesian_hgt_external_validation_metric_matrix.csv", index=False)
    )
    predictions.to_csv(OUT / "true_bayesian_hgt_external_validation_predictions.csv", index=False)
    pd.DataFrame(ece_rows).to_csv(OUT / "true_bayesian_hgt_external_validation_expected_calibration_error.csv", index=False)
    curves.to_csv(OUT / "true_bayesian_hgt_external_validation_calibration_curve.csv", index=False)
    coverage.to_csv(OUT / "true_bayesian_hgt_external_validation_gene_coverage.csv", index=False)
    pd.DataFrame(dataset_summary_rows).to_csv(OUT / "true_bayesian_hgt_external_validation_dataset_summary.csv", index=False)
    pd.DataFrame(model_rows).to_csv(OUT / "true_bayesian_hgt_external_validation_training_summary.csv", index=False)

    manifest = {
        "analysis": "true Bayesian HGT external validation",
        "train_dataset": "SEA-AD",
        "train_h5ad": str(hgt.SEA_AD_H5AD),
        "external_datasets": {k: {kk: str(vv) for kk, vv in spec.items()} for k, spec in EXTERNAL_DATASETS.items()},
        "target_definition": {
            "positive_class": "remodeled",
            "positive_states": hgt.STATE_POSITIVE,
            "negative_states": hgt.STATE_NEGATIVE,
        },
        "models": list(specs),
        "parameters": vars(args),
        "output_dir": str(OUT),
        "result_files": [
            "true_bayesian_hgt_external_validation_metrics_long.csv",
            "true_bayesian_hgt_external_validation_panelC_metrics.csv",
            "true_bayesian_hgt_external_validation_metric_matrix.csv",
            "true_bayesian_hgt_external_validation_predictions.csv",
            "true_bayesian_hgt_external_validation_expected_calibration_error.csv",
            "true_bayesian_hgt_external_validation_calibration_curve.csv",
            "true_bayesian_hgt_external_validation_gene_coverage.csv",
            "true_bayesian_hgt_external_validation_dataset_summary.csv",
            "true_bayesian_hgt_external_validation_training_summary.csv",
        ],
    }
    (OUT / "true_bayesian_hgt_external_validation_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    (OUT / "README_true_bayesian_hgt_external_validation.txt").write_text(
        "\n".join(
            [
                "True Bayesian HGT external-validation result files.",
                "Design: train final Bayesian HGT models on SEA-AD; test on Olah, GSE98969, and GSE140510.",
                "Labels: remodeled vs homeostatic/transitional from each dataset's existing state_hint annotations.",
                "Mouse features: mapped to human canonical gene family names with explicit mouse ortholog symbols.",
                f"Output directory: {OUT}",
            ]
        ),
        encoding="utf-8",
    )
    print(f"Wrote true Bayesian HGT external-validation results to: {OUT}")


if __name__ == "__main__":
    main()
