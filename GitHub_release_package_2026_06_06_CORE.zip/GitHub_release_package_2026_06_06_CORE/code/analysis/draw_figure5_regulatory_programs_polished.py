#!/usr/bin/env python3
"""
Draw a polished replacement Figure 5 focused on candidate regulatory programs.

This replaces the old BACE1-ZNF335-centered main figure with a stronger
program/regulator-family figure:
  A. Regulator-program activity across datasets
  B. Cross-dataset program coupling
  C. Detection-aware candidate regulator ranking
  D. Candidate regulator-family network
  E. Integrated biological model

Outputs:
  results/publication_figures/figure5_regulatory_programs_polished/
    Figure5_candidate_regulatory_programs_polished_900ppi.png
    Figure5_candidate_regulatory_programs_polished_900ppi.tiff
    Figure5_candidate_regulatory_programs_polished_editable.pdf
    Figure5A...Figure5E separate panel PNG/TIFF/PDF
"""

from __future__ import annotations

from pathlib import Path
import shutil

import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, Normalize, TwoSlopeNorm
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Patch, Circle
from matplotlib.lines import Line2D


ROOT = Path(__file__).resolve().parent
SRC6 = ROOT / "results" / "publication_figures" / "figure6_source_data"
SRC4 = ROOT / "results" / "publication_figures" / "figure4_source_data"
SRC5 = ROOT / "results" / "publication_figures" / "figure5_source_data"
OUT = ROOT / "results" / "publication_figures" / "figure5_regulatory_programs_polished"
OUT.mkdir(parents=True, exist_ok=True)

PAL = {
    "dark": "#17202A",
    "muted": "#566573",
    "grid": "#E7ECF2",
    "border": "#B8C2CC",
    "dam": "#C0392B",
    "lysosome": "#E67E22",
    "interferon": "#1F618D",
    "myeloid": "#6C3483",
    "biogenesis": "#117A65",
    "homeostatic": "#117A8B",
    "branch": "#7F8C8D",
}

FAMILY_COLORS = {
    "DAM/lipid-response": PAL["dam"],
    "Lysosome/phagosome": PAL["lysosome"],
    "Interferon/inflammatory": PAL["interferon"],
    "Myeloid TF candidates": PAL["myeloid"],
    "Lysosomal biogenesis": PAL["biogenesis"],
    "Homeostatic identity": PAL["homeostatic"],
}

DATASET_LABELS = {
    "seaad": "SEA-AD\nhuman",
    "olah": "Olah\nhuman",
    "gse98969": "GSE98969\nmouse",
    "gse140510": "GSE140510\nmouse",
}

DATASET_ORDER = ["seaad", "olah", "gse98969", "gse140510"]
PROGRAM_ORDER = [
    "DAM/lipid-response",
    "Lysosome/phagosome",
    "Interferon/inflammatory",
    "Lysosomal biogenesis",
    "Myeloid TF candidates",
]


def setup_style() -> None:
    mpl.rcParams.update(
        {
            "font.family": "Arial",
            "font.size": 8.5,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "figure.facecolor": "white",
            "savefig.facecolor": "white",
            "axes.linewidth": 0.75,
        }
    )


def clean(ax: plt.Axes) -> None:
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(PAL["dark"])
    ax.spines["bottom"].set_color(PAL["dark"])
    ax.tick_params(colors=PAL["dark"], labelsize=8)


def save(fig: plt.Figure, stem: str) -> None:
    png = OUT / f"{stem}_900ppi.png"
    tif = OUT / f"{stem}_900ppi.tiff"
    pdf = OUT / f"{stem}_editable.pdf"
    fig.savefig(png, dpi=900, bbox_inches="tight")
    fig.savefig(tif, dpi=900, bbox_inches="tight", pil_kwargs={"compression": "tiff_lzw"})
    fig.savefig(pdf, bbox_inches="tight")
    plt.close(fig)
    print(f"Wrote {png.name}, {tif.name}, {pdf.name}")


def load_activity() -> pd.DataFrame:
    mat = pd.read_csv(SRC6 / "figure6_panel_a_program_activity_row_z.csv", index_col=0)
    mat = mat.rename(columns={c: c.lower() for c in mat.columns})
    mat = mat[[c for c in DATASET_ORDER if c in mat.columns]]
    mat = mat.reindex([p for p in PROGRAM_ORDER if p in mat.index])
    return mat


def load_coupling() -> pd.DataFrame:
    corr = pd.read_csv(SRC6 / "figure6_panel_b_sample_level_program_correlations.csv")
    corr["rho"] = pd.to_numeric(corr["rho"], errors="coerce")
    corr["abs_rho"] = corr["rho"].abs()
    corr["dataset"] = corr["dataset"].astype(str).str.lower()
    return corr


def load_candidates() -> pd.DataFrame:
    rank = pd.read_csv(SRC6 / "figure6_panel_c_detection_aware_candidate_ranking.csv")
    rank["pct_nonzero"] = pd.to_numeric(rank["pct_nonzero"], errors="coerce")
    rank["priority_score"] = pd.to_numeric(rank["priority_score"], errors="coerce")
    rank["n_datasets_ge5pct"] = pd.to_numeric(rank["n_datasets_ge5pct"], errors="coerce")
    return rank.sort_values("priority_score", ascending=False)


def load_robustness() -> pd.DataFrame:
    robust = pd.read_csv(SRC6 / "figure6_program_robustness_prioritization.csv")
    for col in ["mean_detection_pct", "mean_abs_rho", "positive_association_fraction", "robustness_score"]:
        robust[col] = pd.to_numeric(robust[col], errors="coerce")
    return robust


def draw_panel_a(ax: plt.Axes) -> None:
    mat = load_activity()
    cmap = LinearSegmentedColormap.from_list("program_activity", ["#2166AC", "#F7F7F7", "#B2182B"])
    im = ax.imshow(mat.values, aspect="auto", cmap=cmap, norm=TwoSlopeNorm(vmin=-1.5, vcenter=0, vmax=1.5))
    ax.set_xticks(np.arange(len(mat.columns)))
    ax.set_xticklabels([DATASET_LABELS.get(c, c) for c in mat.columns], fontsize=8.4)
    ax.set_yticks(np.arange(len(mat.index)))
    ax.set_yticklabels(mat.index, fontsize=8.5)
    for i, fam in enumerate(mat.index):
        ax.get_yticklabels()[i].set_color(FAMILY_COLORS.get(fam, PAL["dark"]))
        ax.get_yticklabels()[i].set_fontweight("bold")
    ax.set_title("A  Regulator-program activity across datasets", loc="left", fontsize=11.5, fontweight="bold", pad=8)
    ax.set_xticks(np.arange(-0.5, len(mat.columns), 1), minor=True)
    ax.set_yticks(np.arange(-0.5, len(mat.index), 1), minor=True)
    ax.grid(which="minor", color="white", linewidth=1.2)
    ax.tick_params(length=0)
    for sp in ax.spines.values():
        sp.set_color(PAL["border"])
    return im


def draw_panel_b(ax: plt.Axes) -> None:
    corr = load_coupling()
    key_pairs = [
        "DAM/lipid-response vs Lysosome/phagosome",
        "DAM/lipid-response vs Interferon/inflammatory",
        "Lysosome/phagosome vs Interferon/inflammatory",
        "DAM/lipid-response vs Lysosomal biogenesis",
        "Lysosome/phagosome vs Lysosomal biogenesis",
    ]
    corr = corr[corr["pair"].isin(key_pairs)].copy()
    ylabels = key_pairs[::-1]
    xlabels = [d for d in DATASET_ORDER if d in set(corr["dataset"])]
    cmap = LinearSegmentedColormap.from_list("rho", ["#2166AC", "#F7F7F7", "#B2182B"])
    for xi, dataset in enumerate(xlabels):
        for yi, pair in enumerate(ylabels):
            hit = corr[(corr["dataset"] == dataset) & (corr["pair"] == pair)]
            if hit.empty or not np.isfinite(hit["rho"].iloc[0]):
                ax.scatter(xi, yi, s=95, marker="s", facecolor="#F2F4F7", edgecolor=PAL["border"], linewidth=0.7)
                ax.text(xi, yi, "NA", ha="center", va="center", fontsize=6.5, color=PAL["muted"])
                continue
            rho = float(hit["rho"].iloc[0])
            size = 95 + 330 * min(abs(rho), 1)
            ax.scatter(xi, yi, s=size, c=[rho], cmap=cmap, vmin=-1, vmax=1, edgecolor=PAL["dark"], linewidth=0.45)
            ax.text(xi, yi, f"{rho:.2f}", ha="center", va="center", fontsize=6.4, color="white" if abs(rho) > 0.55 else PAL["dark"], fontweight="bold")
    ax.set_xlim(-0.6, len(xlabels) - 0.4)
    ax.set_ylim(-0.6, len(ylabels) - 0.4)
    ax.set_xticks(np.arange(len(xlabels)))
    ax.set_xticklabels([DATASET_LABELS.get(d, d) for d in xlabels], fontsize=7.8)
    ax.set_yticks(np.arange(len(ylabels)))
    ax.set_yticklabels(ylabels, fontsize=7.5)
    ax.grid(color=PAL["grid"], linewidth=0.6)
    ax.set_title("B  Sample-level program coupling", loc="left", fontsize=11.5, fontweight="bold", pad=8)
    clean(ax)


def draw_panel_c(ax: plt.Axes) -> None:
    rank = load_candidates().head(16).sort_values("priority_score")
    y = np.arange(len(rank))
    colors = [FAMILY_COLORS.get(f, "#777777") for f in rank["family"]]
    ax.barh(y, rank["priority_score"], color=colors, alpha=0.92, edgecolor="white", linewidth=0.5)
    ax.scatter(rank["pct_nonzero"], y, s=34 + rank["n_datasets_ge5pct"].fillna(0) * 35, color="white", edgecolor=PAL["dark"], linewidth=0.65, zorder=4)
    ax.set_yticks(y)
    ax.set_yticklabels(rank["gene_upper"], fontsize=8.4, fontstyle="italic")
    ax.set_xlabel("Detection-aware priority score\n(white dot = mean % nonzero)", fontsize=8.5)
    ax.set_title("C  Detection-aware candidate regulators", loc="left", fontsize=11.5, fontweight="bold", pad=8)
    ax.grid(axis="x", color=PAL["grid"], linewidth=0.65)
    clean(ax)
    handles = [Patch(facecolor=FAMILY_COLORS[k], label=k) for k in ["DAM/lipid-response", "Lysosome/phagosome", "Interferon/inflammatory", "Lysosomal biogenesis"]]
    ax.legend(handles=handles, frameon=False, fontsize=6.9, loc="lower right")


def draw_network(ax: plt.Axes) -> None:
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")
    ax.set_title("D  Candidate regulator-family network", loc="left", fontsize=11.5, fontweight="bold", pad=8)
    nodes = {
        "DAM/lipid-response": (0.20, 0.68, "TREM2\nAPOE\nTYROBP\nLPL\nAXL/ITGAX", PAL["dam"]),
        "Lysosome/phagosome": (0.52, 0.68, "CTSB/CTSD\nLAMP1/2\nCD68\nHEXA/HEXB", PAL["lysosome"]),
        "Myeloid TF candidates": (0.20, 0.32, "SPI1/PU.1\nIRF8\nCEBPB\nMAFB\nRUNX1", PAL["myeloid"]),
        "Interferon/inflammatory": (0.52, 0.32, "STAT1\nIRF7\nISG15\nIFIT/MX1", PAL["interferon"]),
        "Lysosomal biogenesis": (0.82, 0.50, "TFEB\nTFE3\nMITF", PAL["biogenesis"]),
    }
    edges = [
        ("DAM/lipid-response", "Lysosome/phagosome", 0.88, "lipid sensing\nphagolysosome"),
        ("Myeloid TF candidates", "DAM/lipid-response", 0.55, "identity /\nactivation"),
        ("Myeloid TF candidates", "Lysosome/phagosome", 0.55, "myeloid\npriming"),
        ("Interferon/inflammatory", "DAM/lipid-response", 0.42, "context\nbranch"),
        ("Lysosomal biogenesis", "Lysosome/phagosome", 0.40, "stress /\nbiogenesis"),
    ]
    for src, dst, alpha, label in edges:
        x1, y1, *_ = nodes[src]
        x2, y2, *_ = nodes[dst]
        arrow = FancyArrowPatch(
            (x1, y1),
            (x2, y2),
            arrowstyle="-|>",
            mutation_scale=12,
            linewidth=1.2 + 2.0 * alpha,
            color="#566573",
            alpha=0.45 + 0.35 * alpha,
            shrinkA=42,
            shrinkB=42,
            connectionstyle="arc3,rad=0.08",
        )
        ax.add_patch(arrow)
        ax.text((x1 + x2) / 2, (y1 + y2) / 2 + 0.035, label, ha="center", va="center", fontsize=6.8, color=PAL["muted"])
    for name, (x, y, text, color) in nodes.items():
        box = FancyBboxPatch(
            (x - 0.115, y - 0.095),
            0.23,
            0.19,
            boxstyle="round,pad=0.018,rounding_size=0.025",
            facecolor=color,
            edgecolor=PAL["dark"],
            linewidth=0.9,
            alpha=0.93,
        )
        ax.add_patch(box)
        ax.text(x, y + 0.058, name.replace("/", "/\n"), ha="center", va="center", fontsize=7.5, color="white", fontweight="bold")
        ax.text(x, y - 0.035, text, ha="center", va="center", fontsize=6.7, color="white")


def draw_model(ax: plt.Axes) -> None:
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")
    ax.set_title("E  Integrated model: coordinated programs, not one master regulator", loc="left", fontsize=11.5, fontweight="bold", pad=8)

    stages = [
        (0.12, "Homeostatic\nidentity", PAL["homeostatic"], "P2RY12\nTMEM119\nCX3CR1"),
        (0.38, "Transitional\nremodeling", "#D4AC0D", "mixed states\nprogram shift"),
        (0.64, "Lysosome-high /\nphagocytic", PAL["lysosome"], "CTSB/CTSD\nLAMP/CD68"),
        (0.88, "DAM/lipid\nresponse", PAL["dam"], "APOE/TREM2\nTYROBP/LPL"),
    ]
    y = 0.58
    for i in range(len(stages) - 1):
        x1 = stages[i][0] + 0.075
        x2 = stages[i + 1][0] - 0.075
        ax.add_patch(FancyArrowPatch((x1, y), (x2, y), arrowstyle="-|>", mutation_scale=18, linewidth=2.4, color="#7B7D7D"))
    for x, title, color, genes in stages:
        circ = Circle((x, y), 0.075, facecolor=color, edgecolor=PAL["dark"], linewidth=0.9, alpha=0.96)
        ax.add_patch(circ)
        ax.text(x, y + 0.135, title, ha="center", va="center", fontsize=8.4, fontweight="bold", color=color)
        ax.text(x, y, genes, ha="center", va="center", fontsize=6.7, color="white", fontweight="bold")

    branch_box = FancyBboxPatch((0.43, 0.13), 0.44, 0.17, boxstyle="round,pad=0.02,rounding_size=0.02", facecolor="#F8F9F9", edgecolor=PAL["border"], linewidth=0.9)
    ax.add_patch(branch_box)
    ax.text(0.65, 0.235, "Context-dependent branches", ha="center", va="center", fontsize=8.6, fontweight="bold", color=PAL["dark"])
    ax.text(0.65, 0.175, "interferon / inflammatory activation\nproliferative-stress response\nlysosomal biogenesis candidates", ha="center", va="center", fontsize=7.4, color=PAL["muted"])
    ax.add_patch(FancyArrowPatch((0.64, 0.50), (0.65, 0.31), arrowstyle="-|>", mutation_scale=13, linewidth=1.7, linestyle="--", color=PAL["branch"]))

    claim = FancyBboxPatch((0.06, 0.82), 0.88, 0.10, boxstyle="round,pad=0.018,rounding_size=0.02", facecolor="#EBF5FB", edgecolor="#85C1E9", linewidth=0.9)
    ax.add_patch(claim)
    ax.text(0.50, 0.87, "Most reproducible signal: coupled lysosomal/phagocytic and DAM/lipid remodeling", ha="center", va="center", fontsize=8.6, fontweight="bold", color=PAL["dark"])


def draw_panel_e(ax: plt.Axes) -> None:
    draw_model(ax)


def make_assembled() -> None:
    fig = plt.figure(figsize=(16.0, 10.0))
    gs = fig.add_gridspec(3, 6, height_ratios=[1.1, 1.1, 1.0], width_ratios=[1, 1, 1, 1, 1, 1], hspace=0.50, wspace=0.58)
    ax_a = fig.add_subplot(gs[0, 0:2])
    ax_b = fig.add_subplot(gs[0, 2:6])
    ax_c = fig.add_subplot(gs[1, 0:3])
    ax_d = fig.add_subplot(gs[1, 3:6])
    ax_e = fig.add_subplot(gs[2, 0:6])
    im = draw_panel_a(ax_a)
    draw_panel_b(ax_b)
    draw_panel_c(ax_c)
    draw_network(ax_d)
    draw_panel_e(ax_e)
    cax = fig.add_axes([0.315, 0.695, 0.010, 0.15])
    cb = fig.colorbar(im, cax=cax)
    cb.set_label("Program activity\n(row z)", fontsize=7.5)
    cb.ax.tick_params(labelsize=7)
    fig.suptitle("Figure 5. Candidate regulatory programs associated with AD microglial remodeling", fontsize=17, fontweight="bold", x=0.03, ha="left", y=0.985)
    save(fig, "Figure5_candidate_regulatory_programs_polished")


def make_separate() -> None:
    fig, ax = plt.subplots(figsize=(5.8, 4.0))
    im = draw_panel_a(ax)
    cb = fig.colorbar(im, ax=ax, fraction=0.04, pad=0.03)
    cb.set_label("Program activity (row z)", fontsize=8)
    fig.tight_layout()
    save(fig, "Figure5A_program_activity_heatmap")

    fig, ax = plt.subplots(figsize=(7.8, 4.5))
    draw_panel_b(ax)
    fig.tight_layout()
    save(fig, "Figure5B_program_coupling_bubbles")

    fig, ax = plt.subplots(figsize=(7.0, 5.3))
    draw_panel_c(ax)
    fig.tight_layout()
    save(fig, "Figure5C_detection_aware_regulator_ranking")

    fig, ax = plt.subplots(figsize=(7.2, 5.0))
    draw_network(ax)
    fig.tight_layout()
    save(fig, "Figure5D_regulator_family_network")

    fig, ax = plt.subplots(figsize=(10.0, 4.0))
    draw_model(ax)
    fig.tight_layout()
    save(fig, "Figure5E_integrated_program_model")


def copy_sources() -> None:
    src_out = OUT / "source_csvs"
    src_out.mkdir(exist_ok=True)
    for src in [
        SRC6 / "figure6_panel_a_program_activity_row_z.csv",
        SRC6 / "figure6_panel_b_sample_level_program_correlations.csv",
        SRC6 / "figure6_panel_c_detection_aware_candidate_ranking.csv",
        SRC6 / "figure6_program_detection_coverage.csv",
        SRC6 / "figure6_program_robustness_prioritization.csv",
        SRC5 / "figure5_program_nomination_scorecard.csv",
        SRC5 / "figure5_top_detection_aware_candidates.csv",
        SRC4 / "figure4_program_pair_rho_heatmap_matrix.csv",
        SRC4 / "figure4_sample_level_program_scores.csv",
    ]:
        if src.exists():
            shutil.copy2(src, src_out / src.name)


def make_contact_sheet() -> None:
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        return
    files = sorted(OUT.glob("Figure5*_900ppi.png"))
    thumbs = []
    for f in files:
        im = Image.open(f)
        im.thumbnail((520, 360))
        canvas = Image.new("RGB", (560, 420), "white")
        canvas.paste(im, ((560 - im.width) // 2, 18))
        draw = ImageDraw.Draw(canvas)
        draw.text((12, 388), f.name.replace("_900ppi.png", ""), fill=(0, 0, 0))
        thumbs.append(canvas)
    cols = 2
    rows = int(np.ceil(len(thumbs) / cols))
    sheet = Image.new("RGB", (cols * 560, rows * 420), "white")
    for i, thumb in enumerate(thumbs):
        sheet.paste(thumb, ((i % cols) * 560, (i // cols) * 420))
    sheet.save(OUT / "Figure5_regulatory_programs_contact_sheet_preview.png")


def main() -> None:
    setup_style()
    make_assembled()
    make_separate()
    copy_sources()
    make_contact_sheet()
    (OUT / "README.txt").write_text(
        "\n".join(
            [
                "Polished replacement Figure 5 focused on candidate regulatory programs.",
                "This figure replaces the BACE1-ZNF335-centered main figure with a regulator-family story.",
                "All panels are exported as 900 ppi PNG, 900 ppi TIFF, and editable vector PDF.",
                f"Output directory: {OUT}",
            ]
        ),
        encoding="utf-8",
    )
    print(f"All polished Figure 5 outputs written to: {OUT}")


if __name__ == "__main__":
    main()
