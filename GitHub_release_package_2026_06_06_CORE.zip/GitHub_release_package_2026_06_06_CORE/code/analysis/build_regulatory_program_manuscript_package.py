#!/usr/bin/env python3
"""
Build a manuscript-ready figure/source-data package for the revised story:

  Conserved lipid-lysosomal, phagocytic, and candidate regulatory programs
  organize AD microglial remodeling across human and mouse datasets.

The script does not generate new scientific results. It organizes existing
CSV/source-data files and available graph files into:

  results/regulatory_program_manuscript_package/
    README.md
    main_figure_plan.csv
    supplementary_figure_plan.csv
    package_manifest.csv
    missing_graphs_or_sources.csv
    main_figures/
    supplementary_figures/

Run:
  python "F:\\AD\\Mam San\\build_regulatory_program_manuscript_package.py"
"""

from __future__ import annotations

import csv
import json
import shutil
from dataclasses import dataclass, field
from pathlib import Path


ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
OUT = RESULTS / "regulatory_program_manuscript_package_final_v3"
MAX_COPY_BYTES = 8 * 1024 * 1024
MAX_FILES_PER_GROUP = 10


@dataclass
class FileGroup:
    label: str
    paths: list[Path | str] = field(default_factory=list)
    patterns: list[str] = field(default_factory=list)


@dataclass
class FigureSpec:
    figure_id: str
    title: str
    role: str
    key_message: str
    panels: str
    source_groups: list[FileGroup]
    graph_groups: list[FileGroup]
    priority_note: str = ""


def p(rel: str) -> Path:
    return ROOT / rel


def expand_group(group: FileGroup) -> list[Path]:
    found: list[Path] = []
    for path in group.paths:
        pp = Path(path)
        if not pp.is_absolute():
            pp = ROOT / pp
        if pp.exists():
            if pp.is_dir():
                found.extend(sorted(x for x in pp.rglob("*") if x.is_file()))
            else:
                found.append(pp)
    for pat in group.patterns:
        found.extend(sorted(ROOT.glob(pat)))
    # Keep useful source/graph artefacts only.
    # Keep the package portable: CSV/source tables plus PNG/PDF/SVG graphs.
    # Large TIFFs and very large intermediate matrices are intentionally not
    # copied; they can be regenerated from the original result folders.
    allowed = {".csv", ".tsv", ".txt", ".json", ".png", ".pdf", ".svg"}
    uniq = []
    seen = set()
    for f in found:
        if "regulatory_program_manuscript_package" in str(f):
            continue
        if (
            f.is_file()
            and f.suffix.lower() in allowed
            and f.stat().st_size <= MAX_COPY_BYTES
            and f not in seen
        ):
            uniq.append(f)
            seen.add(f)
    return uniq[:MAX_FILES_PER_GROUP]


def copy_files(files: list[Path], dest: Path) -> list[Path]:
    dest.mkdir(parents=True, exist_ok=True)
    copied = []
    used_names: dict[str, int] = {}
    for f in files:
        name = f.name
        if name in used_names:
            used_names[name] += 1
            name = f"{f.stem}__{used_names[f.name]}{f.suffix}"
        else:
            used_names[name] = 0
        target = dest / name
        shutil.copy2(f, target)
        copied.append(target)
    return copied


MAIN_FIGURES = [
    FigureSpec(
        figure_id="Figure_01",
        title="Study design and regulatory-program framework",
        role="Main",
        key_message=(
            "Four datasets are analyzed with shared microglial states and program modules; "
            "the manuscript tests conserved remodeling and candidate regulator families, not a single master regulator."
        ),
        panels=(
            "A dataset overview; B program families; C analysis workflow; "
            "D working model from homeostatic to lysosome/DAM remodeling with interferon/stress branches."
        ),
        source_groups=[
            FileGroup("dataset summaries", [
                p("results/publication_figures/figure6_true_bayesian_hgt_source_data/panelA_true_bayesian_hgt_dataset_sources_summary.csv"),
                p("results/publication_figures/figure2_seaad_discovery_source_data/gene_groups_used.csv"),
                p("results/publication_figures/figure2_seaad_discovery_source_data/state_palette_used_across_figures.csv"),
            ]),
            FileGroup("program candidate source tables", [
                p("results/publication_figures/figure3_source_data/figure3_program_detection_coverage.csv"),
                p("results/publication_figures/figure3_source_data/figure3_program_mean_expression_by_dataset.csv"),
                p("results/publication_figures/figure3_source_data/figure3_detection_aware_candidate_gene_ranking.csv"),
            ]),
        ],
        graph_groups=[
            FileGroup("existing study-design graph", [
                p("results/manuscript_multipanel_figures/main_figures/Figure_1_study_design_state_architecture.png"),
            ]),
        ],
        priority_note="Existing graph is older style; may need redrawing to match the revised regulator-family story.",
    ),
    FigureSpec(
        figure_id="Figure_02",
        title="Human discovery of lipid-lysosomal microglial remodeling in SEA-AD",
        role="Main",
        key_message=(
            "SEA-AD microglia show homeostatic, transitional, lysosome-high, DAM/phagocytic, "
            "interferon-like, and proliferative-like states, with lipid/lysosomal/DAM modules as the strongest human discovery signal."
        ),
        panels="A UMAP states; B module score UMAPs; C marker dot plot; D donor state proportions; E donor/module summary.",
        source_groups=[
            FileGroup("SEA-AD panel CSVs", [p("results/publication_figures/figure2_seaad_discovery_source_data")]),
        ],
        graph_groups=[
            FileGroup("assembled SEA-AD figure", [
                p("results/publication_figures/Figure_2_SEAAD_human_discovery_latest_900ppi.png"),
                p("results/publication_figures/Figure_2_SEAAD_human_discovery_latest_900ppi.tiff"),
                p("results/publication_figures/Figure_2_SEAAD_human_discovery_latest_editable.pdf"),
                p("results/publication_figures/Figure_2_SEAAD_human_discovery_latest_preview.png"),
            ]),
        ],
    ),
    FigureSpec(
        figure_id="Figure_03",
        title="Human validation in live-isolated microglia",
        role="Main",
        key_message=(
            "The Olah live-isolated human cohort reproduces the lipid/DAM and lysosomal remodeling signal, "
            "supporting human cross-cohort conservation."
        ),
        panels="A UMAP states; B module score UMAPs; C marker dot plot; D module scores by state; E human validation summary.",
        source_groups=[
            FileGroup("Olah panel CSVs", [p("results/publication_figures/figure3_olah_validation_source_data")]),
        ],
        graph_groups=[
            FileGroup("assembled Olah figure", [
                p("results/publication_figures/Figure_3_Olah_human_validation_latest_900ppi.png"),
                p("results/publication_figures/Figure_3_Olah_human_validation_latest_900ppi.tiff"),
                p("results/publication_figures/Figure_3_Olah_human_validation_latest_editable.pdf"),
                p("results/publication_figures/Figure_3_Olah_human_validation_latest_preview.png"),
            ]),
        ],
    ),
    FigureSpec(
        figure_id="Figure_04",
        title="Mouse conservation and Trem2-dependent remodeling",
        role="Main",
        key_message=(
            "GSE98969 and GSE140510 support partial conservation of downstream lysosome/DAM remodeling; "
            "GSE140510 shows disease-associated expansion of lysosome/DAM states and Trem2-dependent attenuation trends."
        ),
        panels=(
            "A GSE98969 state UMAP; B GSE98969 module scores; C GSE140510 state UMAP; "
            "D sample state proportions; E group state proportions; F pseudobulk marker heatmap; G Trem2 contrast plot."
        ),
        source_groups=[
            FileGroup("Mouse conservation panel CSVs", [p("results/publication_figures/figure4_mouse_conservation_source_data")]),
        ],
        graph_groups=[
            FileGroup("separate mouse panels", [p("results/publication_figures/figure4_mouse_conservation_separate_panels")]),
        ],
        priority_note="Panels exist separately; assembled multi-panel figure may still need final layout composition.",
    ),
    FigureSpec(
        figure_id="Figure_05",
        title="Candidate regulatory programs and program coupling",
        role="Main",
        key_message=(
            "AD remodeling is organized by regulator families: DAM/lipid-response, lysosome/phagosome, "
            "myeloid TF, interferon, and lysosomal-biogenesis/stress candidates. The strongest signal is coordinated program coupling."
        ),
        panels=(
            "A regulator/program activity heatmap; B regulator-group correlations with lysosome/DAM scores; "
            "C detection-aware regulator ranking; D regulator-family network; E program-level model."
        ),
        source_groups=[
            FileGroup("program regulator family CSVs", [
                p("results/publication_figures/figure3_source_data"),
                p("results/publication_figures/figure4_source_data"),
                p("results/publication_figures/figure5_source_data"),
                p("results/publication_figures/figure6_source_data"),
            ]),
        ],
        graph_groups=[
            FileGroup("program/regulator graphs", [
                p("results/publication_figures/Figure_3_program_regulator_families_900ppi.png"),
                p("results/publication_figures/Figure_3_program_regulator_families_900ppi.tiff"),
                p("results/publication_figures/Figure_3_program_regulator_families_editable.pdf"),
                p("results/publication_figures/Figure_4_program_coupling_evidence_900ppi.png"),
                p("results/publication_figures/Figure_4_program_coupling_evidence_900ppi.tiff"),
                p("results/publication_figures/Figure_4_program_coupling_evidence_editable.pdf"),
                p("results/publication_figures/Figure_5_nomination_framework_900ppi.png"),
                p("results/publication_figures/Figure_5_nomination_framework_900ppi.tiff"),
                p("results/publication_figures/Figure_5_nomination_framework_editable.pdf"),
                p("results/publication_figures/Figure_6_candidate_regulatory_programs_900ppi.png"),
                p("results/publication_figures/Figure_6_candidate_regulatory_programs_900ppi.tiff"),
                p("results/publication_figures/Figure_6_candidate_regulatory_programs_editable.pdf"),
            ]),
        ],
        priority_note="Use this as the main replacement for a BACE1-ZNF335 central figure.",
    ),
    FigureSpec(
        figure_id="Figure_06",
        title="Program-aware Bayesian HGT validation and integrated model",
        role="Main",
        key_message=(
            "Program-aware modeling separates remodeled microglia and transfers to external datasets, "
            "while showing that context covariates are useful but not universally portable."
        ),
        panels=(
            "A Bayesian HGT architecture; B donor-held-out SEA-AD performance; C external validation; "
            "D calibration/uncertainty; E ablation; F feature relevance and program activity."
        ),
        source_groups=[
            FileGroup("true Bayesian HGT source CSVs", [
                p("results/publication_figures/figure6_true_bayesian_hgt_source_data"),
                p("results/bayesian_hgt_true_external_validation"),
                p("results/bayesian_hgt_true_results"),
            ]),
        ],
        graph_groups=[
            FileGroup("true HGT separate panels", [p("results/publication_figures/figure6_true_bayesian_hgt_separate_panels")]),
        ],
        priority_note="Panel C now uses true second-stage external validation when present.",
    ),
]


SUPPLEMENTARY_FIGURES = [
    FigureSpec(
        "Supplementary_Figure_01",
        "Dataset QC and filtering",
        "Supplementary",
        "QC metrics and retained microglia for all datasets.",
        "QC violin/scatter plots and before/after filtering tables.",
        [
            FileGroup("QC tables", patterns=[
                "results/*/tables/*qc*filtering*.csv",
                "results/*/tables/*qc_before*.csv",
                "results/*/tables/*qc_after*.csv",
            ]),
        ],
        [
            FileGroup("QC plots", patterns=[
                "results/*/figures/*qc*.png",
            ]),
        ],
    ),
    FigureSpec(
        "Supplementary_Figure_02",
        "Whole-dataset UMAPs and microglia identification",
        "Supplementary",
        "Whole-dataset clustering and marker-based microglia selection.",
        "Whole UMAPs, Leiden clusters, and microglia marker overlays.",
        [
            FileGroup("cluster marker tables", patterns=[
                "results/*/tables/*whole_cluster_markers*.csv",
                "results/*/tables/*microglia_cluster*.csv",
            ]),
        ],
        [
            FileGroup("whole dataset UMAPs", patterns=[
                "results/*/figures/*whole_umap*.png",
            ]),
        ],
    ),
    FigureSpec(
        "Supplementary_Figure_03",
        "Gene-set and module coverage across datasets",
        "Supplementary",
        "Coverage of homeostatic, lipid, lysosome, DAM/phagocytic, interferon, and proliferative modules across datasets.",
        "Coverage heatmaps/tables for module gene availability.",
        [
            FileGroup("module coverage tables", patterns=[
                "results/*/tables/*module_gene_coverage*.csv",
                "results/publication_figures/*source_data/*coverage*.csv",
                "results/publication_figures/*source_data/*gene_sets_used*.csv",
            ]),
        ],
        [],
        priority_note="CSV/source tables present; graph availability depends on dataset-specific folders.",
    ),
    FigureSpec(
        "Supplementary_Figure_04",
        "Full module-score UMAPs",
        "Supplementary",
        "All module-score projections that are too many for the main figures.",
        "Homeostatic, lipid, lysosome, DAM/phagocytic, interferon, and proliferative module UMAPs.",
        [
            FileGroup("module score cell CSVs", [
                p("results/publication_figures/figure2_seaad_discovery_source_data/seaad_cell_umap_scores_expression.csv"),
                p("results/publication_figures/figure3_olah_validation_source_data/olah_cell_umap_scores_expression.csv"),
                p("results/publication_figures/figure4_mouse_conservation_source_data/panelB_gse98969_5xfad_wt_umap_module_scores.csv"),
            ]),
        ],
        [
            FileGroup("module score UMAPs", patterns=[
                "results/*/figures/*umap_module_scores*.png",
            ]),
        ],
    ),
    FigureSpec(
        "Supplementary_Figure_05",
        "Full marker dot plots and state marker tables",
        "Supplementary",
        "Full marker support for the state labels used in each dataset.",
        "Marker dot plots and state marker tables.",
        [
            FileGroup("marker source tables", patterns=[
                "results/*/tables/*state_markers*.csv",
                "results/publication_figures/*source_data/*marker_dotplot*.csv",
            ]),
        ],
        [
            FileGroup("marker dot plots", patterns=[
                "results/*/figures/*dotplot*.png",
            ]),
        ],
    ),
    FigureSpec(
        "Supplementary_Figure_06",
        "State proportions and module scores by sample",
        "Supplementary",
        "Sample-level distributions supporting the main state/module claims.",
        "Per-sample state proportions, module scores, and group summaries.",
        [
            FileGroup("state/module sample tables", patterns=[
                "results/*/tables/*state_proportion*.csv",
                "results/*/tables/*state_counts*.csv",
                "results/*/tables/*sample_module_scores*.csv",
                "results/publication_figures/*source_data/*state_proportion*.csv",
            ]),
        ],
        [
            FileGroup("state/module plots", patterns=[
                "results/*/figures/*state_proportion*.png",
                "results/*/figures/*sample_module_scores*.png",
            ]),
        ],
    ),
    FigureSpec(
        "Supplementary_Figure_07",
        "Pseudobulk differential expression and marker heatmaps",
        "Supplementary",
        "Pseudobulk expression changes supporting AD and Trem2-linked remodeling.",
        "DE tables, volcano helper plots, and pseudobulk heatmaps.",
        [
            FileGroup("pseudobulk tables", patterns=[
                "results/**/*pseudobulk_de_results.csv",
                "results/**/*pseudobulk_logcpm.csv",
                "results/**/*pseudobulk_counts.csv",
                "results/**/*sample_pseudobulk*.csv",
            ]),
        ],
        [
            FileGroup("pseudobulk plots", patterns=[
                "results/**/*pseudobulk*.png",
                "results/**/*sample_*heatmap*.png",
            ]),
        ],
    ),
    FigureSpec(
        "Supplementary_Figure_08",
        "Pathway enrichment and GSEA",
        "Supplementary",
        "Pathway-level support for lysosome, phagosome, lipid, immune/interferon, and stress programs.",
        "GSEA and focused pathway enrichment tables/plots.",
        [
            FileGroup("GSEA/pathway tables", patterns=[
                "results/**/*gsea*.csv",
                "results/**/*GSEA*.txt",
                "results/graphpad_main_figure_csvs/Figure_4_external_GSEA/*.csv",
            ]),
        ],
        [
            FileGroup("GSEA/pathway plots", patterns=[
                "results/**/*GSEA*.png",
                "results/**/*gsea*.png",
                "results/manuscript_multipanel_figures/*/*GSEA*.png",
            ]),
        ],
    ),
    FigureSpec(
        "Supplementary_Figure_09",
        "Exploratory trajectory analysis",
        "Supplementary",
        "Pseudotime/PAGA analyses used only as exploratory support for a remodeling continuum.",
        "PAGA, pseudotime UMAPs, module trends, and gene trends.",
        [
            FileGroup("trajectory tables", patterns=[
                "results/manuscript_upgrade/transition/*/tables/*.csv",
            ]),
        ],
        [
            FileGroup("trajectory plots", patterns=[
                "results/manuscript_upgrade/transition/*/figures/*.png",
                "results/manuscript_upgrade/figures/transition_helpers/*.png",
            ]),
        ],
    ),
    FigureSpec(
        "Supplementary_Figure_10",
        "Exploratory BACE1-ZNF335/Zfp335 guardrail analysis",
        "Supplementary",
        "BACE1 and ZNF335/Zfp335 are sparse and weakly coupled to remodeling scores; they are not central regulators.",
        "Detection, single-cell correlations, sample-level pseudobulk, and interpretation model.",
        [
            FileGroup("candidate-axis source CSVs", [
                p("results/publication_figures/figure5_candidate_axis_source_data"),
                p("results/candidate_network_specificity/tables"),
            ]),
        ],
        [
            FileGroup("candidate-axis graphs", [
                p("results/publication_figures/figure5_candidate_axis_separate_panels"),
                p("results/candidate_network_specificity/figures"),
            ]),
        ],
        priority_note="This should be supplementary, not the main story.",
    ),
    FigureSpec(
        "Supplementary_Figure_11",
        "Bayesian HGT robustness and external-validation details",
        "Supplementary",
        "Training summaries, prediction files, calibration, uncertainty, and external-validation metrics.",
        "Full performance tables, calibration curves, uncertainty distributions, external predictions, and gene coverage.",
        [
            FileGroup("true HGT tables", [
                p("results/bayesian_hgt_true_results"),
                p("results/bayesian_hgt_true_external_validation"),
                p("results/publication_figures/figure6_true_bayesian_hgt_source_data"),
            ]),
        ],
        [
            FileGroup("true HGT graphs", [p("results/publication_figures/figure6_true_bayesian_hgt_separate_panels")]),
        ],
    ),
]


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def package_figure(fig: FigureSpec, base_dir: Path, manifest: list[dict], missing: list[dict]) -> None:
    fig_dir = base_dir / fig.figure_id
    csv_dir = fig_dir / "csvs"
    graph_dir = fig_dir / "graphs"
    fig_dir.mkdir(parents=True, exist_ok=True)
    copied_sources = 0
    copied_graphs = 0

    for group in fig.source_groups:
        files = expand_group(group)
        if files:
            copied = copy_files(files, csv_dir / safe_name(group.label))
            copied_sources += len(copied)
            for src, dst in zip(files, copied):
                manifest.append(row_for(fig, group.label, "source_csv_or_table", src, dst))
        else:
            missing.append(missing_row(fig, group.label, "source_csv_or_table"))

    for group in fig.graph_groups:
        files = expand_group(group)
        if files:
            copied = copy_files(files, graph_dir / safe_name(group.label))
            copied_graphs += len(copied)
            for src, dst in zip(files, copied):
                manifest.append(row_for(fig, group.label, "graph", src, dst))
        else:
            missing.append(missing_row(fig, group.label, "graph"))

    if fig.source_groups and copied_sources == 0:
        missing.append(missing_row(fig, "all source groups", "source_csv_or_table"))
    if fig.graph_groups and copied_graphs == 0:
        missing.append(missing_row(fig, "all graph groups", "graph"))
    if not fig.graph_groups:
        missing.append(missing_row(fig, "no graph group defined", "graph", "CSV/source package only; graph not currently specified."))

    note = {
        "figure_id": fig.figure_id,
        "title": fig.title,
        "role": fig.role,
        "key_message": fig.key_message,
        "panels": fig.panels,
        "priority_note": fig.priority_note,
        "n_source_files_copied": copied_sources,
        "n_graph_files_copied": copied_graphs,
    }
    (fig_dir / "FIGURE_NOTES.json").write_text(json.dumps(note, indent=2), encoding="utf-8")
    (fig_dir / "README.md").write_text(
        "\n".join(
            [
                f"# {fig.figure_id}. {fig.title}",
                "",
                f"**Role:** {fig.role}",
                "",
                f"**Key message:** {fig.key_message}",
                "",
                f"**Panels:** {fig.panels}",
                "",
                f"**Priority note:** {fig.priority_note or 'None'}",
                "",
                f"Source/table files copied: {copied_sources}",
                f"Graph files copied: {copied_graphs}",
            ]
        ),
        encoding="utf-8",
    )


def safe_name(text: str) -> str:
    keep = []
    for ch in text.lower().replace("/", "_").replace("\\", "_"):
        keep.append(ch if ch.isalnum() else "_")
    return "_".join("".join(keep).split("_"))


def row_for(fig: FigureSpec, group_label: str, kind: str, src: Path, dst: Path) -> dict:
    return {
        "figure_id": fig.figure_id,
        "role": fig.role,
        "title": fig.title,
        "group_label": group_label,
        "file_kind": kind,
        "source_path": str(src),
        "packaged_path": str(dst),
        "status": "copied",
    }


def missing_row(fig: FigureSpec, group_label: str, kind: str, note: str = "") -> dict:
    return {
        "figure_id": fig.figure_id,
        "role": fig.role,
        "title": fig.title,
        "group_label": group_label,
        "file_kind": kind,
        "status": "missing",
        "note": note or "No matching existing file found.",
    }


def plan_rows(figs: list[FigureSpec]) -> list[dict]:
    return [
        {
            "figure_id": f.figure_id,
            "role": f.role,
            "title": f.title,
            "key_message": f.key_message,
            "panels": f.panels,
            "priority_note": f.priority_note,
        }
        for f in figs
    ]


def write_readme() -> None:
    text = """# Regulatory Program Manuscript Package

Central story:

AD microglia across human and mouse datasets converge on conserved lipid-lysosomal and phagocytic/DAM-like remodeling. This remodeling is best explained at the level of coordinated regulator families and biological programs rather than a single master regulator pair.

Core regulator/program families:

- DAM/lipid-response: TREM2, APOE, TYROBP, LPL, CST7, AXL, ITGAX, GPNMB
- Lysosome/phagosome: CTSB, CTSD, CTSS, LAMP1, LAMP2, CD68, HEXA, HEXB
- Myeloid TF candidates: SPI1/PU.1, IRF8, CEBPB, MAFB, RUNX1
- Interferon/inflammatory branch: STAT1, IRF7, ISG15, IFIT1/2/3, MX1
- Lysosomal biogenesis/stress candidates: TFEB, TFE3, MITF

Interpretation guardrail:

BACE1 and ZNF335/Zfp335 should be treated as sparse, exploratory, context-dependent candidates and moved to supplementary evidence rather than used as the manuscript's central mechanism.

This package contains copied source CSVs/tables and available graphs. If a figure has CSVs but no graph, see `missing_graphs_or_sources.csv`.
"""
    (OUT / "README.md").write_text(text, encoding="utf-8")


def main() -> None:
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True, exist_ok=True)
    manifest: list[dict] = []
    missing: list[dict] = []

    for fig in MAIN_FIGURES:
        package_figure(fig, OUT / "main_figures", manifest, missing)
    for fig in SUPPLEMENTARY_FIGURES:
        package_figure(fig, OUT / "supplementary_figures", manifest, missing)

    write_csv(OUT / "main_figure_plan.csv", plan_rows(MAIN_FIGURES))
    write_csv(OUT / "supplementary_figure_plan.csv", plan_rows(SUPPLEMENTARY_FIGURES))
    write_csv(OUT / "package_manifest.csv", manifest)
    write_csv(OUT / "missing_graphs_or_sources.csv", missing)
    write_readme()

    print(f"Wrote manuscript package to: {OUT}")
    print(f"Copied {len(manifest)} files.")
    print(f"Missing/source notes: {len(missing)}")


if __name__ == "__main__":
    main()
