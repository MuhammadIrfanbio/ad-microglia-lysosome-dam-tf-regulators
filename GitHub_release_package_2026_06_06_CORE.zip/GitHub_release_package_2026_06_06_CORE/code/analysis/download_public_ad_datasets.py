#!/usr/bin/env python3
"""Download selected public AD single-cell datasets for the Zfp335 thesis workflow.

Supports curated presets from GEO and a generic URL downloader.

Examples
--------
python download_public_ad_datasets.py --dataset gse140510_mouse --outdir data_raw
python download_public_ad_datasets.py --dataset gse98969_mouse --outdir data_raw --extract
python download_public_ad_datasets.py --url "PASTE_H5AD_URL_HERE" --outdir data_raw/olah_human
"""
from __future__ import annotations

import argparse
import hashlib
import os
import shutil
import sys
import tarfile
from pathlib import Path
from urllib.parse import urlparse
from urllib.request import Request, urlopen

PRESETS = {
    "gse140510_mouse": [
        ("https://ftp.ncbi.nlm.nih.gov/geo/series/GSE140nnn/GSE140510/suppl/GSE140510_RAW.tar", "GSE140510_RAW.tar"),
    ],
    "gse98969_mouse": [
        ("https://ftp.ncbi.nlm.nih.gov/geo/series/GSE98nnn/GSE98969/suppl/GSE98969_RAW.tar", "GSE98969_RAW.tar"),
        ("https://ftp.ncbi.nlm.nih.gov/geo/series/GSE98nnn/GSE98969/suppl/GSE98969_experimental_design_f.txt.gz", "GSE98969_experimental_design_f.txt.gz"),
    ],
}


def stream_download(url: str, dest: Path, chunk_size: int = 1024 * 1024) -> None:
    req = Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urlopen(req) as response, open(dest, "wb") as fout:
        total = response.headers.get("Content-Length")
        total_size = int(total) if total is not None else None
        downloaded = 0
        while True:
            chunk = response.read(chunk_size)
            if not chunk:
                break
            fout.write(chunk)
            downloaded += len(chunk)
            if total_size:
                pct = 100 * downloaded / total_size
                mb = downloaded / (1024 * 1024)
                total_mb = total_size / (1024 * 1024)
                print(f"\r{dest.name}: {mb:.1f}/{total_mb:.1f} MB ({pct:.1f}%)", end="", flush=True)
            else:
                mb = downloaded / (1024 * 1024)
                print(f"\r{dest.name}: {mb:.1f} MB", end="", flush=True)
    print()


def sha256sum(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def extract_archive(path: Path, dest_dir: Path) -> None:
    if tarfile.is_tarfile(path):
        target = dest_dir / path.stem.replace(".tar", "")
        target.mkdir(parents=True, exist_ok=True)
        with tarfile.open(path, "r:*") as tar:
            tar.extractall(target)
        print(f"Extracted to: {target}")
        return
    print(f"Skipping extraction for {path.name} (not a tar archive).")


def main() -> int:
    parser = argparse.ArgumentParser(description="Download public AD single-cell datasets.")
    parser.add_argument("--dataset", choices=sorted(PRESETS), help="Curated preset dataset name.")
    parser.add_argument("--url", help="Generic file URL to download, e.g. a copied CELLxGENE h5ad link.")
    parser.add_argument("--filename", help="Optional output filename for --url downloads.")
    parser.add_argument("--outdir", default="data_raw", help="Output directory.")
    parser.add_argument("--extract", action="store_true", help="Extract tar archives after download.")
    parser.add_argument("--skip-existing", action="store_true", help="Skip files that already exist.")
    args = parser.parse_args()

    if not args.dataset and not args.url:
        parser.error("Provide either --dataset or --url")

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    jobs: list[tuple[str, str]] = []
    if args.dataset:
        jobs.extend(PRESETS[args.dataset])
    if args.url:
        fname = args.filename
        if not fname:
            parsed = urlparse(args.url)
            fname = Path(parsed.path).name or "downloaded_file"
        jobs.append((args.url, fname))

    for url, fname in jobs:
        dest = outdir / fname
        if dest.exists() and args.skip_existing:
            print(f"Skipping existing file: {dest}")
            continue
        print(f"Downloading: {url}")
        stream_download(url, dest)
        print(f"Saved: {dest}")
        print(f"SHA256: {sha256sum(dest)}")
        if args.extract:
            extract_archive(dest, outdir)

    print("Done.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
