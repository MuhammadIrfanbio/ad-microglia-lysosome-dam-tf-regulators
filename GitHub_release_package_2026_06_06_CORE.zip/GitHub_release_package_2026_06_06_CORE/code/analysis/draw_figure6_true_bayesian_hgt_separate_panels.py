#!/usr/bin/env python3
"""
Draw separate Figure 6 panels from true Bayesian HGT panel CSVs.

Inputs:
  results/publication_figures/figure6_true_bayesian_hgt_source_data/

Outputs:
  results/publication_figures/figure6_true_bayesian_hgt_separate_panels/

Each panel is saved as:
  - 900 ppi PNG
  - 900 ppi TIFF
  - editable vector PDF
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

if sys.platform.startswith("win"):
    os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
    py_root = Path(sys.executable).resolve().parent
    for dll_dir in [py_root / "Library" / "bin", py_root / "DLLs"]:
        if dll_dir.exists():
            os.environ["PATH"] = str(dll_dir) + os.pathsep + os.environ.get("PATH", "")
            try:
                os.add_dll_directory(str(dll_dir))
            except (AttributeError, OSError):
                pass

import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm
from matplotlib.lines import Line2D
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Patch, Rectangle


ROOT = Path(__file__).resolve().parent
SRC = ROOT / "results" / "publication_figures" / "figure6_true_bayesian_hgt_source_data"
OUT = ROOT / "results" / "publication_figures" / "figure6_true_bayesian_hgt_separate_panels"
OUT.mkdir(parents=True, exist_ok=True)

PAL = {
    "dark": "#151B23",
    "mid": "#566174",
    "grid": "#E9EDF2",
    "border": "#CAD2DC",
    "blue": "#1262B3",
    "orange": "#F47B20",
    "gray": "#9AA1AA",
    "green": "#5A9E4B",
    "purple": "#8E63AD",
}

MODEL_COLORS = {
    "gene_only": "#A7AAB2",
    "program_only": "#F6B23C",
    "gene_program_no_context": "#F47B20",
    "full_bayesian_hgt": "#1262B3",
}

MODEL_SHORT = {
    "gene_only": "Gene only",
    "program_only": "Program only",
    "gene_program_no_context": "Gene + program",
    "full_bayesian_hgt": "Full Bayesian HGT",
}

METRIC_ORDER = ["AUROC", "AUPRC", "F1", "Balanced accuracy"]
PROGRAM_ORDER = ["Homeostatic", "Lysosome", "DAM/phagocytic", "Lipid", "Interferon/immune", "Proliferative/stress"]
DATASET_ORDER = ["seaad", "olah", "gse98969", "gse140510"]


def pretty_context_label(dataset: str, context: str) -> str:
    dataset_map = {
        "seaad": "SEA-AD",
        "olah": "Olah",
        "gse98969": "GSE98969",
        "gse140510": "GSE140510",
    }
    context_map = {
        "SEA-AD": "",
        "control-like": "control-like",
        "AD-like": "AD-like",
        "WT": "WT",
        "5xFAD": "5xFAD",
        "Trem2_KO": "Trem2_KO",
        "Trem2_KO_5xFAD": "Trem2_KO\n5xFAD",
    }
    ds = dataset_map.get(str(dataset), str(dataset))
    ctx = context_map.get(str(context), str(context).replace("_", "\n"))
    return ds if not ctx else f"{ds}\n{ctx}"


def setup_style() -> None:
    mpl.rcParams.update(
        {
            "font.family": "Arial",
            "font.size": 8.5,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "figure.facecolor": "white",
            "savefig.facecolor": "white",
            "axes.linewidth": 0.7,
        }
    )


def read_csv(name: str, **kwargs) -> pd.DataFrame:
    path = SRC / name
    if not path.exists():
        raise FileNotFoundError(path)
    return pd.read_csv(path, **kwargs)


def save_figure(fig: plt.Figure, stem: str) -> None:
    png = OUT / f"{stem}_900ppi.png"
    tiff = OUT / f"{stem}_900ppi.tiff"
    pdf = OUT / f"{stem}_editable.pdf"
    fig.savefig(png, dpi=900, bbox_inches="tight")
    fig.savefig(tiff, dpi=900, bbox_inches="tight", pil_kwargs={"compression": "tiff_lzw"})
    fig.savefig(pdf, bbox_inches="tight")
    plt.close(fig)
    print(f"Wrote {png.name}, {tiff.name}, {pdf.name}")


def clean_axes(ax: plt.Axes) -> None:
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(PAL["dark"])
    ax.spines["bottom"].set_color(PAL["dark"])
    ax.tick_params(colors=PAL["dark"], labelsize=8)


def draw_panel_a() -> None:
    nodes = read_csv("panelA_true_bayesian_hgt_architecture_nodes.csv")
    edges = read_csv("panelA_true_bayesian_hgt_architecture_edges.csv")
    sources = read_csv("panelA_true_bayesian_hgt_dataset_sources_summary.csv")
    params = read_csv("panelA_true_bayesian_hgt_training_parameters.csv")
    fig, ax = plt.subplots(figsize=(8.8, 5.0))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")

    type_colors = {
        "cell": "#A98BC7",
        "gene": "#72A9E8",
        "program": "#7FB36A",
        "context": "#D3A6C8",
        "model": "#F7F7F7",
        "output": "#FFFFFF",
    }

    pos = {r.node_id: (float(r.x), float(r.y)) for r in nodes.itertuples(index=False)}
    for row in edges.itertuples(index=False):
        if row.source not in pos or row.target not in pos:
            continue
        x1, y1 = pos[row.source]
        x2, y2 = pos[row.target]
        ax.add_patch(
            FancyArrowPatch(
                (x1, y1),
                (x2, y2),
                arrowstyle="-|>",
                mutation_scale=10,
                linewidth=0.75,
                color=PAL["dark"],
                alpha=0.72,
                shrinkA=30,
                shrinkB=30,
            )
        )
        ax.text((x1 + x2) / 2, (y1 + y2) / 2 + 0.022, row.edge_label, fontsize=6.0, ha="center", va="center", color=PAL["mid"])

    for row in nodes.itertuples(index=False):
        x, y = float(row.x), float(row.y)
        if row.node_type == "model":
            w, h = 0.23, 0.15
        elif row.node_type == "output":
            w, h = 0.16, 0.12
        else:
            w, h = 0.14, 0.12
        box = FancyBboxPatch(
            (x - w / 2, y - h / 2),
            w,
            h,
            boxstyle="round,pad=0.012,rounding_size=0.014",
            facecolor=type_colors.get(row.node_type, "#FFFFFF"),
            edgecolor=PAL["border"],
            linewidth=0.9,
        )
        ax.add_patch(box)
        ax.text(x, y, row.label, ha="center", va="center", fontsize=7.6, fontweight="bold", color=PAL["dark"])

    ds_text = "\n".join(
        f"{r.cohort_label}: {int(r.n_microglia):,} cells, {int(r.n_samples)} samples" for r in sources.itertuples(index=False)
    )
    ax.text(0.02, 0.97, "Data sources", ha="left", va="top", fontsize=9.2, fontweight="bold")
    ax.text(0.02, 0.91, ds_text, ha="left", va="top", fontsize=7.4, linespacing=1.35)
    pmap = dict(zip(params["parameter"], params["value"]))
    ax.text(
        0.50,
        0.965,
        f"Bayesian HGT: {pmap.get('n_layers', '?')} layers, d={pmap.get('d_model', '?')}, MC samples={pmap.get('mc_samples', '?')}",
        ha="center",
        va="top",
        fontsize=9.4,
        fontweight="bold",
    )
    ax.set_title("Bayesian HGT architecture and data integration", fontsize=12.0, fontweight="bold", pad=8)
    save_figure(fig, "Figure6A_true_hgt_architecture")


def draw_panel_b() -> None:
    perf = read_csv("panelB_true_hgt_donor_heldout_performance_long.csv")
    perf = perf[perf["metric"].isin(METRIC_ORDER)].copy()
    selected = ["gene_only", "gene_program_no_context", "full_bayesian_hgt"]
    fig, axes = plt.subplots(1, 4, figsize=(11.8, 3.8), sharey=True)
    rng = np.random.default_rng(5)
    for ax, metric in zip(axes, METRIC_ORDER):
        sub = perf[(perf["metric"] == metric) & (perf["model_key"].isin(selected))]
        vals = [sub.loc[sub["model_key"] == m, "value"].astype(float).values for m in selected]
        parts = ax.violinplot(vals, positions=np.arange(len(selected)), widths=0.72, showmeans=False, showmedians=False, showextrema=False)
        for body, model in zip(parts["bodies"], selected):
            body.set_facecolor(MODEL_COLORS[model])
            body.set_alpha(0.45)
            body.set_edgecolor(PAL["dark"])
            body.set_linewidth(0.65)
        for i, model in enumerate(selected):
            y = vals[i]
            jitter = rng.normal(i, 0.045, len(y))
            ax.scatter(jitter, y, s=24, color=MODEL_COLORS[model], edgecolors=PAL["dark"], linewidths=0.35, zorder=3)
            if len(y):
                ax.plot([i - 0.18, i + 0.18], [np.median(y), np.median(y)], color="white", linewidth=1.4, zorder=4)
        ax.set_title(metric, fontsize=9.4, fontweight="bold")
        ax.set_xticks(np.arange(len(selected)))
        ax.set_xticklabels([MODEL_SHORT[m] for m in selected], rotation=35, ha="right", fontsize=7.0)
        ax.set_ylim(0.0, 1.04)
        ax.grid(axis="y", color=PAL["grid"], linewidth=0.55)
        clean_axes(ax)
    axes[0].set_ylabel("Score", fontsize=9.0)
    handles = [Line2D([0], [0], marker="o", linestyle="", markerfacecolor=MODEL_COLORS[m], markeredgecolor=PAL["dark"], label=MODEL_SHORT[m], markersize=6.5) for m in selected]
    fig.legend(handles=handles, frameon=False, ncol=3, loc="lower center", bbox_to_anchor=(0.5, -0.08), fontsize=8.0)
    fig.suptitle("Predictive performance: donor-held-out SEA-AD", fontsize=12.0, fontweight="bold", y=1.02)
    save_figure(fig, "Figure6B_true_hgt_donor_heldout_performance")


def draw_panel_c() -> None:
    status = read_csv("panelC_missing_true_external_validation_status.csv")
    row = status.iloc[0]
    ext = read_csv("panelC_true_hgt_external_validation_metrics_long.csv")
    if str(row.get("status", "")) == "true_external_validation_found" and not ext.empty:
        metrics = ["AUROC", "AUPRC"]
        selected = ["gene_program_no_context", "full_bayesian_hgt"]
        ext = ext[ext["metric"].isin(metrics) & ext["model_key"].isin(selected)].copy()
        if "test_dataset_label" not in ext.columns:
            ext["test_dataset_label"] = ext.get("test_cohort_label", ext.get("test_dataset", "External"))
        dataset_order = [d for d in ["olah", "gse98969", "gse140510"] if d in set(ext["test_dataset"])]
        if not dataset_order:
            dataset_order = list(dict.fromkeys(ext["test_dataset"].astype(str)))
        label_map = {
            "olah": "Olah\nhuman",
            "gse98969": "GSE98969\nmouse",
            "gse140510": "GSE140510\nmouse",
        }
        fig, axes = plt.subplots(1, 2, figsize=(8.8, 3.8), sharey=True)
        width = 0.34
        x = np.arange(len(dataset_order))
        for ax, metric in zip(axes, metrics):
            sub = ext[ext["metric"] == metric]
            for j, model in enumerate(selected):
                vals = []
                for dataset in dataset_order:
                    hit = sub[(sub["test_dataset"] == dataset) & (sub["model_key"] == model)]["value"]
                    vals.append(float(hit.iloc[0]) if len(hit) else np.nan)
                xpos = x + (j - 0.5) * width
                ax.bar(
                    xpos,
                    vals,
                    width=width,
                    color=MODEL_COLORS.get(model, PAL["gray"]),
                    edgecolor="white",
                    linewidth=0.8,
                    label=MODEL_SHORT.get(model, model),
                )
                ax.scatter(xpos, vals, s=18, color=PAL["dark"], zorder=3)
            ax.set_xticks(x)
            ax.set_xticklabels([label_map.get(d, d) for d in dataset_order], fontsize=8.0)
            ax.set_ylim(0.0, 1.02)
            ax.set_title(metric, fontsize=10.2, fontweight="bold")
            ax.grid(axis="y", color=PAL["grid"], linewidth=0.55)
            clean_axes(ax)
        axes[0].set_ylabel("Score", fontsize=9.0)
        handles = [
            Patch(facecolor=MODEL_COLORS[m], edgecolor="white", label=MODEL_SHORT[m])
            for m in selected
        ]
        fig.legend(handles=handles, frameon=False, ncol=2, loc="lower center", bbox_to_anchor=(0.5, -0.08), fontsize=8.2)
        fig.suptitle("External validation across datasets (train on SEA-AD)", fontsize=12.0, fontweight="bold", y=1.03)
        save_figure(fig, "Figure6C_true_hgt_external_validation")
        return

    fig, ax = plt.subplots(figsize=(6.8, 3.8))
    ax.axis("off")
    box = FancyBboxPatch(
        (0.08, 0.22),
        0.84,
        0.50,
        boxstyle="round,pad=0.02,rounding_size=0.02",
        facecolor="#FFF8E6",
        edgecolor="#D09326",
        linewidth=1.2,
    )
    ax.add_patch(box)
    ax.text(0.50, 0.60, "True external validation not available yet", ha="center", va="center", fontsize=12.0, fontweight="bold", color=PAL["dark"])
    ax.text(0.50, 0.47, str(row["message"]), ha="center", va="center", fontsize=8.6, color=PAL["dark"], wrap=True)
    ax.text(0.50, 0.33, "Do not plot proxy external bars as true Bayesian HGT validation.", ha="center", va="center", fontsize=9.0, fontweight="bold", color="#9A5C00")
    ax.set_title("External validation across datasets", fontsize=12.0, fontweight="bold", pad=8)
    save_figure(fig, "Figure6C_true_hgt_external_validation_status")


def draw_panel_d() -> None:
    rel = read_csv("panelD_true_hgt_reliability_curve.csv")
    ece = read_csv("panelD_true_hgt_expected_calibration_error.csv")
    unc = read_csv("panelD_true_hgt_predictive_uncertainty_long.csv")
    selected = ["gene_only", "gene_program_no_context", "full_bayesian_hgt"]
    fig, axes = plt.subplots(1, 3, figsize=(12.4, 3.8))

    ax = axes[0]
    ax.plot([0, 1], [0, 1], linestyle="--", color=PAL["dark"], linewidth=0.8, label="Perfect calibration")
    for model in selected:
        sub = rel[(rel["model_key"] == model) & (rel["n_cells"] > 0)]
        ax.plot(sub["mean_predicted_probability"], sub["observed_frequency"], marker="o", markersize=3.5, linewidth=1.1, color=MODEL_COLORS[model], label=MODEL_SHORT[model])
    ax.set_xlabel("Mean predicted probability", fontsize=8.8)
    ax.set_ylabel("Observed frequency", fontsize=8.8)
    ax.set_title("Reliability curve", fontsize=9.5, fontweight="bold")
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.grid(color=PAL["grid"], linewidth=0.55)
    clean_axes(ax)

    ax = axes[1]
    sub = ece[ece["model_key"].isin(selected)].sort_values("model_order")
    ax.bar(np.arange(len(sub)), sub["expected_calibration_error"], color=[MODEL_COLORS[m] for m in sub["model_key"]], width=0.70)
    for i, v in enumerate(sub["expected_calibration_error"]):
        ax.text(i, v + 0.006, f"{v:.3f}", ha="center", va="bottom", fontsize=7.6)
    ax.set_xticks(np.arange(len(sub)))
    ax.set_xticklabels([MODEL_SHORT[m] for m in sub["model_key"]], rotation=35, ha="right", fontsize=7.0)
    ax.set_ylabel("ECE", fontsize=8.8)
    ax.set_title("Expected calibration error", fontsize=9.5, fontweight="bold")
    ax.grid(axis="y", color=PAL["grid"], linewidth=0.55)
    clean_axes(ax)

    ax = axes[2]
    plot = unc[unc["model_key"].isin(selected)].copy()
    plot["correct_group"] = np.where(plot["correct_prediction"].astype(str).str.lower().eq("true"), "Correct", "Incorrect")
    positions = []
    labels = []
    colors = []
    vals = []
    pos = 0
    for cg in ["Correct", "Incorrect"]:
        for model in selected:
            positions.append(pos)
            labels.append(f"{cg}\n{MODEL_SHORT[model]}")
            colors.append(MODEL_COLORS[model])
            vals.append(plot.loc[(plot["correct_group"] == cg) & (plot["model_key"] == model), "credible_interval_width_95"].astype(float).values)
            pos += 1
        pos += 0.55
    parts = ax.violinplot(vals, positions=positions, widths=0.65, showmeans=False, showmedians=True, showextrema=False)
    for body, color in zip(parts["bodies"], colors):
        body.set_facecolor(color)
        body.set_alpha(0.45)
        body.set_edgecolor(PAL["dark"])
        body.set_linewidth(0.55)
    if "cmedians" in parts:
        parts["cmedians"].set_color(PAL["dark"])
        parts["cmedians"].set_linewidth(0.8)
    ax.set_yscale("log")
    ax.set_ylabel("95% credible interval width", fontsize=8.6)
    ax.set_xticks(positions)
    ax.set_xticklabels(labels, rotation=40, ha="right", fontsize=6.4)
    ax.set_title("Predictive uncertainty", fontsize=9.5, fontweight="bold")
    ax.grid(axis="y", color=PAL["grid"], linewidth=0.55, which="both")
    clean_axes(ax)
    fig.suptitle("Calibration and uncertainty", fontsize=12.0, fontweight="bold", y=1.03)
    save_figure(fig, "Figure6D_true_hgt_calibration_uncertainty")


def draw_panel_e() -> None:
    auroc = read_csv("panelE_true_hgt_ablation_auroc_for_barplot.csv").sort_values("model_order")
    table = read_csv("panelE_true_hgt_ablation_mean_metric_table.csv").sort_values("model_order")
    fig = plt.figure(figsize=(10.8, 4.2))
    ax = fig.add_axes([0.08, 0.18, 0.45, 0.66])
    y = np.arange(len(auroc))[::-1]
    colors = [MODEL_COLORS.get(m, PAL["gray"]) for m in auroc["model_key"]]
    ax.barh(y, auroc["mean"], xerr=auroc["sd"], color=colors, alpha=0.92, edgecolor="white", linewidth=0.5)
    ax.set_yticks(y)
    ax.set_yticklabels([MODEL_SHORT.get(m, m) for m in auroc["model_key"]], fontsize=8.0)
    ax.set_xlim(0.45, 1.02)
    ax.set_xlabel("AUROC", fontsize=8.8)
    ax.set_title("Ablation study: donor-held-out AUROC", fontsize=10.2, fontweight="bold")
    ax.grid(axis="x", color=PAL["grid"], linewidth=0.55)
    clean_axes(ax)

    ax2 = fig.add_axes([0.58, 0.14, 0.37, 0.72])
    ax2.axis("off")
    show = table[["model_key", "AUROC", "AUPRC", "F1", "Balanced accuracy"]].copy()
    show["Model"] = show["model_key"].map(MODEL_SHORT)
    cols = ["Model", "AUROC", "AUPRC", "F1", "Balanced accuracy"]
    cell_text = []
    for r in show[cols].itertuples(index=False):
        cell_text.append([r[0], f"{r[1]:.3f}", f"{r[2]:.3f}", f"{r[3]:.3f}", f"{r[4]:.3f}"])
    tbl = ax2.table(cellText=cell_text, colLabels=cols, cellLoc="center", colLoc="center", loc="center")
    tbl.auto_set_font_size(False)
    tbl.set_fontsize(7.0)
    tbl.scale(1.0, 1.45)
    for (row, col), cell in tbl.get_celld().items():
        cell.set_edgecolor(PAL["border"])
        cell.set_linewidth(0.55)
        if row == 0:
            cell.set_facecolor("#F2F4F7")
            cell.set_text_props(fontweight="bold")
        elif col == 0:
            cell.set_text_props(ha="left")
    fig.suptitle("True Bayesian HGT ablation metrics", fontsize=12.0, fontweight="bold", y=0.98)
    save_figure(fig, "Figure6E_true_hgt_ablation")


def draw_panel_f() -> None:
    rel = read_csv("panelF_true_hgt_feature_relevance_summary.csv")
    activity = read_csv("panelF_program_activity_by_dataset_context_long.csv")
    cmap = LinearSegmentedColormap.from_list("blue_white_red", ["#2166AC", "#F7F7F7", "#EF2B22"])
    fig = plt.figure(figsize=(13.2, 5.2))

    ax1 = fig.add_axes([0.07, 0.20, 0.34, 0.64])
    rel_use = rel[rel["token_type"].isin(["gene", "program"])].copy()
    rel_use["feature_label"] = rel_use["feature"].str.replace("_score", "", regex=False)
    rel_top = rel_use.sort_values("mean_relevance", ascending=False).head(18)
    y = np.arange(len(rel_top))[::-1]
    colors = [PAL["blue"] if t == "gene" else PAL["orange"] for t in rel_top["token_type"]]
    ax1.barh(y, rel_top["mean_relevance"], xerr=rel_top["sd_relevance"].fillna(0), color=colors, alpha=0.9)
    ax1.set_yticks(y)
    ax1.set_yticklabels(rel_top["feature_label"], fontsize=7.8, fontstyle="italic")
    ax1.set_xlabel("Mean |Δ probability| when feature zeroed", fontsize=8.4)
    ax1.set_title("Top HGT feature relevance", fontsize=10.0, fontweight="bold")
    ax1.grid(axis="x", color=PAL["grid"], linewidth=0.55)
    clean_axes(ax1)
    ax1.legend(handles=[Patch(facecolor=PAL["blue"], label="Gene token"), Patch(facecolor=PAL["orange"], label="Program token")], frameon=False, fontsize=7.6)

    ax2 = fig.add_axes([0.50, 0.22, 0.43, 0.60])
    activity["col_label"] = [
        pretty_context_label(ds, ctx) for ds, ctx in zip(activity["dataset"], activity["context"])
    ]
    order_cols = (
        activity[["dataset", "dataset_order", "context", "context_order", "col_label"]]
        .drop_duplicates()
        .sort_values(["dataset_order", "context_order"])["col_label"]
        .tolist()
    )
    mat = activity.pivot_table(index="program_label", columns="col_label", values="program_activity_z_within_program", aggfunc="first")
    mat = mat.reindex([p for p in PROGRAM_ORDER if p in mat.index])
    mat = mat[order_cols]
    im = ax2.imshow(mat.values, aspect="auto", cmap=cmap, norm=TwoSlopeNorm(vmin=-2, vcenter=0, vmax=2))
    ax2.set_yticks(np.arange(len(mat.index)))
    ax2.set_yticklabels(mat.index, fontsize=8.0)
    ax2.set_xticks(np.arange(len(mat.columns)))
    ax2.set_xticklabels(mat.columns, rotation=45, ha="right", fontsize=6.7)
    ax2.tick_params(length=0)
    ax2.set_title("Program activity across datasets and contexts", fontsize=10.0, fontweight="bold")
    for spine in ax2.spines.values():
        spine.set_color(PAL["border"])
        spine.set_linewidth(0.7)
    ax2.set_xticks(np.arange(-0.5, len(mat.columns), 1), minor=True)
    ax2.set_yticks(np.arange(-0.5, len(mat.index), 1), minor=True)
    ax2.grid(which="minor", color="white", linewidth=0.9)
    cax = fig.add_axes([0.945, 0.30, 0.014, 0.42])
    cb = fig.colorbar(im, cax=cax)
    cb.set_label("Program activity (z)", fontsize=7.8)
    cb.ax.tick_params(labelsize=7.0, length=2)
    fig.suptitle("Model interpretability and program activity", fontsize=12.0, fontweight="bold", y=0.98)
    save_figure(fig, "Figure6F_true_hgt_interpretability_program_activity")


def _activity_matrix() -> pd.DataFrame:
    activity = read_csv("panelF_program_activity_by_dataset_context_long.csv")
    activity["col_label"] = [
        pretty_context_label(ds, ctx) for ds, ctx in zip(activity["dataset"], activity["context"])
    ]
    order_cols = (
        activity[["dataset", "dataset_order", "context", "context_order", "col_label"]]
        .drop_duplicates()
        .sort_values(["dataset_order", "context_order"])["col_label"]
        .tolist()
    )
    mat = activity.pivot_table(
        index="program_label",
        columns="col_label",
        values="program_activity_z_within_program",
        aggfunc="first",
    )
    mat = mat.reindex([p for p in PROGRAM_ORDER if p in mat.index])
    return mat[order_cols]


def draw_panel_f1_feature_relevance() -> None:
    rel = read_csv("panelF_true_hgt_feature_relevance_summary.csv")
    rel_use = rel[rel["token_type"].isin(["gene", "program"])].copy()
    rel_use["feature_label"] = rel_use["feature"].str.replace("_score", "", regex=False)
    rel_top = rel_use.sort_values("mean_relevance", ascending=False).head(18)
    y = np.arange(len(rel_top))[::-1]
    colors = [PAL["blue"] if t == "gene" else PAL["orange"] for t in rel_top["token_type"]]

    fig, ax = plt.subplots(figsize=(7.2, 6.6))
    ax.barh(
        y,
        rel_top["mean_relevance"],
        xerr=rel_top["sd_relevance"].fillna(0),
        color=colors,
        alpha=0.92,
        error_kw={"elinewidth": 1.0, "capsize": 2.5, "capthick": 1.0},
    )
    ax.set_yticks(y)
    ax.set_yticklabels(rel_top["feature_label"], fontsize=9.8, fontstyle="italic")
    ax.set_xlabel("Mean |Δ probability| when feature is zeroed", fontsize=10.2)
    ax.set_title("Top HGT Feature Relevance", fontsize=13.5, fontweight="bold", pad=8)
    ax.grid(axis="x", color=PAL["grid"], linewidth=0.65)
    clean_axes(ax)
    ax.legend(
        handles=[Patch(facecolor=PAL["blue"], label="Gene token"), Patch(facecolor=PAL["orange"], label="Program token")],
        frameon=False,
        fontsize=9.5,
        loc="lower right",
    )
    fig.tight_layout(pad=0.9)
    save_figure(fig, "Figure6F1_true_hgt_feature_relevance")


def draw_panel_f2_program_activity() -> None:
    mat = _activity_matrix()
    cmap = LinearSegmentedColormap.from_list("blue_white_red", ["#2166AC", "#F7F7F7", "#EF2B22"])
    fig, ax = plt.subplots(figsize=(8.8, 4.8))
    im = ax.imshow(mat.values, aspect="auto", cmap=cmap, norm=TwoSlopeNorm(vmin=-2, vcenter=0, vmax=2))
    ax.set_yticks(np.arange(len(mat.index)))
    ax.set_yticklabels(mat.index, fontsize=10.0)
    ax.set_xticks(np.arange(len(mat.columns)))
    ax.set_xticklabels(mat.columns, rotation=30, ha="right", fontsize=8.2)
    ax.tick_params(length=0)
    ax.set_title("Program Activity Across Datasets and Contexts", fontsize=13.5, fontweight="bold", pad=8)
    for spine in ax.spines.values():
        spine.set_color(PAL["border"])
        spine.set_linewidth(0.7)
    ax.set_xticks(np.arange(-0.5, len(mat.columns), 1), minor=True)
    ax.set_yticks(np.arange(-0.5, len(mat.index), 1), minor=True)
    ax.grid(which="minor", color="white", linewidth=1.0)
    cb = fig.colorbar(im, ax=ax, fraction=0.035, pad=0.02)
    cb.set_label("Program activity (z)", fontsize=9.2)
    cb.ax.tick_params(labelsize=8.5, length=2)
    fig.tight_layout(pad=0.9)
    save_figure(fig, "Figure6F2_true_hgt_program_activity")


def make_contact_sheet() -> None:
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        return
    files = sorted(OUT.glob("Figure6*_900ppi.png"))
    thumbs = []
    for p in files:
        im = Image.open(p)
        im.thumbnail((560, 390))
        canvas = Image.new("RGB", (600, 450), "white")
        canvas.paste(im, ((600 - im.width) // 2, 18))
        d = ImageDraw.Draw(canvas)
        d.text((12, 420), p.name.replace("_900ppi.png", ""), fill=(0, 0, 0))
        thumbs.append(canvas)
    cols = 2
    rows = (len(thumbs) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * 600, rows * 450), "white")
    for i, t in enumerate(thumbs):
        sheet.paste(t, ((i % cols) * 600, (i // cols) * 450))
    sheet.save(OUT / "Figure6_true_hgt_separate_panels_contact_sheet_preview.png")


def main() -> None:
    setup_style()
    draw_panel_a()
    draw_panel_b()
    draw_panel_c()
    draw_panel_d()
    draw_panel_e()
    draw_panel_f()
    draw_panel_f1_feature_relevance()
    draw_panel_f2_program_activity()
    make_contact_sheet()
    (OUT / "README.txt").write_text(
        "\n".join(
            [
                "Separate Figure 6 panel files generated from true Bayesian HGT source CSVs.",
                f"Source CSV directory: {SRC}",
                "Each panel is saved as 900 ppi PNG, 900 ppi TIFF, and editable PDF.",
                "Panel C is a status figure because true external-validation HGT metrics are not available yet.",
            ]
        ),
        encoding="utf-8",
    )
    print(f"All separate Figure 6 panels written to: {OUT}")


if __name__ == "__main__":
    main()
