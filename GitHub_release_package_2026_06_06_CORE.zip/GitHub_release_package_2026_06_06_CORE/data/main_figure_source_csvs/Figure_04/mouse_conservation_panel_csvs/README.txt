Figure 4 mouse conservation source-data CSVs.
Output directory: F:\AD\Mam San\results\publication_figures\figure4_mouse_conservation_source_data
Panel A: GSE98969 WT/5xFAD UMAP state coordinates.
Panel B: GSE98969 WT/5xFAD UMAP module-score coordinates.
Panel C: GSE140510 UMAP state coordinates.
Panel D: GSE140510 sample-level state counts/proportions.
Panel E: GSE140510 group-level state proportion summaries and sample-level tests.
Panel F: GSE140510 sample-level pseudobulk marker expression matrix and annotations.
Panel G: GSE140510 sample-level module contrasts for Trem2 dependence.
State palette is preserved from Figure 2 when available.