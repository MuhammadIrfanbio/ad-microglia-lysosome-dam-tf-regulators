#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
ZNF335/Zfp335 all-module pathway analysis for microglial AD datasets.

This V2 script fixes the earlier crash by:
1) Never crashing when one .h5ad object is unreadable.
2) Writing outputs into a fresh timestamped folder to avoid permission/file-lock errors.
3) Detecting gene symbols from var_names and common .var columns, not only var_names.
4) Supporting both human ZNF335 and mouse Zfp335 symbols.
5) Expanding analysis beyond the six lipid modules to a broad microglial pathway panel.
6) Generating 900 ppi manuscript-ready PNG figures.

Working directory expected:
    F:\AD\Mam San

Core output:
    F:\AD\Mam San\results\ZNF335_all_modules_900ppi\run_YYYYMMDD_HHMMSS\
"""

import argparse
import gc
import os
import re
import shutil
import sys
import tempfile
import traceback
from pathlib import Path
from datetime import datetime

import numpy as np
import pandas as pd

from scipy import sparse
from scipy.stats import mannwhitneyu, spearmanr

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

try:
    import anndata as ad
    import scanpy as sc
    ANNDATA_OK = True
except Exception:
    ad = None
    sc = None
    ANNDATA_OK = False

try:
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.linear_model import LogisticRegression
    from sklearn.model_selection import StratifiedKFold, cross_val_score
    from sklearn.preprocessing import StandardScaler
    SKLEARN_OK = True
except Exception:
    SKLEARN_OK = False


# =============================================================================
# 1. Curated pathway/module gene sets
# =============================================================================
# Use uppercase internally. Mouse symbols will be matched case-insensitively.
# These modules are intentionally broad. Later you should experimentally validate
# only the top 1-2 genes per most relevant module.

MODULES = {
    # -------------------------------------------------------------------------
    # User-requested lipid modules
    # -------------------------------------------------------------------------
    "LIPID_DAM_lipid_associated_microglia": [
        "APOE", "TREM2", "TYROBP", "LPL", "CST7", "AXL", "ITGAX"
    ],
    "LIPID_uptake_phagocytosis": [
        "CD36", "LRP1", "TREM2", "LPL", "MERTK", "AXL"
    ],
    "LIPID_cholesterol_efflux_transport": [
        "ABCA1", "ABCG1", "APOE", "APOC1", "CLU"
    ],
    "LIPID_droplet_storage": [
        "PLIN2", "SOAT1", "SOAT2", "DGAT1", "DGAT2", "ACAT2"
    ],
    "LIPID_cholesterol_synthesis_SREBP": [
        "SREBF2", "HMGCR", "HMGCS1", "MVK", "MVD", "FDPS", "FDFT1", "SQLE", "LSS", "DHCR7", "DHCR24", "LDLR"
    ],
    "LIPID_nuclear_receptor_regulation": [
        "NR1H3", "NR1H2", "RXRA", "RXRB", "PPARG", "PPARA", "PPARD", "RARA", "RARB"
    ],

    # -------------------------------------------------------------------------
    # Detailed lipid metabolism
    # -------------------------------------------------------------------------
    "LIPID_cholesterol_import_trafficking": [
        "LDLR", "LRP1", "SCARB1", "CD36", "NPC1", "NPC2", "LIPA", "OSBPL1A", "OSBPL2", "STARD3"
    ],
    "LIPID_cholesterol_esterification": [
        "SOAT1", "SOAT2", "ACAT2", "LIPA", "NCEH1", "LIPE"
    ],
    "LIPID_fatty_acid_uptake_transport": [
        "CD36", "SLC27A1", "SLC27A3", "SLC27A4", "SLC27A5", "FABP3", "FABP4", "FABP5", "LPL"
    ],
    "LIPID_fatty_acid_synthesis": [
        "ACLY", "ACACA", "ACACB", "FASN", "SCD", "ELOVL1", "ELOVL5", "ELOVL6", "SREBF1"
    ],
    "LIPID_beta_oxidation_FAO": [
        "CPT1A", "CPT1B", "CPT2", "ACOX1", "ACOX3", "ACADVL", "ACADM", "ACADS", "HADHA", "HADHB", "PPARA"
    ],
    "LIPID_triglyceride_synthesis_lipolysis": [
        "GPAM", "AGPAT1", "AGPAT2", "DGAT1", "DGAT2", "PNPLA2", "LIPE", "MGLL", "PLIN2", "PLIN3"
    ],
    "LIPID_phospholipid_remodeling": [
        "PLA2G4A", "PLA2G6", "LPCAT1", "LPCAT2", "LPCAT3", "LPCAT4", "MBOAT7", "CEPT1", "CHPT1"
    ],
    "LIPID_sphingolipid_ceramide": [
        "SPTLC1", "SPTLC2", "CERS2", "CERS4", "CERS5", "CERS6", "SGMS1", "SGMS2", "ASAH1", "SMPD1", "SMPD2", "DEGS1"
    ],
    "LIPID_eicosanoid_prostaglandin": [
        "PLA2G4A", "PTGS1", "PTGS2", "PTGES", "PTGES2", "PTGER2", "PTGER4", "ALOX5", "ALOX12", "ALOX15", "TBXAS1"
    ],
    "LIPID_oxysterol_LXR_axis": [
        "NR1H3", "NR1H2", "ABCA1", "ABCG1", "APOE", "APOC1", "SREBF1", "MYLIP", "IDOL", "CYP27A1", "CH25H"
    ],
    "LIPID_myelin_lipid_clearance": [
        "TREM2", "APOE", "LPL", "LGALS3", "CTSB", "CTSD", "LIPA", "NPC1", "NPC2", "PLIN2", "CD68", "AXL", "MERTK"
    ],
    "LIPID_ferroptosis_lipid_peroxidation": [
        "GPX4", "SLC7A11", "ACSL4", "LPCAT3", "ALOX5", "ALOX12", "ALOX15", "FTH1", "FTL", "TFRC", "NFE2L2", "HMOX1"
    ],

    # -------------------------------------------------------------------------
    # DAM, homeostatic, lysosome/phagosome, and AD microglial biology
    # -------------------------------------------------------------------------
    "MICRO_homeostatic_identity": [
        "P2RY12", "TMEM119", "CX3CR1", "CSF1R", "SALL1", "GPR34", "SELPLG", "OLFML3", "TGFBR1"
    ],
    "MICRO_DAM_stage1_like": [
        "APOE", "TYROBP", "B2M", "CTSB", "CTSD", "LPL", "AXL"
    ],
    "MICRO_DAM_stage2_TREM2_dependent": [
        "TREM2", "LPL", "CST7", "ITGAX", "CD9", "GPNMB", "CLEC7A", "SPP1", "AXL"
    ],
    "MICRO_TREM2_APOE_axis": [
        "TREM2", "APOE", "TYROBP", "LPL", "AXL", "LGALS3", "GPNMB", "CD9", "SPP1"
    ],
    "MICRO_phagosome_efferocytosis": [
        "MERTK", "AXL", "TYROBP", "TREM2", "LAMP1", "LAMP2", "CD68", "ITGAM", "ITGAX", "FCGR1A", "FCGR2A", "FCGR3A"
    ],
    "MICRO_lysosome_phagosome": [
        "CTSB", "CTSD", "CTSS", "CTSZ", "LAMP1", "LAMP2", "CD68", "HEXA", "HEXB", "LIPA", "NPC1", "NPC2", "ATP6V0D1", "ATP6V1B2"
    ],
    "MICRO_autophagy_mitophagy": [
        "BECN1", "ATG5", "ATG7", "MAP1LC3B", "SQSTM1", "OPTN", "TBK1", "PINK1", "PRKN", "BNIP3", "BNIP3L"
    ],
    "MICRO_complement": [
        "C1QA", "C1QB", "C1QC", "C3", "C4A", "C4B", "CFB", "CFD", "CR1", "CR3", "ITGAM", "ITGB2"
    ],
    "MICRO_antigen_presentation_MHC": [
        "HLA-DRA", "HLA-DRB1", "HLA-DPA1", "HLA-DPB1", "HLA-DQA1", "HLA-DQB1", "CD74", "B2M", "TAP1", "TAP2"
    ],
    "MICRO_interferon_response": [
        "STAT1", "IRF7", "IRF9", "ISG15", "IFIT1", "IFIT2", "IFIT3", "MX1", "OAS1", "OAS2", "IFI44L", "CXCL10"
    ],
    "MICRO_NFkB_inflammatory_cytokine": [
        "NFKB1", "NFKBIA", "RELA", "TNF", "IL1B", "IL6", "CXCL8", "CCL2", "CCL3", "CCL4", "PTGS2", "NOS2"
    ],
    "MICRO_inflammasome": [
        "NLRP3", "PYCARD", "CASP1", "IL1B", "IL18", "GSDMD", "TXNIP", "NEK7"
    ],
    "MICRO_chemokine_migration": [
        "CCL2", "CCL3", "CCL4", "CCL5", "CXCL10", "CX3CR1", "CCR5", "CCR2", "CXCR4", "ITGAM", "ITGB2"
    ],
    "MICRO_proliferation_cell_cycle": [
        "MKI67", "TOP2A", "PCNA", "STMN1", "TYMS", "HMGB2", "UBE2C", "BIRC5", "CDK1", "CCNB1"
    ],
    "MICRO_oxidative_stress_NRF2": [
        "NFE2L2", "KEAP1", "HMOX1", "NQO1", "GCLC", "GCLM", "SOD1", "SOD2", "PRDX1", "PRDX6", "TXN", "TXNRD1"
    ],
    "MICRO_ER_stress_UPR": [
        "HSPA5", "XBP1", "ATF4", "ATF6", "DDIT3", "ERN1", "EIF2AK3", "DNAJB9", "HERPUD1", "PDIA3"
    ],

    # -------------------------------------------------------------------------
    # Metabolic state modules
    # -------------------------------------------------------------------------
    "METAB_glycolysis": [
        "HK1", "HK2", "GPI", "PFKP", "ALDOA", "GAPDH", "PGK1", "PGAM1", "ENO1", "PKM", "LDHA", "SLC2A1"
    ],
    "METAB_TCA_cycle": [
        "CS", "ACO2", "IDH3A", "IDH3B", "OGDH", "DLST", "SUCLG1", "SDHA", "SDHB", "FH", "MDH2"
    ],
    "METAB_OXPHOS_mitochondrial": [
        "NDUFA1", "NDUFA2", "NDUFB8", "NDUFS1", "SDHA", "UQCRC1", "UQCRC2", "COX4I1", "COX5A", "ATP5F1A", "ATP5F1B"
    ],
    "METAB_mTOR_AMPK_nutrient_sensing": [
        "MTOR", "RPTOR", "RICTOR", "AKT1", "TSC1", "TSC2", "RHEB", "PRKAA1", "PRKAA2", "STK11", "ULK1"
    ],

    # -------------------------------------------------------------------------
    # TF/regulator modules relevant to this manuscript
    # -------------------------------------------------------------------------
    "TF_myeloid_core": [
        "SPI1", "IRF8", "CEBPB", "MAFB", "RUNX1", "MEF2C", "SALL1"
    ],
    "TF_interferon_regulators": [
        "STAT1", "STAT2", "IRF1", "IRF7", "IRF9"
    ],
    "TF_lysosomal_biogenesis": [
        "TFEB", "TFE3", "MITF", "ZKSCAN3"
    ],
    "TF_lipid_nuclear_receptors": [
        "NR1H3", "NR1H2", "RXRA", "PPARG", "PPARA", "PPARD", "SREBF1", "SREBF2"
    ],
    "TF_ZNF335_context": [
        "ZNF335", "ZFP335", "REST", "STAT1", "IRF7", "IRF8", "SPI1", "CEBPB", "PPARG", "NR1H3"
    ],
}

ZNF_ALIASES = ["ZNF335", "ZFP335"]


# =============================================================================
# 2. Logging and file management
# =============================================================================

def stamp():
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def safe_print(msg):
    try:
        print(msg, flush=True)
    except Exception:
        pass


def make_logger(log_file):
    log_file = Path(log_file)
    def _log(msg):
        line = f"[{now()}] {msg}"
        safe_print(line)
        try:
            with open(log_file, "a", encoding="utf-8") as handle:
                handle.write(line + "\n")
        except Exception:
            # Never crash due to log permission or file locking.
            safe_print("[LOGGER WARNING] Could not write to log file.")
    return _log


def safe_name(x, max_len=120):
    y = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(x))
    return y[:max_len].strip("_") or "unnamed"


def is_previous_output(path):
    s = str(path).replace("\\", "/").lower()
    bad = [
        "znf335_lipid_module_filter",
        "znf335_all_modules_900ppi",
        "/figures/",
        "/__pycache__/",
    ]
    return any(b in s for b in bad)


def find_input_files(root, recursive=True, include_csv=False):
    root = Path(root)
    patterns = ["*.h5ad"]
    if include_csv:
        patterns += ["*.csv", "*.tsv", "*.txt"]

    files = []
    for pat in patterns:
        files.extend(root.rglob(pat) if recursive else root.glob(pat))

    files = [p for p in files if not is_previous_output(p)]
    return sorted(set(files))


# =============================================================================
# 3. Robust AnnData reading and gene symbol mapping
# =============================================================================

def copy_to_temp_if_requested(path, temp_dir, log, do_copy=False):
    path = Path(path)
    if not do_copy:
        return path
    temp_dir = Path(temp_dir)
    temp_dir.mkdir(parents=True, exist_ok=True)
    dst = temp_dir / path.name
    try:
        log(f"Copying to temporary local file before reading: {dst}")
        shutil.copy2(path, dst)
        return dst
    except Exception as e:
        log(f"Temporary copy failed; reading original. Reason: {repr(e)}")
        return path


def read_adata_robust(path, log, backed=False):
    if not ANNDATA_OK:
        raise ImportError("scanpy/anndata is not installed.")

    # Try scanpy first, then anndata.
    errors = []

    try:
        return sc.read_h5ad(path, backed="r" if backed else None)
    except Exception as e:
        errors.append(("scanpy.read_h5ad", repr(e)))

    try:
        return ad.read_h5ad(path, backed="r" if backed else None)
    except Exception as e:
        errors.append(("anndata.read_h5ad", repr(e)))

    # As a last chance, try backed mode even if not requested.
    if not backed:
        try:
            log("Direct read failed. Trying backed='r' mode.")
            return ad.read_h5ad(path, backed="r")
        except Exception as e:
            errors.append(("anndata.read_h5ad_backed", repr(e)))

    raise RuntimeError("Could not read h5ad. Attempts: " + " | ".join([f"{k}: {v}" for k, v in errors]))


def read_matrix_as_adata(path):
    suffix = Path(path).suffix.lower()
    sep = "," if suffix == ".csv" else "\t"
    df = pd.read_csv(path, sep=sep, index_col=0)

    # Heuristic: if rows look like genes and columns look like cells, transpose.
    # Otherwise assume rows are cells/samples and columns are genes.
    row_gene_like = np.mean([str(x).upper() in {"APOE", "TREM2", "ZNF335", "ZFP335", "LPL", "ABCA1"} for x in df.index[:500]])
    col_gene_like = np.mean([str(x).upper() in {"APOE", "TREM2", "ZNF335", "ZFP335", "LPL", "ABCA1"} for x in df.columns[:500]])
    if row_gene_like > col_gene_like:
        df = df.T

    a = ad.AnnData(df)
    a.obs["source_matrix"] = Path(path).name
    return a


def read_object(path, log, temp_dir=None, copy_to_temp=False, backed=False):
    path = Path(path)
    suffix = path.suffix.lower()

    if suffix == ".h5ad":
        read_path = copy_to_temp_if_requested(path, temp_dir, log, do_copy=copy_to_temp)
        return read_adata_robust(read_path, log=log, backed=backed), "h5ad"

    if suffix in [".csv", ".tsv", ".txt"]:
        return read_matrix_as_adata(path), "matrix"

    raise ValueError(f"Unsupported file type: {path}")


def get_axis(adata, use_raw=True):
    if use_raw and getattr(adata, "raw", None) is not None:
        try:
            return adata.raw.X, adata.raw.var, list(adata.raw.var_names), "raw"
        except Exception:
            pass
    return adata.X, adata.var, list(adata.var_names), "X"


def normalize_symbol(x):
    if x is None:
        return None
    s = str(x).strip()
    if s == "" or s.lower() in ["nan", "none", "na"]:
        return None
    # Remove common Ensembl version suffix only for Ensembl IDs.
    if s.upper().startswith(("ENSG", "ENSMUSG")):
        s = s.split(".")[0]
    return s.upper()


def build_gene_lookup(var_df, var_names):
    """
    Return dict: UPPER_SYMBOL_OR_ID -> column index.
    Searches both var_names and common gene-symbol columns.
    """
    lookup = {}

    def add(symbol, idx):
        key = normalize_symbol(symbol)
        if key and key not in lookup:
            lookup[key] = idx

    for idx, name in enumerate(var_names):
        add(name, idx)

    preferred_cols = [
        "gene_symbol", "gene_symbols", "symbol", "symbols", "gene_name", "gene_names",
        "feature_name", "feature_names", "features", "name", "names",
        "hgnc_symbol", "mgi_symbol", "external_gene_name", "gene", "genes",
        "Gene", "Symbol", "GeneSymbol"
    ]

    # Search preferred first, then any column containing symbol/name/gene.
    cols = []
    for c in preferred_cols:
        if c in var_df.columns:
            cols.append(c)
    for c in var_df.columns:
        lc = str(c).lower()
        if c not in cols and any(k in lc for k in ["symbol", "gene_name", "feature", "hgnc", "mgi"]):
            cols.append(c)

    for col in cols:
        try:
            vals = list(var_df[col].values)
            for idx, val in enumerate(vals):
                add(val, idx)
        except Exception:
            continue

    return lookup, cols


def select_columns_from_X(X, indices):
    M = X[:, indices]
    if sparse.issparse(M):
        return M.toarray()
    try:
        return np.asarray(M)
    except Exception:
        return np.asarray(M[:])


def gene_matrix(adata, genes, use_raw=True):
    X, var_df, var_names, layer = get_axis(adata, use_raw=use_raw)
    lookup, symbol_cols = build_gene_lookup(var_df, var_names)

    indices = []
    found = []
    for g in genes:
        key = normalize_symbol(g)
        if key in lookup:
            idx = lookup[key]
            indices.append(idx)
            found.append(str(var_names[idx]))

    if not indices:
        return None, [], layer, symbol_cols

    M = select_columns_from_X(X, indices).astype(float)
    M[~np.isfinite(M)] = 0.0
    return M, found, layer, symbol_cols


def gene_vector(adata, gene, use_raw=True):
    M, found, layer, symbol_cols = gene_matrix(adata, [gene], use_raw=use_raw)
    if M is None:
        return None, None, layer, symbol_cols
    return np.asarray(M[:, 0]).ravel().astype(float), found[0], layer, symbol_cols


def choose_znf_gene(adata, use_raw=True):
    for g in ZNF_ALIASES:
        v, actual, layer, symbol_cols = gene_vector(adata, g, use_raw=use_raw)
        if v is not None:
            return g, actual, v, layer, symbol_cols
    # Try common lowercase just in case.
    for g in ["Znf335", "zfp335", "znf335"]:
        v, actual, layer, symbol_cols = gene_vector(adata, g, use_raw=use_raw)
        if v is not None:
            return g, actual, v, layer, symbol_cols
    _, var_df, var_names, layer = get_axis(adata, use_raw=use_raw)
    _, symbol_cols = build_gene_lookup(var_df, var_names)
    return None, None, None, layer, symbol_cols


# =============================================================================
# 4. Filtering, scoring, statistics
# =============================================================================

def maybe_filter_microglia(adata, log, disable_filter=False):
    if disable_filter:
        return adata, "no_filter_requested"

    candidate_cols = []
    preferred = [
        "author_cell_type", "cell_type", "celltype", "cell type", "CellType", "cell_type_fine",
        "subclass", "class", "annotation", "annotations", "cluster", "state",
        "major_cell_type", "major_type", "cell_ontology_class", "cell.type"
    ]
    for c in preferred:
        if c in adata.obs.columns:
            candidate_cols.append(c)

    for c in adata.obs.columns:
        lc = str(c).lower()
        if c not in candidate_cols and any(k in lc for k in ["cell", "annot", "type", "class"]):
            candidate_cols.append(c)

    for col in candidate_cols:
        try:
            vals = adata.obs[col].astype(str).str.lower()
            mask = (
                vals.str.contains("microglia", regex=False)
                | vals.str.contains("microglial", regex=False)
                | vals.str.fullmatch("mg")
                | vals.str.contains("myeloid", regex=False)
            )
            if mask.sum() >= 50 and 0.01 <= mask.mean() <= 0.99:
                return adata[mask].copy(), f"filtered_by_{col}"
        except Exception:
            continue

    return adata, "assumed_microglia_or_no_celltype_column"


def zscore_cols(M):
    M = np.asarray(M, dtype=float)
    mu = np.nanmean(M, axis=0)
    sd = np.nanstd(M, axis=0)
    sd[sd == 0] = 1.0
    return (M - mu) / sd


def score_module(adata, genes, use_raw=True):
    M, found, layer, symbol_cols = gene_matrix(adata, genes, use_raw=use_raw)
    if M is None or len(found) == 0:
        return np.full(adata.n_obs, np.nan), [], layer, symbol_cols
    Z = zscore_cols(M)
    score = np.nanmean(Z, axis=1)
    return score, found, layer, symbol_cols


def define_high_low_groups(znf_vec, min_group=25, high_q=0.75, low_q=0.25):
    z = np.asarray(znf_vec, dtype=float)
    z[~np.isfinite(z)] = 0.0
    positive = z > 0
    det = float(positive.mean())

    if positive.sum() >= min_group and det < 0.20:
        high = positive
        low = ~positive
        method = "sparse_TF_positive_vs_zero"
    else:
        qh = np.nanquantile(z, high_q)
        ql = np.nanquantile(z, low_q)
        high = z >= qh
        low = z <= ql
        method = f"quantile_Q{high_q}_vs_Q{low_q}"
        if qh == ql and positive.sum() >= min_group:
            high = positive
            low = ~positive
            method = "collapsed_quantile_positive_vs_zero"

    warning = ""
    if high.sum() < min_group or low.sum() < min_group:
        warning = "_WARNING_small_group"
    return high, low, det, method + warning


def bh_fdr(pvals):
    p = np.asarray(pvals, dtype=float)
    out = np.full(p.shape, np.nan, dtype=float)
    valid = np.isfinite(p)
    pv = p[valid]
    if len(pv) == 0:
        return out
    order = np.argsort(pv)
    ranked = pv[order]
    n = len(ranked)
    q = ranked * n / (np.arange(n) + 1)
    q = np.minimum.accumulate(q[::-1])[::-1]
    q = np.clip(q, 0, 1)
    tmp = np.empty(n)
    tmp[order] = q
    out[valid] = tmp
    return out


def cohen_d(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    x = x[np.isfinite(x)]
    y = y[np.isfinite(y)]
    if len(x) < 2 or len(y) < 2:
        return np.nan
    vx = np.var(x, ddof=1)
    vy = np.var(y, ddof=1)
    pooled = np.sqrt(((len(x)-1)*vx + (len(y)-1)*vy) / max((len(x)+len(y)-2), 1))
    if pooled == 0 or not np.isfinite(pooled):
        return 0.0
    return float((np.mean(x) - np.mean(y)) / pooled)


def cliffs_delta(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    x = x[np.isfinite(x)]
    y = y[np.isfinite(y)]
    if len(x) == 0 or len(y) == 0:
        return np.nan
    try:
        U = mannwhitneyu(x, y, alternative="two-sided").statistic
        return float((2 * U) / (len(x) * len(y)) - 1)
    except Exception:
        return np.nan


def detect_sample_column(obs):
    preferred = [
        "donor", "donor_id", "Donor", "individual", "subject", "sample", "sample_id",
        "Sample", "orig.ident", "orig_ident", "library", "batch", "patient", "case",
        "specimen", "biosample", "mouse", "animal", "replicate"
    ]
    for col in preferred:
        if col in obs.columns:
            n = obs[col].nunique(dropna=True)
            if 2 <= n <= 500:
                return col

    for col in obs.columns:
        try:
            n = obs[col].nunique(dropna=True)
            if 2 <= n <= 500 and obs[col].dtype.name in ["category", "object", "string"]:
                return col
        except Exception:
            continue
    return None


def summarize_direction(effect):
    if not np.isfinite(effect):
        return "not_available"
    if effect > 0:
        return "higher_in_ZNF_high"
    if effect < 0:
        return "lower_in_ZNF_high_inverse"
    return "no_difference"


# =============================================================================
# 5. ML ranking
# =============================================================================

def ml_importance_for_genes(adata, genes, high, low, use_raw=True, log=None):
    if not SKLEARN_OK:
        return {}, {}, np.nan, np.nan

    mask = high | low
    y = high[mask].astype(int)
    if len(np.unique(y)) < 2 or min(np.bincount(y)) < 10:
        return {}, {}, np.nan, np.nan

    sub = adata[mask].copy()
    M, found, layer, symbol_cols = gene_matrix(sub, genes, use_raw=use_raw)
    if M is None or len(found) < 2:
        return {}, {}, np.nan, np.nan

    X = np.asarray(M, dtype=float)
    X[~np.isfinite(X)] = 0.0

    actual_upper = [normalize_symbol(g) for g in found]

    rf_imp = {}
    lasso_coef = {}
    rf_auc = np.nan
    lasso_auc = np.nan

    try:
        Xs = StandardScaler().fit_transform(X)
    except Exception:
        Xs = X

    try:
        cv = StratifiedKFold(n_splits=3, shuffle=True, random_state=7)

        rf = RandomForestClassifier(
            n_estimators=400,
            random_state=7,
            class_weight="balanced",
            n_jobs=-1,
            min_samples_leaf=3
        )
        rf_auc = float(np.mean(cross_val_score(rf, Xs, y, cv=cv, scoring="roc_auc")))
        rf.fit(Xs, y)
        rf_imp = dict(zip(actual_upper, rf.feature_importances_))
    except Exception as e:
        if log:
            log(f"RF skipped: {repr(e)}")

    try:
        lasso = LogisticRegression(
            penalty="l1",
            solver="liblinear",
            class_weight="balanced",
            max_iter=2000,
            random_state=7
        )
        lasso_auc = float(np.mean(cross_val_score(lasso, Xs, y, cv=cv, scoring="roc_auc")))
        lasso.fit(Xs, y)
        lasso_coef = dict(zip(actual_upper, np.ravel(lasso.coef_)))
    except Exception as e:
        if log:
            log(f"LASSO logistic skipped: {repr(e)}")

    return rf_imp, lasso_coef, rf_auc, lasso_auc


# =============================================================================
# 6. Figures, 900 ppi
# =============================================================================

def save_bar_modules(comp_df, dataset, fig_dir, dpi=900):
    if comp_df.empty:
        return
    df = comp_df.sort_values("cohen_d_high_minus_low", ascending=True).copy()
    y = np.arange(df.shape[0])

    fig_h = max(6, 0.24 * df.shape[0] + 2)
    fig, ax = plt.subplots(figsize=(9, fig_h))
    ax.barh(y, df["cohen_d_high_minus_low"].values)
    ax.set_yticks(y)
    ax.set_yticklabels([m.replace("_", " ") for m in df["module"]], fontsize=7)
    ax.axvline(0, linewidth=1)
    ax.set_xlabel("Cohen's d: ZNF-high minus ZNF-low")
    ax.set_title(f"{dataset}: ZNF335/Zfp335-linked module shifts")
    fig.tight_layout()
    fig.savefig(fig_dir / f"{dataset}_module_effects_900ppi.png", dpi=dpi)
    plt.close(fig)


def save_heatmap_modules(comp_df, dataset, fig_dir, dpi=900):
    if comp_df.empty:
        return
    df = comp_df.copy()
    vals = df[["cohen_d_high_minus_low"]].values
    fig_h = max(6, 0.22 * df.shape[0] + 2)
    fig, ax = plt.subplots(figsize=(5.5, fig_h))
    im = ax.imshow(vals, aspect="auto")
    ax.set_yticks(np.arange(df.shape[0]))
    ax.set_yticklabels([m.replace("_", " ") for m in df["module"]], fontsize=7)
    ax.set_xticks([0])
    ax.set_xticklabels(["Cohen d\nhigh-low"])
    for i, v in enumerate(df["cohen_d_high_minus_low"].values):
        if np.isfinite(v):
            ax.text(0, i, f"{v:.2f}", ha="center", va="center", fontsize=6)
    ax.set_title(f"{dataset}: module effect heatmap")
    fig.colorbar(im, ax=ax, fraction=0.05, pad=0.04)
    fig.tight_layout()
    fig.savefig(fig_dir / f"{dataset}_module_heatmap_900ppi.png", dpi=dpi)
    plt.close(fig)


def save_gene_candidate_plot(top_df, dataset, fig_dir, dpi=900, max_genes=40):
    if top_df.empty:
        return
    df = top_df[top_df["dataset"] == dataset].copy()
    if df.empty:
        return
    df["label"] = df["gene_found"].astype(str) + " | " + df["module"].astype(str).str.replace("_", " ", regex=False)
    df = df.sort_values("candidate_score_abs", ascending=True).tail(max_genes)

    fig_h = max(6, 0.28 * df.shape[0] + 2)
    fig, ax = plt.subplots(figsize=(10, fig_h))
    ax.barh(np.arange(df.shape[0]), df["candidate_score_abs"].values)
    ax.set_yticks(np.arange(df.shape[0]))
    ax.set_yticklabels(df["label"].values, fontsize=7)
    ax.set_xlabel("Composite candidate score")
    ax.set_title(f"{dataset}: top ZNF335/Zfp335-associated module genes")
    fig.tight_layout()
    fig.savefig(fig_dir / f"{dataset}_top_candidate_genes_900ppi.png", dpi=dpi)
    plt.close(fig)


def save_summary_heatmap(all_comp, fig_dir, dpi=900):
    if all_comp.empty:
        return
    piv = all_comp.pivot_table(
        index="module",
        columns="dataset",
        values="cohen_d_high_minus_low",
        aggfunc="mean"
    )
    if piv.empty:
        return
    fig_h = max(8, 0.24 * piv.shape[0] + 2)
    fig_w = max(7, 1.4 * piv.shape[1] + 3)
    fig, ax = plt.subplots(figsize=(fig_w, fig_h))
    im = ax.imshow(piv.values, aspect="auto")
    ax.set_yticks(np.arange(piv.shape[0]))
    ax.set_yticklabels([m.replace("_", " ") for m in piv.index], fontsize=7)
    ax.set_xticks(np.arange(piv.shape[1]))
    ax.set_xticklabels(piv.columns, rotation=45, ha="right", fontsize=8)
    ax.set_title("Cross-dataset ZNF335/Zfp335 module effects")
    fig.colorbar(im, ax=ax, fraction=0.03, pad=0.02)
    fig.tight_layout()
    fig.savefig(fig_dir / "ALL_DATASETS_module_effect_heatmap_900ppi.png", dpi=dpi)
    plt.close(fig)


# =============================================================================
# 7. Main per-object analysis
# =============================================================================

def process_one_file(path, args, run_dir, fig_dir, log):
    dataset = safe_name(Path(path).stem)
    log(f"Reading {path}")

    obj_type = ""
    try:
        adata, obj_type = read_object(
            path,
            log=log,
            temp_dir=run_dir / "_temp_read",
            copy_to_temp=args.copy_to_temp,
            backed=False
        )
    except Exception as e:
        log(f"SKIPPED unreadable object: {path}")
        log(f"Reason: {repr(e)}")
        log("Suggestion: if this is an important final object, re-save it with a stable anndata version or regenerate it.")
        return {
            "status": "skipped_unreadable",
            "object": {
                "dataset": dataset,
                "path": str(path),
                "status": "skipped_unreadable",
                "error": repr(e),
            },
            "presence": pd.DataFrame(),
            "comparisons": pd.DataFrame(),
            "sample_corr": pd.DataFrame(),
            "gene_rank": pd.DataFrame(),
        }

    original_n = int(adata.n_obs)
    try:
        adata, filter_note = maybe_filter_microglia(adata, log=log, disable_filter=args.no_filter_microglia)
    except Exception as e:
        filter_note = f"filter_failed_assumed_all_cells: {repr(e)}"

    log(f"{dataset}: n_obs {original_n} -> {adata.n_obs}; filter: {filter_note}")

    if adata.n_obs < args.min_cells:
        log(f"{dataset}: skipped because too few cells/observations after filtering.")
        return {
            "status": "skipped_too_few_cells",
            "object": {
                "dataset": dataset, "path": str(path), "status": "skipped_too_few_cells",
                "n_obs_after_filter": int(adata.n_obs)
            },
            "presence": pd.DataFrame(),
            "comparisons": pd.DataFrame(),
            "sample_corr": pd.DataFrame(),
            "gene_rank": pd.DataFrame(),
        }

    znf_req, znf_actual, znf_vec, znf_layer, symbol_cols = choose_znf_gene(adata, use_raw=not args.no_raw)
    if znf_vec is None:
        # Save gene lookup columns to help debug.
        log(f"{dataset}: skipped because neither ZNF335 nor ZFP335 was found.")
        log(f"{dataset}: gene-symbol columns checked: {symbol_cols}")
        return {
            "status": "skipped_no_znf",
            "object": {
                "dataset": dataset,
                "path": str(path),
                "status": "skipped_no_znf",
                "n_obs_after_filter": int(adata.n_obs),
                "gene_symbol_columns_checked": ";".join(map(str, symbol_cols)),
            },
            "presence": pd.DataFrame(),
            "comparisons": pd.DataFrame(),
            "sample_corr": pd.DataFrame(),
            "gene_rank": pd.DataFrame(),
        }

    high, low, det, group_method = define_high_low_groups(
        znf_vec,
        min_group=args.min_group,
        high_q=args.high_quantile,
        low_q=args.low_quantile
    )
    log(f"{dataset}: using {znf_actual}; detection={det:.4f}; high={high.sum()}; low={low.sum()}; method={group_method}")

    # Module scores and gene presence.
    module_scores = {}
    presence_rows = []
    for module, genes in MODULES.items():
        score, found, layer, symbol_cols_used = score_module(adata, genes, use_raw=not args.no_raw)
        module_scores[module] = score
        found_upper = {normalize_symbol(x) for x in found}
        input_upper = [normalize_symbol(x) for x in genes]
        presence_rows.append({
            "dataset": dataset,
            "object_path": str(path),
            "module": module,
            "n_input_genes": len(genes),
            "n_found_genes": len(found),
            "found_var_names": ";".join(map(str, found)),
            "missing_input_genes": ";".join([g for g in genes if normalize_symbol(g) not in found_upper]),
            "expression_layer": layer,
            "symbol_columns_used": ";".join(map(str, symbol_cols_used)),
        })

    score_df = pd.DataFrame(module_scores, index=adata.obs_names)
    score_df["ZNF_expression"] = znf_vec
    score_df["ZNF_group"] = "middle"
    score_df.loc[low, "ZNF_group"] = "ZNF_low"
    score_df.loc[high, "ZNF_group"] = "ZNF_high"

    # Module comparisons.
    comp_rows = []
    for module in MODULES:
        x = score_df.loc[high, module].values
        y = score_df.loc[low, module].values

        try:
            p = mannwhitneyu(x[np.isfinite(x)], y[np.isfinite(y)], alternative="two-sided").pvalue
        except Exception:
            p = np.nan
        try:
            rho, rp = spearmanr(znf_vec, score_df[module].values, nan_policy="omit")
        except Exception:
            rho, rp = np.nan, np.nan

        eff = cohen_d(x, y)
        comp_rows.append({
            "dataset": dataset,
            "object_path": str(path),
            "ZNF_gene": znf_actual,
            "ZNF_detection_fraction": det,
            "group_method": group_method,
            "n_cells": int(adata.n_obs),
            "n_ZNF_high": int(high.sum()),
            "n_ZNF_low": int(low.sum()),
            "module": module,
            "mean_ZNF_high": float(np.nanmean(x)),
            "mean_ZNF_low": float(np.nanmean(y)),
            "mean_difference_high_minus_low": float(np.nanmean(x) - np.nanmean(y)),
            "cohen_d_high_minus_low": eff,
            "cliffs_delta_high_vs_low": cliffs_delta(x, y),
            "mannwhitney_p": p,
            "spearman_ZNF_vs_module_rho": rho,
            "spearman_ZNF_vs_module_p": rp,
            "direction": summarize_direction(eff),
        })

    comp_df = pd.DataFrame(comp_rows)
    if not comp_df.empty:
        comp_df["mannwhitney_fdr_within_dataset"] = bh_fdr(comp_df["mannwhitney_p"].values)
        comp_df["spearman_fdr_within_dataset"] = bh_fdr(comp_df["spearman_ZNF_vs_module_p"].values)

    # Sample/donor-level correlations.
    sample_rows = []
    sample_col = detect_sample_column(adata.obs)
    if sample_col is not None:
        tmp = score_df.copy()
        tmp[sample_col] = adata.obs[sample_col].astype(str).values
        sample_means = tmp.groupby(sample_col)[["ZNF_expression"] + list(MODULES.keys())].mean()
        for module in MODULES:
            try:
                rho, p = spearmanr(sample_means["ZNF_expression"], sample_means[module], nan_policy="omit")
            except Exception:
                rho, p = np.nan, np.nan
            sample_rows.append({
                "dataset": dataset,
                "object_path": str(path),
                "sample_column": sample_col,
                "n_samples": int(sample_means.shape[0]),
                "ZNF_gene": znf_actual,
                "module": module,
                "sample_level_spearman_rho": rho,
                "sample_level_spearman_p": p,
                "sample_level_direction": summarize_direction(rho),
            })
    sample_df = pd.DataFrame(sample_rows)
    if not sample_df.empty:
        sample_df["sample_level_fdr_within_dataset"] = bh_fdr(sample_df["sample_level_spearman_p"].values)

    # Gene-level ranking.
    all_genes = sorted(set([g for genes in MODULES.values() for g in genes]))
    rf_all, lasso_all, rf_auc_all, lasso_auc_all = ml_importance_for_genes(
        adata, all_genes, high, low, use_raw=not args.no_raw, log=log
    )

    gene_rows = []
    for module, genes in MODULES.items():
        rf_mod, lasso_mod, rf_auc_mod, lasso_auc_mod = ml_importance_for_genes(
            adata, genes, high, low, use_raw=not args.no_raw, log=None
        )
        for gene in genes:
            gv, actual_gene, layer, symbol_cols_used = gene_vector(adata, gene, use_raw=not args.no_raw)
            if gv is None:
                continue

            x = gv[high]
            y = gv[low]
            try:
                p = mannwhitneyu(x[np.isfinite(x)], y[np.isfinite(y)], alternative="two-sided").pvalue
            except Exception:
                p = np.nan
            try:
                rho, rp = spearmanr(znf_vec, gv, nan_policy="omit")
            except Exception:
                rho, rp = np.nan, np.nan

            key = normalize_symbol(actual_gene)
            imp = max(float(rf_mod.get(key, 0.0)), float(rf_all.get(key, 0.0)))
            coef = lasso_mod.get(key, lasso_all.get(key, 0.0))

            gene_rows.append({
                "dataset": dataset,
                "object_path": str(path),
                "module": module,
                "gene_input": gene,
                "gene_found": actual_gene,
                "ZNF_gene": znf_actual,
                "n_ZNF_high": int(high.sum()),
                "n_ZNF_low": int(low.sum()),
                "mean_ZNF_high": float(np.nanmean(x)),
                "mean_ZNF_low": float(np.nanmean(y)),
                "mean_difference_high_minus_low": float(np.nanmean(x) - np.nanmean(y)),
                "cohen_d_high_minus_low": cohen_d(x, y),
                "cliffs_delta_high_vs_low": cliffs_delta(x, y),
                "detection_ZNF_high": float(np.mean(x > 0)) if len(x) else np.nan,
                "detection_ZNF_low": float(np.mean(y > 0)) if len(y) else np.nan,
                "mannwhitney_p": p,
                "spearman_ZNF_vs_gene_rho": rho,
                "spearman_ZNF_vs_gene_p": rp,
                "RF_importance": imp,
                "LASSO_logistic_coef": coef,
                "RF_AUC_module": rf_auc_mod,
                "RF_AUC_all_genes": rf_auc_all,
                "LASSO_AUC_module": lasso_auc_mod,
                "LASSO_AUC_all_genes": lasso_auc_all,
                "direction": summarize_direction(cohen_d(x, y)),
            })

    gene_df = pd.DataFrame(gene_rows)
    if not gene_df.empty:
        gene_df["mannwhitney_fdr_within_dataset"] = bh_fdr(gene_df["mannwhitney_p"].values)
        gene_df["spearman_fdr_within_dataset"] = bh_fdr(gene_df["spearman_ZNF_vs_gene_p"].values)

        # Composite score uses absolute evidence strength because both positive and inverse
        # ZNF335 associations are biologically meaningful in the current manuscript.
        for col in ["cohen_d_high_minus_low", "spearman_ZNF_vs_gene_rho", "RF_importance", "LASSO_logistic_coef"]:
            vals = pd.to_numeric(gene_df[col], errors="coerce").values
            med = np.nanmedian(vals)
            mad = np.nanmedian(np.abs(vals - med))
            if not np.isfinite(mad) or mad == 0:
                mad = np.nanstd(vals)
            if not np.isfinite(mad) or mad == 0:
                zabs = np.abs(vals)
            else:
                zabs = np.abs((vals - med) / mad)
            gene_df[col + "_abs_scaled"] = zabs

        gene_df["candidate_score_abs"] = (
            gene_df["cohen_d_high_minus_low_abs_scaled"].fillna(0)
            + gene_df["spearman_ZNF_vs_gene_rho_abs_scaled"].fillna(0)
            + gene_df["RF_importance_abs_scaled"].fillna(0)
            + gene_df["LASSO_logistic_coef_abs_scaled"].fillna(0)
        )

    # Save dataset figures.
    try:
        save_bar_modules(comp_df, dataset, fig_dir, dpi=args.dpi)
        save_heatmap_modules(comp_df, dataset, fig_dir, dpi=args.dpi)
    except Exception as e:
        log(f"Figure generation failed for {dataset}: {repr(e)}")

    obj_summary = {
        "dataset": dataset,
        "path": str(path),
        "status": "processed",
        "object_type": obj_type,
        "n_obs_original": original_n,
        "n_obs_after_filter": int(adata.n_obs),
        "n_vars": int(adata.n_vars),
        "filter_note": filter_note,
        "ZNF_gene": znf_actual,
        "ZNF_detection_fraction": det,
        "n_ZNF_high": int(high.sum()),
        "n_ZNF_low": int(low.sum()),
        "group_method": group_method,
        "sample_column_detected": sample_col,
        "gene_symbol_columns_checked": ";".join(map(str, symbol_cols)),
        "ZNF_expression_layer": znf_layer,
    }

    try:
        del adata
        gc.collect()
    except Exception:
        pass

    return {
        "status": "processed",
        "object": obj_summary,
        "presence": pd.DataFrame(presence_rows),
        "comparisons": comp_df,
        "sample_corr": sample_df,
        "gene_rank": gene_df,
    }


# =============================================================================
# 8. Output helpers
# =============================================================================

def top_candidates(gene_df, n=2):
    if gene_df is None or gene_df.empty:
        return pd.DataFrame()

    rows = []
    for (dataset, module), sub in gene_df.groupby(["dataset", "module"], dropna=False):
        sub = sub.sort_values("candidate_score_abs", ascending=False)
        rows.append(sub.head(n))
    return pd.concat(rows, axis=0, ignore_index=True) if rows else pd.DataFrame()


def cross_dataset_summary(comp_df):
    if comp_df is None or comp_df.empty:
        return pd.DataFrame()

    rows = []
    for module, sub in comp_df.groupby("module"):
        effects = pd.to_numeric(sub["cohen_d_high_minus_low"], errors="coerce")
        rhos = pd.to_numeric(sub["spearman_ZNF_vs_module_rho"], errors="coerce")
        rows.append({
            "module": module,
            "n_datasets": sub["dataset"].nunique(),
            "mean_cohen_d_high_minus_low": float(np.nanmean(effects)),
            "median_cohen_d_high_minus_low": float(np.nanmedian(effects)),
            "positive_effect_fraction": float(np.nanmean(effects > 0)),
            "inverse_effect_fraction": float(np.nanmean(effects < 0)),
            "mean_abs_cohen_d": float(np.nanmean(np.abs(effects))),
            "mean_spearman_rho": float(np.nanmean(rhos)),
            "mean_abs_spearman_rho": float(np.nanmean(np.abs(rhos))),
        })
    out = pd.DataFrame(rows)
    if not out.empty:
        out["module_priority_score"] = (
            out["mean_abs_cohen_d"].fillna(0)
            + out["mean_abs_spearman_rho"].fillna(0)
            + out["n_datasets"].fillna(0) / max(out["n_datasets"].max(), 1)
        )
        out = out.sort_values("module_priority_score", ascending=False)
    return out


def write_table_safely(df, path, log):
    try:
        df.to_csv(path, index=False)
    except Exception as e:
        log(f"Could not write {path}: {repr(e)}")


def write_excel_safely(tables, xlsx_path, log):
    try:
        with pd.ExcelWriter(xlsx_path, engine="openpyxl") as writer:
            for sheet, df in tables.items():
                s = safe_name(sheet, max_len=31)
                if df is None or df.empty:
                    pd.DataFrame({"note": ["No rows produced."]}).to_excel(writer, sheet_name=s, index=False)
                else:
                    df.to_excel(writer, sheet_name=s, index=False)
    except Exception as e:
        log(f"Could not write Excel workbook {xlsx_path}: {repr(e)}")
        # Fallback: write individual CSVs.
        fallback = Path(xlsx_path).with_suffix("")
        fallback.mkdir(parents=True, exist_ok=True)
        for sheet, df in tables.items():
            if df is not None and not df.empty:
                write_table_safely(df, fallback / f"{safe_name(sheet)}.csv", log)


def main():
    parser = argparse.ArgumentParser(description="ZNF335/Zfp335 broad pathway-module analysis with 900 ppi figures.")
    parser.add_argument("--root", default=r"F:\AD\Mam San")
    parser.add_argument("--out_base", default=None)
    parser.add_argument("--recursive", action="store_true")
    parser.add_argument("--include_csv", action="store_true")
    parser.add_argument("--no_raw", action="store_true")
    parser.add_argument("--no_filter_microglia", action="store_true")
    parser.add_argument("--copy_to_temp", action="store_true",
                        help="Copy each h5ad to a local temp folder before reading. Useful for Windows/network/path read errors.")
    parser.add_argument("--min_cells", type=int, default=100)
    parser.add_argument("--min_group", type=int, default=25)
    parser.add_argument("--high_quantile", type=float, default=0.75)
    parser.add_argument("--low_quantile", type=float, default=0.25)
    parser.add_argument("--top_n", type=int, default=2)
    parser.add_argument("--dpi", type=int, default=900)
    args = parser.parse_args()

    root = Path(args.root)
    if args.out_base is None:
        out_base = root / "results" / "ZNF335_all_modules_900ppi"
    else:
        out_base = Path(args.out_base)

    run_dir = out_base / f"run_{stamp()}"
    fig_dir = run_dir / "figures_900ppi"
    run_dir.mkdir(parents=True, exist_ok=True)
    fig_dir.mkdir(parents=True, exist_ok=True)

    log = make_logger(run_dir / "00_run_log.txt")

    log("Starting ZNF335/Zfp335 all-module pathway analysis V2")
    log(f"Root: {root}")
    log(f"Run directory: {run_dir}")
    log(f"Python: {sys.version}")
    log(f"anndata_scanpy_available: {ANNDATA_OK}")
    log(f"sklearn_available: {SKLEARN_OK}")
    log(f"figure_dpi: {args.dpi}")

    files = find_input_files(root, recursive=args.recursive, include_csv=args.include_csv)
    pd.DataFrame({"path": [str(p) for p in files], "suffix": [p.suffix for p in files]}).to_csv(
        run_dir / "01_input_files_found.csv", index=False
    )
    log(f"Found {len(files)} input file(s).")

    if not files:
        log("No files found. Put .h5ad files under root, or use --include_csv for matrices.")
        return 1

    all_objects = []
    all_presence = []
    all_comp = []
    all_sample = []
    all_gene = []

    for i, path in enumerate(files, start=1):
        log(f"--- Processing {i}/{len(files)} ---")
        try:
            res = process_one_file(path, args, run_dir, fig_dir, log)
        except Exception as e:
            log(f"UNEXPECTED ERROR but continuing: {path}")
            log(repr(e))
            log(traceback.format_exc())
            res = {
                "object": {"dataset": safe_name(Path(path).stem), "path": str(path), "status": "unexpected_error", "error": repr(e)},
                "presence": pd.DataFrame(),
                "comparisons": pd.DataFrame(),
                "sample_corr": pd.DataFrame(),
                "gene_rank": pd.DataFrame(),
            }

        all_objects.append(res.get("object", {}))
        if not res.get("presence", pd.DataFrame()).empty:
            all_presence.append(res["presence"])
        if not res.get("comparisons", pd.DataFrame()).empty:
            all_comp.append(res["comparisons"])
        if not res.get("sample_corr", pd.DataFrame()).empty:
            all_sample.append(res["sample_corr"])
        if not res.get("gene_rank", pd.DataFrame()).empty:
            all_gene.append(res["gene_rank"])

        gc.collect()

    objects_df = pd.DataFrame(all_objects)
    presence_df = pd.concat(all_presence, ignore_index=True) if all_presence else pd.DataFrame()
    comp_df = pd.concat(all_comp, ignore_index=True) if all_comp else pd.DataFrame()
    sample_df = pd.concat(all_sample, ignore_index=True) if all_sample else pd.DataFrame()
    gene_df = pd.concat(all_gene, ignore_index=True) if all_gene else pd.DataFrame()
    top_df = top_candidates(gene_df, n=args.top_n)
    module_summary_df = cross_dataset_summary(comp_df)

    # Save CSVs.
    write_table_safely(objects_df, run_dir / "01_processed_objects_summary.csv", log)
    write_table_safely(presence_df, run_dir / "02_module_gene_presence.csv", log)
    write_table_safely(comp_df, run_dir / "03_cell_level_module_comparisons.csv", log)
    write_table_safely(sample_df, run_dir / "04_sample_level_module_correlations.csv", log)
    write_table_safely(gene_df, run_dir / "05_gene_level_candidate_ranking.csv", log)
    write_table_safely(top_df, run_dir / "06_top_1to2_candidates_per_module.csv", log)
    write_table_safely(module_summary_df, run_dir / "07_cross_dataset_module_priority_summary.csv", log)

    write_excel_safely(
        {
            "processed_objects": objects_df,
            "module_gene_presence": presence_df,
            "cell_module_comparisons": comp_df,
            "sample_module_correlations": sample_df,
            "gene_candidate_ranking": gene_df,
            "top_candidates": top_df,
            "module_priority_summary": module_summary_df,
        },
        run_dir / "ZNF335_all_modules_results.xlsx",
        log
    )

    # Cross-dataset summary figure and candidate gene plots.
    try:
        save_summary_heatmap(comp_df, fig_dir, dpi=args.dpi)
        if not top_df.empty:
            for ds in sorted(top_df["dataset"].dropna().unique()):
                save_gene_candidate_plot(top_df, ds, fig_dir, dpi=args.dpi)
    except Exception as e:
        log(f"Final figure generation failed: {repr(e)}")

    # Write simple interpretation guide.
    guide = run_dir / "INTERPRETATION_GUIDE.txt"
    try:
        with open(guide, "w", encoding="utf-8") as f:
            f.write(
                "Interpretation guide\n"
                "====================\n\n"
                "1. cell_module_comparisons:\n"
                "   - cohen_d_high_minus_low > 0: module is higher in ZNF335/Zfp335-high cells.\n"
                "   - cohen_d_high_minus_low < 0: module is lower in ZNF335/Zfp335-high cells, consistent with inverse coupling.\n\n"
                "2. sample_module_correlations:\n"
                "   - Use this for donor/sample-level interpretation. This is stronger than cell-level visual association.\n\n"
                "3. gene_candidate_ranking:\n"
                "   - candidate_score_abs ranks genes by absolute evidence strength.\n"
                "   - Always check direction before writing biology.\n\n"
                "4. top_candidates:\n"
                "   - This is the shortlist for experiments: usually pick 1-2 genes per prioritized module.\n\n"
                "5. Important caution:\n"
                "   - This script nominates ZNF335-linked modules/candidates. It does not prove direct regulation.\n"
                "   - Experimental validation should use ZNF335 knockdown/overexpression plus qPCR/WB/IF and lipid assays.\n"
            )
    except Exception:
        pass

    log("Finished.")
    log(f"Main Excel workbook: {run_dir / 'ZNF335_all_modules_results.xlsx'}")
    log(f"Top candidates: {run_dir / '06_top_1to2_candidates_per_module.csv'}")
    log(f"900 ppi figures: {fig_dir}")
    log("Unreadable h5ad files were skipped, not fatal. Check 01_processed_objects_summary.csv for status.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
