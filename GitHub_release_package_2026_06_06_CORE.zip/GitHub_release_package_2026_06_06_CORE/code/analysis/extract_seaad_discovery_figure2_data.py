#!/usr/bin/env python3

from pathlib import Path
import csv

import h5py
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent
H5AD = ROOT / "results" / "seaad_microglia_fixed" / "objects" / "seaad_microglia_fixed_microglia_final.h5ad"
OUT = ROOT / "results" / "publication_figures" / "figure2_seaad_discovery_source_data"
OUT.mkdir(parents=True, exist_ok=True)

OBS_COLS = [
    "state_hint",
    "external_donor_name_label",
    "donor_sex_label",
    "age_label",
    "region_label",
    "leiden",
    "homeostatic_score",
    "lysosome_score",
    "dam_phagocytic_score",
    "interferon_score",
    "proliferative_score",
    "regulator_score",
    "bace1_node_score",
    "n_genes_by_counts",
    "total_counts",
    "pct_counts_mt",
]

GENE_GROUPS = {
    "Homeostatic": ["P2RY12", "TMEM119", "CX3CR1", "CSF1R"],
    "DAM/lipid": ["APOE", "TREM2", "TYROBP", "LPL", "CST7", "ITGAX", "AXL", "GPNMB"],
    "Lysosome/phagosome": ["CTSB", "CTSD", "LAMP1", "LAMP2", "CD68", "HEXA", "HEXB"],
    "Interferon": ["ISG15", "IFIT3", "STAT1", "IRF7"],
    "Candidate guardrail": ["ZNF335", "BACE1"],
}
GENES = [g for genes in GENE_GROUPS.values() for g in genes]


def decode_array(x):
    out = []
    for val in x:
        if isinstance(val, bytes):
            out.append(val.decode("utf-8"))
        else:
            out.append(val)
    return np.asarray(out)


def read_obs_col(obs, key):
    obj = obs[key]
    if isinstance(obj, h5py.Dataset):
        arr = obj[()]
        if arr.dtype.kind in {"S", "O"}:
            return decode_array(arr)
        return arr
    if isinstance(obj, h5py.Group) and "codes" in obj and "categories" in obj:
        codes = obj["codes"][()]
        cats = decode_array(obj["categories"][()])
        return np.asarray([cats[c] if c >= 0 else "" for c in codes])
    raise KeyError(f"Unsupported obs column encoding for {key}")


def sparse_columns(group, col_indices):
    shape = tuple(group.attrs["shape"])
    out = np.zeros((shape[0], len(col_indices)), dtype=float)
    col_to_out = {int(c): i for i, c in enumerate(col_indices)}
    data = group["data"]
    indices = group["indices"]
    indptr = group["indptr"]
    for row in range(shape[0]):
        start = int(indptr[row])
        end = int(indptr[row + 1])
        row_idx = indices[start:end]
        row_data = data[start:end]
        for idx, val in zip(row_idx, row_data):
            j = col_to_out.get(int(idx))
            if j is not None:
                out[row, j] = float(val)
    return out


def zscore_columns(frame, cols):
    z = pd.DataFrame(index=frame.index)
    for col in cols:
        x = pd.to_numeric(frame[col], errors="coerce")
        sd = x.std(skipna=True)
        if np.isfinite(sd) and sd > 0:
            z[col] = (x - x.mean(skipna=True)) / sd
        else:
            z[col] = 0.0
    return z


with h5py.File(H5AD, "r") as f:
    obs = f["obs"]
    umap = f["obsm"]["X_umap"][()]
    var_names = decode_array(f["var"]["_index"][()])
    gene_to_idx = {str(g).upper(): i for i, g in enumerate(var_names)}
    gene_indices = [gene_to_idx[g] for g in GENES if g in gene_to_idx]
    gene_names = [g for g in GENES if g in gene_to_idx]

    cells = pd.DataFrame({
        "cell_id": decode_array(obs["_index"][()]) if "_index" in obs else np.arange(umap.shape[0]),
        "UMAP1": umap[:, 0],
        "UMAP2": umap[:, 1],
    })
    for col in OBS_COLS:
        if col in obs:
            cells[col] = read_obs_col(obs, col)

    expr = sparse_columns(f["X"], gene_indices)
    expr_df = pd.DataFrame(expr, columns=gene_names)
    cells = pd.concat([cells, expr_df], axis=1)

for col in ["homeostatic_score", "lysosome_score", "dam_phagocytic_score", "interferon_score", "proliferative_score"]:
    cells[col] = pd.to_numeric(cells[col], errors="coerce")

lipid_genes = [g for g in ["APOE", "TREM2", "LPL", "CST7", "AXL", "GPNMB"] if g in cells.columns]
if lipid_genes:
    cells["lipid_response_score"] = zscore_columns(cells, lipid_genes).mean(axis=1)
else:
    cells["lipid_response_score"] = np.nan

state_order = ["homeostatic_like", "transitional_like", "lysosome_high", "dam_like", "interferon_like", "proliferative_like"]
dot_rows = []
for state in state_order:
    sub = cells[cells["state_hint"] == state]
    for group, genes in GENE_GROUPS.items():
        for gene in genes:
            if gene not in cells.columns:
                continue
            vals = pd.to_numeric(sub[gene], errors="coerce")
            all_vals = pd.to_numeric(cells[gene], errors="coerce")
            sd = all_vals.std(skipna=True)
            avg = vals.mean(skipna=True)
            avg_z = 0.0 if not np.isfinite(sd) or sd == 0 else (avg - all_vals.mean(skipna=True)) / sd
            dot_rows.append({
                "state_hint": state,
                "gene_group": group,
                "gene": gene,
                "avg_expression": avg,
                "avg_expression_z": max(min(avg_z, 2.5), -2.5),
                "pct_expressed": float((vals > 0).mean() * 100) if len(vals) else np.nan,
                "n_cells": len(sub),
            })
dot = pd.DataFrame(dot_rows)

donor_col = "external_donor_name_label"
prop = (
    cells.groupby([donor_col, "state_hint"]).size().rename("n_cells").reset_index()
    .merge(cells.groupby(donor_col).size().rename("donor_cells").reset_index(), on=donor_col)
)
prop["proportion"] = prop["n_cells"] / prop["donor_cells"]

score_cols = ["homeostatic_score", "lysosome_score", "dam_phagocytic_score", "lipid_response_score", "interferon_score", "proliferative_score"]
donor_scores = cells.groupby(donor_col)[score_cols].mean(numeric_only=True).reset_index()
donor_meta = cells.groupby(donor_col).agg(
    n_cells=("cell_id", "size"),
    sex=("donor_sex_label", lambda x: x.dropna().astype(str).iloc[0] if len(x.dropna()) else ""),
    age=("age_label", lambda x: x.dropna().astype(str).iloc[0] if len(x.dropna()) else ""),
    region=("region_label", lambda x: x.dropna().astype(str).iloc[0] if len(x.dropna()) else ""),
).reset_index()
donor_scores = donor_scores.merge(donor_meta, on=donor_col, how="left")
donor_scores["lipid_lysosome_burden"] = donor_scores[["lysosome_score", "dam_phagocytic_score", "lipid_response_score"]].mean(axis=1)

cells.to_csv(OUT / "seaad_cell_umap_scores_expression.csv", index=False)
dot.to_csv(OUT / "seaad_marker_dotplot_by_state.csv", index=False)
prop.to_csv(OUT / "seaad_state_proportions_by_donor.csv", index=False)
donor_scores.to_csv(OUT / "seaad_donor_module_scores.csv", index=False)

with open(OUT / "gene_groups_used.csv", "w", newline="") as handle:
    writer = csv.writer(handle)
    writer.writerow(["gene_group", "gene"])
    for group, genes in GENE_GROUPS.items():
        for gene in genes:
            writer.writerow([group, gene])

print(f"Wrote SEA-AD Figure 2 source data to {OUT}")
