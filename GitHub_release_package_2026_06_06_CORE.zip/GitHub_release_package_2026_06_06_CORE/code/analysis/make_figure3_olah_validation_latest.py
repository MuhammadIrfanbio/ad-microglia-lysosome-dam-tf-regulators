#!/usr/bin/env python3
"""
Draw Figure 3: human validation of lipid-lysosomal microglial remodeling
in Olah live-isolated human microglia, preserving the state colors used in
Figure 2.

Run with the Miniforge Python environment used by the analysis stack if the
default Python does not expose h5py/anndata:

  C:\\ProgramData\\miniforge3\\python.exe make_figure3_olah_validation_latest.py
"""

from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
from scipy import sparse
from scipy.stats import mannwhitneyu

try:
    import anndata as ad
except ImportError as exc:  # pragma: no cover
    raise SystemExit("This script needs anndata/h5py. Use C:\\ProgramData\\miniforge3\\python.exe.") from exc


ROOT = Path(__file__).resolve().parent
OUT_DIR = ROOT / "results" / "publication_figures"
SRC = OUT_DIR / "figure3_olah_validation_source_data"
SRC.mkdir(parents=True, exist_ok=True)

H5AD = ROOT / "results" / "olah_microglia_fixed" / "objects" / "olah_microglia_fixed_microglia_final.h5ad"
PALETTE = OUT_DIR / "figure2_seaad_discovery_source_data" / "state_palette_used_across_figures.csv"
SEA_SUMMARY = OUT_DIR / "figure2_seaad_discovery_source_data" / "figure2_latest_donor_module_summary_matrix.csv"

FIG_PNG = OUT_DIR / "Figure_3_Olah_human_validation_latest_900ppi.png"
FIG_TIFF = OUT_DIR / "Figure_3_Olah_human_validation_latest_900ppi.tiff"
FIG_PDF = OUT_DIR / "Figure_3_Olah_human_validation_latest_editable.pdf"
README = OUT_DIR / "Figure_3_Olah_human_validation_latest_README.txt"


STATE_ORDER = [
    "homeostatic_like",
    "transitional_like",
    "lysosome_high",
    "dam_like",
    "interferon_like",
    "proliferative_like",
]

STATE_DOT_ORDER = [
    "homeostatic_like",
    "transitional_like",
    "lysosome_high",
    "dam_like",
    "interferon_like",
    "proliferative_like",
]

STATE_LABEL = {
    "homeostatic_like": "Homeostatic-like",
    "transitional_like": "Transitional-like",
    "lysosome_high": "Lysosome-high",
    "dam_like": "DAM/\nphagocytic-like",
    "interferon_like": "Interferon-like",
    "proliferative_like": "Proliferative-like",
}

STATE_LABEL_ONE_LINE = {
    "homeostatic_like": "Homeostatic-like",
    "transitional_like": "Transitional-like",
    "lysosome_high": "Lysosome-high",
    "dam_like": "DAM/phagocytic-like",
    "interferon_like": "Interferon-like",
    "proliferative_like": "Proliferative-like",
}

STATE_SHORT_LABEL = {
    "homeostatic_like": "Homeo",
    "transitional_like": "Trans",
    "lysosome_high": "Lyso",
    "dam_like": "DAM",
    "interferon_like": "IFN",
    "proliferative_like": "Prolif",
}

GENE_GROUPS = [
    ("Homeostatic signature", ["P2RY12", "TMEM119", "CX3CR1", "CSF1R"]),
    ("Lipid / DAM signature", ["APOE", "TREM2", "TYROBP", "LPL", "AXL", "GPNMB"]),
    ("Lysosomal / phagocytic signature", ["LAMP1", "LAMP2", "CTSB", "CTSD", "CTSS", "CD68", "CST7"]),
    ("Interferon / immune signature", ["IFIT3", "ISG15", "HLA-DRA", "HLA-DRB1"]),
    ("Candidate upstream /\ncontext genes", ["BACE1", "ZNF335"]),
]

MODULES = [
    ("homeostatic_score", "Homeostatic score"),
    ("lysosome_score", "Lysosome score"),
    ("dam_phagocytic_score", "DAM / phagocytosis score"),
    ("lipid_response_score", "Lipid score"),
]

SUMMARY_ROWS = [
    ("Homeostatic loss", "homeostatic_score", -1),
    ("Lysosome gain", "lysosome_score", 1),
    ("DAM / phagocytosis gain", "dam_phagocytic_score", 1),
    ("Lipid program activation", "lipid_response_score", 1),
    ("Interferon activation", "interferon_score", 1),
    ("Proliferative program", "proliferative_score", 1),
]

PAL = {
    "dark": "#151B23",
    "mid": "#566174",
    "grid": "#E9EDF2",
    "border": "#CAD2DC",
    "red": "#B63A4A",
    "blue": "#2F6FB0",
}


def load_state_palette():
    pal = pd.read_csv(PALETTE)
    return dict(zip(pal["state_hint"], pal["color_hex"]))


def zscore(x):
    x = pd.to_numeric(x, errors="coerce").astype(float)
    sd = x.std(skipna=True)
    if not np.isfinite(sd) or sd == 0:
        return pd.Series(np.zeros(len(x)), index=x.index)
    return (x - x.mean(skipna=True)) / sd


def cohen_d(x, y):
    x = np.asarray(pd.to_numeric(pd.Series(x), errors="coerce").dropna(), dtype=float)
    y = np.asarray(pd.to_numeric(pd.Series(y), errors="coerce").dropna(), dtype=float)
    if len(x) < 2 or len(y) < 2:
        return np.nan
    nx, ny = len(x), len(y)
    pooled = np.sqrt(((nx - 1) * np.var(x, ddof=1) + (ny - 1) * np.var(y, ddof=1)) / (nx + ny - 2))
    if not np.isfinite(pooled) or pooled == 0:
        return np.nan
    return (np.mean(x) - np.mean(y)) / pooled


def p_to_star(p):
    if not np.isfinite(p):
        return ""
    if p < 1e-4:
        return "****"
    if p < 1e-3:
        return "***"
    if p < 1e-2:
        return "**"
    if p < 0.05:
        return "*"
    return "ns"


def read_expression(adata, genes):
    var_lookup = {str(g).upper(): str(g) for g in adata.var_names}
    present = [var_lookup[g.upper()] for g in genes if g.upper() in var_lookup]
    if not present:
        return pd.DataFrame(index=adata.obs_names)
    mat = adata[:, present].X
    if sparse.issparse(mat):
        mat = mat.toarray()
    return pd.DataFrame(mat, columns=[g.upper() for g in present], index=adata.obs_names)


def build_source_data():
    state_colors = load_state_palette()
    all_genes = []
    for _, genes in GENE_GROUPS:
        all_genes.extend(genes)
    lipid_genes = ["APOE", "TREM2", "LPL", "AXL", "GPNMB", "TYROBP"]
    all_genes = sorted(set(all_genes + lipid_genes))

    adata = ad.read_h5ad(H5AD)
    expr = read_expression(adata, all_genes)

    cells = pd.DataFrame({
        "cell_id": adata.obs_names.astype(str),
        "UMAP1": adata.obsm["X_umap"][:, 0],
        "UMAP2": adata.obsm["X_umap"][:, 1],
    })
    keep_obs = [
        "state_hint",
        "donor_id",
        "disease",
        "sex",
        "homeostatic_score",
        "lysosome_score",
        "dam_phagocytic_score",
        "interferon_score",
        "proliferative_score",
        "regulator_score",
        "bace1_node_score",
    ]
    for col in keep_obs:
        if col in adata.obs:
            cells[col] = adata.obs[col].astype(str).values if adata.obs[col].dtype.name in {"category", "object"} else adata.obs[col].values
    cells = pd.concat([cells, expr.reset_index(drop=True)], axis=1)

    lipid_present = [g for g in lipid_genes if g in cells.columns]
    cells["lipid_response_score"] = pd.DataFrame({g: zscore(cells[g]) for g in lipid_present}).mean(axis=1)

    dot_rows = []
    for state in STATE_DOT_ORDER:
        sub = cells[cells["state_hint"] == state]
        for group, genes in GENE_GROUPS:
            for gene in genes:
                if gene not in cells.columns:
                    continue
                vals = pd.to_numeric(sub[gene], errors="coerce")
                all_vals = pd.to_numeric(cells[gene], errors="coerce")
                sd = all_vals.std(skipna=True)
                avg = vals.mean(skipna=True)
                avg_z = 0.0 if not np.isfinite(sd) or sd == 0 else (avg - all_vals.mean(skipna=True)) / sd
                dot_rows.append({
                    "state_hint": state,
                    "gene_group": group,
                    "gene": gene,
                    "avg_expression": avg,
                    "avg_expression_z": np.clip(avg_z, -2.5, 2.5),
                    "pct_expressed": float((vals > 0).mean() * 100) if len(vals) else np.nan,
                    "n_cells": len(sub),
                })
    dot = pd.DataFrame(dot_rows)

    donor_scores = cells.groupby(["donor_id", "disease"], observed=False)[
        ["homeostatic_score", "lysosome_score", "dam_phagocytic_score", "lipid_response_score", "interferon_score", "proliferative_score"]
    ].mean(numeric_only=True).reset_index()
    donor_counts = cells.groupby(["donor_id", "disease"], observed=False).size().rename("n_cells").reset_index()
    donor_scores = donor_scores.merge(donor_counts, on=["donor_id", "disease"], how="left")

    # Source files for reproducibility. The cell table includes only selected genes.
    cells.to_csv(SRC / "olah_cell_umap_scores_expression.csv", index=False)
    dot.to_csv(SRC / "olah_marker_dotplot_by_state.csv", index=False)
    donor_scores.to_csv(SRC / "olah_donor_module_scores.csv", index=False)
    pd.DataFrame([{"state_hint": s, "label": STATE_LABEL_ONE_LINE[s], "color_hex": state_colors[s]} for s in STATE_ORDER]).to_csv(
        SRC / "state_palette_used_from_figure2.csv", index=False
    )
    return cells, dot, donor_scores, state_colors


def panel_label(ax, label, x=-0.10, y=1.10):
    ax.text(x, y, label, transform=ax.transAxes, fontsize=18, fontweight="bold", color=PAL["dark"], ha="left", va="top", clip_on=False)


def panel_title(ax, title, subtitle=None, y=1.07):
    ax.text(0, y, title, transform=ax.transAxes, fontsize=10.3, fontweight="bold", color=PAL["dark"], ha="left", va="bottom", clip_on=False)
    if subtitle:
        ax.text(0, y - 0.092, subtitle, transform=ax.transAxes, fontsize=7.2, color=PAL["mid"], ha="left", va="bottom", clip_on=False)


def clean_axes(ax):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(PAL["dark"])
    ax.spines["bottom"].set_color(PAL["dark"])
    ax.tick_params(colors=PAL["dark"], labelsize=8)


def draw_state_umap(ax, cells, state_colors):
    for state in STATE_ORDER:
        sub = cells[cells["state_hint"] == state]
        ax.scatter(sub["UMAP1"], sub["UMAP2"], s=6.0, c=state_colors[state], alpha=0.80, linewidths=0, label=STATE_LABEL_ONE_LINE[state])
    ax.set_xlabel("UMAP_1", fontsize=9.5)
    ax.set_ylabel("UMAP_2", fontsize=9.5)
    clean_axes(ax)
    panel_label(ax, "A", x=-0.12)
    panel_title(ax, "Olah live human microglia: state map")


def draw_score_umaps(fig, cells, left, bottom, width, height):
    cmap = LinearSegmentedColormap.from_list("module", ["#C4B5E8", "#F7F7F7", "#EF2B22"])
    pad = 0.025
    sub_w = (width - 3 * pad) / 4
    axes = []
    for i, (col, title) in enumerate(MODULES):
        ax = fig.add_axes([left + i * (sub_w + pad), bottom, sub_w, height])
        z = np.clip(zscore(cells[col]), -2, 2)
        order = np.argsort(z.values)
        ax.scatter(cells["UMAP1"].values[order], cells["UMAP2"].values[order], c=z.values[order], s=4.2, cmap=cmap, vmin=-2, vmax=2, linewidths=0)
        ax.set_title(title, fontsize=8.4, fontweight="bold", pad=3)
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_visible(False)
        ax.text(0.02, -0.08, "Low", transform=ax.transAxes, fontsize=7.2, ha="left", va="top")
        ax.text(0.98, -0.08, "High", transform=ax.transAxes, fontsize=7.2, ha="right", va="top")
        bar = ax.inset_axes([0.20, -0.080, 0.55, 0.035])
        grad = np.linspace(-2, 2, 128)[None, :]
        bar.imshow(grad, aspect="auto", cmap=cmap, vmin=-2, vmax=2)
        bar.axis("off")
        axes.append(ax)
    panel_label(axes[0], "B", x=-0.20, y=1.18)
    panel_title(axes[0], "Module scores across microglia (Olah et al.)", y=1.15)


def draw_state_legend(fig, state_colors):
    ax = fig.add_axes([0.060, 0.640, 0.720, 0.034])
    ax.axis("off")
    handles = [Line2D([0], [0], marker="o", linestyle="", markerfacecolor=state_colors[s], markeredgecolor="none", markersize=7.0) for s in STATE_ORDER]
    labels = [STATE_LABEL_ONE_LINE[s] for s in STATE_ORDER]
    ax.legend(handles, labels, frameon=False, ncol=6, fontsize=8.4, loc="center", handletextpad=0.4, columnspacing=1.25)


def draw_dotplot(ax, dot, state_colors):
    gene_order = [gene for _, genes in GENE_GROUPS for gene in genes]
    dot = dot[dot["gene"].isin(gene_order) & dot["state_hint"].isin(STATE_DOT_ORDER)].copy()
    dot["gene"] = pd.Categorical(dot["gene"], categories=gene_order, ordered=True)
    dot["state_hint"] = pd.Categorical(dot["state_hint"], categories=STATE_DOT_ORDER, ordered=True)
    dot = dot.sort_values(["state_hint", "gene"])
    xmap = {gene: i for i, gene in enumerate(gene_order)}
    ymap = {state: len(STATE_DOT_ORDER) - 1 - i for i, state in enumerate(STATE_DOT_ORDER)}
    sizes = 12 + (dot["pct_expressed"].fillna(0) / 100.0) * 120
    sc = ax.scatter(
        dot["gene"].map(xmap).astype(float),
        dot["state_hint"].map(ymap).astype(float),
        s=sizes,
        c=dot["avg_expression_z"],
        cmap=LinearSegmentedColormap.from_list("dot", ["#4575B4", "#F7F7F7", "#D73027"]),
        norm=TwoSlopeNorm(vmin=-2, vcenter=0, vmax=2),
        edgecolors=PAL["dark"],
        linewidths=0.25,
    )
    ax.set_xlim(-0.9, len(gene_order) + 2.3)
    ax.set_ylim(-0.55, len(STATE_DOT_ORDER) - 0.20)
    ax.set_xticks(range(len(gene_order)))
    ax.set_xticklabels(gene_order, rotation=0, ha="center", fontsize=7.0, fontstyle="italic")
    ax.xaxis.tick_top()
    ax.set_yticks([ymap[s] for s in STATE_DOT_ORDER])
    ax.set_yticklabels([STATE_LABEL_ONE_LINE[s] for s in STATE_DOT_ORDER], fontsize=8.1)
    for tick, state in zip(ax.get_yticklabels(), STATE_DOT_ORDER):
        tick.set_color(state_colors[state])
        tick.set_fontweight("bold")
    ax.tick_params(axis="both", length=0)
    for spine in ax.spines.values():
        spine.set_visible(False)
    start = 0
    group_cols = [state_colors["homeostatic_like"], state_colors["transitional_like"], state_colors["lysosome_high"], state_colors["interferon_like"], PAL["border"]]
    for idx, (group_name, genes) in enumerate(GENE_GROUPS):
        end = start + len(genes) - 1
        ax.plot([start - 0.35, end + 0.35], [len(STATE_DOT_ORDER) - 0.02] * 2, color=group_cols[idx], lw=0.9, clip_on=False)
        ax.text((start + end) / 2, len(STATE_DOT_ORDER) + 0.14, group_name, fontsize=7.0, fontweight="bold", ha="center", va="bottom",
                color=group_cols[idx] if idx < 4 else PAL["dark"])
        if start > 0:
            ax.axvline(start - 0.65, color="#A5AEBA", lw=0.70)
        start = end + 1
    panel_label(ax, "C", x=-0.035, y=1.19)
    panel_title(ax, "Marker gene expression across microglial states (Olah et al.)", y=1.15)
    lx = len(gene_order) + 0.55
    ax.text(lx, 5.45, "Percent\nexpressing", fontsize=6.8, ha="left", va="bottom")
    for i, pct in enumerate([25, 50, 75, 100]):
        yy = 4.85 - i * 0.42
        ax.scatter([lx + 0.18], [yy], s=12 + pct / 100 * 120, c="black", linewidths=0)
        ax.text(lx + 0.50, yy, str(pct), fontsize=6.7, va="center", ha="left")
    cax = ax.inset_axes([0.965, 0.08, 0.014, 0.38])
    cb = plt.colorbar(sc, cax=cax)
    cb.set_ticks([-2, -1, 0, 1, 2])
    cb.ax.tick_params(labelsize=6.0, length=2)
    cax.set_title("Average\nexpression\n(z-score)", fontsize=5.8, pad=4)


def draw_violins(fig, cells, state_colors, left, bottom, width, height):
    pad = 0.018
    sub_w = (width - 3 * pad) / 4
    rng = np.random.default_rng(7)
    axes = []
    for i, (col, title) in enumerate(MODULES):
        ax = fig.add_axes([left + i * (sub_w + pad), bottom, sub_w, height])
        vals = [np.clip(zscore(cells.loc[cells["state_hint"] == s, col]), -2.5, 2.5).dropna().values for s in STATE_ORDER]
        parts = ax.violinplot(vals, positions=np.arange(len(STATE_ORDER)), widths=0.72, showmeans=False, showmedians=False, showextrema=False)
        for body, state in zip(parts["bodies"], STATE_ORDER):
            body.set_facecolor(state_colors[state])
            body.set_edgecolor(PAL["dark"])
            body.set_alpha(0.72)
            body.set_linewidth(0.5)
        for j, state in enumerate(STATE_ORDER):
            sub = np.clip(zscore(cells.loc[cells["state_hint"] == state, col]), -2.5, 2.5).dropna()
            if len(sub) > 500:
                sub = sub.sample(500, random_state=7)
            jitter = rng.normal(j, 0.045, len(sub))
            ax.scatter(jitter, sub, s=1.6, c="black", alpha=0.33, linewidths=0)
            full = vals[j]
            if len(full):
                q1, med, q3 = np.percentile(full, [25, 50, 75])
                ax.plot([j - 0.16, j + 0.16], [med, med], color="white", lw=1.0)
                ax.plot([j, j], [q1, q3], color="white", lw=2.0)
        ref = vals[0]
        for j in range(1, len(STATE_ORDER)):
            p = np.nan
            if len(ref) and len(vals[j]):
                p = mannwhitneyu(ref, vals[j], alternative="two-sided").pvalue
            star = p_to_star(p)
            if star != "ns":
                yy = 2.13 + 0.13 * (j % 3)
                ax.plot([0, j], [yy, yy], color=PAL["dark"], lw=0.45)
                ax.text((0 + j) / 2, yy + 0.03, star, fontsize=5.6, ha="center", va="bottom")
        ax.set_title(title, fontsize=7.6, fontweight="bold", pad=3)
        ax.set_ylim(-2.5, 2.5)
        ax.set_xticks(np.arange(len(STATE_ORDER)))
        ax.set_xticklabels([STATE_SHORT_LABEL[s] for s in STATE_ORDER], rotation=35, ha="right", fontsize=7.2)
        for tick, state in zip(ax.get_xticklabels(), STATE_ORDER):
            tick.set_color(state_colors[state])
            tick.set_fontweight("bold")
        if i == 0:
            ax.set_ylabel("Module score (z)", fontsize=8.2)
        else:
            ax.set_yticklabels([])
        clean_axes(ax)
        ax.grid(axis="y", color=PAL["grid"], lw=0.5)
        axes.append(ax)
    panel_label(axes[0], "D", x=-0.18, y=1.22)
    panel_title(axes[0], "Module scores by microglial state (Olah et al.)", "Mann-Whitney tests vs homeostatic-like: * P<0.05, ** P<0.01, *** P<0.001, **** P<0.0001", y=1.18)


def build_validation_summary(cells, donor_scores):
    donor = donor_scores.copy()
    case = donor[donor["disease"].str.contains("Alzheimer", case=False, na=False)]
    ctrl = donor[~donor["disease"].str.contains("Alzheimer", case=False, na=False)]
    rows = []
    sea = pd.read_csv(SEA_SUMMARY, index_col=0) if SEA_SUMMARY.exists() else pd.DataFrame()
    sea_lookup = {
        "Homeostatic loss": "Homeostatic score",
        "Lysosome gain": "Lysosome score",
        "DAM / phagocytosis gain": "DAM/phagocytic score",
        "Lipid program activation": "Lipid score",
        "Interferon activation": "Interferon score",
        "Proliferative program": "Proliferation score",
    }
    for label, col, expected in SUMMARY_ROWS:
        d = cohen_d(case[col], ctrl[col])
        oriented = expected * d if np.isfinite(d) else np.nan
        sea_val = np.nan
        sea_name = sea_lookup[label]
        if sea_name in sea.index and "High" in sea.columns and "Low" in sea.columns:
            sea_val = expected * (sea.loc[sea_name, "High"] - sea.loc[sea_name, "Low"]) / 2
        rows.append({
            "program": label,
            "seaad_discovery_effect": np.clip(sea_val, -1, 1) if np.isfinite(sea_val) else np.nan,
            "olah_validation_effect": np.clip(oriented, -1, 1) if np.isfinite(oriented) else np.nan,
            "direction": "increase" if np.isfinite(oriented) and oriented > 0.15 else ("decrease" if np.isfinite(oriented) and oriented < -0.15 else "no change"),
            "olah_case_donors": case["donor_id"].nunique(),
            "olah_control_donors": ctrl["donor_id"].nunique(),
        })
    out = pd.DataFrame(rows)
    out.to_csv(SRC / "olah_cross_dataset_validation_summary.csv", index=False)
    return out


def draw_validation_summary(ax, cells, donor_scores):
    summary = build_validation_summary(cells, donor_scores)
    cmap = LinearSegmentedColormap.from_list("effect", ["#2F6FB0", "#F7F7F7", "#EF2B22"])
    norm = TwoSlopeNorm(vmin=-1, vcenter=0, vmax=1)
    ax.set_xlim(-0.5, 2.5)
    ax.set_ylim(len(summary) - 0.5, -0.5)
    for i, row in summary.iterrows():
        for j, col in enumerate(["seaad_discovery_effect", "olah_validation_effect"]):
            val = row[col]
            face = "#F7F7F7" if not np.isfinite(val) else cmap(norm(val))
            ax.add_patch(Rectangle((j - 0.5, i - 0.5), 1, 1, facecolor=face, edgecolor="white", linewidth=0.9))
            txt = "NA" if not np.isfinite(val) else f"{val:.2f}"
            ax.text(j, i, txt, ha="center", va="center", fontsize=7.8,
                    color="white" if np.isfinite(val) and abs(val) > 0.55 else PAL["dark"],
                    fontweight="bold")
        ax.add_patch(Rectangle((1.5, i - 0.5), 1, 1, facecolor="white", edgecolor=PAL["border"], linewidth=0.7))
        arrow = "↑" if row["direction"] == "increase" else ("↓" if row["direction"] == "decrease" else "→")
        color = "#B22222" if row["direction"] == "increase" else (PAL["blue"] if row["direction"] == "decrease" else "#777777")
        ax.text(2, i, arrow, ha="center", va="center", fontsize=15, fontweight="bold", color=color)
    ax.set_yticks(np.arange(len(summary)))
    ax.set_yticklabels(summary["program"], fontsize=8.6)
    ax.set_xticks([0, 1, 2])
    ax.set_xticklabels([
        "SEA-AD\nhuman discovery",
        "Olah\nhuman validation",
        "Direction",
    ], fontsize=7.6, fontweight="bold")
    ax.xaxis.tick_top()
    ax.tick_params(length=0)
    for spine in ax.spines.values():
        spine.set_color(PAL["border"])
        spine.set_linewidth(0.7)
    panel_label(ax, "E", x=-0.13, y=1.30)
    panel_title(ax, "Cross-dataset validation summary (human)", "Donor-level effects; positive values support expected AD remodeling", y=1.24)
    sm = mpl.cm.ScalarMappable(norm=norm, cmap=cmap)
    sm.set_array([])
    cax = ax.inset_axes([0.00, -0.28, 0.50, 0.060])
    cb = plt.colorbar(sm, cax=cax, orientation="horizontal")
    cb.set_ticks([-1, -0.5, 0, 0.5, 1])
    cb.ax.tick_params(labelsize=6.6, length=2)
    cax.set_title("Effect size (oriented)", fontsize=6.8, pad=2)
    ax.text(0.58, -0.25, "Direction in AD vs control", transform=ax.transAxes, fontsize=6.9, ha="left", va="center", fontweight="bold")
    ax.text(0.58, -0.38, "↑ Increase    → No change    ↓ Decrease", transform=ax.transAxes, fontsize=6.8, ha="left", va="center")


def main():
    cells, dot, donor_scores, state_colors = build_source_data()
    mpl.rcParams.update({
        "font.family": "Arial",
        "font.size": 8.5,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "figure.facecolor": "white",
        "savefig.facecolor": "white",
    })

    fig = plt.figure(figsize=(18.0, 12.0), dpi=100)
    fig.text(0.012, 0.982, "Figure 3. Human validation of lipid-lysosomal microglial remodeling in live-isolated microglia (Olah et al.)",
             fontsize=14.5, fontweight="bold", color=PAL["dark"], ha="left", va="top")

    ax_a = fig.add_axes([0.055, 0.720, 0.240, 0.215])
    draw_state_umap(ax_a, cells, state_colors)
    draw_score_umaps(fig, cells, left=0.340, bottom=0.735, width=0.610, height=0.190)
    draw_state_legend(fig, state_colors)

    ax_c = fig.add_axes([0.070, 0.430, 0.820, 0.165])
    draw_dotplot(ax_c, dot, state_colors)

    draw_violins(fig, cells, state_colors, left=0.065, bottom=0.105, width=0.540, height=0.215)
    ax_e = fig.add_axes([0.665, 0.140, 0.285, 0.215])
    draw_validation_summary(ax_e, cells, donor_scores)

    fig.text(0.014, 0.008,
             "Olah fixed live-isolated human microglia object: 16,232 cells from 17 donors (14 Alzheimer disease, 3 temporal-lobe epilepsy). "
             "State colors are read from Figure 2 palette and preserved across panels.",
             fontsize=6.6, color=PAL["dark"], ha="left", va="bottom")

    fig.savefig(FIG_PNG, dpi=900)
    fig.savefig(FIG_TIFF, dpi=900, pil_kwargs={"compression": "tiff_lzw"})
    fig.savefig(FIG_PDF)
    plt.close(fig)

    README.write_text(
        "\n".join([
            "Figure 3: Olah human validation figure redrawn from latest fixed analysis outputs.",
            f"PNG: {FIG_PNG.as_posix()}",
            f"TIFF: {FIG_TIFF.as_posix()}",
            f"PDF: {FIG_PDF.as_posix()}",
            f"Source data: {SRC.as_posix()}",
            f"State palette source: {PALETTE.as_posix()}",
            "State colors are preserved from Figure 2.",
        ]),
        encoding="utf-8",
    )
    print("Wrote:")
    print(FIG_PNG)
    print(FIG_TIFF)
    print(FIG_PDF)
    print(SRC)


if __name__ == "__main__":
    main()
