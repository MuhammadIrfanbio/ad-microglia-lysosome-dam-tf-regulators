from __future__ import annotations

import copy
import re
import shutil
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

BASE = Path(r"F:\AD\Mam San\results\Sand_regulatory_program_manuscript_package_final_v2\Final")
MS_IN = BASE / "MANUSCRIPT_PROGRESS_IN_NEUROBIOLOGY_FORMATTED_TF_ZNF335.docx"
SI_IN = BASE / "SUPPLEMENTARY_INFORMATION_SUBMISSION_READY_FINAL_REPRODUCIBLE_TF_ZNF335_v2.docx"
MS_OUT = BASE / "MANUSCRIPT_PROGRESS_IN_NEUROBIOLOGY_FORMATTED_TF_ZNF335_consistency_fixed.docx"
SI_OUT = BASE / "SUPPLEMENTARY_INFORMATION_SUBMISSION_READY_FINAL_REPRODUCIBLE_TF_ZNF335_consistency_fixed.docx"
DL_MS = Path(r"C:\Users\Administrator\Downloads") / MS_OUT.name
DL_SI = Path(r"C:\Users\Administrator\Downloads") / SI_OUT.name

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
NS = {"w": W}
ET.register_namespace("w", W)


def qn(tag: str) -> str:
    return f"{{{W}}}{tag}"


def para_text(p: ET.Element) -> str:
    return "".join(t.text or "" for t in p.findall(".//w:t", NS))


def set_para_text(p: ET.Element, text: str) -> None:
    runs = p.findall("w:r", NS)
    if not runs:
        r = ET.SubElement(p, qn("r"))
    else:
        r = runs[0]
    for child in list(r):
        r.remove(child)
    t = ET.SubElement(r, qn("t"))
    t.text = text
    for extra in runs[1:]:
        p.remove(extra)


def clone_after(parent: ET.Element, after: ET.Element, text: str) -> ET.Element:
    new = copy.deepcopy(after)
    set_para_text(new, text)
    idx = list(parent).index(after)
    parent.insert(idx + 1, new)
    return new


def load_docx(path: Path):
    with zipfile.ZipFile(path, "r") as z:
        files = {name: z.read(name) for name in z.namelist()}
    root = ET.fromstring(files["word/document.xml"])
    body = root.find("w:body", NS)
    if body is None:
        raise RuntimeError("No document body")
    return files, root, body


def save_docx(files: dict[str, bytes], root: ET.Element, out: Path) -> None:
    files = dict(files)
    files["word/document.xml"] = ET.tostring(root, encoding="utf-8", xml_declaration=True)
    if out.exists():
        out.unlink()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for name, data in files.items():
            z.writestr(name, data)


def set_font_size_in_tables(root: ET.Element, half_points: int = 16) -> None:
    # 16 half-points = 8 pt. This improves table fit without changing content.
    for tbl in root.findall(".//w:tbl", NS):
        for r in tbl.findall(".//w:r", NS):
            rpr = r.find("w:rPr", NS)
            if rpr is None:
                rpr = ET.Element(qn("rPr"))
                r.insert(0, rpr)
            sz = rpr.find("w:sz", NS)
            if sz is None:
                sz = ET.SubElement(rpr, qn("sz"))
            sz.set(qn("val"), str(half_points))
            szcs = rpr.find("w:szCs", NS)
            if szcs is None:
                szcs = ET.SubElement(rpr, qn("szCs"))
            szcs.set(qn("val"), str(half_points))


def clean_main_tables(root: ET.Element) -> None:
    replacements = {
        "Regulato r": "Regulator",
        "Interpreta tion": "Interpretation",
        "explorator y": "exploratory",
        "nominate d": "nominated",
        "sample/d onors": "samples/donors",
        "Microgli a": "Microglia",
        "Sample unit": "Sample unit",
    }
    for p in root.findall(".//w:p", NS):
        txt = para_text(p)
        new = txt
        for a, b in replacements.items():
            new = new.replace(a, b)
        if new != txt:
            set_para_text(p, new)
    set_font_size_in_tables(root, 16)


def revise_ms() -> None:
    files, root, body = load_docx(MS_IN)
    for p in root.findall(".//w:p", NS):
        txt = para_text(p)
        new = txt
        new = new.replace(
            "Gal, J.S., Morozov, Y.M., Ayoub, A.E., et al., 2006. Molecular and morphological heterogeneity of neural precursor cells in the mouse neocortical proliferative zones. Nat. Neurosci. 9, 1152-1160.",
            "Gal, Y., Meir, A., Bell, M., et al., 2016. The role of trithorax and REST in the control of neural development by ZNF335. Nat. Neurosci. 19, 1436-1445. https://doi.org/10.1038/nn.4388.",
        )
        new = new.replace(
            "(Gal et al., 2006; Yang et al., 2012)",
            "(Yang et al., 2012; Gal et al., 2016)",
        )
        new = new.replace(
            "Internal model assessment used donor-held-out SEA-AD splits to reduce cell-level leakage.",
            "Internal model assessment used donor-held-out SEA-AD splits to reduce cell-level leakage; all cells from a held-out donor/sample label were excluded from training before prediction for that held-out unit.",
        )
        if new != txt:
            set_para_text(p, new)
    clean_main_tables(root)
    save_docx(files, root, MS_OUT)
    shutil.copy2(MS_OUT, DL_MS)


def revise_si() -> None:
    files, root, body = load_docx(SI_IN)
    for p in root.findall(".//w:p", NS):
        txt = para_text(p)
        new = txt
        new = new.replace(
            "Supplementary Table 6. ZNF335/Zfp335 sample-level module associations.",
            "Supplementary Table 6. ZNF335/Zfp335 module associations by available analysis unit.",
        )
        new = new.replace("n", "n / analysis unit") if txt.strip() == "n" else new
        new = new.replace(
            "Bayesian HGT analyses used donor-held-out SEA-AD validation and external validation across Olah, GSE98969, and GSE140510.",
            "Bayesian HGT analyses used donor-held-out SEA-AD validation and external validation across Olah, GSE98969, and GSE140510. No cell from a held-out SEA-AD donor/sample label was included in training for that held-out prediction fold.",
        )
        new = new.replace(
            "The Bayesian HGT target was harmonized microglial state/remodeled-state prediction. Donor-held-out SEA-AD splitting was used for internal validation to reduce cell-level leakage.",
            "The Bayesian HGT target was harmonized microglial state/remodeled-state prediction. Donor-held-out SEA-AD splitting was used for internal validation to reduce cell-level leakage; all cells from each held-out donor/sample label were excluded from training for that fold.",
        )
        if new != txt:
            set_para_text(p, new)

    # Correct SEA-AD Table 6 cells and interpretations.
    paras = root.findall(".//w:p", NS)
    table6_start = None
    table6_end = None
    for i, p in enumerate(paras):
        if para_text(p).strip().startswith("Supplementary Table 6."):
            table6_start = i
        elif table6_start is not None and i > table6_start and para_text(p).strip() == "Note. Source: Supplementary Figure 14 ZNF335/Zfp335 correlation table. These associations support candidate nomination only; they do not establish direct regulation.":
            table6_end = i
            break
    if table6_start is None or table6_end is None:
        raise RuntimeError("Could not locate Supplementary Table 6 block")

    # SEA-AD n cells are the five occurrences after SEA-AD dataset/species entries.
    seaad_n_count = 0
    for i in range(table6_start, table6_end):
        txt = para_text(paras[i]).strip()
        if txt == "1095" and seaad_n_count < 5:
            set_para_text(paras[i], "1095 cells; exploratory cell-level")
            seaad_n_count += 1
        elif txt.startswith("minimal ") and "sample level association" in txt and i < table6_start + 55:
            set_para_text(paras[i], txt.replace("sample level association", "exploratory cell-level association"))

    # Other dataset n values should explicitly state sample/donor units.
    for i in range(table6_start, table6_end):
        txt = para_text(paras[i]).strip()
        prev = para_text(paras[i - 2]).strip() if i >= 2 else ""
        if txt == "17":
            set_para_text(paras[i], "17 donors")
        elif txt == "97":
            set_para_text(paras[i], "97 samples")
        elif txt == "12":
            set_para_text(paras[i], "12 samples")

    note = "Note. SEA-AD rows use exploratory cell-level correlations because the available donor/sample-level ZNF335 associations were underpowered and not used for formal nomination. Olah, GSE98969, and GSE140510 rows use donor/sample-level correlations. These associations support candidate nomination only; they do not establish direct regulation."
    set_para_text(paras[table6_end], note)
    set_font_size_in_tables(root, 16)
    save_docx(files, root, SI_OUT)
    shutil.copy2(SI_OUT, DL_SI)


def validate(path: Path) -> dict:
    with zipfile.ZipFile(path) as z:
        root = ET.fromstring(z.read("word/document.xml"))
    paras = [para_text(p) for p in root.findall(".//w:p", NS)]
    return {
        "drawings": len(root.findall(".//w:drawing", NS)),
        "tables": len(root.findall(".//w:tbl", NS)),
        "refs_numeric": sum(1 for x in paras if re.match(r"^\d+\.\s", x)),
        "gal2006": sum("Gal, J.S." in x or "Gal et al., 2006" in x for x in paras),
        "gal2016": sum("Gal, Y., Meir" in x or "Gal et al., 2016" in x for x in paras),
        "table6": [x for x in paras if "Supplementary Table 6" in x][:2],
        "seaad1095": sum("1095 cells; exploratory cell-level" in x for x in paras),
        "leakage": sum("held-out donor/sample label" in x for x in paras),
        "split_words": sum(any(bad in x for bad in ["Regulato r", "Interpreta tion", "explorator y", "nominate d"]) for x in paras),
    }


def main() -> None:
    revise_ms()
    revise_si()
    print("MS:", MS_OUT)
    print("SI:", SI_OUT)
    print("MS copied:", DL_MS)
    print("SI copied:", DL_SI)
    print("MS validation:", validate(MS_OUT))
    print("SI validation:", validate(SI_OUT))


if __name__ == "__main__":
    main()
