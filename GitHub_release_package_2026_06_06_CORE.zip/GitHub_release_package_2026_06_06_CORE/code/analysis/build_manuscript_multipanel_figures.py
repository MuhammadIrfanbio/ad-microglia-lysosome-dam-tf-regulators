#!/usr/bin/env python3
"""
build_manuscript_multipanel_figures.py

Assemble 15+ IF-style multi-panel manuscript figures from existing project outputs.
Run from: D:\\Mam San

Creates:
  results\\manuscript_multipanel_figures\\main_figures
  results\\manuscript_multipanel_figures\\supplementary_figures
  results\\manuscript_multipanel_figures\\tables

Main figures:
  Figure 1  Study design and state architecture
  Figure 2  Microglial transition continuum
  Figure 3  Pseudobulk validation
  Figure 4  External GSEA audit/pathway context
  Figure 5  Cross-dataset state meta-summary
  Figure 6  Upstream coupling meta-summary
  Figure 7  Integrated model
"""

import argparse
import textwrap
from pathlib import Path
from typing import Dict, Optional, List

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from matplotlib.gridspec import GridSpec
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle, Rectangle

STATE_ORDER = [
    "homeostatic_like", "transitional_like", "lysosome_high", "dam_like",
    "interferon_like", "proliferative_like",
]
STATE_DISPLAY = {
    "homeostatic_like": "Homeostatic-like",
    "transitional_like": "Transitional-like",
    "lysosome_high": "Lysosome-high",
    "dam_like": "DAM-like",
    "interferon_like": "Interferon-like",
    "proliferative_like": "Proliferative-like",
}


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--project-root", default=".")
    p.add_argument("--output-dir", default=r"results\manuscript_multipanel_figures")
    p.add_argument("--dpi", type=int, default=900)
    p.add_argument("--image-format", default="png", choices=["png", "pdf", "svg", "tiff"])
    return p.parse_args()


def mkdirs(outdir: Path):
    for d in ["main_figures", "supplementary_figures", "tables", "logs"]:
        (outdir / d).mkdir(parents=True, exist_ok=True)


def savefig(fig, path: Path, dpi: int):
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=dpi, bbox_inches="tight")
    plt.close(fig)


def clean_ax(ax):
    ax.set_xticks([])
    ax.set_yticks([])
    for s in ax.spines.values():
        s.set_visible(False)


def add_panel_label(ax, label: str):
    ax.text(-0.04, 1.05, label, transform=ax.transAxes, fontsize=15,
            fontweight="bold", va="top", ha="left")


def wrap_text(s: str, width: int = 58) -> str:
    return "\n".join(textwrap.wrap(str(s), width=width))


def draw_placeholder(ax, title: str, detail: str = "Source figure not found."):
    clean_ax(ax)
    ax.add_patch(Rectangle((0.02, 0.02), 0.96, 0.96, transform=ax.transAxes,
                           fill=False, linestyle="--", linewidth=1.2))
    ax.text(0.5, 0.58, title, ha="center", va="center", transform=ax.transAxes,
            fontsize=11, fontweight="bold")
    ax.text(0.5, 0.42, wrap_text(detail, 45), ha="center", va="center",
            transform=ax.transAxes, fontsize=8)


def show_image(ax, path: Optional[Path], title: Optional[str] = None, placeholder: str = ""):
    clean_ax(ax)
    if path is not None and Path(path).exists():
        try:
            img = mpimg.imread(path)
            ax.imshow(img)
            ax.set_aspect("auto")
            if title:
                ax.set_title(title, fontsize=10, pad=4)
        except Exception as e:
            draw_placeholder(ax, title or "Image error", f"{path}\n{repr(e)}")
    else:
        draw_placeholder(ax, title or "Missing panel", placeholder or f"Missing: {path}")


def draw_text_box(ax, text: str, title: Optional[str] = None, fontsize: float = 9):
    clean_ax(ax)
    if title:
        ax.text(0.02, 0.98, title, transform=ax.transAxes, va="top", ha="left",
                fontsize=11, fontweight="bold")
        y = 0.84
    else:
        y = 0.95
    ax.text(0.02, y, wrap_text(text, 62), transform=ax.transAxes,
            va="top", ha="left", fontsize=fontsize, linespacing=1.25)


def find_first_existing(paths: List[Optional[Path]]) -> Optional[Path]:
    for p in paths:
        if p is not None and Path(p).exists():
            return Path(p)
    return None


def find_first_matching(root: Path, patterns: List[str]) -> Optional[Path]:
    if not root.exists():
        return None
    for pat in patterns:
        matches = sorted(root.glob(pat))
        if matches:
            return matches[0]
    return None


def read_csv(path: Optional[Path]) -> Optional[pd.DataFrame]:
    if path is None or not Path(path).exists():
        return None
    try:
        return pd.read_csv(path)
    except Exception:
        return None


def draw_dataset_design(ax):
    clean_ax(ax)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.text(0.02, 0.95, "Datasets integrated", fontsize=11, fontweight="bold", va="top")
    rows = [
        ("Mouse", "GSE140510", "WT / Trem2_KO / WT_5XFAD / Trem2_KO_5XFAD"),
        ("Mouse", "GSE98969", "independent mouse microglial cohort"),
        ("Human", "Olah", "live human microglia"),
        ("Human", "SEA-AD", "human Microglia-PVM subset"),
    ]
    y = 0.78
    for species, name, desc in rows:
        ax.add_patch(FancyBboxPatch((0.04, y-0.07), 0.18, 0.10,
                                    boxstyle="round,pad=0.01", linewidth=1.0, facecolor="white"))
        ax.text(0.13, y-0.02, species, ha="center", va="center", fontsize=8, fontweight="bold")
        ax.text(0.28, y+0.01, name, ha="left", va="center", fontsize=9, fontweight="bold")
        ax.text(0.28, y-0.045, desc, ha="left", va="center", fontsize=7.7)
        y -= 0.18
    ax.text(0.04, 0.07,
            "Mouse datasets test model-associated remodeling;\n"
            "human datasets test disease-relevant conservation and divergence.", fontsize=8)


def draw_pipeline(ax):
    clean_ax(ax)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    steps = [
        ("Public datasets", "2 mouse\n2 human"),
        ("QC + clustering", "Scanpy\nmicroglia subset"),
        ("State scoring", "Homeostatic\nLysosome\nDAM"),
        ("Validation", "Pseudobulk\nSpecies-safe GSEA"),
        ("Meta-summary", "State architecture\nUpstream coupling"),
    ]
    xs = np.linspace(0.08, 0.92, len(steps))
    y = 0.55
    for i, (head, body) in enumerate(steps):
        ax.add_patch(FancyBboxPatch((xs[i]-0.08, y-0.12), 0.16, 0.24,
                                    boxstyle="round,pad=0.02", linewidth=1.2,
                                    edgecolor="black", facecolor="white"))
        ax.text(xs[i], y+0.045, head, ha="center", va="center", fontsize=8.5, fontweight="bold")
        ax.text(xs[i], y-0.055, body, ha="center", va="center", fontsize=7.5)
        if i < len(steps)-1:
            ax.add_patch(FancyArrowPatch((xs[i]+0.085, y), (xs[i+1]-0.085, y),
                                         arrowstyle="->", mutation_scale=12, linewidth=1.2))
    ax.text(0.02, 0.95, "Analysis workflow", fontsize=11, fontweight="bold", va="top")
    ax.text(0.02, 0.12,
            "Central question: which components of AD microglial remodeling are conserved,\n"
            "and which upstream relationships are species/context dependent?", fontsize=8.5, va="bottom")


def draw_state_model(ax):
    clean_ax(ax)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.text(0.02, 0.95, "State annotation framework", fontsize=11, fontweight="bold", va="top")
    main = [
        ("Homeostatic", "P2RY12/TMEM119\nCX3CR1/CSF1R"),
        ("Transitional", "mixed program"),
        ("Lysosome-high", "CTSB/CTSD\nLAMP1/2/CD68"),
        ("DAM-like", "APOE/TREM2\nTYROBP/LPL/AXL"),
    ]
    xs = [0.12, 0.33, 0.56, 0.80]
    y = 0.58
    for i, (h, b) in enumerate(main):
        ax.add_patch(Circle((xs[i], y), 0.075, fill=False, linewidth=1.2))
        ax.text(xs[i], y+0.015, h, ha="center", va="center", fontsize=7.6, fontweight="bold")
        ax.text(xs[i], y-0.06, b, ha="center", va="top", fontsize=6.5)
        if i < len(main)-1:
            ax.add_patch(FancyArrowPatch((xs[i]+0.08, y), (xs[i+1]-0.08, y),
                                         arrowstyle="->", mutation_scale=12, linewidth=1.2))
    ax.add_patch(FancyArrowPatch((0.56, y-0.10), (0.56, 0.25), arrowstyle="->", mutation_scale=12))
    ax.text(0.56, 0.18, "Interferon-like\nIFN/ISG response", ha="center", fontsize=7.4)
    ax.add_patch(FancyArrowPatch((0.80, y-0.10), (0.88, 0.25), arrowstyle="->", mutation_scale=12))
    ax.text(0.88, 0.18, "Proliferative-like\nminor state", ha="center", fontsize=7.4)
    ax.text(0.06, 0.80, "Homeostatic identity loss", fontsize=8)
    ax.text(0.62, 0.80, "Lysosome/DAM gain", fontsize=8)


def state_proportion_barplot(ax, csv_path: Optional[Path]):
    df = read_csv(csv_path)
    if df is None or df.empty:
        draw_placeholder(ax, "State proportion summary", f"Missing: {csv_path}")
        return
    piv = df.pivot(index="dataset", columns="state_hint", values="proportion").fillna(0)
    cols = [c for c in STATE_ORDER if c in piv.columns] + [c for c in piv.columns if c not in STATE_ORDER]
    piv = piv[cols]
    x = np.arange(len(piv))
    bottom = np.zeros(len(piv))
    for col in piv.columns:
        ax.bar(x, piv[col].values, bottom=bottom, label=STATE_DISPLAY.get(col, col))
        bottom += piv[col].values
    ax.set_xticks(x)
    ax.set_xticklabels(piv.index, rotation=25, ha="right", fontsize=8)
    ax.set_ylabel("Proportion")
    ax.set_title("State occupancy across datasets", fontsize=10)
    ax.legend(fontsize=6, loc="center left", bbox_to_anchor=(1.02, 0.5), frameon=False)
    ax.set_ylim(0, 1.02)


def rho_barplot(ax, upstream_csv: Optional[Path]):
    df = read_csv(upstream_csv)
    if df is None or df.empty or "zfp_bace1_spearman_rho" not in df.columns:
        draw_placeholder(ax, "Upstream rho summary", f"Missing/invalid: {upstream_csv}")
        return
    x = np.arange(len(df))
    vals = df["zfp_bace1_spearman_rho"].astype(float).values
    ax.bar(x, vals)
    ax.axhline(0, linewidth=0.8)
    ax.set_xticks(x)
    ax.set_xticklabels(df["dataset"].astype(str), rotation=25, ha="right", fontsize=8)
    ax.set_ylabel("Spearman rho")
    ax.set_title("Zfp335/ZNF335–Bace1/BACE1 coupling", fontsize=10)
    for i, v in enumerate(vals):
        ax.text(i, v + (0.04 if v >= 0 else -0.08), f"{v:.2f}", ha="center", fontsize=7)


def detectability_plot(ax, upstream_csv: Optional[Path]):
    df = read_csv(upstream_csv)
    if df is None or df.empty or not {"regulator_pct_nonzero", "bace1_pct_nonzero"}.issubset(df.columns):
        draw_placeholder(ax, "Detectability summary", f"Missing/invalid: {upstream_csv}")
        return
    x = np.arange(len(df))
    width = 0.36
    ax.bar(x - width/2, df["regulator_pct_nonzero"].astype(float), width, label="Zfp335/ZNF335")
    ax.bar(x + width/2, df["bace1_pct_nonzero"].astype(float), width, label="Bace1/BACE1")
    ax.set_xticks(x)
    ax.set_xticklabels(df["dataset"].astype(str), rotation=25, ha="right", fontsize=8)
    ax.set_ylabel("% nonzero cells")
    ax.set_title("Upstream gene detectability", fontsize=10)
    ax.legend(fontsize=7, frameon=False)


def draw_leading_edge_table(ax, gsea_focus_csv: Optional[Path]):
    df = read_csv(gsea_focus_csv)
    clean_ax(ax)
    ax.set_title("Selected leading-edge terms", fontsize=10)
    if df is None or df.empty:
        draw_placeholder(ax, "Leading-edge table", f"Missing: {gsea_focus_csv}")
        return
    focus_terms = ["Interferon Alpha Beta Signaling", "Lysosome", "Autophagy",
                   "MHC Class II Antigen Presentation", "Complement and coagulation cascades",
                   "Antigen processing and presentation"]
    rows = []
    for term in focus_terms:
        hit = df[df["Term"].astype(str).str.lower() == term.lower()]
        if hit.empty:
            hit = df[df["Term"].astype(str).str.lower().str.contains(term.lower().split()[0], regex=False)]
        if not hit.empty:
            r = hit.iloc[0]
            lead = str(r.get("Lead_genes", ""))
            rows.append([
                str(r.get("Term", ""))[:32],
                f"{float(r.get('NES', np.nan)):.2f}" if pd.notna(r.get("NES", np.nan)) else "",
                f"{float(r.get('FDR q-val', np.nan)):.3g}" if pd.notna(r.get("FDR q-val", np.nan)) else "",
                lead[:42] + ("..." if len(lead) > 42 else "")
            ])
    if not rows:
        draw_placeholder(ax, "Leading-edge table", "No focus terms found.")
        return
    table = ax.table(cellText=rows, colLabels=["Term", "NES", "FDR", "Leading genes"],
                     loc="center", cellLoc="left", colLoc="left")
    table.auto_set_font_size(False)
    table.set_fontsize(6.3)
    table.scale(1, 1.45)


def draw_integrated_model(ax):
    clean_ax(ax)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.text(0.02, 0.96, "Integrated model", fontsize=12, fontweight="bold", va="top")
    ax.add_patch(FancyBboxPatch((0.04, 0.18), 0.38, 0.62, boxstyle="round,pad=0.02", linewidth=1.2, facecolor="white"))
    ax.text(0.23, 0.74, "Mouse AD models", ha="center", fontsize=10, fontweight="bold")
    ax.text(0.23, 0.62, "Robust downstream\nlysosome/DAM remodeling", ha="center", fontsize=9)
    ax.text(0.23, 0.44, "Zfp335–Bace1\ninverse / near-null", ha="center", fontsize=9)
    ax.text(0.23, 0.27, "state-following or\nweakly embedded", ha="center", fontsize=8)
    ax.add_patch(FancyBboxPatch((0.58, 0.18), 0.38, 0.62, boxstyle="round,pad=0.02", linewidth=1.2, facecolor="white"))
    ax.text(0.77, 0.74, "Human AD microglia", ha="center", fontsize=10, fontweight="bold")
    ax.text(0.77, 0.62, "Conserved state architecture\nwith cohort-specific occupancy", ha="center", fontsize=9)
    ax.text(0.77, 0.44, "ZNF335–BACE1\npositive coupling", ha="center", fontsize=9)
    ax.text(0.77, 0.27, "more coherent upstream\nnetwork embedding", ha="center", fontsize=8)
    ax.add_patch(FancyArrowPatch((0.42, 0.50), (0.58, 0.50), arrowstyle="<->", mutation_scale=12, linewidth=1.2))
    ax.text(0.50, 0.56, "conserved", ha="center", fontsize=8, fontweight="bold")
    ax.text(0.50, 0.41, "homeostatic → lysosome/DAM\ninflammatory remodeling", ha="center", fontsize=8)
    ax.text(0.03, 0.06,
            "Testable prediction: perturbing Zfp335/ZNF335 should alter Bace1/BACE1-linked\n"
            "lysosomal/phagocytic readouts in a species- and context-sensitive manner.", fontsize=8)


def discover_paths(project_root: Path) -> Dict[str, Optional[Path]]:
    r = project_root
    mu = r / "results" / "manuscript_upgrade"
    gsea = r / "results" / "q1_multiomics_gse140510_external_gsea_direct"
    paths = {
        "state_prop_heatmap": mu / "figures" / "state_proportion_meta_summary_900dpi.png",
        "upstream_heatmap": mu / "figures" / "upstream_sign_detectability_matrix_900dpi.png",
        "state_prop_csv": mu / "meta" / "meta_summary_all_available" / "tables" / "state_proportion_meta_summary.csv",
        "upstream_csv": mu / "meta" / "meta_summary_all_available" / "tables" / "upstream_sign_detectability_matrix.csv",
        "gse140510_transition_helper": mu / "figures" / "transition_helpers" / "gse140510_transition_module_trends_900dpi.png",
        "gse98969_transition_helper": mu / "figures" / "transition_helpers" / "gse98969_transition_module_trends_900dpi.png",
        "olah_transition_helper": mu / "figures" / "transition_helpers" / "olah_transition_module_trends_900dpi.png",
        "seaad_transition_helper": mu / "figures" / "transition_helpers" / "seaad_transition_module_trends_900dpi.png",
        "gse140510_pseudotime_umap": mu / "transition" / "gse140510" / "figures" / "trajectory_umap_pseudotime.png",
        "gse140510_paga": mu / "transition" / "gse140510" / "figures" / "paga_state_graph.png",
        "gse140510_volcano": mu / "de" / "gse140510_WT_5XFAD_vs_WT" / "figures" / "pseudobulk_de_volcano_helper_900dpi.png",
        "gse140510_signature": mu / "de" / "gse140510_WT_5XFAD_vs_WT" / "figures" / "signature_direction_barplot_900dpi.png",
        "trem2_vs_wt5xfad_signature": mu / "de" / "gse140510_Trem2_KO_5XFAD_vs_WT_5XFAD" / "figures" / "signature_direction_barplot_900dpi.png",
        "gsea_focus_csv": gsea / "tables" / "gsea_focus_terms_lysosome_dam_inflammation.csv",
        "gsea_reactome": gsea / "figures" / "top_terms_Reactome_Pathways_2024_900dpi.png",
        "gsea_kegg": gsea / "figures" / "top_terms_KEGG_2021_Human_900dpi.png",
    }
    paths["state_prop_csv"] = find_first_existing([
        paths["state_prop_csv"],
        r / "results" / "meta_summary_all4" / "tables" / "state_proportion_meta_summary.csv",
        r / "results" / "meta_summary" / "tables" / "state_proportion_meta_summary.csv",
    ])
    paths["upstream_csv"] = find_first_existing([
        paths["upstream_csv"],
        r / "results" / "meta_summary_all4" / "tables" / "upstream_sign_detectability_matrix.csv",
        r / "results" / "meta_summary" / "tables" / "upstream_sign_detectability_matrix.csv",
        r / "results" / "all_upstream_comparison_with_seaad" / "upstream_comparison_summary.csv",
    ])
    paths["gsea_reactome"] = find_first_existing([
        paths["gsea_reactome"],
        find_first_matching(gsea / "figures", ["*Reactome*900dpi.png", "*Reactome*.png"]),
    ])
    paths["gsea_kegg"] = find_first_existing([
        paths["gsea_kegg"],
        find_first_matching(gsea / "figures", ["*KEGG*900dpi.png", "*KEGG*.png"]),
    ])
    return paths


def write_inventory(paths: Dict[str, Optional[Path]], outdir: Path):
    rows = []
    for k, p in paths.items():
        rows.append({"panel_key": k, "path": str(p) if p else "", "exists": bool(p and Path(p).exists())})
    df = pd.DataFrame(rows)
    df.to_csv(outdir / "tables" / "figure_source_inventory.csv", index=False)
    df[~df["exists"]].to_csv(outdir / "tables" / "missing_figure_sources.csv", index=False)


def fig1(paths, out, dpi, fmt):
    fig = plt.figure(figsize=(13.5, 8))
    gs = GridSpec(2, 2, figure=fig, wspace=0.24, hspace=0.30)
    ax = fig.add_subplot(gs[0,0]); add_panel_label(ax,"A"); draw_dataset_design(ax)
    ax = fig.add_subplot(gs[0,1]); add_panel_label(ax,"B"); draw_pipeline(ax)
    ax = fig.add_subplot(gs[1,0]); add_panel_label(ax,"C"); draw_state_model(ax)
    ax = fig.add_subplot(gs[1,1]); add_panel_label(ax,"D"); state_proportion_barplot(ax, paths["state_prop_csv"])
    fig.suptitle("Figure 1. Study design and conserved microglial state architecture", fontsize=14, fontweight="bold")
    savefig(fig, out / f"Figure_1_study_design_state_architecture.{fmt}", dpi)


def fig2(paths, out, dpi, fmt):
    fig = plt.figure(figsize=(14, 9))
    gs = GridSpec(2, 2, figure=fig, wspace=0.12, hspace=0.23)
    ax = fig.add_subplot(gs[0,0]); add_panel_label(ax,"A"); draw_state_model(ax)
    ax = fig.add_subplot(gs[0,1]); add_panel_label(ax,"B"); show_image(ax, paths["gse140510_transition_helper"], "GSE140510 module-score transition")
    ax = fig.add_subplot(gs[1,0]); add_panel_label(ax,"C"); show_image(ax, paths["gse140510_pseudotime_umap"], "State-continuum DPT")
    ax = fig.add_subplot(gs[1,1]); add_panel_label(ax,"D"); show_image(ax, paths["gse140510_paga"], "PAGA connectivity")
    fig.suptitle("Figure 2. Microglial remodeling follows a homeostatic-to-lysosome/DAM continuum", fontsize=14, fontweight="bold")
    savefig(fig, out / f"Figure_2_microglial_transition_continuum.{fmt}", dpi)


def fig3(paths, out, dpi, fmt):
    fig = plt.figure(figsize=(14, 8.5))
    gs = GridSpec(2, 2, figure=fig, wspace=0.18, hspace=0.26)
    ax = fig.add_subplot(gs[0,0]); add_panel_label(ax,"A"); show_image(ax, paths["gse140510_volcano"], "WT_5XFAD vs WT pseudobulk DE")
    ax = fig.add_subplot(gs[0,1]); add_panel_label(ax,"B"); show_image(ax, paths["gse140510_signature"], "Signature direction")
    ax = fig.add_subplot(gs[1,0]); add_panel_label(ax,"C"); show_image(ax, paths["trem2_vs_wt5xfad_signature"], "Trem2_KO_5XFAD vs WT_5XFAD")
    ax = fig.add_subplot(gs[1,1]); add_panel_label(ax,"D"); draw_text_box(ax, "Sample-level pseudobulk analysis uses biological sample as the statistical unit. GSE140510 contains WT, Trem2_KO, WT_5XFAD, and Trem2_KO_5XFAD groups with three samples per group. Interpret this as orthogonal support for lysosome/DAM and inflammatory remodeling, not causal proof.", title="Pseudobulk design and interpretation", fontsize=8.5)
    fig.suptitle("Figure 3. Pseudobulk validation of AD-model microglial remodeling", fontsize=14, fontweight="bold")
    savefig(fig, out / f"Figure_3_pseudobulk_validation.{fmt}", dpi)


def fig4(paths, out, dpi, fmt):
    fig = plt.figure(figsize=(14, 9))
    gs = GridSpec(2, 2, figure=fig, wspace=0.18, hspace=0.24)
    ax = fig.add_subplot(gs[0,0]); add_panel_label(ax,"A"); show_image(ax, paths["gsea_reactome"], "Reactome top terms (exploratory)")
    ax = fig.add_subplot(gs[0,1]); add_panel_label(ax,"B"); show_image(ax, paths["gsea_kegg"], "KEGG top terms (exploratory)")
    ax = fig.add_subplot(gs[1,0]); add_panel_label(ax,"C"); draw_leading_edge_table(ax, paths["gsea_focus_csv"])
    ax = fig.add_subplot(gs[1,1]); add_panel_label(ax,"D"); draw_text_box(ax, "Audit status: the existing GSE140510 external GSEA is exploratory only because mouse genes were uppercased and matched to human or ambiguous Enrichr libraries. Publication-grade GSEA must be rerun with species-matched frozen GMTs or an explicit ortholog map, plus pathway-overlap and redundancy-collapse tables.", title="External GSEA audit", fontsize=8.5)
    fig.suptitle("Figure 4. External GSEA audit and pathway context", fontsize=14, fontweight="bold")
    savefig(fig, out / f"Figure_4_external_GSEA_audit.{fmt}", dpi)


def fig5(paths, out, dpi, fmt):
    fig = plt.figure(figsize=(14, 8.5))
    gs = GridSpec(2, 2, figure=fig, wspace=0.18, hspace=0.28)
    ax = fig.add_subplot(gs[0,0]); add_panel_label(ax,"A"); show_image(ax, paths["state_prop_heatmap"], "State proportion heatmap")
    ax = fig.add_subplot(gs[0,1]); add_panel_label(ax,"B"); state_proportion_barplot(ax, paths["state_prop_csv"])
    ax = fig.add_subplot(gs[1,0]); add_panel_label(ax,"C"); show_image(ax, paths["gse98969_transition_helper"], "GSE98969 transition helper")
    ax = fig.add_subplot(gs[1,1]); add_panel_label(ax,"D"); draw_text_box(ax, "Interpretation: state architecture is reproducible across mouse and human cohorts, but occupancy is highly context-dependent. GSE140510 shows expanded lysosome-high/DAM-like states; GSE98969 and SEA-AD are more homeostatic-dominant; Olah is DAM-like enriched.", title="Cross-dataset state conclusion", fontsize=8.8)
    fig.suptitle("Figure 5. Cross-dataset state meta-summary", fontsize=14, fontweight="bold")
    savefig(fig, out / f"Figure_5_cross_dataset_state_meta_summary.{fmt}", dpi)


def fig6(paths, out, dpi, fmt):
    fig = plt.figure(figsize=(14, 8.5))
    gs = GridSpec(2, 2, figure=fig, wspace=0.20, hspace=0.30)
    ax = fig.add_subplot(gs[0,0]); add_panel_label(ax,"A"); show_image(ax, paths["upstream_heatmap"], "Upstream sign/detectability matrix")
    ax = fig.add_subplot(gs[0,1]); add_panel_label(ax,"B"); rho_barplot(ax, paths["upstream_csv"])
    ax = fig.add_subplot(gs[1,0]); add_panel_label(ax,"C"); detectability_plot(ax, paths["upstream_csv"])
    ax = fig.add_subplot(gs[1,1]); add_panel_label(ax,"D"); draw_text_box(ax, "Core conclusion: ZNF335/BACE1 coupling is dataset- and species-context dependent. Human microglia datasets provide the strongest transcript-level support, while low detection and mixed mouse directions limit confidence in a conserved Zfp335-Bace1 axis. This is not evidence for a universal causal mechanism.", title="Upstream-coupling interpretation", fontsize=8.8)
    fig.suptitle("Figure 6. Context-dependent upstream Zfp335/ZNF335-Bace1/BACE1 coupling", fontsize=14, fontweight="bold")
    savefig(fig, out / f"Figure_6_upstream_coupling_meta_summary.{fmt}", dpi)


def fig7(paths, out, dpi, fmt):
    fig = plt.figure(figsize=(14, 8))
    gs = GridSpec(1, 2, figure=fig, wspace=0.18)
    ax = fig.add_subplot(gs[0,0]); add_panel_label(ax,"A"); draw_integrated_model(ax)
    ax = fig.add_subplot(gs[0,1]); add_panel_label(ax,"B"); draw_text_box(ax, "Working model for 15+ IF framing:\n\n1. Conserved component: AD microglia repeatedly recover a homeostatic-to-lysosome/DAM remodeling architecture.\n\n2. Divergent component: the Zfp335/ZNF335-Bace1/BACE1 relationship differs across species/cohorts.\n\n3. Mouse datasets mainly capture the downstream activated-state response and have limited confidence for the upstream axis when detection is low.\n\n4. Human datasets show the strongest positive ZNF335-BACE1 transcript-level coupling, but still need orthogonal validation.\n\n5. Causal validation should test Zfp335/ZNF335 perturbation effects on Bace1/BACE1, lysosomal markers, phagocytosis/amyloid handling, and AKT/Rac1-linked readouts.", title="Manuscript take-home message", fontsize=9.2)
    fig.suptitle("Figure 7. Integrated cross-species model of AD microglial remodeling", fontsize=14, fontweight="bold")
    savefig(fig, out / f"Figure_7_integrated_model.{fmt}", dpi)


def supp_transition(paths, out, dpi, fmt):
    fig = plt.figure(figsize=(14, 10))
    gs = GridSpec(2, 2, figure=fig, wspace=0.12, hspace=0.20)
    panels = [("A", "GSE140510", paths["gse140510_transition_helper"]), ("B", "GSE98969", paths["gse98969_transition_helper"]), ("C", "Olah", paths["olah_transition_helper"]), ("D", "SEA-AD", paths["seaad_transition_helper"])]
    for idx, (lab, title, path) in enumerate(panels):
        ax = fig.add_subplot(gs[idx // 2, idx % 2]); add_panel_label(ax, lab); show_image(ax, path, title)
    fig.suptitle("Supplementary Figure. Transition helper plots across datasets", fontsize=14, fontweight="bold")
    savefig(fig, out / f"Supplementary_Figure_transition_helpers_all_datasets.{fmt}", dpi)


def supp_gsea(paths, out, dpi, fmt):
    fig = plt.figure(figsize=(14, 8.5))
    gs = GridSpec(1, 2, figure=fig, wspace=0.16)
    ax = fig.add_subplot(gs[0,0]); add_panel_label(ax,"A"); show_image(ax, paths["gsea_reactome"], "Reactome Pathways 2024 (exploratory)")
    ax = fig.add_subplot(gs[0,1]); add_panel_label(ax,"B"); show_image(ax, paths["gsea_kegg"], "KEGG 2021 Human (exploratory mouse mismatch)")
    fig.suptitle("Supplementary Figure. Exploratory external GSEA top-term plots", fontsize=14, fontweight="bold")
    savefig(fig, out / f"Supplementary_Figure_external_GSEA_top_terms.{fmt}", dpi)


def write_readme(outdir: Path, fmt: str):
    (outdir / "README_MULTIPANEL_FIGURES.txt").write_text(
        "Manuscript multi-panel figure outputs\n"
        "=====================================\n\n"
        "Main figures are in main_figures/:\n"
        f"- Figure_1_study_design_state_architecture.{fmt}\n"
        f"- Figure_2_microglial_transition_continuum.{fmt}\n"
        f"- Figure_3_pseudobulk_validation.{fmt}\n"
        f"- Figure_4_external_GSEA_audit.{fmt}\n"
        f"- Figure_5_cross_dataset_state_meta_summary.{fmt}\n"
        f"- Figure_6_upstream_coupling_meta_summary.{fmt}\n"
        f"- Figure_7_integrated_model.{fmt}\n\n"
        "Supplementary figures are in supplementary_figures/.\n"
        "Inventory tables are in tables/: figure_source_inventory.csv and missing_figure_sources.csv.\n\n"
        "This script assembles existing result figures and generates schematic/text panels.\n"
        "For final submission to a 15+ IF journal, manual polishing in Illustrator/Inkscape may still be useful.\n",
        encoding="utf-8")


def main():
    args = parse_args()
    project_root = Path(args.project_root).resolve()
    outdir = (project_root / args.output_dir).resolve()
    mkdirs(outdir)
    paths = discover_paths(project_root)
    write_inventory(paths, outdir)
    main_out = outdir / "main_figures"
    supp_out = outdir / "supplementary_figures"
    print("Building main figures...")
    fig1(paths, main_out, args.dpi, args.image_format)
    fig2(paths, main_out, args.dpi, args.image_format)
    fig3(paths, main_out, args.dpi, args.image_format)
    fig4(paths, main_out, args.dpi, args.image_format)
    fig5(paths, main_out, args.dpi, args.image_format)
    fig6(paths, main_out, args.dpi, args.image_format)
    fig7(paths, main_out, args.dpi, args.image_format)
    print("Building supplementary figures...")
    supp_transition(paths, supp_out, args.dpi, args.image_format)
    supp_gsea(paths, supp_out, args.dpi, args.image_format)
    write_readme(outdir, args.image_format)
    print(f"Done. Outputs written to: {outdir}")
    print(f"Read: {outdir / 'README_MULTIPANEL_FIGURES.txt'}")
    print(f"Inventory: {outdir / 'tables' / 'figure_source_inventory.csv'}")


if __name__ == "__main__":
    main()
