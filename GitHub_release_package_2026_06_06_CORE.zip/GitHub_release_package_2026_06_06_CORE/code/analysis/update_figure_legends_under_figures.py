from pathlib import Path
import re

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt
from docx.text.paragraph import Paragraph


IN_DOCX = Path(r"D:\PhD\Papers\Research papers\ZFP335\MANUSCRIPT_SUBMISSION_READY_NATURE_LEVEL_with_figures.docx")
OUT_DOCX = Path(r"D:\PhD\Papers\Research papers\ZFP335\MANUSCRIPT_SUBMISSION_READY_NATURE_LEVEL_with_figures_detailed_legends.docx")


LEGENDS = {
    1: (
        "Figure 1. Cross-dataset study design and state-annotation framework. "
        "(A) Four microglial resources integrated for discovery, validation, and species/model comparison: SEA-AD human microglia/PVM subset, Olah live-isolated human microglia, GSE140510 mouse Trem2-linked model with WT, Trem2_KO, WT_5xFAD, and Trem2_KO_5xFAD groups, and GSE98969 independent mouse microglial cohort. "
        "(B) Analysis workflow beginning with public human and mouse datasets, followed by quality control, clustering, microglia subsetting, module scoring, pseudobulk/reactome/KEGG validation, and meta-summary of state architecture and upstream coupling. "
        "(C) Harmonized state-annotation model used across datasets, with homeostatic identity loss and lysosome/DAM gain represented as a remodeling continuum; homeostatic, transitional, lysosome-high, DAM-like, interferon-like, and proliferative-like compartments are shown with representative markers. "
        "(D) Cross-dataset state occupancy summarizing the proportion of microglia assigned to each harmonized state, emphasizing that state labels differ by dataset whereas the recurring remodeled compartments provide the basis for downstream program-level inference."
    ),
    2: (
        "Figure 2. SEA-AD human discovery microglia reveal coordinated lipid-phagolysosomal remodeling. "
        "(A) UMAP of 1,095 SEA-AD microglia annotated into homeostatic-like, transitional-like, lysosome-high, DAM/phagocytic-like, interferon-like, and proliferative-like states. "
        "(B) Cell-level module scores projected onto the UMAP for homeostatic, lysosome, DAM/phagocytic, and lipid programs, showing spatial separation between homeostatic identity and remodeled lysosome/DAM/lipid activity. "
        "(C) Dot plot of state-resolved marker expression, including homeostatic markers P2RY12, TMEM119, CX3CR1, and CSF1R; lipid/DAM markers APOE, TREM2, TYROBP, LPL, CST7, ITGAX, AXL, and GPNMB; lysosomal/phagocytic markers CTSB, CTSD, LAMP1, LAMP2, CD68, HEXA, and HEXB; and interferon/immune markers ISG15, IFIT3, STAT1, and IRF7. Dot color indicates average expression z score and dot size indicates percent expressing. "
        "(D) Donor-level state proportions for SEA-AD donors with at least 20 microglia, ordered by remodeling burden. "
        "(E) Donor-level module summary showing that high-remodeling donors have elevated lipid, lysosome, DAM/phagocytic, interferon, and proliferation module scores relative to lower-remodeling donors, supporting SEA-AD as the human discovery layer for lipid-phagolysosomal remodeling."
    ),
    3: (
        "Figure 3. Independent human validation in live-isolated Olah microglia. "
        "(A) UMAP of 16,232 Olah live-isolated human microglia from 17 donors annotated with the same harmonized state framework used in SEA-AD. "
        "(B) UMAP projections of homeostatic, lysosome, DAM/phagocytosis, and lipid module scores, showing broad preservation of the remodeled module architecture in an independent human dataset. "
        "(C) State-resolved marker-expression dot plot for homeostatic genes P2RY12, TMEM119, CX3CR1, and CSF1R; lipid/DAM genes APOE, TREM2, TYROBP, LPL, AXL, and GPNMB; lysosomal/phagocytic genes LAMP1, LAMP2, CTSB, CTSD, CTSS, CD68, and CST7; and immune markers IFIT3, ISG15, HLA-DRA, and HLA-DRB1. "
        "(D) Violin plots compare module scores across homeostatic-like, transitional-like, lysosome-high, DAM/phagocytic-like, interferon-like, and proliferative-like states; Mann-Whitney tests versus homeostatic-like cells are indicated by asterisks. "
        "(E) Cross-dataset human validation heatmap comparing oriented donor-level effects in SEA-AD discovery and Olah validation. Positive effects for lysosome gain, DAM/phagocytosis gain, lipid program activation, interferon activation, and proliferative program support the conclusion that human AD-associated remodeling is a coordinated lipid-phagolysosomal response with context-dependent inflammatory and proliferative branches."
    ),
    4: (
        "Figure 4. Mouse conservation and Trem2-linked remodeling separate lysosomal and DAM/phagocytic arms. "
        "(A) UMAP of GSE98969 mouse microglia from WT and 5xFAD samples annotated into the harmonized microglial states. "
        "(B) GSE98969 module-score projections for homeostatic, lysosome, and DAM/phagocytosis programs show conservation of remodeled program structure in an independent mouse AD cohort. "
        "(C) UMAP of GSE140510 mouse microglia spanning WT, 5xFAD, Trem2_KO, and Trem2_KO_5xFAD groups. "
        "(D) GSE140510 module-score projections show opposing homeostatic and remodeled lysosome/DAM patterns across the state landscape. "
        "(E) Sample-level stacked bars show state proportions for the 12 GSE140510 samples, three per genotype/model group. "
        "(F) Group-level state proportions indicate that 5xFAD shifts microglia away from homeostatic-like composition toward lysosome-high and DAM/phagocytic-like states, while Trem2_KO_5xFAD partially restores homeostatic-like composition and attenuates the DAM/phagocytic-like arm. "
        "(G) Pseudobulk marker heatmap summarizes homeostatic, DAM/phagocytic, and lysosomal/phagocytic genes across groups. "
        "(H) Effect-size summaries for remodeling modules compare 5xFAD versus WT, Trem2_KO_5xFAD versus Trem2_KO, and Trem2_KO_5xFAD versus 5xFAD. Because each group contains three samples, these contrasts are interpreted as directional effect estimates rather than definitive significance claims."
    ),
    5: (
        "Figure 5. Conserved program coupling identifies the lysosome-DAM axis as the reproducible remodeling core. "
        "(A) Program activity heatmap across SEA-AD (n = 5), Olah (n = 17), GSE98969 (n = 97), and GSE140510 (n = 12), summarizing DAM/lipid-response, lysosome/phagosome, interferon/inflammatory, lysosomal-biogenesis, and myeloid TF candidate families. "
        "(B) Sample- or donor-level Spearman correlations among program families show consistently positive DAM/lipid-response to lysosome/phagosome coupling across all four datasets (rho = 0.90 in SEA-AD, 0.70 in Olah, 0.79 in GSE98969, and 0.73 in GSE140510). "
        "(C) Pooled scatterplot of DAM/lipid-response and lysosome/phagosome scores shows the coupled axis across 131 samples/donors. "
        "(D) Detection-aware ranking identifies top candidate regulatory-program anchors, led by lysosomal/phagocytic and DAM/lipid genes including CTSB, CTSD, HEXB, TREM2, APOE, TYROBP, LAMP1, CD68, CTSL, HEXA, LAMP2, AXL, ITGAX, STAT1, TFEB, MX1, LPL, and CST7. "
        "(E) Family-level robustness integrates mean detection, support across datasets, and mean absolute correlation to the core axis, ranking lysosome/phagosome and DAM/lipid-response as the strongest families. "
        "(F) Program-level framework summarizes a conserved lysosome/phagosome and DAM/lipid-response core with context-dependent interferon, lysosomal-biogenesis, and myeloid-TF branches. "
        "(G-I) Cross-dataset anchor evidence, robustness-component decomposition, and gene-prioritization landscape show that the strongest anchors are recurring effector genes rather than isolated single candidates. "
        "(J) Mechanistic summary places AD-remodeled microglia at the intersection of the coupled lysosome-DAM axis and weaker context-dependent branches."
    ),
    6: (
        "Figure 6. Bayesian heterogeneous graph transformer modeling supports predictive value of the program architecture. "
        "(A) Bayesian HGT architecture integrating cell, gene-expression, program-activity, and context-metadata tokens into a Bayesian encoder with Monte Carlo dropout, producing remodeled-state probability and posterior predictive uncertainty; the model used two layers, hidden dimension 64, four attention heads, 50 Monte Carlo samples, dropout 0.25, batch size 256, 120 epochs, and patience 18. Data sources include SEA-AD for training and Olah, GSE98969, and GSE140510 for external validation. "
        "(B) Donor-held-out SEA-AD performance comparing gene-only, gene-plus-program, and full Bayesian HGT models across AUROC, AUPRC, F1, and balanced accuracy. Program-aware models outperform the gene-only baseline, and the full HGT achieves high AUROC and balanced accuracy. "
        "(C) External validation after training on SEA-AD shows strong transfer to Olah and GSE140510, while GSE98969 demonstrates context-dependent transfer behavior. "
        "(D) Calibration and uncertainty summaries include reliability curves, expected calibration error, and predictive uncertainty for correct versus incorrect predictions. "
        "(E) Ablation metrics show that program-only and gene-plus-program models approach the full HGT, supporting the importance of curated program structure. "
        "(F) Feature-relevance ranking identifies both program tokens and gene tokens, including homeostatic, DAM/phagocytic, interferon, proliferative, CX3CR1, lysosome, CSF1R, IFIT3, TMEM119, APOE, lipid, LAMP2, CD68, CTSB, ZNF335, TREM2, CST7, and LPL. "
        "(G) Program-activity heatmap across datasets and contexts illustrates which activity patterns are portable and which are context-specific."
    ),
    7: (
        "Figure 7. TF-regulator integration nominates ZNF335 as a low-detection, human-prioritized candidate after canonical regulatory biology is recovered. "
        "(A-D) State-resolved TF expression and detection across GSE98969 mouse, GSE140510 mouse, Olah human, and SEA-AD human datasets. Dot color represents expression and dot size represents detection; TF groups include myeloid core, myeloid inflammatory, myeloid homeostatic, myeloid activation, interferon, lysosomal biogenesis, and exploratory regulator categories. These panels show that canonical myeloid and interferon regulators are more broadly interpretable than ZNF335/Zfp335, which is present but low-detection. "
        "(E-G) TF/module correlation networks in GSE98969, GSE140510, and Olah display regulator-to-module associations with absolute Spearman rho at least 0.4 among the top 40 links; red edges indicate positive correlations and blue edges indicate inverse correlations. "
        "(H) SEA-AD discovery heatmap summarizes TF associations with homeostasis, lysosome, DAM/phagocytosis, interferon, and proliferative modules, recovering expected STAT1/IRF7 interferon-associated patterns while showing minimal core-program association for ZNF335/Zfp335. "
        "(I) Olah donor-level validation heatmap shows the strongest human ZNF335 signal: inverse associations with proliferative score, DAM/phagocytic score, and lysosome score, consistent with a bounded candidate-modulator interpretation rather than a state-marker claim. "
        "(J) Evidence-filter matrix integrates coverage, detection, state support, human absolute correlation, Olah inverse evidence, HGT relevance, and final candidacy. ZNF335/Zfp335 is nominated because it is present in all final objects, has coherent human donor-level inverse coupling, and ranks highly in HGT relevance, while the legend and manuscript explicitly do not claim that it is a proven causal regulator."
    ),
}


def paragraph_has_picture(paragraph: Paragraph) -> bool:
    return bool(paragraph._p.xpath(".//pic:pic"))


def remove_paragraph(paragraph: Paragraph) -> None:
    element = paragraph._element
    element.getparent().remove(element)
    paragraph._p = paragraph._element = None


def is_page_break_only(paragraph: Paragraph) -> bool:
    return not paragraph.text.strip() and "w:br" in paragraph._p.xml and "page" in paragraph._p.xml


def paragraph_after(paragraph: Paragraph) -> Paragraph:
    new_p = OxmlElement("w:p")
    paragraph._p.addnext(new_p)
    return Paragraph(new_p, paragraph._parent)


def format_legend(paragraph: Paragraph, text: str) -> None:
    paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
    paragraph.paragraph_format.space_before = Pt(4)
    paragraph.paragraph_format.space_after = Pt(8)
    paragraph.paragraph_format.keep_together = True

    match = re.match(r"^(Figure \d+\.\s+)(.*)$", text)
    if not match:
        paragraph.add_run(text)
        return

    prefix, rest = match.groups()
    run = paragraph.add_run(prefix)
    run.bold = True
    run.font.size = Pt(9)
    run.font.name = "Arial"
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "Arial")

    run = paragraph.add_run(rest)
    run.font.size = Pt(9)
    run.font.name = "Arial"
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "Arial")


def main() -> None:
    doc = Document(IN_DOCX)

    caption_numbers_by_para = {}
    for paragraph in doc.paragraphs:
        match = re.match(r"^\s*Figure\s+([1-7])\.", paragraph.text)
        if match:
            caption_numbers_by_para[paragraph] = int(match.group(1))

    image_paragraphs = [p for p in doc.paragraphs if paragraph_has_picture(p)]
    if len(image_paragraphs) != 7:
        raise RuntimeError(f"Expected 7 figure image paragraphs; found {len(image_paragraphs)}")

    for paragraph in caption_numbers_by_para:
        remove_paragraph(paragraph)

    for paragraph in list(doc.paragraphs):
        if is_page_break_only(paragraph):
            remove_paragraph(paragraph)

    for fig_num, image_para in reversed(list(enumerate(image_paragraphs, start=1))):
        image_para.paragraph_format.keep_with_next = True
        legend_para = paragraph_after(image_para)
        format_legend(legend_para, LEGENDS[fig_num])
        if fig_num != 7:
            break_para = paragraph_after(legend_para)
            break_para.add_run().add_break(WD_BREAK.PAGE)

    doc.save(OUT_DOCX)
    print(OUT_DOCX)


if __name__ == "__main__":
    main()
