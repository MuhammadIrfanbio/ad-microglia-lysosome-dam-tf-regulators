GSEA Publication Readiness Audit

What this audit did:
- Froze existing downloaded GMT files into frozen_gmt/ and recorded checksums.
- Computed per-pathway rank-universe overlap for existing external GSEA runs.
- Audited species/library compatibility for mouse GSE140510 runs.
- Collapsed redundant existing GSEA terms by overlap-gene Jaccard >= 0.7.

Important conclusion:
The existing GSE140510 external GSEA runs are not publication-ready because they used uppercased mouse genes with human or ambiguous Enrichr libraries and include unresolved library errors. Treat them as exploratory only.

Publication path:
- Rerun run_external_enrichr_prerank_gsea.py with --gmt-files pointing to frozen species-matched GMT files, or with --library-species human_ortholog plus an explicit --ortholog-map.
- Run discovery and validation as separate --analysis-stage values.
- Report tables/gene_universe_summary.csv, tables/frozen_gmt_manifest.csv, and tables/pathway_gene_universe_overlap.csv with the GSEA results.

