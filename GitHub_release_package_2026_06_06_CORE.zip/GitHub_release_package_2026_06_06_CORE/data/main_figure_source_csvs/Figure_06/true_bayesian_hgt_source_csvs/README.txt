Figure 6 true Bayesian HGT panel source-data CSVs.
Output directory: F:\AD\Mam San\results\publication_figures\figure6_true_bayesian_hgt_source_data
True HGT source directory: F:\AD\Mam San\results\bayesian_hgt_true_results
True HGT external-validation source directory: F:\AD\Mam San\results\bayesian_hgt_true_external_validation
Panel C external validation is populated when true second-stage external-validation files are present.
All other model panels use the completed true Bayesian HGT result files.