# GitHub core package

Generated: 2026-06-06 21:11:38

This is the recommended GitHub repository content. It contains code, compact derived source tables, references, environment files, and documentation.

Large manuscript DOCX files, large figure binaries, cell-level UMAP tables, pseudobulk matrices, marker tables, prediction tables, and other large tables are excluded from this core package and listed in:

`docs/EXCLUDED_LARGE_FILES_FOR_DATA_REPOSITORY.csv`

Deposit excluded large files in Zenodo/OSF/Figshare or attach them as GitHub release assets. Do not commit them directly to the repository unless using Git LFS.

Full local package:
`F:\AD\Mam San\results\Sand_regulatory_program_manuscript_package_final_v2\Final\GitHub_release_package_2026_06_06_LIGHT`
