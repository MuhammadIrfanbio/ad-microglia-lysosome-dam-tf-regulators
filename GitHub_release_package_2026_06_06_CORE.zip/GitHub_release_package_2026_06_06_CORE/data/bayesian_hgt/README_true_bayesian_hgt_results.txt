True Bayesian HGT result files.
Model: MC-dropout Bayesian heterogeneous graph transformer implemented in PyTorch.
Task: remodeled vs homeostatic/transitional microglia.
Validation: donor-held-out SEA-AD cross-validation.
Output directory: F:\AD\Mam San\results\bayesian_hgt_true_results