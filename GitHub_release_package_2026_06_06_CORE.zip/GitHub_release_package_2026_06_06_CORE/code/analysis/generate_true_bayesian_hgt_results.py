#!/usr/bin/env python3
"""
Generate true Bayesian HGT candidate result files from the updated AD microglia data.

This is a self-contained PyTorch implementation of a Bayesian heterogeneous
graph-transformer-style classifier using MC dropout for posterior predictive
uncertainty. It does not require torch_geometric.

Model task:
  Predict remodeled AD-associated microglial state
  positive class = lysosome_high, dam_like, interferon_like, proliferative_like
  negative class = homeostatic_like, transitional_like

Graph/token structure per cell:
  - cell token
  - gene expression tokens
  - program activity tokens
  - context metadata tokens

Outputs are intentionally named and annotated as true Bayesian HGT result files:
  results/bayesian_hgt_true_results/
    true_bayesian_hgt_donor_heldout_performance.csv
    true_bayesian_hgt_donor_heldout_predictions.csv
    true_bayesian_hgt_calibration_curve.csv
    true_bayesian_hgt_expected_calibration_error.csv
    true_bayesian_hgt_uncertainty.csv
    true_bayesian_hgt_ablation_summary.csv
    true_bayesian_hgt_interpretability_feature_relevance.csv
    true_bayesian_hgt_architecture_nodes.csv
    true_bayesian_hgt_architecture_edges.csv
    true_bayesian_hgt_training_manifest.json

Run example:
  C:\\ProgramData\\miniforge3\\python.exe generate_true_bayesian_hgt_results.py --epochs 120 --mc-samples 50

For a fast smoke test:
  C:\\ProgramData\\miniforge3\\python.exe generate_true_bayesian_hgt_results.py --epochs 5 --mc-samples 5 --max-cells 800
"""

from __future__ import annotations

import argparse
import json
import math
import os
import random
import re
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

if sys.platform.startswith("win"):
    # Calling C:\ProgramData\miniforge3\python.exe directly from another conda
    # prompt does not activate Miniforge DLL search paths. Set this before any
    # scientific package import, because OpenMP can initialize very early.
    os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
    py_root = Path(sys.executable).resolve().parent
    dll_dirs = [
        py_root / "Library" / "bin",
        py_root / "DLLs",
        py_root / "Lib" / "site-packages" / "torch" / "lib",
    ]
    for dll_dir in reversed([d for d in dll_dirs if d.exists()]):
        os.environ["PATH"] = str(dll_dir) + os.pathsep + os.environ.get("PATH", "")
    if (py_root / "Lib" / "site-packages" / "torch" / "lib").exists() and os.environ.get("BAYESIAN_HGT_DLL_REEXEC") != "1":
        # Some torch DLL dependencies are resolved from PATH only at process
        # startup. Re-exec once so the updated PATH is active from launch.
        os.environ["BAYESIAN_HGT_DLL_REEXEC"] = "1"
        raise SystemExit(subprocess.call([sys.executable, str(Path(__file__).resolve()), *sys.argv[1:]], env=os.environ))
    for dll_dir in dll_dirs:
        if dll_dir.exists():
            try:
                os.add_dll_directory(str(dll_dir))
            except (AttributeError, OSError):
                pass

try:
    import torch
    import torch.nn as nn
    from torch.utils.data import DataLoader, TensorDataset
except ImportError as exc:  # pragma: no cover
    raise SystemExit(
        "\nThis script needs PyTorch, but the current Python environment does not have it.\n"
        f"Current Python: {sys.executable}\n\n"
        "Use the Miniforge Python that is already available in this workspace:\n"
        '  "C:\\ProgramData\\miniforge3\\python.exe" "F:\\AD\\Mam San\\generate_true_bayesian_hgt_results.py" --epochs 120 --mc-samples 50\n\n'
        "Or install PyTorch into the active environment before running this script."
    ) from exc

import numpy as np
import pandas as pd
from scipy import sparse
from sklearn.metrics import (
    average_precision_score,
    balanced_accuracy_score,
    brier_score_loss,
    f1_score,
    roc_auc_score,
)
from sklearn.model_selection import LeaveOneGroupOut
from sklearn.preprocessing import StandardScaler

try:
    import anndata as ad
except ImportError as exc:  # pragma: no cover
    raise SystemExit("This script needs anndata/h5py. Use C:\\ProgramData\\miniforge3\\python.exe.") from exc


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results" / "bayesian_hgt_true_results"
OUT.mkdir(parents=True, exist_ok=True)

SEA_AD_H5AD = ROOT / "results" / "seaad_microglia_fixed" / "objects" / "seaad_microglia_fixed_microglia_final.h5ad"

STATE_POSITIVE = ["lysosome_high", "dam_like", "interferon_like", "proliferative_like"]
STATE_NEGATIVE = ["homeostatic_like", "transitional_like"]

PROGRAM_COLS = [
    "homeostatic_score",
    "lysosome_score",
    "dam_phagocytic_score",
    "lipid_score",
    "interferon_score",
    "proliferative_score",
]

LIPID_GENES = ["APOE", "TREM2", "TYROBP", "LPL", "CST7", "ITGAX", "AXL", "GPNMB"]

GENE_FAMILIES = [
    "BACE1",
    "ZNF335",
    "APOE",
    "TREM2",
    "TYROBP",
    "LPL",
    "CTSB",
    "CTSD",
    "LAMP1",
    "LAMP2",
    "CD68",
    "CST7",
    "P2RY12",
    "TMEM119",
    "CX3CR1",
    "CSF1R",
    "ISG15",
    "IFIT3",
]

CONTEXT_COLS = ["donor_sex_label", "age_label", "region_label"]


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def dense(X) -> np.ndarray:
    if sparse.issparse(X):
        return X.toarray()
    return np.asarray(X)


def zscore(x: pd.Series) -> pd.Series:
    x = pd.to_numeric(x, errors="coerce").astype(float)
    sd = x.std(ddof=0)
    if not np.isfinite(sd) or sd == 0:
        return pd.Series(np.zeros(len(x)), index=x.index)
    return (x - x.mean()) / sd


def parse_numeric_age(value: object) -> float:
    text = str(value)
    match = re.search(r"[-+]?\d*\.?\d+", text)
    return float(match.group()) if match else np.nan


def expression_matrix(adata: ad.AnnData, genes: list[str]) -> pd.DataFrame:
    present = [g for g in genes if g in adata.var_names]
    expr = pd.DataFrame(index=adata.obs_names)
    if present:
        expr = expr.join(pd.DataFrame(dense(adata[:, present].X), index=adata.obs_names, columns=present))
    for gene in genes:
        if gene not in expr.columns:
            expr[gene] = 0.0
    return expr[genes].astype(float)


def load_seaad(max_cells: int | None = None, seed: int = 7) -> pd.DataFrame:
    if not SEA_AD_H5AD.exists():
        raise FileNotFoundError(SEA_AD_H5AD)
    adata = ad.read_h5ad(SEA_AD_H5AD)
    obs = adata.obs.copy()
    obs["cell_id"] = adata.obs_names.astype(str)
    obs["donor_id"] = obs["external_donor_name_label"].astype(str)
    obs["target"] = obs["state_hint"].isin(STATE_POSITIVE).astype(int)
    obs["target_label"] = np.where(obs["target"] == 1, "remodeled", "homeostatic_or_transitional")

    expr = expression_matrix(adata, GENE_FAMILIES)
    expr.columns = [f"gene::{c}" for c in expr.columns]

    lipid_present = [g for g in LIPID_GENES if g in adata.var_names]
    if lipid_present:
        lipid = expression_matrix(adata, lipid_present).apply(zscore, axis=0).mean(axis=1)
    else:
        lipid = pd.Series(0.0, index=adata.obs_names)
    obs["lipid_score"] = lipid.reindex(obs.index).fillna(0.0).values

    for col in PROGRAM_COLS:
        if col not in obs.columns:
            obs[col] = 0.0
    for col in CONTEXT_COLS:
        if col not in obs.columns:
            obs[col] = "unknown"
    obs["age_numeric"] = pd.to_numeric(obs["age_label"].map(parse_numeric_age), errors="coerce").astype(float)

    data = pd.concat(
        [
            obs[
                [
                    "cell_id",
                    "donor_id",
                    "state_hint",
                    "target",
                    "target_label",
                    "age_numeric",
                ]
                + CONTEXT_COLS
                + PROGRAM_COLS
            ],
            expr,
        ],
        axis=1,
    )
    if max_cells and len(data) > max_cells:
        data = (
            data.groupby(["donor_id", "target"], group_keys=False)
            .apply(lambda x: x.sample(min(len(x), max(1, int(max_cells * len(x) / len(data)))), random_state=seed))
            .sample(frac=1, random_state=seed)
        )
        if len(data) > max_cells:
            data = data.sample(max_cells, random_state=seed)
    return data.reset_index(drop=True)


@dataclass
class FeatureSpec:
    name: str
    gene_cols: list[str]
    program_cols: list[str]
    context_cols: list[str]
    include_context: bool


def make_feature_specs() -> list[FeatureSpec]:
    gene_cols = [f"gene::{g}" for g in GENE_FAMILIES]
    return [
        FeatureSpec("gene_only", gene_cols, [], [], False),
        FeatureSpec("program_only", [], PROGRAM_COLS, [], False),
        FeatureSpec("gene_program_no_context", gene_cols, PROGRAM_COLS, [], False),
        FeatureSpec("full_bayesian_hgt", gene_cols, PROGRAM_COLS, CONTEXT_COLS + ["age_numeric"], True),
    ]


class HGTFeatureBuilder:
    def __init__(self, spec: FeatureSpec):
        self.spec = spec
        self.gene_scaler = StandardScaler()
        self.program_scaler = StandardScaler()
        self.age_scaler = StandardScaler()
        self.context_vocab: dict[str, dict[str, int]] = {}

    def fit(self, df: pd.DataFrame) -> "HGTFeatureBuilder":
        if self.spec.gene_cols:
            self.gene_scaler.fit(df[self.spec.gene_cols].fillna(0.0))
        if self.spec.program_cols:
            self.program_scaler.fit(df[self.spec.program_cols].fillna(0.0))
        if self.spec.include_context:
            if "age_numeric" in self.spec.context_cols:
                age = pd.to_numeric(df["age_numeric"], errors="coerce").astype(float)
                fill = age.median()
                if not np.isfinite(fill):
                    fill = 0.0
                self.age_scaler.fit(age.fillna(fill).to_frame())
            for col in self.spec.context_cols:
                if col == "age_numeric":
                    continue
                context = df[col].astype("object").where(df[col].notna(), "unknown").astype(str)
                vals = sorted(context.unique())
                self.context_vocab[col] = {v: i + 1 for i, v in enumerate(vals)}
                self.context_vocab[col]["<UNK>"] = 0
        return self

    @property
    def n_gene_tokens(self) -> int:
        return len(self.spec.gene_cols)

    @property
    def n_program_tokens(self) -> int:
        return len(self.spec.program_cols)

    @property
    def n_context_tokens(self) -> int:
        return len(self.spec.context_cols) if self.spec.include_context else 0

    @property
    def n_tokens(self) -> int:
        return 1 + self.n_gene_tokens + self.n_program_tokens + self.n_context_tokens

    def transform(self, df: pd.DataFrame) -> tuple[np.ndarray, np.ndarray, dict[str, list[str]]]:
        n = len(df)
        scalar = np.zeros((n, self.n_tokens), dtype=np.float32)
        type_id = np.zeros((n, self.n_tokens), dtype=np.int64)
        names = {"cell": ["cell"], "gene": [], "program": [], "context": []}
        pos = 1
        if self.spec.gene_cols:
            vals = self.gene_scaler.transform(df[self.spec.gene_cols].fillna(0.0)).astype(np.float32)
            scalar[:, pos : pos + vals.shape[1]] = vals
            type_id[:, pos : pos + vals.shape[1]] = 1
            names["gene"] = [c.replace("gene::", "") for c in self.spec.gene_cols]
            pos += vals.shape[1]
        if self.spec.program_cols:
            vals = self.program_scaler.transform(df[self.spec.program_cols].fillna(0.0)).astype(np.float32)
            scalar[:, pos : pos + vals.shape[1]] = vals
            type_id[:, pos : pos + vals.shape[1]] = 2
            names["program"] = self.spec.program_cols[:]
            pos += vals.shape[1]
        if self.spec.include_context:
            for col in self.spec.context_cols:
                type_id[:, pos] = 3
                names["context"].append(col)
                if col == "age_numeric":
                    age = pd.to_numeric(df["age_numeric"], errors="coerce").astype(float)
                    fill = age.median()
                    if not np.isfinite(fill):
                        fill = 0.0
                    scalar[:, pos] = self.age_scaler.transform(age.fillna(fill).to_frame()).ravel().astype(np.float32)
                else:
                    vocab = self.context_vocab[col]
                    context = df[col].astype("object").where(df[col].notna(), "unknown").astype(str)
                    scalar[:, pos] = (
                        context.map(lambda x: vocab.get(x, 0)).astype(float).values
                    )
                    denom = max(vocab.values()) if vocab else 1
                    scalar[:, pos] = scalar[:, pos] / max(denom, 1)
                pos += 1
        return scalar, type_id, names


class BayesianHGTClassifier(nn.Module):
    def __init__(self, n_tokens: int, d_model: int = 64, n_heads: int = 4, n_layers: int = 2, dropout: float = 0.25):
        super().__init__()
        self.n_tokens = n_tokens
        self.scalar_proj = nn.Linear(1, d_model)
        self.position_embedding = nn.Embedding(n_tokens, d_model)
        self.type_embedding = nn.Embedding(4, d_model)
        self.cls_embedding = nn.Parameter(torch.zeros(1, 1, d_model))
        enc_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=n_heads,
            dim_feedforward=d_model * 3,
            dropout=dropout,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.encoder = nn.TransformerEncoder(enc_layer, num_layers=n_layers)
        self.norm = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)
        self.classifier = nn.Linear(d_model, 1)
        nn.init.trunc_normal_(self.cls_embedding, std=0.02)

    def forward(self, scalar_tokens: torch.Tensor, type_ids: torch.Tensor) -> torch.Tensor:
        b, t = scalar_tokens.shape
        positions = torch.arange(t, device=scalar_tokens.device).unsqueeze(0).expand(b, t)
        x = self.scalar_proj(scalar_tokens.unsqueeze(-1))
        x = x + self.position_embedding(positions) + self.type_embedding(type_ids)
        x[:, :1, :] = x[:, :1, :] + self.cls_embedding
        x = self.encoder(x)
        cls = self.norm(x[:, 0, :])
        return self.classifier(self.dropout(cls)).squeeze(-1)


def train_model(
    train_scalar: np.ndarray,
    train_type: np.ndarray,
    train_y: np.ndarray,
    val_scalar: np.ndarray,
    val_type: np.ndarray,
    val_y: np.ndarray,
    args: argparse.Namespace,
    device: torch.device,
) -> BayesianHGTClassifier:
    model = BayesianHGTClassifier(
        n_tokens=train_scalar.shape[1],
        d_model=args.d_model,
        n_heads=args.n_heads,
        n_layers=args.n_layers,
        dropout=args.dropout,
    ).to(device)
    pos = float(train_y.sum())
    neg = float(len(train_y) - train_y.sum())
    pos_weight = torch.tensor([neg / max(pos, 1.0)], device=device)
    loss_fn = nn.BCEWithLogitsLoss(pos_weight=pos_weight)
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    ds = TensorDataset(
        torch.tensor(train_scalar, dtype=torch.float32),
        torch.tensor(train_type, dtype=torch.long),
        torch.tensor(train_y, dtype=torch.float32),
    )
    dl = DataLoader(ds, batch_size=args.batch_size, shuffle=True)
    best_state = None
    best_loss = math.inf
    patience_left = args.patience
    val_scalar_t = torch.tensor(val_scalar, dtype=torch.float32, device=device)
    val_type_t = torch.tensor(val_type, dtype=torch.long, device=device)
    val_y_t = torch.tensor(val_y, dtype=torch.float32, device=device)
    for _epoch in range(1, args.epochs + 1):
        model.train()
        for xb, tb, yb in dl:
            xb, tb, yb = xb.to(device), tb.to(device), yb.to(device)
            opt.zero_grad(set_to_none=True)
            loss = loss_fn(model(xb, tb), yb)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
        model.eval()
        with torch.no_grad():
            val_loss = float(loss_fn(model(val_scalar_t, val_type_t), val_y_t).cpu())
        if val_loss < best_loss:
            best_loss = val_loss
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            patience_left = args.patience
        else:
            patience_left -= 1
            if patience_left <= 0:
                break
    if best_state is not None:
        model.load_state_dict(best_state)
    return model


def mc_predict(
    model: BayesianHGTClassifier,
    scalar: np.ndarray,
    type_ids: np.ndarray,
    mc_samples: int,
    batch_size: int,
    device: torch.device,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    ds = TensorDataset(torch.tensor(scalar, dtype=torch.float32), torch.tensor(type_ids, dtype=torch.long))
    dl = DataLoader(ds, batch_size=batch_size, shuffle=False)
    all_samples = []
    model.train()  # keep dropout active for MC posterior predictive sampling
    with torch.no_grad():
        for _ in range(mc_samples):
            probs = []
            for xb, tb in dl:
                xb, tb = xb.to(device), tb.to(device)
                probs.append(torch.sigmoid(model(xb, tb)).detach().cpu().numpy())
            all_samples.append(np.concatenate(probs))
    draws = np.vstack(all_samples)
    mean = draws.mean(axis=0)
    lower = np.quantile(draws, 0.025, axis=0)
    upper = np.quantile(draws, 0.975, axis=0)
    return mean, lower, upper


def metric_rows(y: np.ndarray, prob: np.ndarray) -> dict[str, float]:
    pred = (prob >= 0.5).astype(int)
    out = {
        "AUROC": np.nan,
        "AUPRC": np.nan,
        "F1": float(f1_score(y, pred, zero_division=0)),
        "Balanced accuracy": float(balanced_accuracy_score(y, pred)),
        "Brier": np.nan,
    }
    if len(np.unique(y)) == 2:
        out["AUROC"] = float(roc_auc_score(y, prob))
        out["AUPRC"] = float(average_precision_score(y, prob))
        out["Brier"] = float(brier_score_loss(y, prob))
    return out


def entropy(prob: np.ndarray) -> np.ndarray:
    p = np.clip(prob, 1e-6, 1 - 1e-6)
    return -(p * np.log2(p) + (1 - p) * np.log2(1 - p))


def expected_calibration_error(y: np.ndarray, prob: np.ndarray, bins: int = 10) -> tuple[float, pd.DataFrame]:
    rows = []
    edges = np.linspace(0, 1, bins + 1)
    ece = 0.0
    for i in range(bins):
        lo, hi = edges[i], edges[i + 1]
        mask = (prob >= lo) & (prob < hi if i < bins - 1 else prob <= hi)
        if mask.sum() == 0:
            rows.append(
                {
                    "bin": i + 1,
                    "bin_low": lo,
                    "bin_high": hi,
                    "mean_predicted_probability": (lo + hi) / 2,
                    "observed_frequency": np.nan,
                    "n_cells": 0,
                }
            )
            continue
        obs = float(y[mask].mean())
        mean_p = float(prob[mask].mean())
        ece += (mask.sum() / len(y)) * abs(obs - mean_p)
        rows.append(
            {
                "bin": i + 1,
                "bin_low": lo,
                "bin_high": hi,
                "mean_predicted_probability": mean_p,
                "observed_frequency": obs,
                "n_cells": int(mask.sum()),
            }
        )
    return float(ece), pd.DataFrame(rows)


def split_train_validation(train_df: pd.DataFrame, seed: int) -> tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    idx = np.arange(len(train_df))
    val_size = max(1, int(0.15 * len(idx)))
    for _ in range(100):
        val_idx = rng.choice(idx, size=val_size, replace=False)
        tr_idx = np.setdiff1d(idx, val_idx)
        if train_df.iloc[val_idx]["target"].nunique() == 2 and train_df.iloc[tr_idx]["target"].nunique() == 2:
            return tr_idx, val_idx
    return idx, idx


def run_donor_heldout(data: pd.DataFrame, args: argparse.Namespace) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    specs = make_feature_specs()
    logo = LeaveOneGroupOut()
    y_all = data["target"].astype(int).values
    groups = data["donor_id"].astype(str).values
    perf_rows = []
    pred_rows = []
    ablation_rows = []
    importance_rows = []
    device = torch.device("cuda" if torch.cuda.is_available() and not args.cpu else "cpu")
    for fold, (train_idx, test_idx) in enumerate(logo.split(data, y_all, groups), start=1):
        train_df = data.iloc[train_idx].reset_index(drop=True)
        test_df = data.iloc[test_idx].reset_index(drop=True)
        if train_df["target"].nunique() < 2 or test_df["target"].nunique() < 2:
            continue
        held_donor = test_df["donor_id"].iloc[0]
        tr_local, val_local = split_train_validation(train_df, args.seed + fold)
        for spec in specs:
            builder = HGTFeatureBuilder(spec).fit(train_df.iloc[tr_local])
            tr_s, tr_t, token_names = builder.transform(train_df.iloc[tr_local])
            val_s, val_t, _ = builder.transform(train_df.iloc[val_local])
            test_s, test_t, _ = builder.transform(test_df)
            model = train_model(
                tr_s,
                tr_t,
                train_df.iloc[tr_local]["target"].astype(int).values,
                val_s,
                val_t,
                train_df.iloc[val_local]["target"].astype(int).values,
                args,
                device,
            )
            prob, lo, hi = mc_predict(model, test_s, test_t, args.mc_samples, args.batch_size, device)
            y_test = test_df["target"].astype(int).values
            metrics = metric_rows(y_test, prob)
            for metric, value in metrics.items():
                perf_rows.append(
                    {
                        "analysis": "true Bayesian HGT donor-held-out",
                        "fold": fold,
                        "held_out_donor": held_donor,
                        "model_key": spec.name,
                        "metric": metric,
                        "value": value,
                        "n_train": int(len(tr_s)),
                        "n_validation": int(len(val_s)),
                        "n_test": int(len(test_s)),
                    }
                )
                if metric in {"AUROC", "AUPRC", "F1", "Balanced accuracy"}:
                    ablation_rows.append(
                        {
                            "analysis": "true Bayesian HGT ablation",
                            "fold": fold,
                            "held_out_donor": held_donor,
                            "model_key": spec.name,
                            "metric": metric,
                            "value": value,
                        }
                    )
            tmp = test_df[["cell_id", "donor_id", "state_hint", "target", "target_label"]].copy()
            tmp["fold"] = fold
            tmp["model_key"] = spec.name
            tmp["predicted_probability"] = prob
            tmp["credible_interval_lower_95"] = lo
            tmp["credible_interval_upper_95"] = hi
            tmp["credible_interval_width_95"] = hi - lo
            tmp["predictive_uncertainty_entropy"] = entropy(prob)
            tmp["predicted_label"] = (prob >= 0.5).astype(int)
            tmp["correct_prediction"] = tmp["predicted_label"] == tmp["target"]
            pred_rows.append(tmp)
            if spec.name == "full_bayesian_hgt":
                for token_type, names in token_names.items():
                    if token_type == "cell":
                        continue
                    start = 1
                    if token_type == "gene":
                        offset = 1
                    elif token_type == "program":
                        offset = 1 + len(token_names["gene"])
                    else:
                        offset = 1 + len(token_names["gene"]) + len(token_names["program"])
                    for j, name in enumerate(names):
                        token_index = offset + j
                        perturbed = test_s.copy()
                        perturbed[:, token_index] = 0.0
                        p2, _, _ = mc_predict(model, perturbed, test_t, max(3, args.mc_samples // 5), args.batch_size, device)
                        importance_rows.append(
                            {
                                "analysis": "true Bayesian HGT interpretability",
                                "fold": fold,
                                "held_out_donor": held_donor,
                                "token_type": token_type,
                                "feature": name,
                                "mean_abs_probability_delta_when_zeroed": float(np.mean(np.abs(prob - p2))),
                            }
                        )
    return (
        pd.DataFrame(perf_rows),
        pd.concat(pred_rows, ignore_index=True) if pred_rows else pd.DataFrame(),
        pd.DataFrame(ablation_rows),
        pd.DataFrame(importance_rows),
    )


def write_architecture() -> None:
    nodes = [
        ("cell_token", "cell", "Cell token", 0.15, 0.55),
        ("gene_tokens", "gene", "Gene expression tokens", 0.38, 0.72),
        ("program_tokens", "program", "Program activity tokens", 0.38, 0.38),
        ("context_tokens", "context", "Context metadata tokens", 0.38, 0.16),
        ("hgt_encoder", "model", "Bayesian HGT encoder with MC dropout", 0.64, 0.52),
        ("state_output", "output", "Remodeled-state probability", 0.86, 0.62),
        ("uncertainty_output", "output", "Posterior predictive uncertainty", 0.86, 0.38),
    ]
    edges = [
        ("cell_token", "hgt_encoder", "cell node embedding"),
        ("gene_tokens", "hgt_encoder", "cell-gene expression relation"),
        ("program_tokens", "hgt_encoder", "cell-program activity relation"),
        ("context_tokens", "hgt_encoder", "cell-context covariate relation"),
        ("hgt_encoder", "state_output", "posterior mean probability"),
        ("hgt_encoder", "uncertainty_output", "MC-dropout credible interval"),
    ]
    pd.DataFrame(nodes, columns=["node_id", "node_type", "label", "x", "y"]).to_csv(
        OUT / "true_bayesian_hgt_architecture_nodes.csv", index=False
    )
    pd.DataFrame(edges, columns=["source", "target", "edge_label"]).to_csv(
        OUT / "true_bayesian_hgt_architecture_edges.csv", index=False
    )


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Train a true Bayesian HGT candidate model on updated SEA-AD microglia")
    p.add_argument("--epochs", type=int, default=120)
    p.add_argument("--patience", type=int, default=18)
    p.add_argument("--batch-size", type=int, default=256)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--weight-decay", type=float, default=1e-4)
    p.add_argument("--dropout", type=float, default=0.25)
    p.add_argument("--d-model", type=int, default=64)
    p.add_argument("--n-heads", type=int, default=4)
    p.add_argument("--n-layers", type=int, default=2)
    p.add_argument("--mc-samples", type=int, default=50)
    p.add_argument("--seed", type=int, default=7)
    p.add_argument("--max-cells", type=int, default=None, help="Optional downsampling for smoke tests")
    p.add_argument("--cpu", action="store_true", help="Force CPU even if CUDA exists")
    return p.parse_args()


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    write_architecture()
    data = load_seaad(max_cells=args.max_cells, seed=args.seed)
    data.to_csv(OUT / "true_bayesian_hgt_training_cell_feature_table.csv", index=False)
    dataset_summary = pd.DataFrame(
        [
            {
                "analysis": "true Bayesian HGT training data",
                "dataset": "SEA-AD",
                "n_cells": len(data),
                "n_donors": data["donor_id"].nunique(),
                "n_positive_remodeled": int(data["target"].sum()),
                "pct_positive_remodeled": float(data["target"].mean() * 100),
                "positive_states": ";".join(STATE_POSITIVE),
                "negative_states": ";".join(STATE_NEGATIVE),
            }
        ]
    )
    dataset_summary.to_csv(OUT / "true_bayesian_hgt_dataset_summary.csv", index=False)
    perf, pred, ablation, importance = run_donor_heldout(data, args)
    perf.to_csv(OUT / "true_bayesian_hgt_donor_heldout_performance.csv", index=False)
    pred.to_csv(OUT / "true_bayesian_hgt_donor_heldout_predictions.csv", index=False)
    ablation.to_csv(OUT / "true_bayesian_hgt_ablation_metrics_long.csv", index=False)
    if not ablation.empty:
        (
            ablation.groupby(["model_key", "metric"], observed=True)["value"]
            .agg(mean="mean", median="median", sd="std", n_folds="count")
            .reset_index()
            .to_csv(OUT / "true_bayesian_hgt_ablation_summary.csv", index=False)
        )
    importance.to_csv(OUT / "true_bayesian_hgt_interpretability_feature_relevance.csv", index=False)
    if not pred.empty:
        rows = []
        ece_rows = []
        for model_key, sub in pred.groupby("model_key", observed=True):
            ece, curve = expected_calibration_error(sub["target"].values.astype(int), sub["predicted_probability"].values.astype(float))
            curve.insert(0, "model_key", model_key)
            rows.append(curve)
            ece_rows.append({"model_key": model_key, "expected_calibration_error": ece, "n_cells": len(sub)})
        pd.concat(rows, ignore_index=True).to_csv(OUT / "true_bayesian_hgt_calibration_curve.csv", index=False)
        pd.DataFrame(ece_rows).to_csv(OUT / "true_bayesian_hgt_expected_calibration_error.csv", index=False)
        pred[
            [
                "cell_id",
                "donor_id",
                "state_hint",
                "model_key",
                "target",
                "predicted_probability",
                "credible_interval_lower_95",
                "credible_interval_upper_95",
                "credible_interval_width_95",
                "predictive_uncertainty_entropy",
                "correct_prediction",
            ]
        ].to_csv(OUT / "true_bayesian_hgt_uncertainty.csv", index=False)
    manifest = {
        "analysis": "true Bayesian HGT result generation",
        "model": "Bayesian heterogeneous graph transformer with MC dropout posterior predictive sampling",
        "input_h5ad": str(SEA_AD_H5AD),
        "output_dir": str(OUT),
        "target_definition": {
            "positive_class": "remodeled",
            "positive_states": STATE_POSITIVE,
            "negative_states": STATE_NEGATIVE,
        },
        "parameters": vars(args),
        "result_files": [
            "true_bayesian_hgt_donor_heldout_performance.csv",
            "true_bayesian_hgt_donor_heldout_predictions.csv",
            "true_bayesian_hgt_calibration_curve.csv",
            "true_bayesian_hgt_expected_calibration_error.csv",
            "true_bayesian_hgt_uncertainty.csv",
            "true_bayesian_hgt_ablation_summary.csv",
            "true_bayesian_hgt_interpretability_feature_relevance.csv",
        ],
    }
    (OUT / "true_bayesian_hgt_training_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    (OUT / "README_true_bayesian_hgt_results.txt").write_text(
        "\n".join(
            [
                "True Bayesian HGT result files.",
                "Model: MC-dropout Bayesian heterogeneous graph transformer implemented in PyTorch.",
                "Task: remodeled vs homeostatic/transitional microglia.",
                "Validation: donor-held-out SEA-AD cross-validation.",
                f"Output directory: {OUT}",
            ]
        ),
        encoding="utf-8",
    )
    print(f"Wrote true Bayesian HGT results to: {OUT}")


if __name__ == "__main__":
    main()
