from __future__ import annotations

import copy
import re
import shutil
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

BASE = Path(r"F:\AD\Mam San\results\Sand_regulatory_program_manuscript_package_final_v2\Final")
SI_IN = BASE / "SUPPLEMENTARY_INFORMATION_SUBMISSION_READY_FINAL_REPRODUCIBLE_TF_ZNF335_consistency_fixed.docx"
SI_OUT = BASE / "SUPPLEMENTARY_INFORMATION_PROGRESS_IN_NEUROBIOLOGY_FORMATTED_TF_ZNF335_consistency_fixed.docx"
DL_OUT = Path(r"C:\Users\Administrator\Downloads") / SI_OUT.name

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
NS = {"w": W}
ET.register_namespace("w", W)


def qn(tag: str) -> str:
    return f"{{{W}}}{tag}"


def para_text(p: ET.Element) -> str:
    return "".join(t.text or "" for t in p.findall(".//w:t", NS))


def set_para_text(p: ET.Element, text: str) -> None:
    runs = p.findall("w:r", NS)
    r = runs[0] if runs else ET.SubElement(p, qn("r"))
    for child in list(r):
        r.remove(child)
    t = ET.SubElement(r, qn("t"))
    t.text = text
    for extra in runs[1:]:
        p.remove(extra)


REFS = [
    "Butovsky, O., Jedrychowski, M.P., Moore, C.S., et al., 2014. Identification of a unique TGF-beta-dependent molecular and functional signature in microglia. Nat. Neurosci. 17, 131-143. https://doi.org/10.1038/nn.3599.",
    "Deczkowska, A., Keren-Shaul, H., Weiner, A., Colonna, M., Schwartz, M., Amit, I., 2018. Disease-associated microglia: a universal immune sensor of neurodegeneration. Cell 173, 1073-1081. https://doi.org/10.1016/j.cell.2018.05.003.",
    "Gabitto, M.I., Travaglini, K.J., Rachleff, V.M., et al., 2024. Integrated multimodal cell atlas of Alzheimer's disease. Nat. Neurosci. 27, 2366-2383.",
    "Gal, Y., Meir, A., Bell, M., et al., 2016. The role of trithorax and REST in the control of neural development by ZNF335. Nat. Neurosci. 19, 1436-1445. https://doi.org/10.1038/nn.4388.",
    "Gerrits, E., Brouwer, N., Kooistra, S.M., et al., 2021. Distinct amyloid-beta and tau-associated microglia profiles in Alzheimer's disease. Acta Neuropathol. 141, 681-696.",
    "Hu, Z., Dong, Y., Wang, K., Sun, Y., 2020. Heterogeneous graph transformer. Proceedings of The Web Conference 2020, 2704-2710. https://doi.org/10.1145/3366423.3380027.",
    "Keren-Shaul, H., Spinrad, A., Weiner, A., et al., 2017. A unique microglia type associated with restricting development of Alzheimer's disease. Cell 169, 1276-1290.e17. https://doi.org/10.1016/j.cell.2017.05.018.",
    "Krasemann, S., Madore, C., Cialic, R., et al., 2017. The TREM2-APOE pathway drives the transcriptional phenotype of dysfunctional microglia in neurodegenerative diseases. Immunity 47, 566-581.e9. https://doi.org/10.1016/j.immuni.2017.08.008.",
    "Mathys, H., Davila-Velderrain, J., Peng, Z., et al., 2019. Single-cell transcriptomic analysis of Alzheimer's disease. Nature 570, 332-337. https://doi.org/10.1038/s41586-019-1195-2.",
    "Mathys, H., Peng, Z., Boix, C.A., et al., 2024. Single-cell multiregion dissection of Alzheimer's disease. Nature 632, 858-868.",
    "Nugent, A.A., Lin, K., van Lengerich, B., et al., 2020. TREM2 regulates microglial cholesterol metabolism upon chronic phagocytic challenge. Neuron 105, 837-854.e9. https://doi.org/10.1016/j.neuron.2019.12.007.",
    "Olah, M., Menon, V., Habib, N., et al., 2020. Single cell RNA sequencing of human microglia uncovers a subset associated with Alzheimer's disease. Nat. Commun. 11, 6129.",
    "Olah, M., Patrick, E., Villani, A.C., et al., 2018. A transcriptomic atlas of aged human microglia. Nat. Commun. 9, 539. https://doi.org/10.1038/s41467-018-02926-5.",
    "Sardiello, M., Palmieri, M., di Ronza, A., et al., 2009. A gene network regulating lysosomal biogenesis and function. Science 325, 473-477. https://doi.org/10.1126/science.1174447.",
    "Wolf, F.A., Angerer, P., Theis, F.J., 2018. SCANPY: large-scale single-cell gene expression data analysis. Genome Biol. 19, 15. https://doi.org/10.1186/s13059-017-1382-0.",
    "Yang, Y.J., Baltus, A.E., Mathew, R.S., et al., 2012. Microcephaly gene links trithorax and REST/NRSF to control neural stem cell proliferation and differentiation. Cell 151, 1097-1112. https://doi.org/10.1016/j.cell.2012.10.043.",
]

with zipfile.ZipFile(SI_IN, "r") as z:
    files = {name: z.read(name) for name in z.namelist()}
root = ET.fromstring(files["word/document.xml"])
body = root.find("w:body", NS)
if body is None:
    raise RuntimeError("No body")

children = list(body)
ref_idx = None
for i, child in enumerate(children):
    if child.tag == qn("p") and para_text(child).strip() == "Supplementary References":
        ref_idx = i
        break
if ref_idx is None:
    raise RuntimeError("No Supplementary References heading")
for child in children[ref_idx + 1 :]:
    if child.tag == qn("p") and re.match(r"^\d+\.\s", para_text(child).strip()):
        body.remove(child)
anchor = list(body)[ref_idx]
for ref in reversed(REFS):
    p = copy.deepcopy(anchor)
    set_para_text(p, ref)
    body.insert(ref_idx + 1, p)

files["word/document.xml"] = ET.tostring(root, encoding="utf-8", xml_declaration=True)
if SI_OUT.exists():
    SI_OUT.unlink()
with zipfile.ZipFile(SI_OUT, "w", zipfile.ZIP_DEFLATED) as z:
    for name, data in files.items():
        z.writestr(name, data)
shutil.copy2(SI_OUT, DL_OUT)

paras = [para_text(p) for p in root.findall(".//w:p", NS)]
print("Wrote:", SI_OUT)
print("Copied:", DL_OUT)
print("numeric refs:", sum(1 for x in paras if re.match(r"^\d+\.\s", x)))
print("table6 seaad units:", sum("1095 cells; exploratory cell-level" in x for x in paras))
print("fig13:", sum("Supplementary Figure 13" in x for x in paras), "fig14:", sum("Supplementary Figure 14" in x for x in paras))
