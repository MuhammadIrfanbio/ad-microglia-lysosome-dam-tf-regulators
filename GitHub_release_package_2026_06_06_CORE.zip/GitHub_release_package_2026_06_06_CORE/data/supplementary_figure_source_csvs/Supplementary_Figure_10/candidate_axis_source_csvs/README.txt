Figure 5 candidate BACE1-ZNF335/Zfp335 axis source-data CSVs.
Output directory: F:\AD\Mam San\results\publication_figures\figure5_candidate_axis_source_data
Panel A: candidate-gene expression projected on UMAP for SEA-AD and GSE140510.
Panel B: candidate-gene detection rates across SEA-AD, Olah, GSE98969, and GSE140510.
Panel C: single-cell Pearson/Spearman correlations with DAM and lysosome scores.
Panel D: sample-level pseudobulk candidate-gene expression.
Panel E: interpretation model source elements and claims.