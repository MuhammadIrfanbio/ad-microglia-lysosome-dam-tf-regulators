from __future__ import annotations

import re
import shutil
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET


BASE = Path(r"F:\AD\Mam San\results\Sand_regulatory_program_manuscript_package_final_v2\Final")
DOCX = BASE / "MANUSCRIPT_PROGRESS_IN_NEUROBIOLOGY_FORMATTED_TF_ZNF335_consistency_fixed.docx"
OUTDIR = BASE / "EndNote_reference_library"
DL_OUTDIR = Path(r"C:\Users\Administrator\Downloads\EndNote_reference_library")

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
NS = {"w": W}


def para_text(p: ET.Element) -> str:
    return "".join(t.text or "" for t in p.findall(".//w:t", NS))


def extract_references(docx: Path) -> list[str]:
    with zipfile.ZipFile(docx) as z:
        root = ET.fromstring(z.read("word/document.xml"))
    paras = [para_text(p).strip() for p in root.findall(".//w:p", NS)]
    refs: list[str] = []
    in_refs = False
    for text in paras:
        if text == "References":
            in_refs = True
            continue
        if in_refs and text == "Figure legends":
            break
        if in_refs and text:
            refs.append(text)
    return refs


def split_authors(authors: str) -> list[str]:
    authors = authors.replace(" and ", ", ")
    parts = [a.strip() for a in authors.split(",")]
    result: list[str] = []
    i = 0
    while i < len(parts):
        if i + 1 < len(parts) and re.match(r"^[A-Z](?:\.[A-Z])*\.?$", parts[i + 1].replace(" ", "")):
            result.append(f"{parts[i]}, {parts[i + 1]}")
            i += 2
        else:
            if parts[i] and parts[i].lower() != "et al.":
                result.append(parts[i])
            i += 1
    return [a for a in result if a]


def parse_reference(ref: str) -> dict[str, str | list[str]]:
    doi = ""
    doi_match = re.search(r"https?://doi\.org/([^\s.]+(?:\.[^\s.]+)*)\.?$", ref)
    if doi_match:
        doi = doi_match.group(1).rstrip(".")
        ref_wo_doi = re.sub(r"\s*https?://doi\.org/[^\s]+\.?$", "", ref).strip()
    else:
        ref_wo_doi = ref

    m = re.match(r"^(.*?),\s*(\d{4})\.\s+(.*?)\.\s+(.+)$", ref_wo_doi)
    if not m:
        return {
            "type": "GEN",
            "authors": [],
            "year": "",
            "title": ref,
            "journal": "",
            "volume": "",
            "pages": "",
            "doi": doi,
            "raw": ref,
        }
    authors_raw, year, title, rest = m.groups()
    authors = split_authors(authors_raw)

    journal = rest
    volume = ""
    pages = ""
    # Common form: Journal 17, 131-143
    jm = re.match(r"^(.*?)(?:\s+(\d+[A-Za-z]?))?,\s*([A-Za-z0-9.\-–e]+(?:-[A-Za-z0-9.\-–e]+)?)\.?$", rest)
    if jm:
        journal = jm.group(1).strip()
        volume = (jm.group(2) or "").strip()
        pages = (jm.group(3) or "").strip()
    return {
        "type": "CONF" if "Conference" in journal or "Proceedings" in journal else "JOUR",
        "authors": authors,
        "year": year,
        "title": title.strip(),
        "journal": journal.strip(),
        "volume": volume,
        "pages": pages,
        "doi": doi,
        "raw": ref,
    }


def write_enw(records: list[dict], path: Path) -> None:
    lines: list[str] = []
    for rec in records:
        lines.append("%0 Journal Article" if rec["type"] == "JOUR" else "%0 Conference Paper")
        for author in rec["authors"]:
            lines.append(f"%A {author}")
        lines.append(f"%D {rec['year']}")
        lines.append(f"%T {rec['title']}")
        if rec["journal"]:
            lines.append(f"%J {rec['journal']}")
        if rec["volume"]:
            lines.append(f"%V {rec['volume']}")
        if rec["pages"]:
            lines.append(f"%P {rec['pages']}")
        if rec["doi"]:
            lines.append(f"%R {rec['doi']}")
            lines.append(f"%U https://doi.org/{rec['doi']}")
        lines.append("")
    path.write_text("\n".join(lines), encoding="utf-8")


def write_ris(records: list[dict], path: Path) -> None:
    lines: list[str] = []
    for rec in records:
        lines.append(f"TY  - {'CONF' if rec['type'] == 'CONF' else 'JOUR'}")
        for author in rec["authors"]:
            lines.append(f"AU  - {author}")
        lines.append(f"PY  - {rec['year']}")
        lines.append(f"TI  - {rec['title']}")
        if rec["journal"]:
            lines.append(f"JO  - {rec['journal']}")
            lines.append(f"T2  - {rec['journal']}")
        if rec["volume"]:
            lines.append(f"VL  - {rec['volume']}")
        if rec["pages"]:
            lines.append(f"SP  - {rec['pages']}")
        if rec["doi"]:
            lines.append(f"DO  - {rec['doi']}")
            lines.append(f"UR  - https://doi.org/{rec['doi']}")
        lines.append(f"N1  - Source reference: {rec['raw']}")
        lines.append("ER  - ")
        lines.append("")
    path.write_text("\n".join(lines), encoding="utf-8")


def bib_key(rec: dict, idx: int) -> str:
    authors = rec.get("authors") or []
    first = "ref"
    if authors:
        first = re.sub(r"[^A-Za-z0-9]", "", str(authors[0]).split(",")[0])
    return f"{first}{rec.get('year','')}_{idx:02d}"


def write_bib(records: list[dict], path: Path) -> None:
    entries: list[str] = []
    for idx, rec in enumerate(records, 1):
        typ = "inproceedings" if rec["type"] == "CONF" else "article"
        authors = " and ".join(rec["authors"])
        fields = [
            f"  author = {{{authors}}}",
            f"  title = {{{rec['title']}}}",
            f"  year = {{{rec['year']}}}",
        ]
        if rec["journal"]:
            fields.append(f"  journal = {{{rec['journal']}}}")
        if rec["volume"]:
            fields.append(f"  volume = {{{rec['volume']}}}")
        if rec["pages"]:
            fields.append(f"  pages = {{{rec['pages']}}}")
        if rec["doi"]:
            fields.append(f"  doi = {{{rec['doi']}}}")
        entries.append(f"@{typ}{{{bib_key(rec, idx)},\n" + ",\n".join(fields) + "\n}")
    path.write_text("\n\n".join(entries), encoding="utf-8")


def write_readme(path: Path, n: int) -> None:
    text = f"""EndNote reference import package

Source manuscript:
{DOCX}

Records exported: {n}

Files:
- progress_neurobiology_references.enw : EndNote tagged import format.
- progress_neurobiology_references.ris : RIS format, also importable by EndNote, Zotero, Mendeley, and most reference managers.
- progress_neurobiology_references.bib : BibTeX backup.
- progress_neurobiology_references.txt : plain-text reference list from the manuscript.

EndNote import:
1. Open EndNote.
2. File > Import > File.
3. Choose progress_neurobiology_references.enw.
4. Import Option: EndNote Import.
5. If ENW import is unavailable, import the RIS file using Reference Manager (RIS).

Note:
EndNote's native .enl library is proprietary and normally must be created by EndNote itself. These files are the correct importable source files for generating that library.
"""
    path.write_text(text, encoding="utf-8")


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    refs = extract_references(DOCX)
    records = [parse_reference(r) for r in refs]

    (OUTDIR / "progress_neurobiology_references.txt").write_text("\n\n".join(refs), encoding="utf-8")
    write_enw(records, OUTDIR / "progress_neurobiology_references.enw")
    write_ris(records, OUTDIR / "progress_neurobiology_references.ris")
    write_bib(records, OUTDIR / "progress_neurobiology_references.bib")
    write_readme(OUTDIR / "README_EndNote_import.txt", len(records))

    if DL_OUTDIR.exists():
        shutil.rmtree(DL_OUTDIR)
    shutil.copytree(OUTDIR, DL_OUTDIR)

    print(f"Extracted references: {len(refs)}")
    print(f"Wrote: {OUTDIR}")
    print(f"Copied: {DL_OUTDIR}")
    for p in sorted(OUTDIR.iterdir()):
        print(p.name, p.stat().st_size)


if __name__ == "__main__":
    main()
