from pathlib import Path
import re

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.text.paragraph import Paragraph
from docx.shared import Inches
from PIL import Image


SOURCE_DOCX = Path(r"D:\PhD\Papers\Research papers\ZFP335\MANUSCRIPT_SUBMISSION_READY_NATURE_LEVEL.docx")
FIGURE_DIR = Path(r"D:\PhD\Papers\Research papers\ZFP335")
OUT_DIR = Path(r"F:\AD\Mam San\zfp335_manuscript_with_figures")
OUT_DOCX = OUT_DIR / "MANUSCRIPT_SUBMISSION_READY_NATURE_LEVEL_with_figures.docx"
ASSET_DIR = OUT_DIR / "optimized_figures"


def paragraph_after(paragraph: Paragraph) -> Paragraph:
    new_p = OxmlElement("w:p")
    paragraph._p.addnext(new_p)
    return Paragraph(new_p, paragraph._parent)


def prepare_image(src: Path, dest: Path, width_in: float, max_height_in: float, dpi: int = 300) -> None:
    Image.MAX_IMAGE_PIXELS = None
    with Image.open(src) as im:
        im = im.convert("RGB")
        max_w_px = int(width_in * dpi)
        max_h_px = int(max_height_in * dpi)
        im.thumbnail((max_w_px, max_h_px), Image.Resampling.LANCZOS)
        im.save(dest, "JPEG", quality=92, optimize=True, progressive=True)


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    ASSET_DIR.mkdir(parents=True, exist_ok=True)

    doc = Document(SOURCE_DOCX)
    section = doc.sections[0]
    usable_width_in = (
        section.page_width - section.left_margin - section.right_margin
    ) / 914400
    max_figure_height_in = 7.9

    captions = {}
    for paragraph in doc.paragraphs:
        match = re.match(r"^\s*Figure\s+(\d+)\.", paragraph.text)
        if match:
            captions[int(match.group(1))] = paragraph

    figure_paths = {}
    for fig_num in range(1, 8):
        path = FIGURE_DIR / f"Figure-{fig_num}.jpg"
        if path.exists():
            figure_paths[fig_num] = path

    missing_captions = sorted(set(figure_paths) - set(captions))
    missing_images = sorted(set(captions) - set(figure_paths))
    if missing_captions or missing_images:
        raise RuntimeError(
            f"Caption/image mismatch. Missing captions: {missing_captions}; "
            f"missing images: {missing_images}"
        )

    for fig_num in sorted(figure_paths, reverse=True):
        src = figure_paths[fig_num]
        optimized = ASSET_DIR / src.name

        with Image.open(src) as probe:
            aspect = probe.height / probe.width
        display_width_in = min(usable_width_in, max_figure_height_in / aspect)
        prepare_image(src, optimized, display_width_in, max_figure_height_in)

        caption = captions[fig_num]
        caption.paragraph_format.keep_with_next = True

        image_para = paragraph_after(caption)
        image_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        image_para.paragraph_format.keep_together = True
        image_para.paragraph_format.space_after = Inches(0.05)
        image_para.add_run().add_picture(str(optimized), width=Inches(display_width_in))

        if fig_num != max(figure_paths):
            break_para = paragraph_after(image_para)
            break_para.add_run().add_break(WD_BREAK.PAGE)

    doc.save(OUT_DOCX)
    print(OUT_DOCX)


if __name__ == "__main__":
    main()
