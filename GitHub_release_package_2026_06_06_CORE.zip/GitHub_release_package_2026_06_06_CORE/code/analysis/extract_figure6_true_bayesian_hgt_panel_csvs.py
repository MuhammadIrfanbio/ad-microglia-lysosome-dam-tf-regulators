#!/usr/bin/env python3
"""
Extract exact panel CSVs for Figure 6 from true Bayesian HGT outputs.

This script uses the completed true Bayesian HGT run in:
  results/bayesian_hgt_true_results/

and, when available, the second-stage external validation run in:
  results/bayesian_hgt_true_external_validation/

and writes panel-ready source CSVs for the Figure 6 diagram:
  results/publication_figures/figure6_true_bayesian_hgt_source_data/

Panel mapping:
  A. Architecture and data integration
  B. Donor-held-out SEA-AD performance
  C. External validation across datasets
  D. Calibration and uncertainty
  E. Ablation study
  F. Interpretability and program activity

Important:
  The original true Bayesian HGT run generated donor-held-out SEA-AD outputs,
  calibration, uncertainty, ablation, and interpretability. Panel C is populated
  only when true second-stage external-validation outputs are available.
"""

from __future__ import annotations

import gzip
import io
import json
import os
import re
import sys
from pathlib import Path
from typing import Iterable

if sys.platform.startswith("win"):
    os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
    py_root = Path(sys.executable).resolve().parent
    for dll_dir in [
        py_root / "Library" / "bin",
        py_root / "DLLs",
    ]:
        if dll_dir.exists():
            os.environ["PATH"] = str(dll_dir) + os.pathsep + os.environ.get("PATH", "")
            try:
                os.add_dll_directory(str(dll_dir))
            except (AttributeError, OSError):
                pass

import numpy as np
import pandas as pd
from scipy import sparse

try:
    import anndata as ad
except ImportError as exc:  # pragma: no cover
    raise SystemExit("This script needs anndata/h5py. Use C:\\ProgramData\\miniforge3\\python.exe.") from exc


ROOT = Path(__file__).resolve().parent
TRUE = ROOT / "results" / "bayesian_hgt_true_results"
EXTERNAL_TRUE = ROOT / "results" / "bayesian_hgt_true_external_validation"
OUT = ROOT / "results" / "publication_figures" / "figure6_true_bayesian_hgt_source_data"
OUT.mkdir(parents=True, exist_ok=True)

H5ADS = {
    "seaad": ROOT / "results" / "seaad_microglia_fixed" / "objects" / "seaad_microglia_fixed_microglia_final.h5ad",
    "olah": ROOT / "results" / "olah_microglia_fixed" / "objects" / "olah_microglia_fixed_microglia_final.h5ad",
    "gse98969": ROOT / "results" / "gse98969_microglia_fixed" / "objects" / "gse98969_microglia_fixed_microglia_final.h5ad",
    "gse140510": ROOT / "results" / "gse140510_mouse_microglia_fixed" / "objects" / "gse140510_mouse_microglia_fixed_microglia_final.h5ad",
}
GSE98969_DESIGN = ROOT / "gse98969_work_fixed" / "downloads" / "GSE98969_experimental_design_f.txt.gz"

DATASET_LABEL = {
    "seaad": "SEA-AD (human)",
    "olah": "Olah (human)",
    "gse98969": "GSE98969 (mouse)",
    "gse140510": "GSE140510 (mouse)",
}
SPECIES = {"seaad": "human", "olah": "human", "gse98969": "mouse", "gse140510": "mouse"}
SAMPLE_COL = {
    "seaad": "external_donor_name_label",
    "olah": "donor_id",
    "gse98969": "sample_id",
    "gse140510": "sample_id",
}

STATE_POSITIVE = ["lysosome_high", "dam_like", "interferon_like", "proliferative_like"]
STATE_NEGATIVE = ["homeostatic_like", "transitional_like"]

PROGRAM_SCORE_COLS = [
    "homeostatic_score",
    "lysosome_score",
    "dam_phagocytic_score",
    "lipid_score",
    "interferon_score",
    "proliferative_score",
]
PROGRAM_LABEL = {
    "homeostatic_score": "Homeostatic",
    "lysosome_score": "Lysosome",
    "dam_phagocytic_score": "DAM/phagocytic",
    "lipid_score": "Lipid",
    "interferon_score": "Interferon/immune",
    "proliferative_score": "Proliferative/stress",
}
LIPID_GENES = {
    "human": ["APOE", "TREM2", "TYROBP", "LPL", "CST7", "ITGAX", "AXL", "GPNMB"],
    "mouse": ["Apoe", "Trem2", "Tyrobp", "Lpl", "Cst7", "Itgax", "Axl", "Gpnmb"],
}
GROUP_ORDER_140510 = ["WT", "5xFAD", "Trem2_KO", "Trem2_KO_5xFAD"]
GROUP_ORDER_98969 = ["WT", "5xFAD"]

MODEL_LABEL = {
    "gene_only": "Baseline (gene expression only)",
    "program_only": "Program scores only",
    "gene_program_no_context": "+ Program structure (no context)",
    "full_bayesian_hgt": "Full Bayesian HGT (with context)",
}
MODEL_ORDER = {
    "gene_only": 0,
    "program_only": 1,
    "gene_program_no_context": 2,
    "full_bayesian_hgt": 3,
}


def require_file(path: Path) -> None:
    if not path.exists():
        raise FileNotFoundError(path)


def dense(X) -> np.ndarray:
    if sparse.issparse(X):
        return X.toarray()
    return np.asarray(X)


def zscore(x: pd.Series) -> pd.Series:
    x = pd.to_numeric(x, errors="coerce").astype(float)
    sd = x.std(ddof=0)
    if not np.isfinite(sd) or sd == 0:
        return pd.Series(np.zeros(len(x)), index=x.index)
    return (x - x.mean()) / sd


def infer_gse140510_group(sample_id: str) -> str:
    s = str(sample_id).upper()
    if "TREM2_KO_5XFAD" in s:
        return "Trem2_KO_5xFAD"
    if "5XFAD" in s:
        return "5xFAD"
    if "TREM2_KO" in s:
        return "Trem2_KO"
    if re.search(r"(^|_)WT(_|$)", s):
        return "WT"
    return "Unknown"


def read_gse98969_design() -> pd.DataFrame:
    require_file(GSE98969_DESIGN)
    lines = []
    found_header = False
    with gzip.open(GSE98969_DESIGN, "rt", encoding="utf-8", errors="replace") as handle:
        for line in handle:
            if line.startswith("Well_ID\tSeq_batch_ID"):
                found_header = True
            if found_header:
                lines.append(line)
    design = pd.read_csv(io.StringIO("".join(lines)), sep="\t")
    design = design.rename(columns={"Well_ID": "cell_barcode", "Amp_batch_ID": "amp_batch_id"})
    design["design_group"] = design["Mouse_ID"].astype(str).map(
        {
            "C57BL/6": "WT",
            "5XFAD": "5xFAD",
            "Trem2KO": "Trem2_KO",
            "Trem2KO_5XFAD": "Trem2_KO_5xFAD",
        }
    ).fillna("Other")
    return design[["cell_barcode", "amp_batch_id", "Mouse_ID", "design_group", "Batch_desc"]].drop_duplicates("cell_barcode")


def add_lipid_score(adata: ad.AnnData, obs: pd.DataFrame, dataset: str) -> pd.Series:
    genes = [g for g in LIPID_GENES[SPECIES[dataset]] if g in adata.var_names]
    if not genes:
        return pd.Series(np.nan, index=obs.index)
    expr = pd.DataFrame(dense(adata[obs.index, genes].X), index=obs.index, columns=genes)
    return expr.apply(zscore, axis=0).mean(axis=1)


def load_obs(dataset: str) -> pd.DataFrame:
    require_file(H5ADS[dataset])
    adata = ad.read_h5ad(H5ADS[dataset])
    obs = adata.obs.copy()
    obs["cell_id"] = adata.obs_names.astype(str)
    obs["sample_id_for_analysis"] = obs[SAMPLE_COL[dataset]].astype(str)
    if dataset == "seaad":
        obs["disease_context"] = "SEA-AD"
    elif dataset == "olah":
        obs["disease_context"] = obs["disease"].astype(str).map(
            {"Alzheimer disease": "AD-like", "temporal lobe epilepsy": "control-like"}
        ).fillna(obs["disease"].astype(str))
    elif dataset == "gse98969":
        design = read_gse98969_design()
        obs = obs.merge(design, on="cell_barcode", how="left", suffixes=("", "_design"))
        obs.index = adata.obs_names
        obs["disease_context"] = obs["design_group"].fillna("Unknown")
        obs = obs[obs["disease_context"].isin(GROUP_ORDER_98969)].copy()
    elif dataset == "gse140510":
        obs["disease_context"] = obs["sample_id_for_analysis"].map(infer_gse140510_group)
    obs["remodeled_target"] = obs["state_hint"].isin(STATE_POSITIVE).astype(int)
    obs["lipid_score"] = add_lipid_score(adata, obs, dataset)
    return obs


def model_labelize(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["model_label"] = out["model_key"].map(MODEL_LABEL).fillna(out["model_key"])
    out["model_order"] = out["model_key"].map(MODEL_ORDER).fillna(99).astype(int)
    return out


def write_panel_a(manifest: dict) -> None:
    nodes = pd.read_csv(TRUE / "true_bayesian_hgt_architecture_nodes.csv")
    edges = pd.read_csv(TRUE / "true_bayesian_hgt_architecture_edges.csv")
    nodes.to_csv(OUT / "panelA_true_bayesian_hgt_architecture_nodes.csv", index=False)
    edges.to_csv(OUT / "panelA_true_bayesian_hgt_architecture_edges.csv", index=False)
    rows = []
    for dataset in ["seaad", "olah", "gse98969", "gse140510"]:
        obs = load_obs(dataset)
        rows.append(
            {
                "dataset": dataset,
                "cohort_label": DATASET_LABEL[dataset],
                "species": SPECIES[dataset],
                "n_microglia": int(len(obs)),
                "n_samples": int(obs["sample_id_for_analysis"].nunique()),
                "n_remodeled": int(obs["remodeled_target"].sum()),
                "pct_remodeled": float(obs["remodeled_target"].mean() * 100),
                "used_for_true_hgt_training": dataset == "seaad",
            }
        )
    pd.DataFrame(rows).to_csv(OUT / "panelA_true_bayesian_hgt_dataset_sources_summary.csv", index=False)
    pd.DataFrame(
        [
            {
                "parameter": k,
                "value": json.dumps(v) if isinstance(v, (list, dict)) else v,
            }
            for k, v in manifest.get("parameters", {}).items()
        ]
    ).to_csv(OUT / "panelA_true_bayesian_hgt_training_parameters.csv", index=False)


def write_panel_b() -> None:
    perf = pd.read_csv(TRUE / "true_bayesian_hgt_donor_heldout_performance.csv")
    perf = model_labelize(perf)
    perf.to_csv(OUT / "panelB_true_hgt_donor_heldout_performance_long.csv", index=False)
    summary = (
        perf.groupby(["model_key", "model_label", "model_order", "metric"], observed=True)["value"]
        .agg(mean="mean", median="median", sd="std", n_folds="count")
        .reset_index()
        .sort_values(["metric", "model_order"])
    )
    summary.to_csv(OUT / "panelB_true_hgt_donor_heldout_performance_summary.csv", index=False)
    pivot = summary.pivot_table(index=["model_key", "model_label", "model_order"], columns="metric", values="mean").reset_index()
    pivot.sort_values("model_order").to_csv(OUT / "panelB_true_hgt_donor_heldout_performance_mean_matrix.csv", index=False)


def write_panel_c() -> None:
    possible = [
        EXTERNAL_TRUE / "true_bayesian_hgt_external_validation_panelC_metrics.csv",
        EXTERNAL_TRUE / "true_bayesian_hgt_external_validation_metrics_long.csv",
        TRUE / "true_bayesian_hgt_external_validation_metrics.csv",
        TRUE / "true_bayesian_hgt_external_validation.csv",
        TRUE / "true_bayesian_hgt_external_validation_train_seaad.csv",
    ]
    existing = [p for p in possible if p.exists()]
    if existing:
        ext = pd.read_csv(existing[0])
        ext = model_labelize(ext) if "model_key" in ext.columns else ext
        ext.to_csv(OUT / "panelC_true_hgt_external_validation_metrics_long.csv", index=False)
        status = {
            "panel": "C",
            "status": "true_external_validation_found",
            "source_file": str(existing[0]),
            "n_rows": int(len(ext)),
        }
    else:
        pd.DataFrame(
            columns=["train_dataset", "test_dataset", "test_cohort_label", "model_key", "model_label", "metric", "value", "n_test"]
        ).to_csv(OUT / "panelC_true_hgt_external_validation_metrics_long.csv", index=False)
        status = {
            "panel": "C",
            "status": "missing_true_external_validation",
            "source_file": "",
            "n_rows": 0,
            "message": (
                "No true Bayesian HGT external-validation metrics were found in results/bayesian_hgt_true_external_validation "
                "or results/bayesian_hgt_true_results. The completed base run contains donor-held-out SEA-AD validation only."
            ),
        }
    pd.DataFrame([status]).to_csv(OUT / "panelC_missing_true_external_validation_status.csv", index=False)


def write_panel_d() -> None:
    rel = pd.read_csv(TRUE / "true_bayesian_hgt_calibration_curve.csv")
    ece = pd.read_csv(TRUE / "true_bayesian_hgt_expected_calibration_error.csv")
    unc = pd.read_csv(TRUE / "true_bayesian_hgt_uncertainty.csv")
    rel = model_labelize(rel)
    ece = model_labelize(ece)
    unc = model_labelize(unc)
    rel.to_csv(OUT / "panelD_true_hgt_reliability_curve.csv", index=False)
    ece.to_csv(OUT / "panelD_true_hgt_expected_calibration_error.csv", index=False)
    unc.to_csv(OUT / "panelD_true_hgt_predictive_uncertainty_long.csv", index=False)
    unc_summary = (
        unc.groupby(["model_key", "model_label", "model_order", "correct_prediction"], observed=True)[
            "credible_interval_width_95"
        ]
        .agg(mean="mean", median="median", sd="std", n_cells="count")
        .reset_index()
    )
    unc_summary.to_csv(OUT / "panelD_true_hgt_predictive_uncertainty_summary.csv", index=False)


def write_panel_e() -> None:
    metrics = pd.read_csv(TRUE / "true_bayesian_hgt_ablation_metrics_long.csv")
    summary = pd.read_csv(TRUE / "true_bayesian_hgt_ablation_summary.csv")
    metrics = model_labelize(metrics)
    summary = model_labelize(summary)
    metrics.to_csv(OUT / "panelE_true_hgt_ablation_metrics_long.csv", index=False)
    summary.to_csv(OUT / "panelE_true_hgt_ablation_summary.csv", index=False)
    table = summary.pivot_table(index=["model_key", "model_label", "model_order"], columns="metric", values="mean").reset_index()
    table = table.sort_values("model_order")
    table.to_csv(OUT / "panelE_true_hgt_ablation_mean_metric_table.csv", index=False)
    auroc = summary[summary["metric"] == "AUROC"].sort_values("model_order")
    auroc.to_csv(OUT / "panelE_true_hgt_ablation_auroc_for_barplot.csv", index=False)


def write_panel_f() -> None:
    relevance = pd.read_csv(TRUE / "true_bayesian_hgt_interpretability_feature_relevance.csv")
    relevance_summary = (
        relevance.groupby(["token_type", "feature"], observed=True)["mean_abs_probability_delta_when_zeroed"]
        .agg(mean_relevance="mean", median_relevance="median", sd_relevance="std", n_folds="count")
        .reset_index()
        .sort_values(["token_type", "mean_relevance"], ascending=[True, False])
    )
    relevance.to_csv(OUT / "panelF_true_hgt_feature_relevance_by_fold.csv", index=False)
    relevance_summary.to_csv(OUT / "panelF_true_hgt_feature_relevance_summary.csv", index=False)

    activity_rows = []
    for dataset in ["seaad", "olah", "gse98969", "gse140510"]:
        obs = load_obs(dataset)
        contexts = sorted(obs["disease_context"].dropna().unique())
        preferred = {
            "seaad": ["SEA-AD"],
            "olah": ["control-like", "AD-like"],
            "gse98969": GROUP_ORDER_98969,
            "gse140510": GROUP_ORDER_140510,
        }[dataset]
        contexts = [c for c in preferred if c in set(contexts)] + [c for c in contexts if c not in preferred]
        for context_order, context in enumerate(contexts):
            sub = obs[obs["disease_context"] == context]
            for program_order, program in enumerate(PROGRAM_SCORE_COLS):
                if program not in sub.columns:
                    continue
                activity_rows.append(
                    {
                        "dataset": dataset,
                        "cohort_label": DATASET_LABEL[dataset],
                        "dataset_order": ["seaad", "olah", "gse98969", "gse140510"].index(dataset),
                        "context": context,
                        "context_order": context_order,
                        "program": program,
                        "program_label": PROGRAM_LABEL[program],
                        "program_order": program_order,
                        "mean_score": float(sub[program].mean()),
                        "median_score": float(sub[program].median()),
                        "n_cells": int(len(sub)),
                        "n_samples": int(sub["sample_id_for_analysis"].nunique()),
                    }
                )
    activity = pd.DataFrame(activity_rows)
    activity["program_activity_z_within_program"] = activity.groupby("program")["mean_score"].transform(zscore)
    activity.to_csv(OUT / "panelF_program_activity_by_dataset_context_long.csv", index=False)
    activity.pivot_table(
        index="program_label",
        columns=["dataset", "context"],
        values="program_activity_z_within_program",
        aggfunc="first",
    ).to_csv(OUT / "panelF_program_activity_z_matrix.csv")


def main() -> None:
    require_file(TRUE / "true_bayesian_hgt_training_manifest.json")
    manifest = json.loads((TRUE / "true_bayesian_hgt_training_manifest.json").read_text(encoding="utf-8"))
    write_panel_a(manifest)
    write_panel_b()
    write_panel_c()
    write_panel_d()
    write_panel_e()
    write_panel_f()
    source_status = [
        {"panel": "A", "status": "true_hgt_and_updated_data", "notes": "Architecture from true run; dataset summaries from fixed h5ad objects."},
        {"panel": "B", "status": "true_hgt", "notes": "Donor-held-out SEA-AD performance from true Bayesian HGT run."},
        {"panel": "C", "status": "true_external_if_second_stage_run", "notes": "Reads results/bayesian_hgt_true_external_validation when present; otherwise see missing-status CSV."},
        {"panel": "D", "status": "true_hgt", "notes": "Calibration and uncertainty from true Bayesian HGT predictions."},
        {"panel": "E", "status": "true_hgt", "notes": "Ablation metrics from true Bayesian HGT run."},
        {"panel": "F", "status": "true_hgt_and_updated_data", "notes": "Feature relevance from true HGT; program activity from fixed h5ad objects."},
    ]
    pd.DataFrame(source_status).to_csv(OUT / "figure6_true_hgt_panel_source_status.csv", index=False)
    manifest_out = {
        "output_dir": str(OUT),
        "true_hgt_results_dir": str(TRUE),
        "input_manifest": str(TRUE / "true_bayesian_hgt_training_manifest.json"),
        "panel_csvs": {
            "A": [
                "panelA_true_bayesian_hgt_architecture_nodes.csv",
                "panelA_true_bayesian_hgt_architecture_edges.csv",
                "panelA_true_bayesian_hgt_dataset_sources_summary.csv",
                "panelA_true_bayesian_hgt_training_parameters.csv",
            ],
            "B": [
                "panelB_true_hgt_donor_heldout_performance_long.csv",
                "panelB_true_hgt_donor_heldout_performance_summary.csv",
                "panelB_true_hgt_donor_heldout_performance_mean_matrix.csv",
            ],
            "C": [
                "panelC_true_hgt_external_validation_metrics_long.csv",
                "panelC_missing_true_external_validation_status.csv",
            ],
            "D": [
                "panelD_true_hgt_reliability_curve.csv",
                "panelD_true_hgt_expected_calibration_error.csv",
                "panelD_true_hgt_predictive_uncertainty_long.csv",
                "panelD_true_hgt_predictive_uncertainty_summary.csv",
            ],
            "E": [
                "panelE_true_hgt_ablation_metrics_long.csv",
                "panelE_true_hgt_ablation_summary.csv",
                "panelE_true_hgt_ablation_mean_metric_table.csv",
                "panelE_true_hgt_ablation_auroc_for_barplot.csv",
            ],
            "F": [
                "panelF_true_hgt_feature_relevance_by_fold.csv",
                "panelF_true_hgt_feature_relevance_summary.csv",
                "panelF_program_activity_by_dataset_context_long.csv",
                "panelF_program_activity_z_matrix.csv",
            ],
        },
    }
    (OUT / "figure6_true_bayesian_hgt_source_data_manifest.json").write_text(json.dumps(manifest_out, indent=2), encoding="utf-8")
    (OUT / "README.txt").write_text(
        "\n".join(
            [
                "Figure 6 true Bayesian HGT panel source-data CSVs.",
                f"Output directory: {OUT}",
                f"True HGT source directory: {TRUE}",
                f"True HGT external-validation source directory: {EXTERNAL_TRUE}",
                "Panel C external validation is populated when true second-stage external-validation files are present.",
                "All other model panels use the completed true Bayesian HGT result files.",
            ]
        ),
        encoding="utf-8",
    )
    print(f"Wrote Figure 6 true Bayesian HGT panel CSVs to: {OUT}")


if __name__ == "__main__":
    main()
