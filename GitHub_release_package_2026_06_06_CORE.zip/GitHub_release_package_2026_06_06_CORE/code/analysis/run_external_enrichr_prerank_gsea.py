#!/usr/bin/env python3
"""
run_external_enrichr_prerank_gsea.py

Robust external GSEA runner for this project.

Why this exists:
  Some GSEApy versions on Windows can list Enrichr libraries with
  get_library_name(), but fail when fetching/parsing them via get_library().
  This script can bypass that by downloading the Enrichr library text directly,
  parsing it into a gene_set dictionary, freezing the exact GMT file used, and
  then calling gseapy.prerank() with the dictionary.

Publication guardrails:
  - Mouse ranks use native mouse symbols by default. Human-style libraries for
    mouse require --library-species human_ortholog and an explicit --ortholog-map.
  - Every GMT used is copied into frozen_gmt/ with a checksum manifest.
  - Every pathway gets a gene-universe/overlap row before GSEA.
  - Discovery and validation runs are explicitly labeled.

Input:
  A prerank file from q1_multiomics_context_pipeline:
    results\<run>\tables\prerank_input_gsea_tie_broken.rnk
  or:
    results\<run>\tables\prerank_input.rnk

Example:
  python run_external_enrichr_prerank_gsea.py ^
    --rank-file results\q1_multiomics_gse140510_gsea_external\tables\prerank_input_gsea_tie_broken.rnk ^
    --species mouse ^
    --libraries KEGG_2019_Mouse,Mouse_Gene_Atlas ^
    --output-dir results\q1_multiomics_gse140510_external_gsea_direct
"""

import argparse
import hashlib
import json
import re
import shutil
import urllib.parse
import urllib.request
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


ENRICHR_URL = "https://maayanlab.cloud/Enrichr/geneSetLibrary"
DEFAULT_LIBRARIES = {
    "human": "GO_Biological_Process_2025,Reactome_Pathways_2024,KEGG_2021_Human",
    "mouse": "KEGG_2019_Mouse,Mouse_Gene_Atlas,MGI_Mammalian_Phenotype_Level_4_2024",
}
MOUSE_NATIVE_LIBRARY_HINTS = ["mouse", "mgi", "mammalian_phenotype", "kegg_2019_mouse"]
HUMAN_LIBRARY_HINTS = ["human", "reactome_pathways", "kegg_2021_human"]


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--rank-file", required=True)
    p.add_argument("--species", choices=["mouse", "human"], default="human")
    p.add_argument(
        "--libraries",
        default=None,
        help="Comma-separated Enrichr libraries. Defaults are species-aware. Prefer --gmt-files for frozen publication runs.",
    )
    p.add_argument(
        "--gmt-files",
        default=None,
        help="Comma-separated local GMT files. These are copied into frozen_gmt/ and used directly instead of downloading Enrichr libraries.",
    )
    p.add_argument(
        "--library-species",
        choices=["native", "human_ortholog"],
        default="native",
        help="Use native species gene symbols, or explicitly convert mouse symbols to human ortholog symbols for human libraries.",
    )
    p.add_argument(
        "--ortholog-map",
        default=None,
        help="CSV/TSV with mouse_gene,human_gene or source_gene,target_gene columns. Required for mouse --library-species human_ortholog.",
    )
    p.add_argument("--analysis-stage", choices=["discovery", "validation"], default="discovery")
    p.add_argument(
        "--validation-terms-file",
        default=None,
        help="Required for --analysis-stage validation. CSV/TXT containing terms to validate; column 'term' or first column is used.",
    )
    p.add_argument("--output-dir", required=True)
    p.add_argument("--min-size", type=int, default=5)
    p.add_argument("--max-size", type=int, default=1000)
    p.add_argument("--permutations", type=int, default=1000)
    p.add_argument("--threads", type=int, default=4)
    p.add_argument("--dpi", type=int, default=900)
    p.add_argument("--redundancy-jaccard", type=float, default=0.7)
    p.add_argument("--skip-redundancy-collapse", action="store_true")
    p.add_argument(
        "--allow-dynamic-enrichr-download",
        action="store_true",
        help="Allow downloading GMTs from Enrichr. Publication runs should instead use --gmt-files or archive frozen_gmt/.",
    )
    p.add_argument(
        "--allow-unvalidated-rank",
        action="store_true",
        help="Allow a rank file without upstream metadata-manifest validation. Exploratory only.",
    )
    return p.parse_args()


def require_validated_upstream_rank(rank_file: Path):
    tables_dir = rank_file.parent
    summary_file = tables_dir / "pseudobulk_de_model_summary.json"
    if not summary_file.exists():
        raise RuntimeError(
            "Refusing to run external GSEA: upstream DE model summary is missing next to the rank file. "
            "Rerun q1_multiomics_context_pipeline_gsea_fixed.py with the metadata manifest."
        )
    with open(summary_file, "r", encoding="utf-8") as f:
        summary = json.load(f)
    validation = summary.get("metadata_manifest_validation")
    comparison_validation = validation.get("comparison_manifest_validation") if isinstance(validation, dict) else None
    if not comparison_validation and isinstance(validation, dict) and "n_manifest_comparison_samples_validated" in validation:
        comparison_validation = validation
    validation_skipped = isinstance(validation, dict) and validation.get("skipped")
    comparison_skipped = isinstance(comparison_validation, dict) and comparison_validation.get("skipped")
    if not isinstance(validation, dict) or validation_skipped or not isinstance(comparison_validation, dict) or comparison_skipped:
        raise RuntimeError(
            "Refusing to run external GSEA: the upstream rank file was not validated against the clean metadata manifest. "
            "Rerun DE with metadata_manifest_validation passing, or use --allow-unvalidated-rank for exploratory-only output."
        )
    if int(comparison_validation.get("n_manifest_comparison_samples_validated", 0)) <= 0:
        raise RuntimeError("Refusing to run external GSEA: no manifest-validated comparison samples were recorded upstream.")


def split_csv_arg(value: str):
    return [x.strip() for x in str(value).split(",") if x.strip()]


def safe_name(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", str(value)).strip("_") or "gmt"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def validate_species_library_plan(args, libraries, gmt_files):
    if args.analysis_stage == "validation" and not args.validation_terms_file:
        raise ValueError("--analysis-stage validation requires --validation-terms-file with pre-specified validation terms.")

    if args.species == "mouse" and args.library_species == "human_ortholog" and not args.ortholog_map:
        raise ValueError("Mouse-to-human GSEA requires --ortholog-map when --library-species human_ortholog is used.")

    if args.species == "mouse" and args.library_species == "native" and libraries:
        unsafe = []
        for lib in libraries:
            low = lib.lower()
            is_mouse = any(h in low for h in MOUSE_NATIVE_LIBRARY_HINTS)
            is_human = any(h in low for h in HUMAN_LIBRARY_HINTS)
            if is_human or not is_mouse:
                unsafe.append(lib)
        if unsafe:
            raise ValueError(
                "Refusing mouse/native GSEA with non-mouse or ambiguous Enrichr libraries: "
                + ", ".join(unsafe)
                + ". Use mouse libraries/GMTs, or use --library-species human_ortholog with --ortholog-map."
            )

    if args.species == "human" and args.library_species == "native" and libraries:
        mouse_libs = [lib for lib in libraries if any(h in lib.lower() for h in MOUSE_NATIVE_LIBRARY_HINTS)]
        if mouse_libs:
            raise ValueError("Refusing human/native GSEA with mouse libraries: " + ", ".join(mouse_libs))

    if libraries and not args.allow_dynamic_enrichr_download and not gmt_files:
        raise ValueError(
            "Dynamic Enrichr downloads are disabled by default for publication reproducibility. "
            "Use --gmt-files with archived GMTs, or pass --allow-dynamic-enrichr-download for an exploratory/download-and-freeze run."
        )


def load_ortholog_map(path: Path) -> dict:
    sep = "\t" if path.suffix.lower() in [".tsv", ".txt"] else ","
    df = pd.read_csv(path, sep=sep)
    lower = {c.lower(): c for c in df.columns}
    if {"mouse_gene", "human_gene"}.issubset(lower):
        src, dst = lower["mouse_gene"], lower["human_gene"]
    elif {"source_gene", "target_gene"}.issubset(lower):
        src, dst = lower["source_gene"], lower["target_gene"]
    else:
        raise ValueError("--ortholog-map must contain mouse_gene,human_gene or source_gene,target_gene columns.")
    return {
        str(a): str(b).upper()
        for a, b in zip(df[src], df[dst])
        if pd.notna(a) and pd.notna(b) and str(a).strip() and str(b).strip()
    }


def freeze_gmt(path: Path, library: str, outdir: Path, source: str) -> dict:
    frozen = outdir / "frozen_gmt"
    frozen.mkdir(parents=True, exist_ok=True)
    digest = sha256_file(path)
    dest = frozen / f"{safe_name(library)}__sha256_{digest[:16]}.gmt"
    if not dest.exists():
        shutil.copy2(path, dest)
    return {
        "library": library,
        "source": source,
        "original_path": str(path),
        "frozen_path": str(dest),
        "sha256": digest,
        "bytes": int(path.stat().st_size),
    }


def download_enrichr_library(library: str, outdir: Path) -> Path:
    outdir.mkdir(parents=True, exist_ok=True)
    out = outdir / f"{library}.gmt"
    if out.exists() and out.stat().st_size > 0:
        return out

    params = urllib.parse.urlencode({"mode": "text", "libraryName": library})
    url = f"{ENRICHR_URL}?{params}"
    with urllib.request.urlopen(url, timeout=120) as resp:
        text = resp.read().decode("utf-8", errors="replace")

    if not text.strip() or "Error" in text[:200]:
        raise RuntimeError(f"Could not download Enrichr library {library}. First chars: {text[:200]}")

    out.write_text(text, encoding="utf-8")
    return out


def parse_gmt_to_dict(path: Path, symbol_transform="native"):
    gene_sets = {}
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            parts = line.rstrip("\n").split("\t")
            if len(parts) < 3:
                continue
            term = parts[0]
            genes = [g.strip() for g in parts[2:] if g.strip()]
            if symbol_transform in ["uppercase", "human_ortholog"]:
                genes = [g.upper() for g in genes]
            genes = sorted(set(genes))
            if genes:
                gene_sets[term] = genes
    return gene_sets


def load_rank(path: Path, args, ortholog_map=None):
    df = pd.read_csv(path, sep="\t", header=None, names=["gene", "score"])
    df["gene"] = df["gene"].astype(str)
    df["score"] = pd.to_numeric(df["score"], errors="coerce")
    df = df.dropna(subset=["gene", "score"])
    n_raw = int(df.shape[0])
    if args.species == "mouse" and args.library_species == "human_ortholog":
        if ortholog_map is None:
            raise ValueError("ortholog_map is required for mouse human_ortholog mode.")
        df["input_gene"] = df["gene"]
        df["gene"] = df["gene"].map(ortholog_map)
        df = df.dropna(subset=["gene"])
        symbol_transform = "mouse_to_human_ortholog"
    elif args.species == "human":
        df["gene"] = df["gene"].str.upper()
        symbol_transform = "uppercase_human_symbols"
    else:
        symbol_transform = "native_mouse_symbols"
    # Collapse duplicates after any transformation by max absolute score, preserving sign from max abs.
    df["abs_score"] = df["score"].abs()
    df = df.sort_values("abs_score", ascending=False).drop_duplicates("gene")
    df = df[["gene", "score"]].sort_values("score", ascending=False).reset_index(drop=True)
    # Tie-break deterministic
    df["score"] = df["score"].astype(float) + np.linspace(1e-9, 0, df.shape[0])
    summary = {
        "rank_file": str(path),
        "species": args.species,
        "library_species": args.library_species,
        "symbol_transform": symbol_transform,
        "n_rank_rows_input": n_raw,
        "n_rank_genes_after_transform": int(df.shape[0]),
        "n_duplicate_genes_collapsed": int(n_raw - df.shape[0]),
    }
    return df, summary


def make_overlap_report(library: str, gene_sets: dict, rank_genes: set, min_size: int, max_size: int):
    rows = []
    filtered = {}
    for term, genes in gene_sets.items():
        unique_genes = sorted(set(genes))
        overlap = [g for g in unique_genes if g in rank_genes]
        passed = min_size <= len(overlap) <= max_size
        rows.append({
            "library": library,
            "term": term,
            "n_genes_in_gmt": len(unique_genes),
            "n_rank_gene_universe": len(rank_genes),
            "n_overlap": len(overlap),
            "overlap_fraction_of_pathway": len(overlap) / max(len(unique_genes), 1),
            "overlap_fraction_of_rank_universe": len(overlap) / max(len(rank_genes), 1),
            "passes_size_filter": bool(passed),
            "overlap_genes": ";".join(overlap),
        })
        if passed:
            filtered[term] = overlap
    return pd.DataFrame(rows), filtered


def load_validation_terms(path: Path) -> set:
    if path.suffix.lower() in [".csv", ".tsv"]:
        sep = "\t" if path.suffix.lower() == ".tsv" else ","
        df = pd.read_csv(path, sep=sep)
        col = "term" if "term" in df.columns else df.columns[0]
        vals = df[col].dropna().astype(str).tolist()
    else:
        vals = [x.strip() for x in path.read_text(encoding="utf-8").splitlines() if x.strip()]
    return {v.lower() for v in vals}


def term_column(df: pd.DataFrame) -> str:
    return "Term" if "Term" in df.columns else df.columns[0]


def fdr_column(df: pd.DataFrame):
    for c in ["FDR q-val", "FDR", "fdr", "Adjusted P-value"]:
        if c in df.columns:
            return c
    return None


def collapse_redundant_terms(combined: pd.DataFrame, term_genes: dict, threshold: float):
    if combined.empty:
        return combined, pd.DataFrame()
    tcol = term_column(combined)
    fcol = fdr_column(combined)
    work = combined.copy()
    if fcol:
        work = work.sort_values([fcol, "NES"] if "NES" in work.columns else [fcol], ascending=[True, False] if "NES" in work.columns else [True])
    elif "NES" in work.columns:
        work = work.reindex(work["NES"].abs().sort_values(ascending=False).index)
    kept = []
    clusters = []
    for _, row in work.iterrows():
        lib = str(row.get("library", ""))
        term = str(row[tcol])
        genes = set(term_genes.get((lib, term), set()))
        redundant_to = None
        redundant_j = 0.0
        for kept_idx, kept_row in enumerate(kept):
            if str(kept_row.get("library", "")) != lib:
                continue
            kept_term = str(kept_row[tcol])
            kept_genes = set(term_genes.get((lib, kept_term), set()))
            union = genes | kept_genes
            j = len(genes & kept_genes) / len(union) if union else 0.0
            if j >= threshold:
                redundant_to = kept_term
                redundant_j = j
                break
        clusters.append({
            "library": lib,
            "term": term,
            "kept_representative": redundant_to is None,
            "redundant_to": "" if redundant_to is None else redundant_to,
            "jaccard_to_representative": redundant_j,
        })
        if redundant_to is None:
            kept.append(row)
    collapsed = pd.DataFrame(kept).reset_index(drop=True) if kept else combined.iloc[0:0].copy()
    return collapsed, pd.DataFrame(clusters)


def run_one_library(gp, rank_file: Path, library: str, gene_sets: dict, outdir: Path, args):
    out = outdir / library
    out.mkdir(parents=True, exist_ok=True)
    pre = gp.prerank(
        rnk=str(rank_file),
        gene_sets=gene_sets,
        threads=args.threads,
        min_size=args.min_size,
        max_size=args.max_size,
        permutation_num=args.permutations,
        seed=0,
        outdir=str(out),
        verbose=False,
    )
    res = pre.res2d.copy()
    res["library"] = library
    return res


def plot_top(res: pd.DataFrame, library: str, outdir: Path, dpi: int):
    if res.empty:
        return
    term_col = "Term" if "Term" in res.columns else res.columns[0]
    nes_col = "NES" if "NES" in res.columns else None
    if nes_col is None:
        return
    fdr_col = "FDR q-val" if "FDR q-val" in res.columns else ("FDR" if "FDR" in res.columns else None)
    top = res.copy()
    if fdr_col:
        top = top.sort_values(fdr_col).head(20)
    else:
        top = top.reindex(top[nes_col].abs().sort_values(ascending=False).index).head(20)

    plt.figure(figsize=(9, max(5, 0.35 * len(top))))
    plt.barh(top[term_col].astype(str)[::-1], top[nes_col].astype(float)[::-1])
    plt.axvline(0, linewidth=0.8)
    plt.xlabel("Normalized enrichment score (NES)")
    plt.title(f"Top preranked GSEA terms: {library}")
    plt.tight_layout()
    plt.savefig(outdir / f"top_terms_{library}_900dpi.png", dpi=dpi, bbox_inches="tight")
    plt.close()


def main():
    args = parse_args()
    outdir = Path(args.output_dir)
    tables = outdir / "tables"
    figs = outdir / "figures"
    downloads = outdir / "downloads"
    for p in [tables, figs, downloads, outdir / "frozen_gmt"]:
        p.mkdir(parents=True, exist_ok=True)

    rank_file = Path(args.rank_file)
    if not args.allow_unvalidated_rank:
        require_validated_upstream_rank(rank_file)

    libraries = split_csv_arg(args.libraries or DEFAULT_LIBRARIES[args.species])
    gmt_files = [Path(x) for x in split_csv_arg(args.gmt_files)] if args.gmt_files else []
    validate_species_library_plan(args, libraries if not gmt_files else [], gmt_files)

    try:
        import gseapy as gp
    except Exception as e:
        raise SystemExit("Please install gseapy first: pip install gseapy") from e

    ortholog_map = load_ortholog_map(Path(args.ortholog_map)) if args.ortholog_map else None
    rank, rank_summary = load_rank(rank_file, args, ortholog_map=ortholog_map)
    rank_out = tables / f"rank_{safe_name(rank_summary['symbol_transform'])}_tiebroken.rnk"
    rank.to_csv(rank_out, sep="\t", index=False, header=False)
    pd.DataFrame([rank_summary]).to_csv(tables / "gene_universe_summary.csv", index=False)
    all_res = []
    all_overlap = []
    frozen_manifest = []
    term_genes = {}

    if gmt_files:
        library_paths = [(path.stem, path, "local_gmt") for path in gmt_files]
    else:
        library_paths = []
        for lib in libraries:
            print(f"Downloading/parsing {lib}")
            gmt = download_enrichr_library(lib, downloads)
            library_paths.append((lib, gmt, "enrichr_download"))

    symbol_transform = "uppercase" if args.library_species == "human_ortholog" or args.species == "human" else "native"

    for lib, gmt, source in library_paths:
        print(f"Parsing frozen-planned GMT: {lib}")
        try:
            freeze_row = freeze_gmt(gmt, lib, outdir, source)
            frozen_manifest.append(freeze_row)
            gs = parse_gmt_to_dict(Path(freeze_row["frozen_path"]), symbol_transform=symbol_transform)

            # Filter to overlapping sets to avoid cryptic GSEApy errors.
            rank_genes = set(rank["gene"])
            overlap_report, filtered = make_overlap_report(lib, gs, rank_genes, args.min_size, args.max_size)
            overlap_report["gmt_sha256"] = freeze_row["sha256"]
            all_overlap.append(overlap_report)
            for term, genes in filtered.items():
                term_genes[(lib, term)] = set(genes)

            pd.DataFrame({
                "library": [lib],
                "n_terms_downloaded": [len(gs)],
                "n_terms_after_overlap_filter": [len(filtered)],
                "median_overlap": [float(overlap_report.loc[overlap_report["passes_size_filter"], "n_overlap"].median()) if len(filtered) else 0.0],
                "max_overlap": [int(overlap_report["n_overlap"].max()) if not overlap_report.empty else 0],
                "gmt_sha256": [freeze_row["sha256"]],
                "analysis_stage": [args.analysis_stage],
                "library_species": [args.library_species],
            }).to_csv(tables / f"overlap_summary_{lib}.csv", index=False)

            if not filtered:
                print(f"SKIP {lib}: no overlapping gene sets after filtering")
                continue

            print(f"Running GSEA {lib} with {len(filtered)} filtered terms")
            res = run_one_library(gp, rank_out, lib, filtered, outdir / "gsea_runs", args)
            res["analysis_stage"] = args.analysis_stage
            res["library_species"] = args.library_species
            res["gmt_sha256"] = freeze_row["sha256"]
            if args.analysis_stage == "validation":
                validation_terms = load_validation_terms(Path(args.validation_terms_file))
                tcol = term_column(res)
                res = res[res[tcol].astype(str).str.lower().isin(validation_terms)].copy()
            res.to_csv(tables / f"gsea_prerank_{args.analysis_stage}_{lib}.csv", index=False)
            plot_top(res, lib, figs, args.dpi)
            all_res.append(res)

        except Exception as e:
            print(f"FAILED {lib}: {repr(e)}")
            (tables / f"ERROR_{lib}.txt").write_text(repr(e), encoding="utf-8")

    if frozen_manifest:
        pd.DataFrame(frozen_manifest).to_csv(tables / "frozen_gmt_manifest.csv", index=False)
    if all_overlap:
        pathway_overlap = pd.concat(all_overlap, ignore_index=True)
        pathway_overlap.to_csv(tables / "pathway_gene_universe_overlap.csv", index=False)

    if all_res:
        combined = pd.concat(all_res, ignore_index=True)
        combined.to_csv(tables / f"gsea_{args.analysis_stage}_all_libraries.csv", index=False)
        combined.to_csv(tables / "gsea_prerank_external_all_libraries.csv", index=False)

        if not args.skip_redundancy_collapse:
            collapsed, clusters = collapse_redundant_terms(combined, term_genes, args.redundancy_jaccard)
            collapsed.to_csv(tables / f"gsea_{args.analysis_stage}_collapsed_terms.csv", index=False)
            clusters.to_csv(tables / "gsea_redundant_term_clusters.csv", index=False)

        # Focused disease-relevant term table
        term_col = "Term" if "Term" in combined.columns else combined.columns[0]
        focus_words = [
            "lysosome", "phagocyt", "endocyt", "endosome", "autophag",
            "antigen", "complement", "immune", "inflamm", "microglia",
            "amyloid", "lipid", "apopt", "oxidative", "interferon"
        ]
        mask = combined[term_col].astype(str).str.lower().apply(lambda x: any(w in x for w in focus_words))
        focus = combined[mask].copy()
        if not focus.empty:
            fdr_col = "FDR q-val" if "FDR q-val" in focus.columns else None
            if fdr_col:
                focus = focus.sort_values(fdr_col)
            focus.to_csv(tables / f"gsea_{args.analysis_stage}_focus_terms_lysosome_dam_inflammation.csv", index=False)
            focus.to_csv(tables / "gsea_focus_terms_lysosome_dam_inflammation.csv", index=False)

    readme = outdir / "README_EXTERNAL_GSEA.txt"
    readme.write_text(
        "External preranked GSEA outputs\n"
        "===============================\n\n"
        "Main outputs:\n"
        f"- tables/gsea_{args.analysis_stage}_all_libraries.csv\n"
        f"- tables/gsea_{args.analysis_stage}_collapsed_terms.csv\n"
        "- tables/pathway_gene_universe_overlap.csv\n"
        "- tables/frozen_gmt_manifest.csv\n"
        "- tables/gene_universe_summary.csv\n"
        "- figures/top_terms_<library>_900dpi.png\n"
        "- tables/overlap_summary_<library>.csv\n\n"
        "Species/library policy:\n"
        "- Mouse/native mode preserves mouse symbols and refuses human or ambiguous Enrichr library names.\n"
        "- Mouse-to-human library use requires --library-species human_ortholog and --ortholog-map.\n"
        "- GMT files used in the run are frozen under frozen_gmt/ and recorded with SHA-256 checksums.\n"
        f"- This run analysis_stage={args.analysis_stage}; library_species={args.library_species}.\n",
        encoding="utf-8",
    )
    print(f"Done: {outdir}")


if __name__ == "__main__":
    main()
