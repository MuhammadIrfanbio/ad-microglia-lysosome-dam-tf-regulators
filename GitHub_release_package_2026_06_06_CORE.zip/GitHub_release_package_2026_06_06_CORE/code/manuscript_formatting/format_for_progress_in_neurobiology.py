from __future__ import annotations

import copy
import re
import shutil
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

BASE = Path(r"F:\AD\Mam San\results\Sand_regulatory_program_manuscript_package_final_v2\Final")
MS_IN = BASE / "MANUSCRIPT_SUBMISSION_READY_FINAL_REPRODUCIBLE_40REF_TF_ZNF335_USER_FIG7_v4.docx"
MS_OUT = BASE / "MANUSCRIPT_PROGRESS_IN_NEUROBIOLOGY_FORMATTED_TF_ZNF335.docx"
DL_OUT = Path(r"C:\Users\Administrator\Downloads") / MS_OUT.name

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
NS = {"w": W}
ET.register_namespace("w", W)


def qn(tag: str) -> str:
    return f"{{{W}}}{tag}"


def para_text(p: ET.Element) -> str:
    return "".join(t.text or "" for t in p.findall(".//w:t", NS))


def set_para_text(p: ET.Element, text: str) -> None:
    runs = p.findall("w:r", NS)
    if not runs:
        r = ET.SubElement(p, qn("r"))
    else:
        r = runs[0]
    for child in list(r):
        r.remove(child)
    t = ET.SubElement(r, qn("t"))
    t.text = text
    for extra in runs[1:]:
        p.remove(extra)


def clone_after(parent: ET.Element, after: ET.Element, text: str) -> ET.Element:
    new = copy.deepcopy(after)
    set_para_text(new, text)
    idx = list(parent).index(after)
    parent.insert(idx + 1, new)
    return new


def remove_p(parent: ET.Element, p: ET.Element) -> None:
    parent.remove(p)


def load_docx(path: Path):
    with zipfile.ZipFile(path, "r") as z:
        files = {name: z.read(name) for name in z.namelist()}
    root = ET.fromstring(files["word/document.xml"])
    body = root.find("w:body", NS)
    if body is None:
        raise RuntimeError("No document body")
    return files, root, body


def save_docx(files: dict[str, bytes], root: ET.Element, out: Path) -> None:
    files = dict(files)
    files["word/document.xml"] = ET.tostring(root, encoding="utf-8", xml_declaration=True)
    if out.exists():
        out.unlink()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for name, data in files.items():
            z.writestr(name, data)


ABSTRACT = (
    "Alzheimer's disease (AD) microglia remodel across lipid-handling, lysosomal, phagocytic, inflammatory, "
    "and stress-response programs, but single-cell regulator analyses often overinterpret sparse transcription-factor "
    "signals. We analyzed four harmonized microglial resources: SEA-AD human discovery, Olah live-isolated human "
    "microglia validation, GSE98969 mouse AD conservation, and GSE140510 Trem2-linked mouse modeling. Microglia were "
    "summarized by homeostatic-like, transitional-like, lysosome-high, DAM/phagocytic-like, interferon-like, and "
    "proliferative-like states, and by curated homeostatic, lysosome/phagosome, DAM/lipid-response, interferon, and "
    "proliferative modules. The most reproducible signal was coordinated DAM/lipid-response and lysosome/phagosome "
    "remodeling. Corrected SEA-AD sensitivity was underpowered, whereas Olah, GSE98969, and GSE140510 supported "
    "positive sample-level coupling and robustness analyses. In GSE140510, 5xFAD reduced the homeostatic-like fraction "
    "from 0.651 to 0.261 and increased lysosome-high and DAM/phagocytic-like fractions from 0.161 to 0.322 and 0.057 "
    "to 0.265; Trem2_KO_5xFAD attenuated the DAM/phagocytic-like fraction to 0.066. Bayesian heterogeneous graph "
    "transformer analysis confirmed that curated program structure carried strong predictive signal. A detection-aware "
    "TF-regulator framework recovered canonical myeloid, interferon, and lysosomal-biogenesis biology before nominating "
    "ZNF335/Zfp335 as a low-detection, model-relevant, experimentally testable candidate. The study supports conserved "
    "lysosome-DAM program architecture rather than a single-gene causal mechanism."
)

KEYWORDS = "Keywords: Alzheimer's disease; microglia; disease-associated microglia; lysosome; phagocytosis; transcription factors; ZNF335"

HIGHLIGHTS = [
    "Highlights",
    "Conserved AD microglial remodeling is centered on coupled DAM/lipid-response and lysosome/phagosome programs.",
    "Corrected SEA-AD sensitivity is underpowered, while Olah, GSE98969, and GSE140510 carry the formal robustness evidence.",
    "Trem2 deficiency attenuates the DAM/phagocytic arm more strongly than the broader lysosomal remodeling state.",
    "Detection-aware TF integration recovers canonical myeloid, interferon, and lysosomal-biogenesis biology before ZNF335 nomination.",
    "ZNF335/Zfp335 is framed as a low-detection, model-relevant candidate modulator, not a proven causal driver.",
]

AUTHOR_YEAR = {
    "[1,2]": "(Keren-Shaul et al., 2017; Krasemann et al., 2017)",
    "[1-8,10-12]": "(Butovsky et al., 2014; Keren-Shaul et al., 2017; Krasemann et al., 2017; Deczkowska et al., 2018; Olah et al., 2018, 2020; Mathys et al., 2019, 2024; Nugent et al., 2020; Gerrits et al., 2021; Gabitto et al., 2024)",
    "[1-12]": "(Butovsky et al., 2014; Keren-Shaul et al., 2017; Krasemann et al., 2017; Deczkowska et al., 2018; Olah et al., 2018, 2020; Mathys et al., 2019, 2024; Sardiello et al., 2009; Nugent et al., 2020; Gerrits et al., 2021; Gabitto et al., 2024)",
    "[15,16]": "(Gal et al., 2006; Yang et al., 2012)",
    "[13,17-40]": "(Wolf et al., 2018; Stuart et al., 2019; Luecken and Theis, 2019; Amezquita et al., 2020; Hu et al., 2020; Pedregosa et al., 2011; Paszke et al., 2019; Benjamini and Hochberg, 1995; Spearman, 1904; Subramanian et al., 2005; Liberzon et al., 2011, 2015; Gillespie et al., 2022; Kanehisa et al., 2021; Ashburner et al., 2000; The Gene Ontology Consortium, 2021; Love et al., 2014; Robinson et al., 2010; Ritchie et al., 2015; Hao et al., 2021; Grubman et al., 2019; Zhou et al., 2020)",
}

REFS = [
    "Amezquita, R.A., Lun, A.T.L., Becht, E., et al., 2020. Orchestrating single-cell analysis with Bioconductor. Nat. Methods 17, 137-145. https://doi.org/10.1038/s41592-019-0654-x.",
    "Ashburner, M., Ball, C.A., Blake, J.A., et al., 2000. Gene Ontology: tool for the unification of biology. Nat. Genet. 25, 25-29. https://doi.org/10.1038/75556.",
    "Benjamini, Y., Hochberg, Y., 1995. Controlling the false discovery rate: a practical and powerful approach to multiple testing. J. R. Stat. Soc. Series B Stat. Methodol. 57, 289-300. https://doi.org/10.1111/j.2517-6161.1995.tb02031.x.",
    "Butovsky, O., Jedrychowski, M.P., Moore, C.S., et al., 2014. Identification of a unique TGF-beta-dependent molecular and functional signature in microglia. Nat. Neurosci. 17, 131-143. https://doi.org/10.1038/nn.3599.",
    "Deczkowska, A., Keren-Shaul, H., Weiner, A., Colonna, M., Schwartz, M., Amit, I., 2018. Disease-associated microglia: a universal immune sensor of neurodegeneration. Cell 173, 1073-1081. https://doi.org/10.1016/j.cell.2018.05.003.",
    "Gabitto, M.I., Travaglini, K.J., Rachleff, V.M., et al., 2024. Integrated multimodal cell atlas of Alzheimer's disease. Nat. Neurosci. 27, 2366-2383.",
    "Gal, J.S., Morozov, Y.M., Ayoub, A.E., et al., 2006. Molecular and morphological heterogeneity of neural precursor cells in the mouse neocortical proliferative zones. Nat. Neurosci. 9, 1152-1160.",
    "Gal, Y., Ghahramani, Z., 2016. Dropout as a Bayesian approximation: representing model uncertainty in deep learning. International Conference on Machine Learning 48, 1050-1059.",
    "Gerrits, E., Brouwer, N., Kooistra, S.M., et al., 2021. Distinct amyloid-beta and tau-associated microglia profiles in Alzheimer's disease. Acta Neuropathol. 141, 681-696.",
    "Gillespie, M., Jassal, B., Stephan, R., et al., 2022. The Reactome pathway knowledgebase 2022. Nucleic Acids Res. 50, D687-D692. https://doi.org/10.1093/nar/gkab1028.",
    "Grubman, A., Chew, G., Ouyang, J.F., et al., 2019. A single-cell atlas of entorhinal cortex from individuals with Alzheimer's disease reveals cell-type-specific gene expression regulation. Nat. Neurosci. 22, 2087-2097. https://doi.org/10.1038/s41593-019-0539-4.",
    "Hao, Y., Hao, S., Andersen-Nissen, E., et al., 2021. Integrated analysis of multimodal single-cell data. Cell 184, 3573-3587.e29. https://doi.org/10.1016/j.cell.2021.04.048.",
    "Hu, Z., Dong, Y., Wang, K., Sun, Y., 2020. Heterogeneous graph transformer. Proceedings of The Web Conference 2020, 2704-2710.",
    "Kanehisa, M., Furumichi, M., Sato, Y., Ishiguro-Watanabe, M., Tanabe, M., 2021. KEGG: integrating viruses and cellular organisms. Nucleic Acids Res. 49, D545-D551. https://doi.org/10.1093/nar/gkaa970.",
    "Keren-Shaul, H., Spinrad, A., Weiner, A., et al., 2017. A unique microglia type associated with restricting development of Alzheimer's disease. Cell 169, 1276-1290.e17. https://doi.org/10.1016/j.cell.2017.05.018.",
    "Kingma, D.P., Ba, J., 2015. Adam: a method for stochastic optimization. International Conference on Learning Representations. arXiv:1412.6980.",
    "Kipf, T.N., Welling, M., 2017. Semi-supervised classification with graph convolutional networks. International Conference on Learning Representations. arXiv:1609.02907.",
    "Krasemann, S., Madore, C., Cialic, R., et al., 2017. The TREM2-APOE pathway drives the transcriptional phenotype of dysfunctional microglia in neurodegenerative diseases. Immunity 47, 566-581.e9. https://doi.org/10.1016/j.immuni.2017.08.008.",
    "Liberzon, A., Birger, C., Thorvaldsdottir, H., Ghandi, M., Mesirov, J.P., Tamayo, P., 2015. The Molecular Signatures Database hallmark gene set collection. Cell Syst. 1, 417-425. https://doi.org/10.1016/j.cels.2015.12.004.",
    "Liberzon, A., Subramanian, A., Pinchback, R., Thorvaldsdottir, H., Tamayo, P., Mesirov, J.P., 2011. Molecular signatures database (MSigDB) 3.0. Bioinformatics 27, 1739-1740. https://doi.org/10.1093/bioinformatics/btr260.",
    "Love, M.I., Huber, W., Anders, S., 2014. Moderated estimation of fold change and dispersion for RNA-seq data with DESeq2. Genome Biol. 15, 550. https://doi.org/10.1186/s13059-014-0550-8.",
    "Luecken, M.D., Theis, F.J., 2019. Current best practices in single-cell RNA-seq analysis: a tutorial. Mol. Syst. Biol. 15, e8746. https://doi.org/10.15252/msb.20188746.",
    "Mathys, H., Davila-Velderrain, J., Peng, Z., et al., 2019. Single-cell transcriptomic analysis of Alzheimer's disease. Nature 570, 332-337. https://doi.org/10.1038/s41586-019-1195-2.",
    "Mathys, H., Peng, Z., Boix, C.A., et al., 2024. Single-cell multiregion dissection of Alzheimer's disease. Nature 632, 858-868.",
    "Nugent, A.A., Lin, K., van Lengerich, B., et al., 2020. TREM2 regulates microglial cholesterol metabolism upon chronic phagocytic challenge. Neuron 105, 837-854.e9. https://doi.org/10.1016/j.neuron.2019.12.007.",
    "Olah, M., Menon, V., Habib, N., et al., 2020. Single cell RNA sequencing of human microglia uncovers a subset associated with Alzheimer's disease. Nat. Commun. 11, 6129.",
    "Olah, M., Patrick, E., Villani, A.C., et al., 2018. A transcriptomic atlas of aged human microglia. Nat. Commun. 9, 539. https://doi.org/10.1038/s41467-018-02926-5.",
    "Paszke, A., Gross, S., Massa, F., et al., 2019. PyTorch: an imperative style, high-performance deep learning library. Adv. Neural Inf. Process. Syst. 32, 8024-8035.",
    "Pedregosa, F., Varoquaux, G., Gramfort, A., et al., 2011. Scikit-learn: machine learning in Python. J. Mach. Learn. Res. 12, 2825-2830.",
    "Ritchie, M.E., Phipson, B., Wu, D., et al., 2015. limma powers differential expression analyses for RNA-sequencing and microarray studies. Nucleic Acids Res. 43, e47. https://doi.org/10.1093/nar/gkv007.",
    "Robinson, M.D., McCarthy, D.J., Smyth, G.K., 2010. edgeR: a Bioconductor package for differential expression analysis of digital gene expression data. Bioinformatics 26, 139-140. https://doi.org/10.1093/bioinformatics/btp616.",
    "Sardiello, M., Palmieri, M., di Ronza, A., et al., 2009. A gene network regulating lysosomal biogenesis and function. Science 325, 473-477. https://doi.org/10.1126/science.1174447.",
    "Satija, R., Farrell, J.A., Gennert, D., Schier, A.F., Regev, A., 2015. Spatial reconstruction of single-cell gene expression data. Nat. Biotechnol. 33, 495-502. https://doi.org/10.1038/nbt.3192.",
    "Spearman, C., 1904. The proof and measurement of association between two things. Am. J. Psychol. 15, 72-101. https://doi.org/10.2307/1412107.",
    "Stuart, T., Butler, A., Hoffman, P., et al., 2019. Comprehensive integration of single-cell data. Cell 177, 1888-1902.e21. https://doi.org/10.1016/j.cell.2019.05.031.",
    "Subramanian, A., Tamayo, P., Mootha, V.K., et al., 2005. Gene set enrichment analysis: a knowledge-based approach for interpreting genome-wide expression profiles. Proc. Natl. Acad. Sci. U. S. A. 102, 15545-15550. https://doi.org/10.1073/pnas.0506580102.",
    "The Gene Ontology Consortium, 2021. The Gene Ontology resource: enriching a GOld mine. Nucleic Acids Res. 49, D325-D334.",
    "Wolf, F.A., Angerer, P., Theis, F.J., 2018. SCANPY: large-scale single-cell gene expression data analysis. Genome Biol. 19, 15. https://doi.org/10.1186/s13059-017-1382-0.",
    "Yang, Y.J., Baltus, A.E., Mathew, R.S., et al., 2012. Microcephaly gene links trithorax and REST/NRSF to control neural stem cell proliferation and differentiation. Cell 151, 1097-1112. https://doi.org/10.1016/j.cell.2012.10.043.",
    "Zhou, Y., Song, W.M., Andhey, P.S., et al., 2020. Human and mouse single-nucleus transcriptomics reveal TREM2-dependent and TREM2-independent cellular responses in Alzheimer's disease. Nat. Med. 26, 131-142. https://doi.org/10.1038/s41591-019-0695-9.",
]


def convert_citations(text: str) -> str:
    for old, new in AUTHOR_YEAR.items():
        text = text.replace(old, new)
    return text


def replace_references(body: ET.Element) -> None:
    children = list(body)
    ref_idx = fig_idx = None
    for i, child in enumerate(children):
        if child.tag == qn("p") and para_text(child).strip() == "References":
            ref_idx = i
        elif ref_idx is not None and child.tag == qn("p") and para_text(child).strip() == "Figure legends":
            fig_idx = i
            break
    if ref_idx is None or fig_idx is None:
        raise RuntimeError("Could not find reference block")
    for child in children[ref_idx + 1 : fig_idx]:
        body.remove(child)
    anchor = list(body)[ref_idx]
    for ref in reversed(REFS):
        p = copy.deepcopy(anchor)
        set_para_text(p, ref)
        body.insert(ref_idx + 1, p)


def main() -> None:
    files, root, body = load_docx(MS_IN)
    children = list(body)
    paras = [p for p in children if p.tag == qn("p")]

    # Shorten abstract: replace Background paragraph with single abstract, remove Methods/Results/Conclusions paragraphs.
    bg = meth = res = con = kw = None
    for p in paras:
        txt = para_text(p).strip()
        if txt.startswith("Background:"):
            bg = p
        elif txt.startswith("Methods:"):
            meth = p
        elif txt.startswith("Results:"):
            res = p
        elif txt.startswith("Conclusions:"):
            con = p
        elif txt.startswith("Keywords:"):
            kw = p
    if not all([bg, meth, res, con, kw]):
        raise RuntimeError("Could not locate abstract block")
    set_para_text(bg, ABSTRACT)
    for p in [meth, res, con]:
        remove_p(body, p)
    set_para_text(kw, KEYWORDS)

    # Insert highlights after keywords if absent.
    if not any(para_text(p).strip() == "Highlights" for p in body.findall("w:p", NS)):
        anchor = kw
        for text in HIGHLIGHTS:
            anchor = clone_after(body, anchor, text)

    # Article type note more compatible with Progress in Neurobiology.
    for p in body.findall("w:p", NS):
        txt = para_text(p).strip()
        if txt == "Article type: Original research":
            set_para_text(p, "Article type: Research article")

    # Convert visible in-text numeric citation groups.
    for p in body.findall("w:p", NS):
        txt = para_text(p)
        new = convert_citations(txt)
        if new != txt:
            set_para_text(p, new)

    replace_references(body)
    save_docx(files, root, MS_OUT)
    shutil.copy2(MS_OUT, DL_OUT)

    with zipfile.ZipFile(MS_OUT) as z:
        root = ET.fromstring(z.read("word/document.xml"))
    paras = [para_text(p) for p in root.findall(".//w:p", NS)]
    abstract_words = len(re.findall(r"\b\w+\b", ABSTRACT))
    validation = {
        "abstract_words": abstract_words,
        "refs": len(REFS),
        "numeric_ref_paragraphs": sum(1 for x in paras if re.match(r"^\d+\.\s", x)),
        "remaining_bracket_cites": [x for x in paras if re.search(r"\[\d", x)][:5],
        "drawings": len(root.findall(".//w:drawing", NS)),
        "tables": len(root.findall(".//w:tbl", NS)),
        "highlights": sum(x.strip() == "Highlights" for x in paras),
        "keywords": [x for x in paras if x.startswith("Keywords:")],
    }
    print("Wrote:", MS_OUT)
    print("Copied:", DL_OUT)
    print("Validation:", validation)


if __name__ == "__main__":
    main()
