#!/usr/bin/env python3
import argparse, warnings
from pathlib import Path
import anndata as ad
import numpy as np
import pandas as pd
import scanpy as sc
import matplotlib.pyplot as plt
warnings.filterwarnings("ignore")

HUMAN_MICROGLIA = ["P2RY12","TMEM119","CX3CR1","CSF1R","AIF1","TYROBP","TREM2","FCER1G","APOE"]
OTHER_MARKERS = {
    "astrocyte": ["SLC1A2","SLC1A3","AQP4","GFAP","ALDH1L1"],
    "oligodendrocyte": ["PLP1","MBP","MOG","MAG","CLDN11"],
    "opc": ["PDGFRA","VCAN","CSPG4"],
    "neuron": ["SNAP25","SYT1","RBFOX3","GAD1","SLC17A7"],
    "endothelial": ["CLDN5","PECAM1","KDR","FLT1"],
}

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--input-h5ad", required=True)
    p.add_argument("--output-dir", required=True)
    p.add_argument("--celltype-column", default=None)
    p.add_argument("--celltype-values", default=None)
    p.add_argument("--microglia-clusters", default=None)
    p.add_argument("--min-genes", type=int, default=200)
    p.add_argument("--max-genes", type=int, default=10000)
    p.add_argument("--max-mt", type=float, default=20.0)
    return p.parse_args()

def set_varnames_from_symbols(adata):
    for c in ["feature_name","gene_symbol","gene_name","symbol","gene","hgnc_symbol"]:
        if c in adata.var.columns:
            vals = adata.var[c].astype(str)
            if vals.str.contains("P2RY12|TMEM119|CX3CR1|CSF1R|APOE|TREM2", case=False, regex=True).any():
                adata.var = adata.var.copy()
                adata.var_names = vals.values
                adata.var.index.name = None
                if c in adata.var.columns:
                    adata.var = adata.var.drop(columns=[c])
                adata.var_names_make_unique()
                return c
    return None

def ensure_clustered(adata):
    sc.pp.normalize_total(adata, target_sum=1e4)
    sc.pp.log1p(adata)
    adata.raw = adata.copy()
    sc.pp.highly_variable_genes(adata, n_top_genes=3000, flavor="seurat")
    if "highly_variable" in adata.var.columns:
        adata = adata[:, adata.var["highly_variable"]].copy()
    sc.pp.scale(adata, max_value=10)
    sc.tl.pca(adata)
    sc.pp.neighbors(adata, n_neighbors=15, n_pcs=30)
    sc.tl.umap(adata)
    sc.tl.leiden(adata, resolution=0.4)
    return adata

def export_markers(adata, outdir):
    sc.tl.rank_genes_groups(adata, groupby="leiden", method="wilcoxon")
    rg = adata.uns["rank_genes_groups"]
    groups = rg["names"].dtype.names
    rows = []
    for g in groups:
        for i in range(len(rg["names"][g])):
            rows.append({
                "group": g,
                "names": rg["names"][g][i],
                "scores": rg["scores"][g][i],
                "logfoldchanges": rg["logfoldchanges"][g][i] if "logfoldchanges" in rg else np.nan,
                "pvals": rg["pvals"][g][i],
                "pvals_adj": rg["pvals_adj"][g][i],
            })
    df = pd.DataFrame(rows)
    df.to_csv(outdir / "whole_cluster_markers.csv", index=False)
    df.groupby("group").head(5).to_csv(outdir / "whole_cluster_markers_top5.csv", index=False)
    df[df["names"].isin(HUMAN_MICROGLIA)].sort_values(["names","group","scores"], ascending=[True,True,False]).to_csv(
        outdir / "whole_cluster_microglia_marker_hits.csv", index=False
    )

def main():
    args = parse_args()
    outdir = Path(args.output_dir)
    figs, tabs, objs = outdir / "figures", outdir / "tables", outdir / "objects"
    for p in [figs, tabs, objs]:
        p.mkdir(parents=True, exist_ok=True)
    adata = sc.read_h5ad(args.input_h5ad)
    source = set_varnames_from_symbols(adata)
    if "counts" not in adata.layers:
        adata.layers["counts"] = adata.X.copy()
    adata.var["mt"] = adata.var_names.str.upper().str.startswith("MT-")
    sc.pp.calculate_qc_metrics(adata, qc_vars=["mt"], inplace=True)
    adata = adata[
        (adata.obs["n_genes_by_counts"] >= args.min_genes) &
        (adata.obs["n_genes_by_counts"] <= args.max_genes) &
        (adata.obs["pct_counts_mt"] <= args.max_mt)
    ].copy()

    if args.celltype_column and args.celltype_values:
        vals = [x.strip() for x in args.celltype_values.split(",") if x.strip()]
        adata = adata[adata.obs[args.celltype_column].astype(str).isin(vals)].copy()
        adata.write(objs / "second_human_microglia_prepared.h5ad")
        pd.DataFrame({"varname_source":[source], "n_cells":[adata.n_obs], "n_genes":[adata.n_vars]}).to_csv(tabs / "prep_summary.csv", index=False)
        print(objs / "second_human_microglia_prepared.h5ad")
        return

    adata = ensure_clustered(adata)
    mg_present = [g for g in HUMAN_MICROGLIA if g in adata.var_names]
    if mg_present:
        sc.tl.score_genes(adata, gene_list=mg_present, score_name="microglia_score", use_raw=False)
    else:
        adata.obs["microglia_score"] = 0.0

    sc.pl.umap(adata, color=["leiden","microglia_score"], show=False)
    plt.savefig(figs / "discovery_umap_leiden_microglia_score.png", dpi=150, bbox_inches="tight")
    plt.close()

    feats = mg_present[:]
    for genes in OTHER_MARKERS.values():
        feats.extend([g for g in genes if g in adata.var_names])
    feats = list(dict.fromkeys(feats))[:18]
    if feats:
        sc.pl.umap(adata, color=feats, ncols=3, show=False)
        plt.savefig(figs / "discovery_umap_marker_panel.png", dpi=150, bbox_inches="tight")
        plt.close()

    export_markers(adata, tabs)
    adata.write(objs / "second_human_discovery_qc_clustered.h5ad")

    if args.microglia_clusters:
        keep = [x.strip() for x in args.microglia_clusters.split(",") if x.strip()]
        mg = adata[adata.obs["leiden"].astype(str).isin(keep)].copy()
        mg.write(objs / "second_human_microglia_prepared.h5ad")
        pd.DataFrame({"varname_source":[source], "selected_clusters":[",".join(keep)], "n_cells":[mg.n_obs], "n_genes":[mg.n_vars]}).to_csv(
            tabs / "prep_summary.csv", index=False
        )
        print(objs / "second_human_microglia_prepared.h5ad")
    else:
        pd.DataFrame({"varname_source":[source], "n_cells":[adata.n_obs], "n_genes":[adata.n_vars]}).to_csv(
            tabs / "prep_summary.csv", index=False
        )
        print("Discovery pass completed. Inspect marker outputs and rerun with --microglia-clusters.")
if __name__ == "__main__":
    main()
