#!/usr/bin/env python3
"""
download_olah_live_human_microglia.py

Downloads the original source H5AD(s) for the CELLxGENE collection:
  Live Human Microglia Single-cell RNA-seq
Collection URL:
  https://cellxgene.cziscience.com/collections/fcb3d1c1-03d2-41ac-8229-458e072b7a1c

Method:
  Uses cellxgene-census metadata + download_source_h5ad().

Install requirement:
  pip install cellxgene-census

Outputs:
  - downloaded h5ad(s)
  - dataset_manifest.csv
  - optional merged h5ad if multiple datasets are present

If the collection currently contains multiple datasets, the script downloads all
of them and can merge them with anndata.concat(join="outer").
"""

import argparse
import logging
from pathlib import Path

import anndata as ad
import pandas as pd

COLLECTION_ID = "fcb3d1c1-03d2-41ac-8229-458e072b7a1c"

def setup_logger(outdir: Path) -> logging.Logger:
    outdir.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("olah_download")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
    sh = logging.StreamHandler()
    sh.setFormatter(fmt)
    logger.addHandler(sh)
    fh = logging.FileHandler(outdir / "olah_download.log", mode="w", encoding="utf-8")
    fh.setFormatter(fmt)
    logger.addHandler(fh)
    return logger

def main():
    ap = argparse.ArgumentParser(description="Download Olah live human microglia H5AD(s) from CELLxGENE")
    ap.add_argument("--outdir", default="olah_live_human_microglia")
    ap.add_argument("--merge", action="store_true", help="Merge downloaded H5ADs into one file")
    args = ap.parse_args()

    try:
        import cellxgene_census
    except ImportError as e:
        raise SystemExit("Please install cellxgene-census first: pip install cellxgene-census") from e

    root = Path(args.outdir)
    downloads = root / "downloads"
    processed = root / "processed"
    downloads.mkdir(parents=True, exist_ok=True)
    processed.mkdir(parents=True, exist_ok=True)
    logger = setup_logger(root)

    logger.info("Opening CELLxGENE Census")
    census = cellxgene_census.open_soma()
    ds = census["census_info"]["datasets"].read().concat().to_pandas()
    census.close()

    sub = ds[ds["collection_id"] == COLLECTION_ID].copy()
    if sub.empty:
        # fallback title search
        sub = ds[
            ds["collection_name"].astype(str).str.contains("Live Human Microglia", case=False, na=False)
            | ds["dataset_title"].astype(str).str.contains("microglia", case=False, na=False)
        ].copy()

    if sub.empty:
        raise RuntimeError("Could not find Olah live human microglia dataset(s) in CELLxGENE Census metadata.")

    sub = sub.sort_values(["dataset_total_cell_count", "dataset_title"], ascending=[False, True]).reset_index(drop=True)
    sub.to_csv(processed / "dataset_manifest.csv", index=False)
    logger.info("Found %d matching dataset(s)", len(sub))

    downloaded = []
    for _, row in sub.iterrows():
        dataset_id = row["dataset_id"]
        title = str(row["dataset_title"]).strip().replace("/", "_").replace("\\", "_")
        out_h5ad = downloads / f"{dataset_id}__{title[:80]}.h5ad"
        logger.info("Downloading dataset_id=%s title=%s", dataset_id, title)
        import cellxgene_census
        cellxgene_census.download_source_h5ad(dataset_id, to_path=str(out_h5ad))
        downloaded.append((dataset_id, out_h5ad, title))

    if args.merge and downloaded:
        logger.info("Merging %d H5AD(s)", len(downloaded))
        adatas = []
        for dataset_id, path, title in downloaded:
            a = ad.read_h5ad(path)
            a.obs["dataset_id"] = dataset_id
            a.obs["dataset_title"] = title
            # preserve raw counts if present in X only
            if "counts" not in a.layers:
                a.layers["counts"] = a.X.copy()
            adatas.append(a)
        merged = ad.concat(adatas, join="outer", merge="same", label="download_batch", keys=[x[0] for x in downloaded], index_unique="-")
        out_merged = processed / "olah_live_human_microglia_merged.h5ad"
        merged.write(out_merged)
        logger.info("Saved merged H5AD: %s", out_merged)

    logger.info("Done")

if __name__ == "__main__":
    main()
