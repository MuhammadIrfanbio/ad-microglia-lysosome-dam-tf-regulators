from __future__ import annotations

import re
import shutil
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

BASE = Path(r"F:\AD\Mam San\results\Sand_regulatory_program_manuscript_package_final_v2\Final")
MS = BASE / "MANUSCRIPT_PROGRESS_IN_NEUROBIOLOGY_FORMATTED_TF_ZNF335.docx"
DL = Path(r"C:\Users\Administrator\Downloads") / MS.name
W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
NS = {"w": W}
ET.register_namespace("w", W)


def qn(tag: str) -> str:
    return f"{{{W}}}{tag}"


def para_text(p):
    return "".join(t.text or "" for t in p.findall(".//w:t", NS))


def set_para_text(p, text):
    runs = p.findall("w:r", NS)
    r = runs[0] if runs else ET.SubElement(p, qn("r"))
    for child in list(r):
        r.remove(child)
    t = ET.SubElement(r, qn("t"))
    t.text = text
    for extra in runs[1:]:
        p.remove(extra)


with zipfile.ZipFile(MS, "r") as z:
    files = {name: z.read(name) for name in z.namelist()}
root = ET.fromstring(files["word/document.xml"])

repls = {
    "[3-8]": "(Mathys et al., 2019, 2024; Olah et al., 2018, 2020; Gerrits et al., 2021; Gabitto et al., 2024)",
}
for p in root.findall(".//w:p", NS):
    txt = para_text(p)
    new = txt
    for old, val in repls.items():
        new = new.replace(old, val)
    if new != txt:
        set_para_text(p, new)

files["word/document.xml"] = ET.tostring(root, encoding="utf-8", xml_declaration=True)
with zipfile.ZipFile(MS, "w", zipfile.ZIP_DEFLATED) as z:
    for name, data in files.items():
        z.writestr(name, data)
shutil.copy2(MS, DL)

paras = [para_text(p) for p in root.findall(".//w:p", NS)]
print("Updated:", MS)
print("Copied:", DL)
print("remaining bracket cites:", [x for x in paras if re.search(r"\[\d", x)])
abstract = next(x for x in paras if x.startswith("Alzheimer's disease (AD) microglia remodel"))
print("abstract words:", len(re.findall(r"\b\w+\b", abstract)))
print("refs numeric:", sum(1 for x in paras if re.match(r"^\d+\.\s", x)))
print("drawings:", len(root.findall(".//w:drawing", NS)), "tables:", len(root.findall(".//w:tbl", NS)))
