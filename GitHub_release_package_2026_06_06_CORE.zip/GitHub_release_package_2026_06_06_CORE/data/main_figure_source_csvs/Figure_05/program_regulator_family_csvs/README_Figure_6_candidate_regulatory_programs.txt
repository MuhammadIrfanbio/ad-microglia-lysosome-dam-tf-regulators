Figure 6. Candidate regulatory programs associated with AD microglial remodeling

Outputs:
- F:/AD/Mam San/results/publication_figures/Figure_6_candidate_regulatory_programs_900ppi.png
- F:/AD/Mam San/results/publication_figures/Figure_6_candidate_regulatory_programs_900ppi.tiff
- F:/AD/Mam San/results/publication_figures/Figure_6_candidate_regulatory_programs_editable.pdf

Panels:
A. Candidate regulator/program activity across datasets.
B. Sample/donor-level Spearman correlations between core remodeling and regulatory program branches.
C. Detection-aware ranking of candidate genes/regulators.
D. Program-family network replacing the single BACE1-ZNF335 main-axis claim.
E. Final model: conserved downstream lysosomal/phagocytic DAM-like remodeling with candidate upstream lipid-response, myeloid TF, interferon, and lysosomal-biogenesis programs.

Interpretation: main claim is module-level; BACE1-ZNF335 is retained only as a supplementary guardrail/context-dependent axis.
Source data directory: F:/AD/Mam San/results/publication_figures/figure6_source_data
