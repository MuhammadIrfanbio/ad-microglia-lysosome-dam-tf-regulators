#!/usr/bin/env python3
"""
Zfp335–Bace1–lysosome microglia validation pipeline
===================================================

A single-file Scanpy workflow for:
1) loading one scRNA/snRNA dataset
2) QC and clustering
3) marker inspection and optional microglia subsetting
4) re-clustering microglia
5) module scoring for the Zfp335/Bace1/lysosome/DAM axis
6) heuristic state annotation and figure/table export

Supported inputs
----------------
- .h5ad
- 10x matrix directory (filtered_feature_bc_matrix)
- CSV counts matrix (+ optional metadata)

Typical usage
-------------
# A) Start with a microglia-only h5ad
python zfp335_ad_pipeline.py \
  --input-type h5ad \
  --input data_raw/mouse_microglia.h5ad \
  --species mouse \
  --microglia-only \
  --output-dir results_mouse

# B) Start with a whole-brain 10x dataset, inspect clusters, then rerun
python zfp335_ad_pipeline.py \
  --input-type 10x \
  --input data_raw/filtered_feature_bc_matrix \
  --species mouse \
  --output-dir results_wholebrain

# Then rerun after inspecting cluster marker plots, e.g. clusters 2,4,7 are microglia
python zfp335_ad_pipeline.py \
  --input-type 10x \
  --input data_raw/filtered_feature_bc_matrix \
  --species mouse \
  --microglia-clusters 2,4,7 \
  --output-dir results_microglia

# C) CSV counts, genes x cells, with optional metadata
python zfp335_ad_pipeline.py \
  --input-type csv \
  --input data_raw/counts_matrix.csv \
  --metadata data_raw/cell_metadata.csv \
  --csv-orientation genes_by_cells \
  --species mouse \
  --microglia-only \
  --output-dir results_csv

Optional gene set override
--------------------------
Provide a CSV with columns: gene_set,gene
Example:
  regulator,Zfp335
  bace1_node,Bace1
  lysosome,Ctsb
  ...

Notes
-----
- If you do NOT set --microglia-only, --microglia-clusters, or a cell type selector,
  the script will stop after the whole-dataset stage and tell you to inspect the outputs.
- Heuristic state labels are intentionally conservative. The microglia stage now exports
  state-label validation tables for multi-resolution Leiden agreement, scoring-method
  sensitivity, and score-consistency checks.
"""

from __future__ import annotations

import argparse
import json
import logging
import math
import os
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scanpy as sc
from anndata import AnnData


# -----------------------------
# Defaults
# -----------------------------

MOUSE_GENE_SETS: Dict[str, List[str]] = {
    "regulator": ["Zfp335"],
    "bace1_node": ["Bace1"],
    "lysosome": ["Ctsb", "Ctsd", "Lamp1", "Lamp2", "Cd68", "Hexa", "Hexb", "Atp6v1b2", "Atp6v0d1"],
    "dam_phagocytic": ["Apoe", "Trem2", "Tyrobp", "Cst7", "Lpl", "Itgax", "Axl", "Gpnmb", "Fcer1g", "Cd68"],
    "homeostatic": ["P2ry12", "Tmem119", "Cx3cr1", "Csf1r", "Selplg"],
    "interferon": ["Ifitm3", "Isg15", "Ifit3", "Stat1", "Irf7"],
    "proliferative": ["Mki67", "Top2a", "Birc5", "Pcna", "Ube2c"],
}

HUMAN_GENE_SETS: Dict[str, List[str]] = {
    "regulator": ["ZNF335"],
    "bace1_node": ["BACE1"],
    "lysosome": ["CTSB", "CTSD", "LAMP1", "LAMP2", "CD68", "HEXA", "HEXB", "ATP6V1B2", "ATP6V0D1"],
    "dam_phagocytic": ["APOE", "TREM2", "TYROBP", "CST7", "LPL", "ITGAX", "AXL", "GPNMB", "FCER1G", "CD68"],
    "homeostatic": ["P2RY12", "TMEM119", "CX3CR1", "CSF1R", "SELPLG"],
    "interferon": ["IFITM3", "ISG15", "IFIT3", "STAT1", "IRF7"],
    "proliferative": ["MKI67", "TOP2A", "BIRC5", "PCNA", "UBE2C"],
}

MOUSE_MICROGLIA_MARKERS = ["P2ry12", "Tmem119", "Cx3cr1", "Csf1r", "Aif1", "Tyrobp"]
HUMAN_MICROGLIA_MARKERS = ["P2RY12", "TMEM119", "CX3CR1", "CSF1R", "AIF1", "TYROBP"]


# -----------------------------
# Argument parsing
# -----------------------------

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="All-in-one Zfp335/Bace1 microglia validation pipeline")

    parser.add_argument("--input-type", required=True, choices=["h5ad", "10x", "csv"], help="Input format")
    parser.add_argument("--input", required=True, help="Input file or directory")
    parser.add_argument("--metadata", default=None, help="Optional metadata CSV for --input-type csv")
    parser.add_argument(
        "--csv-orientation",
        default="genes_by_cells",
        choices=["genes_by_cells", "cells_by_genes"],
        help="Orientation of CSV count matrix",
    )
    parser.add_argument("--species", default="mouse", choices=["mouse", "human"], help="Species for default gene sets")
    parser.add_argument("--output-dir", required=True, help="Directory for outputs")
    parser.add_argument("--project-name", default="zfp335_axis_validation", help="Prefix for output files")
    parser.add_argument("--gene-sets-file", default=None, help="Optional CSV or JSON gene set file")

    parser.add_argument("--microglia-only", action="store_true", help="Set if the dataset is already microglia-only")
    parser.add_argument(
        "--microglia-clusters",
        default=None,
        help="Comma-separated cluster IDs from the whole-dataset Leiden solution to subset as microglia, e.g. 2,4,7",
    )
    parser.add_argument("--celltype-column", default=None, help="Metadata column for cell type selection")
    parser.add_argument(
        "--celltype-values",
        default=None,
        help="Comma-separated values in --celltype-column that define microglia, e.g. Microglia,Mic",
    )

    parser.add_argument("--donor-column", default=None, help="Optional donor/sample column for summary tables")
    parser.add_argument("--diagnosis-column", default=None, help="Optional diagnosis column for summary tables")

    parser.add_argument("--min-genes", type=int, default=200, help="QC: minimum genes per cell")
    parser.add_argument("--max-genes", type=int, default=6000, help="QC: maximum genes per cell")
    parser.add_argument("--max-mt", type=float, default=10.0, help="QC: maximum percent mitochondrial counts")
    parser.add_argument("--min-cells-per-gene", type=int, default=3, help="Remove genes expressed in fewer than this many cells")

    parser.add_argument("--n-top-genes", type=int, default=3000, help="Number of HVGs")
    parser.add_argument("--n-neighbors", type=int, default=15, help="Neighbors for graph construction")
    parser.add_argument("--n-pcs", type=int, default=30, help="PCs for neighbor graph")
    parser.add_argument("--resolution", type=float, default=0.4, help="Leiden resolution")
    parser.add_argument("--random-state", type=int, default=0, help="Random seed")
    parser.add_argument(
        "--skip-state-validation",
        action="store_true",
        help="Skip state-label robustness annotations and validation tables.",
    )
    parser.add_argument(
        "--state-validation-resolutions",
        default="0.2,0.4,0.8,1.2",
        help="Comma-separated Leiden resolutions for state-label robustness checks.",
    )
    parser.add_argument(
        "--state-transition-deltas",
        default="0,0.025,0.05,0.1",
        help="Comma-separated top-minus-second score thresholds for state-label sensitivity checks.",
    )

    return parser.parse_args()


# -----------------------------
# Utilities
# -----------------------------

def setup_output_dirs(output_dir: Path) -> Dict[str, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    subdirs = {
        "root": output_dir,
        "figures": output_dir / "figures",
        "tables": output_dir / "tables",
        "objects": output_dir / "objects",
        "logs": output_dir / "logs",
    }
    for p in subdirs.values():
        p.mkdir(parents=True, exist_ok=True)
    return subdirs


def setup_logger(log_path: Path) -> logging.Logger:
    logger = logging.getLogger("zfp335_pipeline")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()

    fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")

    fh = logging.FileHandler(log_path)
    fh.setFormatter(fmt)
    logger.addHandler(fh)

    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(fmt)
    logger.addHandler(sh)

    return logger


def load_gene_sets(species: str, gene_sets_file: Optional[str], logger: logging.Logger) -> Dict[str, List[str]]:
    gene_sets = MOUSE_GENE_SETS.copy() if species == "mouse" else HUMAN_GENE_SETS.copy()
    if gene_sets_file is None:
        logger.info("Using built-in default gene sets for %s", species)
        return gene_sets

    path = Path(gene_sets_file)
    if not path.exists():
        raise FileNotFoundError(f"Gene set file not found: {path}")

    if path.suffix.lower() == ".csv":
        df = pd.read_csv(path)
        required = {"gene_set", "gene"}
        if not required.issubset(df.columns):
            raise ValueError(f"Gene set CSV must contain columns: {required}")
        custom: Dict[str, List[str]] = {}
        for gs, sub in df.groupby("gene_set"):
            custom[gs] = sorted(sub["gene"].dropna().astype(str).unique().tolist())
        logger.info("Loaded custom gene sets from CSV: %s", path)
        return custom

    if path.suffix.lower() == ".json":
        with open(path, "r", encoding="utf-8") as f:
            custom = json.load(f)
        logger.info("Loaded custom gene sets from JSON: %s", path)
        return custom

    raise ValueError("Gene set file must be .csv or .json")


def save_gene_sets_table(gene_sets: Dict[str, List[str]], table_path: Path) -> None:
    rows = []
    for gs, genes in gene_sets.items():
        for gene in genes:
            rows.append({"gene_set": gs, "gene": gene})
    pd.DataFrame(rows).to_csv(table_path, index=False)


def get_microglia_markers(species: str) -> List[str]:
    return MOUSE_MICROGLIA_MARKERS if species == "mouse" else HUMAN_MICROGLIA_MARKERS


def get_mt_mask(var_names: pd.Index, species: str) -> np.ndarray:
    if species == "mouse":
        return var_names.str.startswith("mt-") | var_names.str.startswith("MT-")
    return var_names.str.startswith("MT-") | var_names.str.startswith("mt-")


def present_genes(adata: AnnData, genes: List[str]) -> List[str]:
    return [g for g in genes if g in adata.var_names or (adata.raw is not None and g in adata.raw.var_names)]


def get_gene_vector(adata: AnnData, gene: str) -> Optional[np.ndarray]:
    if adata.raw is not None and gene in adata.raw.var_names:
        x = adata.raw[:, gene].X
    elif gene in adata.var_names:
        x = adata[:, gene].X
    else:
        return None
    if hasattr(x, "toarray"):
        x = x.toarray()
    return np.asarray(x).ravel()


def safe_write_h5ad(adata: AnnData, path: Path, logger: logging.Logger) -> None:
    try:
        adata.write(path)
        logger.info("Saved AnnData: %s", path)
    except Exception as e:
        logger.warning("Could not save AnnData to %s: %s", path, e)


# -----------------------------
# Data loading
# -----------------------------

def load_input_data(args: argparse.Namespace, logger: logging.Logger) -> AnnData:
    input_path = Path(args.input)
    if args.input_type == "h5ad":
        logger.info("Loading h5ad: %s", input_path)
        adata = sc.read_h5ad(input_path)

    elif args.input_type == "10x":
        logger.info("Loading 10x matrix: %s", input_path)
        adata = sc.read_10x_mtx(input_path, var_names="gene_symbols", cache=False)
        adata.var_names_make_unique()

    elif args.input_type == "csv":
        logger.info("Loading CSV counts: %s", input_path)
        counts = pd.read_csv(input_path, index_col=0)
        if args.csv_orientation == "genes_by_cells":
            counts_df = counts.T
        else:
            counts_df = counts
        adata = AnnData(X=counts_df.values)
        adata.obs_names = counts_df.index.astype(str)
        adata.var_names = counts_df.columns.astype(str)
        adata.var_names_make_unique()

        if args.metadata is not None:
            metadata_path = Path(args.metadata)
            logger.info("Loading metadata: %s", metadata_path)
            meta = pd.read_csv(metadata_path, index_col=0)
            shared = adata.obs_names.intersection(meta.index.astype(str))
            if len(shared) == 0:
                raise ValueError("No shared cell IDs between CSV counts and metadata index")
            adata = adata[shared].copy()
            meta = meta.loc[shared].copy()
            adata.obs = meta
        else:
            logger.info("No metadata provided for CSV input")

    else:
        raise ValueError(f"Unsupported input type: {args.input_type}")

    adata.obs_names = adata.obs_names.astype(str)
    adata.var_names = adata.var_names.astype(str)
    adata.var_names_make_unique()
    logger.info("Loaded data with shape: %s cells x %s genes", adata.n_obs, adata.n_vars)
    return adata


# -----------------------------
# QC, clustering, plotting
# -----------------------------

def run_basic_qc(
    adata: AnnData,
    args: argparse.Namespace,
    outdirs: Dict[str, Path],
    logger: logging.Logger,
) -> AnnData:
    logger.info("Running basic QC")
    sc.pp.filter_genes(adata, min_cells=args.min_cells_per_gene)
    adata.var["mt"] = get_mt_mask(adata.var_names, args.species)
    sc.pp.calculate_qc_metrics(adata, qc_vars=["mt"], inplace=True)

    qc_before = pd.DataFrame(
        {
            "n_cells": [adata.n_obs],
            "n_genes": [adata.n_vars],
            "median_total_counts": [float(np.median(adata.obs["total_counts"]))],
            "median_n_genes_by_counts": [float(np.median(adata.obs["n_genes_by_counts"]))],
            "median_pct_counts_mt": [float(np.median(adata.obs["pct_counts_mt"]))],
        }
    )
    qc_before.to_csv(outdirs["tables"] / f"{args.project_name}_qc_before_filtering.csv", index=False)

    sc.pl.violin(
        adata,
        ["n_genes_by_counts", "total_counts", "pct_counts_mt"],
        jitter=0.4,
        multi_panel=True,
        show=False,
    )
    plt.savefig(outdirs["figures"] / f"{args.project_name}_qc_violin_before.png", bbox_inches="tight")
    plt.close("all")

    sc.pl.scatter(adata, x="total_counts", y="pct_counts_mt", show=False)
    plt.savefig(outdirs["figures"] / f"{args.project_name}_qc_scatter_counts_mt_before.png", bbox_inches="tight")
    plt.close("all")

    sc.pl.scatter(adata, x="total_counts", y="n_genes_by_counts", show=False)
    plt.savefig(outdirs["figures"] / f"{args.project_name}_qc_scatter_counts_genes_before.png", bbox_inches="tight")
    plt.close("all")

    keep = (
        (adata.obs["n_genes_by_counts"] >= args.min_genes)
        & (adata.obs["n_genes_by_counts"] <= args.max_genes)
        & (adata.obs["pct_counts_mt"] < args.max_mt)
    )
    adata = adata[keep].copy()
    logger.info("After QC filtering: %s cells x %s genes", adata.n_obs, adata.n_vars)

    qc_after = pd.DataFrame(
        {
            "n_cells": [adata.n_obs],
            "n_genes": [adata.n_vars],
            "median_total_counts": [float(np.median(adata.obs["total_counts"]))],
            "median_n_genes_by_counts": [float(np.median(adata.obs["n_genes_by_counts"]))],
            "median_pct_counts_mt": [float(np.median(adata.obs["pct_counts_mt"]))],
        }
    )
    qc_after.to_csv(outdirs["tables"] / f"{args.project_name}_qc_after_filtering.csv", index=False)

    return adata


def normalize_for_clustering(adata: AnnData, logger: logging.Logger) -> AnnData:
    logger.info("Normalizing and log-transforming")
    if "counts" not in adata.layers:
        logger.info("Preserving pre-normalization matrix in layers['counts']")
        adata.layers["counts"] = adata.X.copy()
    sc.pp.normalize_total(adata, target_sum=1e4)
    sc.pp.log1p(adata)
    adata.raw = adata.copy()
    return adata


def cluster_and_embed(adata: AnnData, args: argparse.Namespace, logger: logging.Logger) -> AnnData:
    logger.info("Computing HVGs, PCA, neighbors, Leiden, UMAP")
    sc.pp.highly_variable_genes(adata, n_top_genes=args.n_top_genes, flavor="seurat")
    hvg_mask = adata.var["highly_variable"].fillna(False).values
    if hvg_mask.sum() < 200:
        logger.warning("Few HVGs detected (%s); falling back to all genes for PCA", int(hvg_mask.sum()))
        sc.pp.scale(adata, max_value=10)
        sc.tl.pca(adata, svd_solver="arpack", random_state=args.random_state)
    else:
        adata_hvg = adata[:, hvg_mask].copy()
        sc.pp.scale(adata_hvg, max_value=10)
        sc.tl.pca(adata_hvg, svd_solver="arpack", random_state=args.random_state)
        adata.obsm["X_pca"] = adata_hvg.obsm["X_pca"]
        if "PCs" in adata_hvg.varm:
            adata.varm["PCs"] = np.zeros((adata.n_vars, adata_hvg.varm["PCs"].shape[1]))
            adata.varm["PCs"][hvg_mask, :] = adata_hvg.varm["PCs"]
        adata.uns["pca"] = adata_hvg.uns["pca"]

    n_pcs = min(args.n_pcs, adata.obsm["X_pca"].shape[1])
    sc.pp.neighbors(adata, n_neighbors=args.n_neighbors, n_pcs=n_pcs)
    sc.tl.umap(adata, random_state=args.random_state)
    sc.tl.leiden(adata, resolution=args.resolution, random_state=args.random_state, key_added="leiden")
    return adata


def plot_whole_dataset_outputs(
    adata: AnnData,
    args: argparse.Namespace,
    outdirs: Dict[str, Path],
    logger: logging.Logger,
) -> None:
    logger.info("Plotting whole-dataset outputs")
    sc.pl.umap(adata, color=["leiden"], legend_loc="on data", show=False)
    plt.savefig(outdirs["figures"] / f"{args.project_name}_whole_umap_leiden.png", bbox_inches="tight")
    plt.close("all")

    markers = present_genes(adata, get_microglia_markers(args.species))
    if markers:
        sc.pl.umap(adata, color=markers, show=False)
        plt.savefig(outdirs["figures"] / f"{args.project_name}_whole_umap_microglia_markers.png", bbox_inches="tight")
        plt.close("all")

    try:
        sc.tl.rank_genes_groups(adata, groupby="leiden", method="wilcoxon")
        rg = sc.get.rank_genes_groups_df(adata, group=None)
        rg.to_csv(outdirs["tables"] / f"{args.project_name}_whole_cluster_markers.csv", index=False)

        # top 5 markers per cluster summary
        top5 = (
            rg.sort_values(["group", "scores"], ascending=[True, False])
            .groupby("group")
            .head(5)
            .copy()
        )
        top5.to_csv(outdirs["tables"] / f"{args.project_name}_whole_cluster_markers_top5.csv", index=False)
    except Exception as e:
        logger.warning("Could not compute cluster markers on whole dataset: %s", e)


def select_microglia_subset(adata: AnnData, args: argparse.Namespace, logger: logging.Logger) -> Tuple[Optional[AnnData], str]:
    if args.microglia_only:
        logger.info("Dataset flagged as microglia-only")
        return adata.copy(), "microglia_only"

    if args.celltype_column and args.celltype_values:
        if args.celltype_column not in adata.obs.columns:
            raise ValueError(f"celltype-column not found in obs: {args.celltype_column}")
        values = [x.strip() for x in args.celltype_values.split(",") if x.strip()]
        mask = adata.obs[args.celltype_column].astype(str).isin(values)
        logger.info("Selecting microglia using %s in %s", args.celltype_column, values)
        subset = adata[mask].copy()
        logger.info("Selected %s microglia cells", subset.n_obs)
        return subset, f"obs:{args.celltype_column}"

    if args.microglia_clusters:
        clusters = [x.strip() for x in args.microglia_clusters.split(",") if x.strip()]
        mask = adata.obs["leiden"].astype(str).isin(clusters)
        logger.info("Selecting microglia clusters from Leiden solution: %s", clusters)
        subset = adata[mask].copy()
        logger.info("Selected %s microglia cells", subset.n_obs)
        return subset, f"leiden:{','.join(clusters)}"

    logger.info("No microglia selector provided; stopping after whole-dataset stage")
    return None, "none"


def score_modules(adata: AnnData, gene_sets: Dict[str, List[str]], logger: logging.Logger) -> pd.DataFrame:
    summary_rows = []
    for gs_name, genes in gene_sets.items():
        genes_present = present_genes(adata, genes)
        score_col = f"{gs_name}_score"
        if len(genes_present) >= 2:
            sc.tl.score_genes(adata, gene_list=genes_present, score_name=score_col, use_raw=True)
            status = "scored"
        elif len(genes_present) == 1:
            vec = get_gene_vector(adata, genes_present[0])
            adata.obs[score_col] = vec if vec is not None else np.nan
            status = "single_gene_proxy"
        else:
            adata.obs[score_col] = np.nan
            status = "missing"
        summary_rows.append({
            "gene_set": gs_name,
            "n_defined": len(genes),
            "n_present": len(genes_present),
            "genes_present": ";".join(genes_present),
            "status": status,
        })
    return pd.DataFrame(summary_rows)


STATE_SCORE_COLUMNS = ["homeostatic_score", "dam_phagocytic_score", "lysosome_score", "interferon_score", "proliferative_score"]
STATE_LABEL_MAP = {
    "homeostatic_score": "homeostatic_like",
    "dam_phagocytic_score": "dam_like",
    "lysosome_score": "lysosome_high",
    "interferon_score": "interferon_like",
    "proliferative_score": "proliferative_like",
}


def parse_float_list(value: str) -> List[float]:
    out = []
    for item in str(value).split(","):
        item = item.strip()
        if not item:
            continue
        out.append(float(item))
    return out


def safe_float_label(value: float) -> str:
    return str(value).replace(".", "p").replace("-", "m")


def state_annotation_from_scores(
    adata: AnnData,
    transition_delta: float = 0.05,
    transform: str = "raw",
) -> pd.Series:
    needed = STATE_SCORE_COLUMNS
    missing = [c for c in needed if c not in adata.obs.columns]
    if missing:
        raise ValueError(f"Missing score columns for heuristic annotation: {missing}")

    scores = adata.obs[needed].apply(pd.to_numeric, errors="coerce").copy()
    if transform == "zscore":
        scores = scores.apply(lambda x: (x - x.mean()) / x.std(ddof=0) if x.std(ddof=0) > 0 else x * 0.0)
    elif transform != "raw":
        raise ValueError(f"Unsupported state score transform: {transform}")
    scores = scores.fillna(-np.inf)
    best = scores.idxmax(axis=1)
    states = best.map(STATE_LABEL_MAP).astype(str)

    # Soften labels where the top two scores are nearly tied.
    vals = np.sort(scores.values, axis=1)
    top_minus_second = vals[:, -1] - vals[:, -2]
    states = pd.Series(states.values, index=adata.obs_names, name="state_hint")
    states[top_minus_second < transition_delta] = "transitional_like"
    return states


def heuristic_state_annotation(adata: AnnData) -> pd.Series:
    return state_annotation_from_scores(adata, transition_delta=0.05, transform="raw")


def add_state_validation_annotations(adata: AnnData, args: argparse.Namespace, logger: logging.Logger) -> None:
    if args.skip_state_validation:
        logger.info("Skipping state-label validation annotations by user request")
        return

    logger.info("Adding state-label validation annotations")
    for res in parse_float_list(args.state_validation_resolutions):
        key = f"leiden_res_{safe_float_label(res)}"
        if key not in adata.obs.columns:
            sc.tl.leiden(adata, resolution=res, random_state=args.random_state, key_added=key)

    for delta in parse_float_list(args.state_transition_deltas):
        delta_label = safe_float_label(delta)
        for transform in ["raw", "zscore"]:
            key = f"state_{transform}_delta_{delta_label}"
            adata.obs[key] = state_annotation_from_scores(adata, transition_delta=delta, transform=transform)


def normalized_mutual_info(tab: pd.DataFrame) -> float:
    counts = tab.values.astype(float)
    total = counts.sum()
    if total <= 0:
        return float("nan")
    pxy = counts / total
    px = pxy.sum(axis=1, keepdims=True)
    py = pxy.sum(axis=0, keepdims=True)
    nz = pxy > 0
    mi = float((pxy[nz] * np.log(pxy[nz] / (px @ py)[nz])).sum())
    hx = float(-(px[px > 0] * np.log(px[px > 0])).sum())
    hy = float(-(py[py > 0] * np.log(py[py > 0])).sum())
    if hx <= 0 or hy <= 0:
        return float("nan")
    return mi / math.sqrt(hx * hy)


def export_state_validation_tables(
    adata: AnnData,
    args: argparse.Namespace,
    outdirs: Dict[str, Path],
    logger: logging.Logger,
) -> None:
    if args.skip_state_validation or "state_hint" not in adata.obs.columns:
        return

    logger.info("Exporting state-label validation tables")
    tables = outdirs["tables"]
    compare_cols = [
        c for c in adata.obs.columns
        if c == "leiden" or c.startswith("leiden_res_") or c.startswith("state_raw_delta_") or c.startswith("state_zscore_delta_")
    ]
    summary_rows = []
    for col in compare_cols:
        tab = pd.crosstab(adata.obs["state_hint"].astype(str), adata.obs[col].astype(str))
        tab.to_csv(tables / f"{args.project_name}_state_validation_confusion_state_hint_vs_{col}.csv")
        row_prop = tab.div(tab.sum(axis=1).replace(0, np.nan), axis=0).fillna(0.0)
        row_prop.to_csv(tables / f"{args.project_name}_state_validation_confusion_state_hint_vs_{col}_rowprop.csv")
        dominant = tab.max(axis=1).sum() / max(tab.values.sum(), 1)
        summary_rows.append({
            "comparison_column": col,
            "n_levels": int(tab.shape[1]),
            "n_cells": int(tab.values.sum()),
            "weighted_state_purity": float(dominant),
            "normalized_mutual_information": normalized_mutual_info(tab),
        })

    if summary_rows:
        pd.DataFrame(summary_rows).to_csv(tables / f"{args.project_name}_state_validation_summary.csv", index=False)

    score_cols = [c for c in STATE_SCORE_COLUMNS if c in adata.obs.columns]
    consistency_rows = []
    if score_cols:
        med = adata.obs.groupby("state_hint")[score_cols].median(numeric_only=True)
        med.to_csv(tables / f"{args.project_name}_state_validation_median_module_scores.csv")
        expected = {
            "homeostatic_like": "homeostatic_score",
            "dam_like": "dam_phagocytic_score",
            "lysosome_high": "lysosome_score",
            "interferon_like": "interferon_score",
            "proliferative_like": "proliferative_score",
        }
        for state, row in med.iterrows():
            ranks = row.rank(ascending=False, method="min")
            expected_score = expected.get(str(state))
            consistency_rows.append({
                "state_hint": state,
                "expected_score": expected_score or "",
                "expected_score_rank": float(ranks[expected_score]) if expected_score in ranks.index else np.nan,
                "top_score": str(row.idxmax()),
                "top_score_value": float(row.max()),
            })
        pd.DataFrame(consistency_rows).to_csv(tables / f"{args.project_name}_state_validation_score_consistency.csv", index=False)


def summarize_by_group(adata: AnnData, group_col: str, out_path: Path) -> None:
    numeric_cols = [c for c in adata.obs.columns if pd.api.types.is_numeric_dtype(adata.obs[c])]
    if not numeric_cols:
        return
    summary = adata.obs.groupby(group_col)[numeric_cols].median(numeric_only=True)
    summary.to_csv(out_path)


def plot_microglia_outputs(
    adata: AnnData,
    args: argparse.Namespace,
    outdirs: Dict[str, Path],
    gene_sets: Dict[str, List[str]],
    logger: logging.Logger,
) -> None:
    logger.info("Plotting microglia-stage outputs")

    # Core UMAPs
    sc.pl.umap(adata, color=["leiden", "state_hint"], legend_loc="on data", show=False)
    plt.savefig(outdirs["figures"] / f"{args.project_name}_microglia_umap_states.png", bbox_inches="tight")
    plt.close("all")

    module_cols = [c for c in [
        "homeostatic_score",
        "dam_phagocytic_score",
        "lysosome_score",
        "interferon_score",
        "proliferative_score",
        "bace1_node_score",
    ] if c in adata.obs.columns]
    if module_cols:
        sc.pl.umap(adata, color=module_cols, show=False)
        plt.savefig(outdirs["figures"] / f"{args.project_name}_microglia_umap_module_scores.png", bbox_inches="tight")
        plt.close("all")

    genes_to_show = []
    regulator_gene = gene_sets.get("regulator", [None])[0]
    bace1_gene = gene_sets.get("bace1_node", [None])[0]
    for g in [regulator_gene, bace1_gene]:
        if g is not None and present_genes(adata, [g]):
            genes_to_show.append(g)
    for g in ["Cd68", "Lamp1", "Ctsb", "Apoe", "P2ry12", "CD68", "LAMP1", "CTSB", "APOE", "P2RY12"]:
        if g not in genes_to_show and present_genes(adata, [g]):
            genes_to_show.append(g)
    genes_to_show = genes_to_show[:8]
    if genes_to_show:
        sc.pl.umap(adata, color=genes_to_show, show=False)
        plt.savefig(outdirs["figures"] / f"{args.project_name}_microglia_umap_axis_genes.png", bbox_inches="tight")
        plt.close("all")

    # Violin plots by state
    violin_cols = [c for c in [
        "homeostatic_score",
        "dam_phagocytic_score",
        "lysosome_score",
        "bace1_node_score",
    ] if c in adata.obs.columns]
    if violin_cols:
        sc.pl.violin(adata, violin_cols, groupby="state_hint", rotation=45, show=False)
        plt.savefig(outdirs["figures"] / f"{args.project_name}_microglia_violin_scores_by_state.png", bbox_inches="tight")
        plt.close("all")

    # Dotplot with key genes
    dotplot_genes = []
    for group in ["regulator", "bace1_node", "lysosome", "dam_phagocytic", "homeostatic"]:
        dotplot_genes.extend(present_genes(adata, gene_sets.get(group, []))[:4])
    dotplot_genes = list(dict.fromkeys(dotplot_genes))[:20]
    if dotplot_genes:
        sc.pl.dotplot(adata, var_names=dotplot_genes, groupby="state_hint", show=False)
        plt.savefig(outdirs["figures"] / f"{args.project_name}_microglia_dotplot_axis_by_state.png", bbox_inches="tight")
        plt.close("all")

    # Basic correlations
    regulator_gene = gene_sets.get("regulator", [None])[0]
    for gene, score_col, suffix in [
        (regulator_gene, "lysosome_score", "regulator_vs_lysosome"),
        (regulator_gene, "dam_phagocytic_score", "regulator_vs_dam"),
        (bace1_gene, "lysosome_score", "bace1_vs_lysosome"),
        (bace1_gene, "dam_phagocytic_score", "bace1_vs_dam"),
    ]:
        if gene and score_col in adata.obs.columns:
            vec = get_gene_vector(adata, gene)
            if vec is not None:
                x = vec
                y = adata.obs[score_col].values
                mask = np.isfinite(x) & np.isfinite(y)
                if mask.sum() > 10:
                    r = np.corrcoef(x[mask], y[mask])[0, 1]
                    plt.figure(figsize=(5, 4))
                    plt.scatter(x[mask], y[mask], s=6, alpha=0.35)
                    plt.xlabel(gene)
                    plt.ylabel(score_col)
                    plt.title(f"r = {r:.3f}")
                    plt.tight_layout()
                    plt.savefig(outdirs["figures"] / f"{args.project_name}_corr_{suffix}.png", bbox_inches="tight")
                    plt.close("all")


def export_summary_tables(
    adata: AnnData,
    args: argparse.Namespace,
    outdirs: Dict[str, Path],
    gene_sets: Dict[str, List[str]],
    selector_mode: str,
    logger: logging.Logger,
) -> None:
    logger.info("Exporting summary tables")

    # State counts
    if "state_hint" in adata.obs.columns:
        adata.obs["state_hint"].value_counts(dropna=False).rename_axis("state_hint").reset_index(name="n_cells").to_csv(
            outdirs["tables"] / f"{args.project_name}_microglia_state_counts.csv", index=False
        )

    # Cluster counts
    if "leiden" in adata.obs.columns:
        adata.obs["leiden"].value_counts().rename_axis("leiden").reset_index(name="n_cells").to_csv(
            outdirs["tables"] / f"{args.project_name}_microglia_cluster_counts.csv", index=False
        )

    # Median scores by state and cluster
    if "state_hint" in adata.obs.columns:
        summarize_by_group(adata, "state_hint", outdirs["tables"] / f"{args.project_name}_median_scores_by_state.csv")
    if "leiden" in adata.obs.columns:
        summarize_by_group(adata, "leiden", outdirs["tables"] / f"{args.project_name}_median_scores_by_cluster.csv")

    export_state_validation_tables(adata, args, outdirs, logger)

    # Optional donor/state table
    if args.donor_column and args.donor_column in adata.obs.columns:
        donor_state = pd.crosstab(adata.obs[args.donor_column], adata.obs.get("state_hint", pd.Series(index=adata.obs_names, data="NA")))
        donor_state.to_csv(outdirs["tables"] / f"{args.project_name}_cell_counts_by_donor_state.csv")

    # Optional donor/diagnosis summary
    validation_cols = [
        c for c in adata.obs.columns
        if c.startswith("leiden_res_") or c.startswith("state_raw_delta_") or c.startswith("state_zscore_delta_")
    ]
    meta_cols = [c for c in [args.donor_column, args.diagnosis_column, "state_hint", "leiden"] if c and c in adata.obs.columns]
    meta_cols = list(dict.fromkeys(meta_cols + validation_cols))
    if meta_cols:
        adata.obs[meta_cols].to_csv(outdirs["tables"] / f"{args.project_name}_obs_selected_metadata.csv")

    # Key gene expression table
    keys = []
    for group in ["regulator", "bace1_node", "lysosome", "dam_phagocytic", "homeostatic"]:
        keys.extend(gene_sets.get(group, []))
    keys = list(dict.fromkeys(keys))
    expr_rows = []
    for gene in keys:
        vec = get_gene_vector(adata, gene)
        if vec is not None:
            expr_rows.append({
                "gene": gene,
                "mean": float(np.nanmean(vec)),
                "median": float(np.nanmedian(vec)),
                "pct_nonzero": float((vec > 0).mean() * 100.0),
            })
    if expr_rows:
        pd.DataFrame(expr_rows).to_csv(outdirs["tables"] / f"{args.project_name}_key_gene_expression_summary.csv", index=False)

    # Pipeline run summary
    summary = {
        "project_name": args.project_name,
        "input_type": args.input_type,
        "input": args.input,
        "species": args.species,
        "selector_mode": selector_mode,
        "n_cells_final": int(adata.n_obs),
        "n_genes_final": int(adata.n_vars),
    }
    with open(outdirs["tables"] / f"{args.project_name}_run_summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)


# -----------------------------
# Main
# -----------------------------

def main() -> None:
    args = parse_args()
    output_dir = Path(args.output_dir)
    outdirs = setup_output_dirs(output_dir)
    logger = setup_logger(outdirs["logs"] / f"{args.project_name}.log")

    sc.settings.verbosity = 2
    sc.settings.set_figure_params(dpi=110, facecolor="white")

    logger.info("Starting pipeline")
    logger.info("Arguments: %s", vars(args))

    gene_sets = load_gene_sets(args.species, args.gene_sets_file, logger)
    save_gene_sets_table(gene_sets, outdirs["tables"] / f"{args.project_name}_gene_sets_used.csv")

    adata = load_input_data(args, logger)
    adata = run_basic_qc(adata, args, outdirs, logger)
    adata = normalize_for_clustering(adata, logger)
    adata = cluster_and_embed(adata, args, logger)
    plot_whole_dataset_outputs(adata, args, outdirs, logger)
    safe_write_h5ad(adata, outdirs["objects"] / f"{args.project_name}_whole_qc_clustered.h5ad", logger)

    microglia_adata, selector_mode = select_microglia_subset(adata, args, logger)
    if microglia_adata is None:
        logger.info("Pipeline finished at whole-dataset stage.")
        logger.info(
            "Next step: inspect whole-dataset outputs, identify microglia clusters using marker plots and the cluster marker table, then rerun with --microglia-clusters or a cell type selector."
        )
        return

    logger.info("Proceeding to microglia-stage analysis")
    # Re-cluster within microglia subset.
    microglia_adata = microglia_adata.copy()
    microglia_adata = cluster_and_embed(microglia_adata, args, logger)
    module_summary = score_modules(microglia_adata, gene_sets, logger)
    module_summary.to_csv(outdirs["tables"] / f"{args.project_name}_module_gene_coverage.csv", index=False)

    # Heuristic state hints.
    microglia_adata.obs["state_hint"] = heuristic_state_annotation(microglia_adata)
    add_state_validation_annotations(microglia_adata, args, logger)

    # Differential markers on microglia clusters and state hints.
    try:
        sc.tl.rank_genes_groups(microglia_adata, groupby="leiden", method="wilcoxon")
        rg_cluster = sc.get.rank_genes_groups_df(microglia_adata, group=None)
        rg_cluster.to_csv(outdirs["tables"] / f"{args.project_name}_microglia_cluster_markers.csv", index=False)
    except Exception as e:
        logger.warning("Could not compute microglia cluster markers: %s", e)

    try:
        sc.tl.rank_genes_groups(microglia_adata, groupby="state_hint", method="wilcoxon")
        rg_state = sc.get.rank_genes_groups_df(microglia_adata, group=None)
        rg_state.to_csv(outdirs["tables"] / f"{args.project_name}_microglia_state_markers.csv", index=False)
    except Exception as e:
        logger.warning("Could not compute microglia state markers: %s", e)

    plot_microglia_outputs(microglia_adata, args, outdirs, gene_sets, logger)
    export_summary_tables(microglia_adata, args, outdirs, gene_sets, selector_mode, logger)
    safe_write_h5ad(microglia_adata, outdirs["objects"] / f"{args.project_name}_microglia_final.h5ad", logger)

    logger.info("Pipeline completed successfully")
    logger.info("Main outputs are in: %s", output_dir)


if __name__ == "__main__":
    main()
