#!/usr/bin/env python
r"""
Advanced vector figure generator for the TF-regulator extension analysis.

Input folder expected:
    F:\AD\Mam San\results\tf_regulator_extension

Outputs:
    advanced_vector_figures/
        TF_regulator_advanced_multipage_editable.pdf
        Fig01_...pdf/svg/png
        Fig02_...pdf/svg/png
        Fig03_...pdf/svg/png, etc.

Notes:
- PDF/SVG outputs are vector/editable.
- PNG outputs are exported at 900 dpi for high-resolution raster use.
- Matplotlib PDF text is saved as TrueType text where possible (pdf.fonttype=42).
"""

from __future__ import annotations

import argparse
import math
import re
import textwrap
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

try:
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from matplotlib import cm, colors, gridspec, patches, patheffects
    from matplotlib.backends.backend_pdf import PdfPages
    from matplotlib.lines import Line2D
    from matplotlib.path import Path as MplPath
    from matplotlib.patches import PathPatch
except ImportError as exc:  # pragma: no cover
    raise SystemExit(
        "Matplotlib is required. Install it with:\n"
        "  conda install -c conda-forge matplotlib -y\n"
    ) from exc

try:
    from scipy.cluster.hierarchy import linkage, leaves_list
    from scipy.spatial.distance import pdist
except Exception:  # scipy is optional for plotting, but already in your environment
    linkage = None
    leaves_list = None
    pdist = None


# -----------------------------------------------------------------------------
# Global style: publication-oriented, vector-safe, editable text in PDF/SVG
# -----------------------------------------------------------------------------

mpl.rcParams.update(
    {
        "pdf.fonttype": 42,           # editable TrueType text in Illustrator/Inkscape
        "ps.fonttype": 42,
        "svg.fonttype": "none",     # keep SVG text editable
        "font.family": "DejaVu Sans",
        "font.size": 8,
        "axes.titlesize": 10,
        "axes.labelsize": 8,
        "xtick.labelsize": 7,
        "ytick.labelsize": 7,
        "axes.linewidth": 0.6,
        "xtick.major.width": 0.5,
        "ytick.major.width": 0.5,
        "figure.dpi": 160,
        "savefig.dpi": 900,
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.04,
        "legend.frameon": False,
    }
)

DATASET_ORDER = ["seaad", "olah", "gse98969", "gse140510"]
DATASET_LABELS = {
    "seaad": "SEA-AD human",
    "olah": "Olah human",
    "gse98969": "GSE98969 mouse",
    "gse140510": "GSE140510 mouse",
}

CATEGORY_ORDER = [
    "myeloid_core",
    "myeloid_inflammatory",
    "myeloid_homeostatic",
    "myeloid_activation",
    "interferon",
    "lysosomal_biogenesis",
    "exploratory_regulator",
]

CATEGORY_COLORS = {
    "myeloid_core": "#3B5B92",
    "myeloid_inflammatory": "#B14D3A",
    "myeloid_homeostatic": "#4E8B58",
    "myeloid_activation": "#7E5EA8",
    "interferon": "#2F8C99",
    "lysosomal_biogenesis": "#B9832D",
    "exploratory_regulator": "#707070",
    "unknown": "#BDBDBD",
}


def safe_name(text: str) -> str:
    text = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(text).strip())
    text = re.sub(r"_+", "_", text).strip("_")
    return text or "figure"


def read_csv_or_empty(path: Path) -> pd.DataFrame:
    if not path.exists():
        warnings.warn(f"Missing file: {path}")
        return pd.DataFrame()
    return pd.read_csv(path)


def to_bool(x) -> bool:
    if pd.isna(x):
        return False
    if isinstance(x, bool):
        return x
    return str(x).strip().lower() in {"true", "1", "yes", "y", "present"}


def as_float(x, default=np.nan):
    try:
        return float(x)
    except Exception:
        return default


def gene_label_df(df: pd.DataFrame) -> pd.DataFrame:
    """Add stable label and ordering columns to a TF table."""
    if df.empty:
        return df.copy()
    out = df.copy()
    for col in ["family", "gene", "category"]:
        if col not in out.columns:
            out[col] = "unknown"
    out["gene_label"] = out["family"].astype(str) + " [" + out["gene"].astype(str) + "]"
    cat_rank = {c: i for i, c in enumerate(CATEGORY_ORDER)}
    out["category_rank"] = out["category"].map(cat_rank).fillna(999).astype(int)
    return out


def ordered_datasets(df: pd.DataFrame) -> list[str]:
    if df.empty or "dataset" not in df.columns:
        return []
    values = list(dict.fromkeys(df["dataset"].astype(str)))
    ordered = [x for x in DATASET_ORDER if x in values]
    ordered += [x for x in values if x not in ordered]
    return ordered


def ordered_gene_labels(df: pd.DataFrame) -> list[str]:
    if df.empty:
        return []
    tmp = gene_label_df(df)
    cols = ["category_rank", "family", "gene", "gene_label"]
    return tmp.sort_values(cols)["gene_label"].drop_duplicates().tolist()


def gene_label_to_category(df: pd.DataFrame) -> dict[str, str]:
    if df.empty:
        return {}
    tmp = gene_label_df(df)
    return tmp.drop_duplicates("gene_label").set_index("gene_label")["category"].to_dict()


def label_dataset(ds: str) -> str:
    return DATASET_LABELS.get(ds, ds)


def luminance_from_rgba(rgba) -> float:
    r, g, b = rgba[:3]
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def add_panel_label(ax, label: str, x=-0.08, y=1.04):
    ax.text(
        x,
        y,
        label,
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=12,
        fontweight="bold",
    )


def draw_category_strip(ax, col_labels: list[str], cat_map: dict[str, str], height=0.18):
    """Draw vector category strip above a heatmap-like axis."""
    if not col_labels:
        return
    top = ax.inset_axes([0, 1.015, 1, height])
    top.set_xlim(0, len(col_labels))
    top.set_ylim(0, 1)
    for i, gene in enumerate(col_labels):
        cat = cat_map.get(gene, "unknown")
        top.add_patch(
            patches.Rectangle(
                (i, 0), 1, 1,
                facecolor=CATEGORY_COLORS.get(cat, CATEGORY_COLORS["unknown"]),
                edgecolor="white",
                lw=0.4,
            )
        )
    top.set_axis_off()


def category_legend_handles(categories: list[str] | None = None) -> list[patches.Patch]:
    cats = categories or CATEGORY_ORDER
    return [
        patches.Patch(
            facecolor=CATEGORY_COLORS.get(c, CATEGORY_COLORS["unknown"]),
            edgecolor="none",
            label=c.replace("_", " "),
        )
        for c in cats
    ]


EXPORT_DPI = 900

def save_figure(fig, out_dir: Path, name: str, multipdf: PdfPages | None = None, dpi: int | None = None) -> list[Path]:
    if dpi is None:
        dpi = EXPORT_DPI
    out_dir.mkdir(parents=True, exist_ok=True)
    base = out_dir / safe_name(name)
    written = []
    for ext in ["pdf", "svg", "png"]:
        path = base.with_suffix(f".{ext}")
        if ext == "png":
            fig.savefig(path, dpi=dpi, facecolor="white")
        else:
            fig.savefig(path, dpi=dpi, facecolor="white")
        written.append(path)
    if multipdf is not None:
        multipdf.savefig(fig, bbox_inches="tight", dpi=dpi, facecolor="white")
    plt.close(fig)
    return written


def add_index_entry(index_rows: list[dict], figure_id: str, title: str, description: str, files: list[Path]):
    index_rows.append(
        {
            "figure_id": figure_id,
            "title": title,
            "description": description,
            "files": ";".join(str(p.name) for p in files),
        }
    )


# -----------------------------------------------------------------------------
# Vector plot primitives
# -----------------------------------------------------------------------------


def rectangle_heatmap(
    ax,
    matrix: pd.DataFrame,
    cmap_name: str,
    norm,
    fmt: str = "{:.1f}",
    missing_hatch: str = "////",
    annotate: bool = True,
    text_threshold: float | None = None,
    linewidth: float = 0.45,
):
    """Draw an editable vector heatmap using one Rectangle patch per cell."""
    cmap = plt.get_cmap(cmap_name)
    n_rows, n_cols = matrix.shape
    ax.set_xlim(0, n_cols)
    ax.set_ylim(0, n_rows)
    ax.invert_yaxis()

    for r, row_name in enumerate(matrix.index):
        for c, col_name in enumerate(matrix.columns):
            val = matrix.loc[row_name, col_name]
            is_missing = pd.isna(val)
            if is_missing:
                face = "#F5F5F5"
                edge = "#C8C8C8"
                hatch = missing_hatch
            else:
                face = cmap(norm(val))
                edge = "#F3F3F3"
                hatch = None
            rect = patches.Rectangle(
                (c, r),
                1,
                1,
                facecolor=face,
                edgecolor=edge,
                lw=linewidth,
                hatch=hatch,
            )
            ax.add_patch(rect)
            if annotate and not is_missing:
                if text_threshold is None or abs(val) >= text_threshold:
                    txt_color = "white" if luminance_from_rgba(face) < 0.48 else "#1A1A1A"
                    ax.text(
                        c + 0.5,
                        r + 0.5,
                        fmt.format(val),
                        ha="center",
                        va="center",
                        color=txt_color,
                        fontsize=6,
                    )

    ax.set_xticks(np.arange(n_cols) + 0.5)
    ax.set_xticklabels(matrix.columns, rotation=60, ha="right", rotation_mode="anchor")
    ax.set_yticks(np.arange(n_rows) + 0.5)
    ax.set_yticklabels(matrix.index)
    ax.tick_params(length=0)
    for spine in ax.spines.values():
        spine.set_visible(False)


def dot_matrix(
    ax,
    x_labels: list[str],
    y_labels: list[str],
    color_values: pd.DataFrame,
    size_values: pd.DataFrame | None,
    cmap_name: str,
    norm,
    min_size: float = 8,
    max_size: float = 260,
    missing_alpha: float = 0.12,
    edgecolor: str = "#333333",
):
    cmap = plt.get_cmap(cmap_name)
    x_lookup = {x: i for i, x in enumerate(x_labels)}
    y_lookup = {y: i for i, y in enumerate(y_labels)}

    for y in y_labels:
        for x in x_labels:
            if y not in color_values.index or x not in color_values.columns:
                continue
            v = color_values.loc[y, x]
            if pd.isna(v):
                ax.scatter(
                    x_lookup[x],
                    y_lookup[y],
                    s=min_size,
                    facecolor="#EAEAEA",
                    edgecolor="none",
                    alpha=missing_alpha,
                )
                continue
            if size_values is None or y not in size_values.index or x not in size_values.columns:
                s_val = 0.5
            else:
                s_val = size_values.loc[y, x]
                if pd.isna(s_val):
                    s_val = 0.0
            size = min_size + (max_size - min_size) * min(max(float(s_val) / 100.0, 0), 1)
            ax.scatter(
                x_lookup[x],
                y_lookup[y],
                s=size,
                facecolor=cmap(norm(v)),
                edgecolor=edgecolor,
                linewidth=0.35,
            )
    ax.set_xlim(-0.5, len(x_labels) - 0.5)
    ax.set_ylim(-0.5, len(y_labels) - 0.5)
    ax.invert_yaxis()
    ax.set_xticks(range(len(x_labels)))
    ax.set_xticklabels(x_labels, rotation=60, ha="right", rotation_mode="anchor")
    ax.set_yticks(range(len(y_labels)))
    ax.set_yticklabels(y_labels)
    ax.grid(which="major", color="#D9D9D9", linewidth=0.35)
    ax.set_axisbelow(True)
    for spine in ax.spines.values():
        spine.set_visible(False)


def cluster_rows(matrix: pd.DataFrame) -> list[str]:
    """Hierarchical state ordering; gracefully falls back to original order."""
    if matrix.shape[0] < 3 or matrix.shape[1] < 2 or linkage is None or leaves_list is None or pdist is None:
        return matrix.index.tolist()
    x = matrix.fillna(0).to_numpy(dtype=float)
    # Standardize columns so highly expressed genes do not dominate the state order.
    std = x.std(axis=0)
    std[std == 0] = 1.0
    x = (x - x.mean(axis=0)) / std
    try:
        dist = pdist(x, metric="correlation")
        if not np.isfinite(dist).all():
            return matrix.index.tolist()
        order = leaves_list(linkage(dist, method="average"))
        return matrix.index[order].tolist()
    except Exception:
        return matrix.index.tolist()


# -----------------------------------------------------------------------------
# Figure builders
# -----------------------------------------------------------------------------


def figure_final_detectability(final_detection: pd.DataFrame, out_dir: Path, multipdf, index_rows):
    if final_detection.empty:
        return
    df = gene_label_df(final_detection)
    df["dataset"] = df["dataset"].astype(str)
    df["present"] = df.get("present", True).map(to_bool)
    genes = ordered_gene_labels(df)
    datasets = ordered_datasets(df)
    cat_map = gene_label_to_category(df)

    det = df.pivot_table(index="dataset", columns="gene_label", values="detection_pct", aggfunc="first")
    present = df.pivot_table(index="dataset", columns="gene_label", values="present", aggfunc="first")
    det = det.reindex(index=datasets, columns=genes)
    present = present.reindex(index=datasets, columns=genes).fillna(False)
    det = det.where(present.astype(bool))
    det.index = [label_dataset(x) for x in det.index]

    max_det = np.nanmax(det.to_numpy(dtype=float)) if np.isfinite(det.to_numpy(dtype=float)).any() else 100
    vmax = max(10, min(100, math.ceil(max_det / 10) * 10))

    width = max(11.0, 0.58 * len(genes) + 3.8)
    height = max(4.6, 0.65 * len(datasets) + 2.6)
    fig, ax = plt.subplots(figsize=(width, height), constrained_layout=True)
    norm = colors.Normalize(vmin=0, vmax=vmax)
    rectangle_heatmap(ax, det, "viridis", norm, fmt="{:.1f}", annotate=True)
    draw_category_strip(ax, genes, cat_map)
    ax.set_title("Final microglia objects: TF/regulator detectability", loc="left", fontweight="bold", pad=22)
    ax.set_xlabel("Focused transcription-regulator panel")
    ax.set_ylabel("Dataset")
    add_panel_label(ax, "A")

    sm = cm.ScalarMappable(norm=norm, cmap="viridis")
    sm.set_array([])
    cbar = fig.colorbar(sm, ax=ax, fraction=0.025, pad=0.015)
    cbar.set_label("Detection (% cells)")

    handles = category_legend_handles([c for c in CATEGORY_ORDER if c in set(cat_map.values())])
    handles.append(patches.Patch(facecolor="#F5F5F5", edgecolor="#888888", hatch="////", label="not detected / missing"))
    ax.legend(handles=handles, loc="upper left", bbox_to_anchor=(0, -0.34), ncol=3, title="Regulator category")

    files = save_figure(fig, out_dir, "Fig01_final_h5ad_TF_detectability_vector_heatmap", multipdf)
    add_index_entry(index_rows, "Fig01", "Final TF detectability heatmap", "Vector heatmap of final h5ad detection percentages with category strip and missing-gene hatching.", files)


def figure_marker_state_effect(marker_summary: pd.DataFrame, final_detection: pd.DataFrame, out_dir: Path, multipdf, index_rows):
    if marker_summary.empty:
        return
    df = gene_label_df(marker_summary)
    genes = ordered_gene_labels(final_detection if not final_detection.empty else df)
    datasets = ordered_datasets(df)

    # Prefer signed largest absolute effect where available. Fall back to top-positive LFC.
    if "largest_abs_logfoldchange" not in df.columns:
        df["largest_abs_logfoldchange"] = np.nan
    if "top_positive_logfoldchange" not in df.columns:
        df["top_positive_logfoldchange"] = np.nan
    df["effect_lfc"] = df["largest_abs_logfoldchange"].apply(as_float)
    df.loc[df["effect_lfc"].isna(), "effect_lfc"] = df.loc[df["effect_lfc"].isna(), "top_positive_logfoldchange"].apply(as_float)
    df["abs_lfc"] = df["effect_lfc"].abs()
    df["n_positive_fdr_states"] = df.get("n_positive_fdr_states", 0).apply(lambda x: int(as_float(x, 0)))
    df["top_positive_state"] = df.get("top_positive_state", "").fillna("").astype(str)
    df["top_positive_padj"] = df.get("top_positive_padj", np.nan).apply(as_float)

    max_abs = df["effect_lfc"].abs().max()
    if not np.isfinite(max_abs) or max_abs == 0:
        max_abs = 1.0
    norm = colors.TwoSlopeNorm(vmin=-max_abs, vcenter=0, vmax=max_abs)
    cmap = plt.get_cmap("coolwarm")

    width = max(11.0, 0.62 * len(genes) + 3.5)
    height = max(4.8, 0.72 * len(datasets) + 2.8)
    fig, ax = plt.subplots(figsize=(width, height), constrained_layout=True)

    x_lookup = {g: i for i, g in enumerate(genes)}
    y_lookup = {d: i for i, d in enumerate(datasets)}
    ax.set_xlim(-0.5, len(genes) - 0.5)
    ax.set_ylim(-0.5, len(datasets) - 0.5)
    ax.invert_yaxis()

    # Background grid is vector and helps figure editing.
    for xi in range(len(genes)):
        for yi in range(len(datasets)):
            ax.add_patch(patches.Rectangle((xi - 0.5, yi - 0.5), 1, 1, facecolor="#FAFAFA", edgecolor="#E4E4E4", lw=0.35))

    for _, row in df.iterrows():
        g = row["gene_label"]
        d = str(row["dataset"])
        if g not in x_lookup or d not in y_lookup:
            continue
        effect = as_float(row["effect_lfc"])
        marker_rows = int(as_float(row.get("marker_rows", 0), 0))
        x = x_lookup[g]
        y = y_lookup[d]
        if marker_rows <= 0 or not np.isfinite(effect):
            ax.scatter(x, y, s=28, marker="x", color="#B0B0B0", linewidth=0.75)
            continue
        size = 35 + 210 * min(abs(effect) / max_abs, 1.0)
        edge = "#111111" if row["n_positive_fdr_states"] > 0 else "#777777"
        lw = 0.95 if row["n_positive_fdr_states"] > 0 else 0.35
        ax.scatter(x, y, s=size, c=[cmap(norm(effect))], edgecolor=edge, linewidth=lw, zorder=3)
        if row["n_positive_fdr_states"] > 0:
            state = row["top_positive_state"][:12]
            if state:
                ax.text(x, y + 0.33, state, ha="center", va="top", fontsize=5.6, color="#222222")
            ax.text(x, y - 0.30, "*", ha="center", va="bottom", fontsize=10, fontweight="bold", color="#111111")

    ax.set_xticks(range(len(genes)))
    ax.set_xticklabels(genes, rotation=60, ha="right", rotation_mode="anchor")
    ax.set_yticks(range(len(datasets)))
    ax.set_yticklabels([label_dataset(x) for x in datasets])
    ax.tick_params(length=0)
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.set_title("Marker-table state association: effect size and FDR-supported states", loc="left", fontweight="bold")
    ax.set_xlabel("Focused transcription-regulator panel")
    ax.set_ylabel("Dataset")
    add_panel_label(ax, "B")

    sm = cm.ScalarMappable(norm=norm, cmap="coolwarm")
    sm.set_array([])
    cbar = fig.colorbar(sm, ax=ax, fraction=0.025, pad=0.015)
    cbar.set_label("Largest signed log-fold change")

    # Size legend
    example_vals = [round(max_abs * f, 2) for f in [0.25, 0.5, 1.0]]
    size_handles = [
        plt.scatter([], [], s=35 + 210 * min(v / max_abs, 1.0), facecolor="#D0D0D0", edgecolor="#333333", linewidth=0.45, label=f"|LFC| {v:g}")
        for v in example_vals
    ]
    sig_handle = Line2D([0], [0], marker="o", color="none", markerfacecolor="#D0D0D0", markeredgecolor="#111111", markeredgewidth=1.0, label="positive FDR<0.05 state")
    missing_handle = Line2D([0], [0], marker="x", color="#B0B0B0", linestyle="none", label="not in marker table")
    ax.legend(handles=size_handles + [sig_handle, missing_handle], loc="upper left", bbox_to_anchor=(0, -0.34), ncol=3)

    files = save_figure(fig, out_dir, "Fig02_marker_table_state_effect_advanced_bubble_grid", multipdf)
    add_index_entry(index_rows, "Fig02", "Marker-state association bubble grid", "Bubble grid encoding signed log-fold change, effect magnitude, and FDR-supported positive states.", files)


def figure_state_expression_dotplots(state_expr: pd.DataFrame, final_detection: pd.DataFrame, out_dir: Path, multipdf, index_rows):
    if state_expr.empty:
        return
    df = gene_label_df(state_expr)
    all_genes = ordered_gene_labels(final_detection if not final_detection.empty else df)
    cat_map = gene_label_to_category(final_detection if not final_detection.empty else df)

    for ds in ordered_datasets(df):
        sub = df.loc[df["dataset"].astype(str) == ds].copy()
        if sub.empty:
            continue
        if "state" not in sub.columns:
            continue
        sub["state"] = sub["state"].astype(str)
        sub["mean_expression"] = sub.get("mean_expression", np.nan).apply(as_float)
        sub["state_detection_pct"] = sub.get("state_detection_pct", np.nan).apply(as_float)

        # Keep genes present in this dataset, but preserve global order.
        genes_here = [g for g in all_genes if g in set(sub["gene_label"])]
        mean_mat = sub.pivot_table(index="state", columns="gene_label", values="mean_expression", aggfunc="mean").reindex(columns=genes_here)
        det_mat = sub.pivot_table(index="state", columns="gene_label", values="state_detection_pct", aggfunc="mean").reindex(columns=genes_here)
        if mean_mat.empty:
            continue
        state_order = cluster_rows(np.log1p(mean_mat.fillna(0)))
        mean_mat = mean_mat.reindex(index=state_order)
        det_mat = det_mat.reindex(index=state_order)
        color_mat = np.log1p(mean_mat)
        vmax = float(np.nanpercentile(color_mat.to_numpy(dtype=float), 98)) if np.isfinite(color_mat.to_numpy(dtype=float)).any() else 1.0
        if vmax <= 0 or not np.isfinite(vmax):
            vmax = 1.0
        norm = colors.Normalize(vmin=0, vmax=vmax)

        width = max(12.0, 0.62 * len(genes_here) + 4.2)
        height = max(5.2, 0.34 * len(state_order) + 3.2)
        fig, ax = plt.subplots(figsize=(width, height), constrained_layout=True)
        dot_matrix(ax, genes_here, state_order, color_mat, det_mat, "magma", norm, min_size=10, max_size=260)
        draw_category_strip(ax, genes_here, cat_map)
        ax.set_title(f"{label_dataset(ds)}: state-resolved TF expression and detection", loc="left", fontweight="bold", pad=22)
        ax.set_xlabel("Focused transcription-regulator panel")
        ax.set_ylabel("Microglia state")
        add_panel_label(ax, "C")

        sm = cm.ScalarMappable(norm=norm, cmap="magma")
        sm.set_array([])
        cbar = fig.colorbar(sm, ax=ax, fraction=0.025, pad=0.015)
        cbar.set_label("log1p(mean expression)")

        size_handles = [
            plt.scatter([], [], s=10 + (260 - 10) * s / 100, facecolor="#BDBDBD", edgecolor="#333333", linewidth=0.35, label=f"{s}%")
            for s in [5, 25, 50, 75]
        ]
        cat_handles = category_legend_handles([c for c in CATEGORY_ORDER if c in set(cat_map.values())])
        leg1 = ax.legend(handles=size_handles, title="Detection", loc="upper left", bbox_to_anchor=(0, -0.35), ncol=4)
        ax.add_artist(leg1)
        ax.legend(handles=cat_handles, title="Category", loc="upper left", bbox_to_anchor=(0.42, -0.35), ncol=3)

        fig_name = f"Fig03_state_expression_dotplot_{safe_name(ds)}"
        files = save_figure(fig, out_dir, fig_name, multipdf)
        add_index_entry(index_rows, f"Fig03_{ds}", f"{label_dataset(ds)} state expression dotplot", "Dot size shows state-level detection percentage; dot color shows log1p mean expression; rows are clustered by TF expression pattern.", files)


def figure_sample_module_correlation_heatmaps(correlations: pd.DataFrame, final_detection: pd.DataFrame, out_dir: Path, multipdf, index_rows):
    if correlations.empty:
        return
    df = gene_label_df(correlations)
    df["spearman_rho"] = df.get("spearman_rho", np.nan).apply(as_float)
    df["spearman_pvalue"] = df.get("spearman_pvalue", np.nan).apply(as_float)
    datasets = ordered_datasets(df)
    genes = ordered_gene_labels(final_detection if not final_detection.empty else df)
    modules = sorted(df["module_score"].dropna().astype(str).unique().tolist()) if "module_score" in df.columns else []
    if not datasets or not modules:
        return

    n_panels = len(datasets)
    n_cols = 2 if n_panels > 1 else 1
    n_rows = int(math.ceil(n_panels / n_cols))
    fig_w = max(13.0, 4.8 * n_cols + 2.2)
    fig_h = max(8.0, 0.34 * len(genes) * n_rows + 2.8)
    fig = plt.figure(figsize=(fig_w, fig_h), constrained_layout=True)
    gs = gridspec.GridSpec(n_rows, n_cols, figure=fig)
    norm = colors.TwoSlopeNorm(vmin=-1, vcenter=0, vmax=1)

    for i, ds in enumerate(datasets):
        ax = fig.add_subplot(gs[i // n_cols, i % n_cols])
        sub = df.loc[df["dataset"].astype(str) == ds]
        mat = sub.pivot_table(index="gene_label", columns="module_score", values="spearman_rho", aggfunc="first")
        pmat = sub.pivot_table(index="gene_label", columns="module_score", values="spearman_pvalue", aggfunc="first")
        mat = mat.reindex(index=[g for g in genes if g in mat.index], columns=modules)
        pmat = pmat.reindex(index=mat.index, columns=modules)
        rectangle_heatmap(ax, mat, "coolwarm", norm, fmt="{:.2f}", annotate=True, text_threshold=0.2, linewidth=0.35)

        # Add significance outlines without rasterization.
        for r, g in enumerate(mat.index):
            for c, m in enumerate(mat.columns):
                p = pmat.loc[g, m] if g in pmat.index and m in pmat.columns else np.nan
                if np.isfinite(p) and p < 0.05:
                    ax.add_patch(patches.Rectangle((c + 0.06, r + 0.06), 0.88, 0.88, fill=False, edgecolor="#111111", lw=0.75))
        ax.set_title(label_dataset(ds), loc="left", fontweight="bold")
        ax.set_xlabel("Module score")
        ax.set_ylabel("Regulator")
        if i == 0:
            add_panel_label(ax, "D")

    sm = cm.ScalarMappable(norm=norm, cmap="coolwarm")
    sm.set_array([])
    cbar = fig.colorbar(sm, ax=fig.axes, fraction=0.020, pad=0.010)
    cbar.set_label("Spearman rho")
    fig.suptitle("Sample-level TF/module coupling across datasets", x=0.02, ha="left", fontweight="bold", fontsize=11)

    files = save_figure(fig, out_dir, "Fig04_sample_level_TF_module_correlation_heatmaps", multipdf)
    add_index_entry(index_rows, "Fig04", "Sample-level TF/module correlation heatmaps", "Faceted vector heatmaps of Spearman rho between TF expression and module scores; black outlines indicate p<0.05.", files)


def draw_bezier_edge(ax, x0, y0, x1, y1, color, lw, alpha=0.85):
    dx = x1 - x0
    verts = [(x0, y0), (x0 + dx * 0.48, y0), (x1 - dx * 0.48, y1), (x1, y1)]
    codes = [MplPath.MOVETO, MplPath.CURVE4, MplPath.CURVE4, MplPath.CURVE4]
    path = MplPath(verts, codes)
    patch = PathPatch(path, facecolor="none", edgecolor=color, lw=lw, alpha=alpha, capstyle="round")
    ax.add_patch(patch)


def figure_correlation_networks(correlations: pd.DataFrame, out_dir: Path, multipdf, index_rows, min_abs_rho: float = 0.4, max_edges: int = 40):
    if correlations.empty:
        return
    df = gene_label_df(correlations)
    df["spearman_rho"] = df.get("spearman_rho", np.nan).apply(as_float)
    df["spearman_pvalue"] = df.get("spearman_pvalue", np.nan).apply(as_float)
    datasets = ordered_datasets(df)
    cmap = plt.get_cmap("coolwarm")
    norm = colors.TwoSlopeNorm(vmin=-1, vcenter=0, vmax=1)

    for ds in datasets:
        sub = df.loc[df["dataset"].astype(str) == ds].copy()
        sub = sub.loc[np.isfinite(sub["spearman_rho"])]
        sub = sub.loc[sub["spearman_rho"].abs() >= min_abs_rho]
        if sub.empty:
            sub = df.loc[df["dataset"].astype(str) == ds].copy()
            sub = sub.loc[np.isfinite(sub["spearman_rho"])].sort_values("spearman_rho", key=lambda s: s.abs(), ascending=False).head(min(12, max_edges))
        else:
            sub = sub.sort_values("spearman_rho", key=lambda s: s.abs(), ascending=False).head(max_edges)
        if sub.empty or "module_score" not in sub.columns:
            continue

        genes = sub.groupby("gene_label")["spearman_rho"].apply(lambda s: s.abs().max()).sort_values(ascending=False).index.tolist()
        modules = sub.groupby("module_score")["spearman_rho"].apply(lambda s: s.abs().max()).sort_values(ascending=False).index.tolist()
        max_nodes = max(len(genes), len(modules), 2)
        fig_h = max(6.5, 0.38 * max_nodes + 2.4)
        fig, ax = plt.subplots(figsize=(10.5, fig_h), constrained_layout=True)
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.axis("off")

        y_genes = np.linspace(0.92, 0.08, len(genes)) if len(genes) > 1 else np.array([0.5])
        y_modules = np.linspace(0.92, 0.08, len(modules)) if len(modules) > 1 else np.array([0.5])
        gene_pos = {g: (0.18, y) for g, y in zip(genes, y_genes)}
        mod_pos = {m: (0.82, y) for m, y in zip(modules, y_modules)}

        # Edges first so nodes/text remain on top.
        for _, row in sub.iterrows():
            g = row["gene_label"]
            m = row["module_score"]
            rho = row["spearman_rho"]
            if g not in gene_pos or m not in mod_pos:
                continue
            x0, y0 = gene_pos[g]
            x1, y1 = mod_pos[m]
            lw = 0.6 + 5.0 * min(abs(rho), 1.0)
            draw_bezier_edge(ax, x0 + 0.065, y0, x1 - 0.065, y1, cmap(norm(rho)), lw)

        def draw_node(label, pos, side):
            x, y = pos
            rect_w = 0.26 if side == "left" else 0.30
            x0 = x - rect_w if side == "right" else x
            ax.add_patch(
                patches.FancyBboxPatch(
                    (x0, y - 0.018),
                    rect_w,
                    0.036,
                    boxstyle="round,pad=0.007,rounding_size=0.008",
                    facecolor="white",
                    edgecolor="#222222",
                    lw=0.55,
                    zorder=5,
                )
            )
            ha = "left" if side == "left" else "right"
            tx = x0 + 0.006 if side == "left" else x0 + rect_w - 0.006
            ax.text(tx, y, label, ha=ha, va="center", fontsize=7, zorder=6)

        for g, pos in gene_pos.items():
            draw_node(g, pos, "left")
        for m, pos in mod_pos.items():
            draw_node(m, pos, "right")

        ax.text(0.18, 0.985, "Regulator", ha="left", va="bottom", fontweight="bold")
        ax.text(0.82, 0.985, "Module score", ha="right", va="bottom", fontweight="bold")
        ax.set_title(
            f"{label_dataset(ds)}: TF/module correlation network (|rho| >= {min_abs_rho:g}; top {max_edges})",
            loc="left",
            fontweight="bold",
        )
        add_panel_label(ax, "E", x=-0.02, y=1.02)

        sm = cm.ScalarMappable(norm=norm, cmap="coolwarm")
        sm.set_array([])
        cbar = fig.colorbar(sm, ax=ax, fraction=0.025, pad=0.01)
        cbar.set_label("Spearman rho")

        fig_name = f"Fig05_TF_module_correlation_network_{safe_name(ds)}"
        files = save_figure(fig, out_dir, fig_name, multipdf)
        add_index_entry(index_rows, f"Fig05_{ds}", f"{label_dataset(ds)} TF/module network", "Vector network summarizing strongest sample-level TF/module correlations; edge color indicates direction and edge width indicates magnitude.", files)


def figure_raw_detection_evidence(raw140: pd.DataFrame, raw989: pd.DataFrame, out_dir: Path, multipdf, index_rows):
    if raw140.empty and raw989.empty:
        return

    fig = plt.figure(figsize=(14.0, 9.0), constrained_layout=True)
    gs = gridspec.GridSpec(2, 1, height_ratios=[1.25, 1.0], figure=fig)
    fig.suptitle("Raw-data regulator evidence before final object filtering", x=0.02, ha="left", fontweight="bold", fontsize=11)

    if not raw140.empty:
        ax1 = fig.add_subplot(gs[0, 0])
        d1 = gene_label_df(raw140)
        d1["detection_pct"] = d1.get("detection_pct", np.nan).apply(as_float)
        d1["present_in_features"] = d1.get("present_in_features", True).map(to_bool)
        samples = sorted(d1["sample"].dropna().astype(str).unique().tolist()) if "sample" in d1.columns else []
        genes = ordered_gene_labels(d1)
        color_mat = d1.pivot_table(index="gene_label", columns="sample", values="detection_pct", aggfunc="mean").reindex(index=genes, columns=samples)
        present = d1.pivot_table(index="gene_label", columns="sample", values="present_in_features", aggfunc="first").reindex(index=genes, columns=samples).fillna(False)
        vmax = float(np.nanpercentile(color_mat.to_numpy(dtype=float), 98)) if np.isfinite(color_mat.to_numpy(dtype=float)).any() else 1.0
        if vmax <= 0 or not np.isfinite(vmax):
            vmax = 1.0
        norm = colors.Normalize(vmin=0, vmax=vmax)
        cmap = plt.get_cmap("cividis")
        for yi, g in enumerate(genes):
            for xi, s in enumerate(samples):
                val = color_mat.loc[g, s]
                is_present = to_bool(present.loc[g, s])
                if not is_present:
                    ax1.scatter(xi, yi, s=30, marker="x", color="#B0B0B0", linewidth=0.7)
                elif np.isfinite(val):
                    size = 18 + 190 * min(val / max(vmax, 1e-9), 1.0)
                    ax1.scatter(xi, yi, s=size, facecolor=cmap(norm(val)), edgecolor="#333333", linewidth=0.3)
        ax1.set_xlim(-0.5, len(samples) - 0.5)
        ax1.set_ylim(-0.5, len(genes) - 0.5)
        ax1.invert_yaxis()
        ax1.set_xticks(range(len(samples)))
        ax1.set_xticklabels(samples, rotation=45, ha="right")
        ax1.set_yticks(range(len(genes)))
        ax1.set_yticklabels(genes)
        ax1.grid(color="#E2E2E2", linewidth=0.35)
        ax1.set_axisbelow(True)
        for spine in ax1.spines.values():
            spine.set_visible(False)
        ax1.set_title("GSE140510 raw 10x files: sample-level TF detection", loc="left", fontweight="bold")
        ax1.set_ylabel("Regulator")
        ax1.set_xlabel("Raw sample")
        add_panel_label(ax1, "F")
        sm1 = cm.ScalarMappable(norm=norm, cmap="cividis")
        sm1.set_array([])
        cbar1 = fig.colorbar(sm1, ax=ax1, fraction=0.025, pad=0.010)
        cbar1.set_label("Detection (% cells)")
    else:
        ax1 = fig.add_subplot(gs[0, 0])
        ax1.axis("off")
        ax1.text(0.5, 0.5, "GSE140510 raw file not available", ha="center", va="center")

    if not raw989.empty:
        ax2 = fig.add_subplot(gs[1, 0])
        d2 = gene_label_df(raw989)
        if "sample" in d2.columns:
            d2 = d2.loc[d2["sample"].astype(str) == "ALL_RAW_MATRICES"].copy()
        d2["detection_pct"] = d2.get("detection_pct", np.nan).apply(as_float)
        d2["present_in_matrix"] = d2.get("present_in_matrix", True).map(to_bool)
        genes = ordered_gene_labels(d2)
        d2 = d2.set_index("gene_label").reindex(genes).reset_index()
        y = np.arange(len(d2))
        vals = d2["detection_pct"].fillna(0).to_numpy(dtype=float)
        present = d2["present_in_matrix"].map(to_bool).to_numpy()
        vmax = max(1, float(np.nanmax(vals)) if np.isfinite(vals).any() else 1)
        norm2 = colors.Normalize(vmin=0, vmax=vmax)
        cmap2 = plt.get_cmap("cividis")
        for yi, val, pres in zip(y, vals, present):
            ax2.plot([0, val], [yi, yi], color="#BDBDBD", lw=1.1, zorder=1)
            if pres:
                ax2.scatter(val, yi, s=60 + 160 * val / max(vmax, 1e-9), facecolor=cmap2(norm2(val)), edgecolor="#222222", linewidth=0.35, zorder=3)
                ax2.text(val + 0.6, yi, f"{val:.2f}%", va="center", fontsize=7)
            else:
                ax2.scatter(0, yi, s=42, marker="x", color="#B0B0B0", linewidth=0.8, zorder=3)
                ax2.text(0.6, yi, "not present", va="center", fontsize=7, color="#777777")
        ax2.set_yticks(y)
        ax2.set_yticklabels(d2["gene_label"].tolist())
        ax2.invert_yaxis()
        ax2.set_xlim(0, max(vmax * 1.18, 5))
        ax2.grid(axis="x", color="#E2E2E2", linewidth=0.35)
        for spine in ax2.spines.values():
            spine.set_visible(False)
        ax2.set_title("GSE98969 raw extracted matrices: aggregate detection", loc="left", fontweight="bold")
        ax2.set_xlabel("Aggregate detection (% cells)")
        ax2.set_ylabel("Regulator")
        add_panel_label(ax2, "G")
    else:
        ax2 = fig.add_subplot(gs[1, 0])
        ax2.axis("off")
        ax2.text(0.5, 0.5, "GSE98969 raw matrix summary not available", ha="center", va="center")

    files = save_figure(fig, out_dir, "Fig06_raw_detection_evidence_advanced_panel", multipdf)
    add_index_entry(index_rows, "Fig06", "Raw detection evidence panel", "Two-part raw-data evidence figure: sample-level GSE140510 detection dot map and GSE98969 aggregate lollipop panel.", files)


def write_methods_note(out_dir: Path, input_dir: Path):
    note = f"""
Advanced TF-regulator vector figures
===================================

Input directory:
{input_dir}

Output directory:
{out_dir}

Export details:
- PDF and SVG files are vector/editable.
- PNG files were exported at 900 dpi.
- Matplotlib was configured with pdf.fonttype=42 and svg.fonttype='none' to keep text editable where supported.
- Heatmaps are drawn as individual vector rectangles rather than raster images.
- Dot plots, bubble plots, lollipop plots, and networks are vector artists.

Recommended manuscript use:
- Use PDF/SVG for Illustrator, Inkscape, Affinity Designer, CorelDRAW, or PowerPoint editing.
- Use PNG only for preview or raster submission portals requiring fixed resolution.
- For journal submission, prefer individual PDF panels or SVG files; combine/edit labels in Illustrator/Inkscape/PowerPoint.
""".strip()
    (out_dir / "README_advanced_figure_exports.txt").write_text(note + "\n", encoding="utf-8")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Generate advanced editable vector figures from TF-regulator extension CSV outputs.")
    parser.add_argument(
        "--input-dir",
        default=r"F:\AD\Mam San\results\tf_regulator_extension",
        help="Folder containing 01-10 TF-regulator extension output files.",
    )
    parser.add_argument(
        "--out-dir",
        default=None,
        help="Output folder. Defaults to <input-dir>/advanced_vector_figures.",
    )
    parser.add_argument("--dpi", type=int, default=900, help="DPI for PNG export. PDF/SVG remain vector.")
    parser.add_argument("--min-rho", type=float, default=0.4, help="Minimum |rho| for network edges.")
    parser.add_argument("--max-network-edges", type=int, default=40, help="Maximum edges per dataset network.")
    args = parser.parse_args(argv)

    global EXPORT_DPI
    EXPORT_DPI = args.dpi

    input_dir = Path(args.input_dir)
    out_dir = Path(args.out_dir) if args.out_dir else input_dir / "advanced_vector_figures"
    out_dir.mkdir(parents=True, exist_ok=True)

    raw140 = read_csv_or_empty(input_dir / "01_raw_gse140510_10x_tf_detection.csv")
    raw989 = read_csv_or_empty(input_dir / "02_raw_gse98969_matrix_tf_detection.csv")
    final_detection = read_csv_or_empty(input_dir / "04_final_h5ad_tf_detection.csv")
    state_expr = read_csv_or_empty(input_dir / "05_final_state_tf_mean_expression.csv")
    marker_summary = read_csv_or_empty(input_dir / "06_marker_table_tf_state_summary.csv")
    correlations = read_csv_or_empty(input_dir / "07_sample_level_tf_module_correlations.csv")

    index_rows: list[dict] = []
    multipage_pdf = out_dir / "TF_regulator_advanced_multipage_editable.pdf"

    print(f"Reading TF-regulator outputs from: {input_dir}")
    print(f"Writing advanced vector figures to: {out_dir}")

    with PdfPages(multipage_pdf) as multipdf:
        figure_final_detectability(final_detection, out_dir, multipdf, index_rows)
        figure_marker_state_effect(marker_summary, final_detection, out_dir, multipdf, index_rows)
        figure_state_expression_dotplots(state_expr, final_detection, out_dir, multipdf, index_rows)
        figure_sample_module_correlation_heatmaps(correlations, final_detection, out_dir, multipdf, index_rows)
        figure_correlation_networks(correlations, out_dir, multipdf, index_rows, min_abs_rho=args.min_rho, max_edges=args.max_network_edges)
        figure_raw_detection_evidence(raw140, raw989, out_dir, multipdf, index_rows)

    pd.DataFrame(index_rows).to_csv(out_dir / "advanced_figure_index.csv", index=False)
    write_methods_note(out_dir, input_dir)

    print("\nDone.")
    print(f"Multipage editable vector PDF:\n  {multipage_pdf}")
    print(f"Individual PDF/SVG/900-dpi PNG panels:\n  {out_dir}")
    print("Open advanced_figure_index.csv for a panel-by-panel inventory.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
