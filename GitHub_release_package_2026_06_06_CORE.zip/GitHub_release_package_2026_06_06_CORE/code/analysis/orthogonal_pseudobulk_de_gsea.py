#!/usr/bin/env python3
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import scanpy as sc
from scipy import sparse
from scipy.stats import mannwhitneyu

GENESETS = {
    "mouse": {"lysosome": ["Ctsb","Ctsd","Lamp1","Lamp2","Cd68","Hexa","Hexb","Atp6v1b2","Atp6v0d1"], "dam_phagocytic": ["Apoe","Trem2","Tyrobp","Cst7","Lpl","Itgax","Axl","Gpnmb","Fcer1g"], "homeostatic": ["P2ry12","Tmem119","Cx3cr1","Csf1r","Selplg"]},
    "human": {"lysosome": ["CTSB","CTSD","LAMP1","LAMP2","CD68","HEXA","HEXB","ATP6V1B2","ATP6V0D1"], "dam_phagocytic": ["APOE","TREM2","TYROBP","CST7","LPL","ITGAX","AXL","GPNMB","FCER1G"], "homeostatic": ["P2RY12","TMEM119","CX3CR1","CSF1R","SELPLG"]},
}
def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--input-h5ad", required=True)
    p.add_argument("--output-dir", required=True)
    p.add_argument("--species", required=True, choices=["mouse","human"])
    p.add_argument("--sample-column", required=True)
    p.add_argument("--group-column", required=True)
    p.add_argument("--case-label", required=True)
    p.add_argument("--control-label", required=True)
    p.add_argument("--run-gsea", action="store_true")
    p.add_argument("--gmt", default=None)
    p.add_argument(
        "--allow-nonpublication-mannwhitney",
        action="store_true",
        help="Run the legacy Mann-Whitney/logCPM workflow for exploratory checks only.",
    )
    return p.parse_args()
def pseudobulk(adata, sample_col):
    mat = adata.layers["counts"] if "counts" in adata.layers else adata.X
    samples = adata.obs[sample_col].astype(str)
    rows = []
    for s in samples.unique().tolist():
        idx = np.where(samples.values == s)[0]
        sub = mat[idx]
        summed = np.asarray(sub.sum(axis=0)).ravel() if sparse.issparse(sub) else np.asarray(sub.sum(axis=0)).ravel()
        rows.append(pd.Series(summed, index=adata.var_names, name=s))
    return pd.DataFrame(rows)
def logcpm(df):
    lib = df.sum(axis=1)
    return np.log1p(df.div(lib.replace(0, np.nan), axis=0) * 1e6)
def bh(p):
    p = np.asarray(p, dtype=float); n = len(p); order = np.argsort(p); out = np.empty(n); prev = 1.0
    for rank, idx in enumerate(order[::-1], start=1):
        val = min(prev, p[idx] * n / (n - rank + 1)); out[idx] = val; prev = val
    return out
def main():
    args = parse_args()
    if not args.allow_nonpublication_mannwhitney:
        raise RuntimeError(
            "orthogonal_pseudobulk_de_gsea.py is a legacy exploratory Mann-Whitney/logCPM workflow. "
            "Use q1_multiomics_context_pipeline_gsea_fixed.py with edgeR/DESeq2-style count-model DE "
            "and the clean metadata manifest for publication-grade DE/GSEA."
        )
    outdir = Path(args.output_dir)
    tabs = outdir / "tables"; tabs.mkdir(parents=True, exist_ok=True)
    adata = sc.read_h5ad(args.input_h5ad)
    pb = pseudobulk(adata, args.sample_column)
    pb.to_csv(tabs / "pseudobulk_counts.csv")
    logdf = logcpm(pb)
    logdf.to_csv(tabs / "pseudobulk_logcpm.csv")
    meta = adata.obs[[args.sample_column, args.group_column]].drop_duplicates().rename(columns={args.sample_column:"sample_id"}).set_index("sample_id").reindex(logdf.index)
    case = meta.index[meta[args.group_column].astype(str) == args.case-label if False else args.case_label].tolist()
    ctrl = meta.index[meta[args.group_column].astype(str) == args.control_label].tolist()
    rows = []
    for gene in logdf.columns:
        x, y = logdf.loc[case, gene].dropna().values, logdf.loc[ctrl, gene].dropna().values
        if len(x) == 0 or len(y) == 0: continue
        _, p = mannwhitneyu(x, y, alternative="two-sided")
        rows.append({"gene": gene, "mean_case": float(np.mean(x)), "mean_control": float(np.mean(y)), "delta_mean": float(np.mean(x)-np.mean(y)), "log2fc_means": float(np.log2((np.mean(np.expm1(x))+1e-6)/(np.mean(np.expm1(y))+1e-6))), "p_value": float(p)})
    de = pd.DataFrame(rows).sort_values("p_value")
    de["p_adj_bh"] = bh(de["p_value"].values)
    de.to_csv(tabs / "pseudobulk_de_results.csv", index=False)
    sigrows = []
    for name, genes in GENESETS[args.species].items():
        present = [g for g in genes if g in logdf.columns]
        if not present: continue
        sigrows.append({"gene_set": name, "n_genes_present": len(present), "mean_case_logcpm": float(logdf.loc[case, present].mean().mean()), "mean_control_logcpm": float(logdf.loc[ctrl, present].mean().mean()), "delta_mean_logcpm": float(logdf.loc[case, present].mean().mean() - logdf.loc[ctrl, present].mean().mean())})
    pd.DataFrame(sigrows).to_csv(tabs / "signature_direction_summary.csv", index=False)
    de.sort_values("delta_mean", ascending=False).head(50).to_csv(tabs / "top_up_genes.csv", index=False)
    de.sort_values("delta_mean", ascending=True).head(50).to_csv(tabs / "top_down_genes.csv", index=False)
    if args.run_gsea:
        try:
            import gseapy as gp
            if args.gmt:
                rank = de[["gene","delta_mean"]].dropna().sort_values("delta_mean", ascending=False)
                rank.columns = ["gene","score"]
                res = gp.prerank(rnk=rank, gene_sets=args.gmt, permutation_num=100, seed=0, outdir=str(outdir / "gsea_out"), verbose=False)
                if hasattr(res, "res2d"): res.res2d.to_csv(tabs / "gsea_prerank_results.csv", index=False)
        except Exception as e:
            (tabs / "gsea_error.txt").write_text(repr(e), encoding="utf-8")
    print(outdir)
if __name__ == "__main__":
    main()
