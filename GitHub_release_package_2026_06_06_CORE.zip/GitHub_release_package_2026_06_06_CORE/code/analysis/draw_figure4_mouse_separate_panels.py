#!/usr/bin/env python3
"""
Draw separate Figure 4 panel figures from the extracted mouse source CSVs.

Inputs:
  results/publication_figures/figure4_mouse_conservation_source_data/

Outputs:
  results/publication_figures/figure4_mouse_conservation_separate_panels/

Each panel is saved as:
  - 900 ppi PNG
  - 900 ppi TIFF
  - editable vector PDF
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm
from matplotlib.lines import Line2D
from matplotlib.patches import Patch, Rectangle


ROOT = Path(__file__).resolve().parent
SRC = ROOT / "results" / "publication_figures" / "figure4_mouse_conservation_source_data"
OUT = ROOT / "results" / "publication_figures" / "figure4_mouse_conservation_separate_panels"
OUT.mkdir(parents=True, exist_ok=True)

STATE_ORDER = [
    "homeostatic_like",
    "transitional_like",
    "lysosome_high",
    "dam_like",
    "interferon_like",
    "proliferative_like",
]

STATE_LABEL = {
    "homeostatic_like": "Homeostatic-like",
    "transitional_like": "Transitional-like",
    "lysosome_high": "Lysosome-high",
    "dam_like": "DAM/phagocytic-like",
    "interferon_like": "Interferon-like",
    "proliferative_like": "Proliferative-like",
}

STATE_SHORT = {
    "homeostatic_like": "Homeo",
    "transitional_like": "Trans",
    "lysosome_high": "Lyso",
    "dam_like": "DAM",
    "interferon_like": "IFN",
    "proliferative_like": "Prolif",
}

GROUP_ORDER = ["WT", "5xFAD", "Trem2_KO", "Trem2_KO_5xFAD"]
GROUP_LABEL = {
    "WT": "WT",
    "5xFAD": "5xFAD",
    "Trem2_KO": "Trem2 KO",
    "Trem2_KO_5xFAD": "Trem2 KO 5xFAD",
}
GROUP_COLORS = {
    "WT": "#B9BDC6",
    "5xFAD": "#C92525",
    "Trem2_KO": "#2166AC",
    "Trem2_KO_5xFAD": "#6A3D9A",
}

PAL = {
    "dark": "#151B23",
    "mid": "#566174",
    "grid": "#E9EDF2",
    "border": "#CAD2DC",
}


def setup_style() -> None:
    mpl.rcParams.update(
        {
            "font.family": "Arial",
            "font.size": 8.5,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "figure.facecolor": "white",
            "savefig.facecolor": "white",
            "axes.linewidth": 0.7,
        }
    )


def read_csv(name: str, **kwargs) -> pd.DataFrame:
    path = SRC / name
    if not path.exists():
        raise FileNotFoundError(path)
    return pd.read_csv(path, **kwargs)


def load_state_colors() -> dict[str, str]:
    pal = read_csv("figure4_state_palette_preserved_from_figure2.csv")
    return dict(zip(pal["state"], pal["color_hex"]))


def save_figure(fig: plt.Figure, stem: str) -> None:
    png = OUT / f"{stem}_900ppi.png"
    tiff = OUT / f"{stem}_900ppi.tiff"
    pdf = OUT / f"{stem}_editable.pdf"
    fig.savefig(png, dpi=900, bbox_inches="tight")
    fig.savefig(tiff, dpi=900, bbox_inches="tight", pil_kwargs={"compression": "tiff_lzw"})
    fig.savefig(pdf, bbox_inches="tight")
    plt.close(fig)
    print(f"Wrote {png.name}, {tiff.name}, {pdf.name}")


def clean_axes(ax: plt.Axes) -> None:
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(PAL["dark"])
    ax.spines["bottom"].set_color(PAL["dark"])
    ax.tick_params(colors=PAL["dark"], labelsize=8)


def add_state_legend(ax: plt.Axes, colors: dict[str, str], ncol: int = 3, y: float = -0.18) -> None:
    handles = [
        Line2D([0], [0], marker="o", linestyle="", markerfacecolor=colors[s], markeredgecolor="none", markersize=6.8)
        for s in STATE_ORDER
    ]
    labels = [STATE_LABEL[s] for s in STATE_ORDER]
    ax.legend(
        handles,
        labels,
        loc="upper center",
        bbox_to_anchor=(0.5, y),
        ncol=ncol,
        frameon=False,
        fontsize=8.2,
        handletextpad=0.35,
        columnspacing=1.1,
    )


def draw_umap_states(df: pd.DataFrame, title: str, stem: str, point_size: float) -> None:
    colors = load_state_colors()
    fig, ax = plt.subplots(figsize=(5.2, 4.8))
    for state in STATE_ORDER:
        sub = df[df["state_hint"] == state]
        if sub.empty:
            continue
        ax.scatter(
            sub["UMAP_1"],
            sub["UMAP_2"],
            s=point_size,
            c=colors[state],
            alpha=0.86,
            linewidths=0,
            label=STATE_LABEL[state],
        )
    ax.set_title(title, fontsize=11.0, fontweight="bold", pad=8)
    ax.set_xlabel("UMAP_1", fontsize=9.5)
    ax.set_ylabel("UMAP_2", fontsize=9.5)
    clean_axes(ax)
    add_state_legend(ax, colors, ncol=3, y=-0.16)
    save_figure(fig, stem)


def draw_panel_a() -> None:
    df = read_csv("panelA_gse98969_5xfad_wt_umap_states.csv")
    draw_umap_states(df, "GSE98969 mouse microglia states (WT and 5xFAD)", "Figure4A_GSE98969_umap_states", 4.6)


def draw_panel_c() -> None:
    df = read_csv("panelC_gse140510_umap_states.csv")
    draw_umap_states(df, "GSE140510 mouse microglia states", "Figure4C_GSE140510_umap_states", 8.5)


def zscore(x: pd.Series) -> pd.Series:
    x = pd.to_numeric(x, errors="coerce").astype(float)
    sd = x.std(ddof=0)
    if not np.isfinite(sd) or sd == 0:
        return pd.Series(np.zeros(len(x)), index=x.index)
    return (x - x.mean()) / sd


def draw_panel_b() -> None:
    df = read_csv("panelB_gse98969_5xfad_wt_umap_module_scores.csv")
    modules = [
        ("homeostatic_score", "Homeostatic score"),
        ("lysosome_score", "Lysosome score"),
        ("dam_phagocytic_score", "DAM/phagocytosis score"),
    ]
    cmap = LinearSegmentedColormap.from_list("module", ["#B8ABD9", "#F7F7F7", "#EF2B22"])
    fig, axes = plt.subplots(1, 3, figsize=(10.2, 3.7), sharex=True, sharey=True)
    for ax, (col, title) in zip(axes, modules):
        zz = np.clip(zscore(df[col]), -2, 2)
        order = np.argsort(zz.values)
        sc = ax.scatter(
            df["UMAP_1"].values[order],
            df["UMAP_2"].values[order],
            c=zz.values[order],
            s=3.8,
            cmap=cmap,
            vmin=-2,
            vmax=2,
            linewidths=0,
        )
        ax.set_title(title, fontsize=9.2, fontweight="bold")
        ax.set_xlabel("UMAP_1", fontsize=8.8)
        if ax is axes[0]:
            ax.set_ylabel("UMAP_2", fontsize=8.8)
        clean_axes(ax)
    cbar = fig.colorbar(sc, ax=axes, fraction=0.030, pad=0.018)
    cbar.set_label("Score (z)", fontsize=8.5)
    cbar.ax.tick_params(labelsize=7.2, length=2)
    fig.suptitle("GSE98969 module scores projected on UMAP", fontsize=11.2, fontweight="bold", y=0.98)
    save_figure(fig, "Figure4B_GSE98969_module_score_umaps")


def draw_panel_d() -> None:
    colors = load_state_colors()
    wide = read_csv("panelD_gse140510_state_proportions_by_sample_wide.csv")
    wide["analysis_group"] = pd.Categorical(wide["analysis_group"], categories=GROUP_ORDER, ordered=True)
    wide = wide.sort_values(["analysis_group", "sample_id"]).reset_index(drop=True)
    fig, ax = plt.subplots(figsize=(7.2, 4.4))
    x = np.arange(len(wide))
    bottom = np.zeros(len(wide))
    stack_order = ["homeostatic_like", "transitional_like", "lysosome_high", "interferon_like", "proliferative_like", "dam_like"]
    for state in stack_order:
        vals = wide[state].astype(float).values
        ax.bar(x, vals, bottom=bottom, color=colors[state], width=0.82, edgecolor="white", linewidth=0.35)
        bottom += vals
    ax.set_ylim(0, 1.02)
    ax.set_xlim(-0.6, len(wide) - 0.4)
    ax.set_ylabel("Proportion of microglia", fontsize=9.2)
    ax.set_xlabel("Samples", fontsize=9.2)
    ax.set_xticks(x)
    ax.set_xticklabels([s.replace("GSM", "").replace("_", "\n") for s in wide["sample_id"]], fontsize=6.4)
    clean_axes(ax)
    ax.grid(axis="y", color=PAL["grid"], linewidth=0.6)
    group_spans = []
    for group in GROUP_ORDER:
        idx = np.where(wide["analysis_group"].astype(str).values == group)[0]
        if len(idx):
            group_spans.append((idx.min(), idx.max(), group))
            ax.text(
                (idx.min() + idx.max()) / 2,
                1.055,
                f"{GROUP_LABEL[group]}\n(n={len(idx)})",
                ha="center",
                va="bottom",
                fontsize=8.0,
                fontweight="bold",
                color=GROUP_COLORS[group],
                transform=ax.get_xaxis_transform(),
            )
    for x0, x1, _group in group_spans[:-1]:
        ax.axvline(x1 + 0.5, color=PAL["border"], linewidth=0.8)
    handles = [Patch(facecolor=colors[s], label=STATE_LABEL[s]) for s in STATE_ORDER]
    ax.legend(handles=handles, frameon=False, ncol=3, fontsize=7.8, loc="upper center", bbox_to_anchor=(0.5, -0.22))
    ax.set_title("GSE140510 state proportions by sample", fontsize=11.0, fontweight="bold", pad=8)
    save_figure(fig, "Figure4D_GSE140510_state_proportions_by_sample")


def draw_panel_e() -> None:
    colors = load_state_colors()
    df = read_csv("panelE_gse140510_state_proportions_by_group_long.csv")
    stats_df = read_csv("panelE_gse140510_state_proportion_pairwise_stats.csv")
    states = ["homeostatic_like", "lysosome_high", "dam_like", "interferon_like", "proliferative_like"]
    fig, axes = plt.subplots(1, len(states), figsize=(12.2, 3.8), sharey=True)
    rng = np.random.default_rng(4)
    for ax, state in zip(axes, states):
        sub = df[df["state_hint"] == state].copy()
        vals = [sub.loc[sub["analysis_group"] == g, "proportion"].astype(float).values for g in GROUP_ORDER]
        bp = ax.boxplot(vals, positions=np.arange(len(GROUP_ORDER)), widths=0.52, patch_artist=True, showfliers=False)
        for patch, group in zip(bp["boxes"], GROUP_ORDER):
            patch.set_facecolor(GROUP_COLORS[group])
            patch.set_alpha(0.20)
            patch.set_edgecolor(PAL["dark"])
            patch.set_linewidth(0.7)
        for element in ["whiskers", "caps", "medians"]:
            for line in bp[element]:
                line.set_color(PAL["dark"])
                line.set_linewidth(0.7)
        for i, group in enumerate(GROUP_ORDER):
            y = sub.loc[sub["analysis_group"] == group, "proportion"].astype(float).values
            jitter = rng.normal(i, 0.055, size=len(y))
            ax.scatter(jitter, y, s=21, c=GROUP_COLORS[group], edgecolors=PAL["dark"], linewidths=0.35, zorder=3)
        ax.set_title(STATE_LABEL[state], color=colors[state], fontsize=9.2, fontweight="bold")
        ax.set_xticks(np.arange(len(GROUP_ORDER)))
        ax.set_xticklabels([GROUP_LABEL[g] for g in GROUP_ORDER], rotation=40, ha="right", fontsize=7.0)
        ax.set_ylim(-0.02, 1.03)
        clean_axes(ax)
        ax.grid(axis="y", color=PAL["grid"], linewidth=0.55)
        st_stats = stats_df[(stats_df["state_hint"] == state) & (stats_df["significance"] != "ns")]
        y0 = 0.91
        comparison_positions = {
            "5xFAD vs WT": (0, 1),
            "Trem2_KO_5xFAD vs Trem2_KO": (2, 3),
            "Trem2_KO_5xFAD vs 5xFAD": (1, 3),
        }
        for k, row in enumerate(st_stats.itertuples(index=False)):
            if row.comparison not in comparison_positions:
                continue
            x1, x2 = comparison_positions[row.comparison]
            yy = y0 + 0.045 * k
            ax.plot([x1, x1, x2, x2], [yy - 0.01, yy, yy, yy - 0.01], color=PAL["dark"], lw=0.55)
            ax.text((x1 + x2) / 2, yy + 0.006, row.significance, ha="center", va="bottom", fontsize=7.0, fontweight="bold")
    axes[0].set_ylabel("Proportion of microglia", fontsize=9.2)
    handles = [Line2D([0], [0], marker="o", linestyle="", markerfacecolor=GROUP_COLORS[g], markeredgecolor=PAL["dark"], label=GROUP_LABEL[g], markersize=6.5) for g in GROUP_ORDER]
    fig.legend(handles=handles, frameon=False, ncol=4, loc="lower center", bbox_to_anchor=(0.5, -0.04), fontsize=8.0)
    fig.suptitle("GSE140510 state proportions by group", fontsize=11.2, fontweight="bold", y=1.02)
    save_figure(fig, "Figure4E_GSE140510_state_proportions_by_group")


def draw_panel_f() -> None:
    mat = read_csv("panelF_gse140510_pseudobulk_marker_expression_gene_zscore_matrix.csv", index_col=0)
    sample_meta = read_csv("panelF_gse140510_pseudobulk_sample_metadata.csv")
    gene_anno = read_csv("panelF_gse140510_marker_gene_annotation.csv")
    sample_order = sample_meta["sample_id"].tolist()
    mat = mat[sample_order]
    gene_order = gene_anno["gene"].tolist()
    mat = mat.loc[gene_order]
    cmap = LinearSegmentedColormap.from_list("heat", ["#2166AC", "#F7F7F7", "#EF2B22"])

    fig = plt.figure(figsize=(7.6, 6.0))
    ax = fig.add_axes([0.16, 0.16, 0.62, 0.70])
    im = ax.imshow(mat.values, aspect="auto", cmap=cmap, norm=TwoSlopeNorm(vmin=-2, vcenter=0, vmax=2), interpolation="nearest")
    ax.set_yticks(np.arange(len(mat.index)))
    ax.set_yticklabels(mat.index, fontsize=7.2, fontstyle="italic")
    ax.yaxis.tick_right()
    ax.set_xticks(np.arange(len(sample_order)))
    ax.set_xticklabels([s.replace("GSM", "").replace("_", "\n") for s in sample_order], rotation=90, fontsize=5.6)
    ax.tick_params(length=0)
    for spine in ax.spines.values():
        spine.set_color(PAL["border"])
        spine.set_linewidth(0.7)

    top = fig.add_axes([0.16, 0.875, 0.62, 0.035], sharex=ax)
    for i, row in sample_meta.iterrows():
        top.add_patch(Rectangle((i - 0.5, 0), 1, 1, facecolor=GROUP_COLORS[row["analysis_group"]], edgecolor="white", linewidth=0.4))
    top.set_xlim(-0.5, len(sample_order) - 0.5)
    top.set_ylim(0, 1)
    top.axis("off")

    start = 0
    for group, sub in gene_anno.groupby("gene_group", sort=False):
        n = len(sub)
        mid = start + (n - 1) / 2
        ax.text(len(sample_order) + 0.35, mid, group, ha="left", va="center", fontsize=7.3, fontweight="bold")
        if start > 0:
            ax.axhline(start - 0.5, color="white", lw=1.4)
        start += n

    cax = fig.add_axes([0.28, 0.070, 0.30, 0.025])
    cb = fig.colorbar(im, cax=cax, orientation="horizontal")
    cb.set_label("Row z-score", fontsize=7.8)
    cb.ax.tick_params(labelsize=7.0, length=2)
    handles = [Patch(facecolor=GROUP_COLORS[g], label=GROUP_LABEL[g]) for g in GROUP_ORDER]
    fig.legend(handles=handles, frameon=False, ncol=4, loc="upper center", bbox_to_anchor=(0.47, 0.965), fontsize=7.6)
    fig.suptitle("GSE140510 pseudobulk marker expression", fontsize=11.2, fontweight="bold", y=0.995)
    save_figure(fig, "Figure4F_GSE140510_pseudobulk_marker_heatmap")


def draw_panel_g() -> None:
    df = read_csv("panelG_gse140510_trem2_dependence_module_contrasts.csv")
    contrast_labels = {
        "5xFAD_vs_WT": "5xFAD vs WT",
        "Trem2_KO_5xFAD_vs_Trem2_KO": "Trem2 KO 5xFAD vs Trem2 KO",
        "Trem2_KO_5xFAD_vs_5xFAD": "Trem2 KO 5xFAD vs 5xFAD",
    }
    contrast_colors = {
        "5xFAD_vs_WT": GROUP_COLORS["5xFAD"],
        "Trem2_KO_5xFAD_vs_Trem2_KO": "#1D5CFF",
        "Trem2_KO_5xFAD_vs_5xFAD": GROUP_COLORS["Trem2_KO_5xFAD"],
    }
    fig, axes = plt.subplots(3, 1, figsize=(5.8, 6.8), sharex=True)
    for ax, contrast in zip(axes, df["contrast"].drop_duplicates()):
        sub = df[df["contrast"] == contrast].sort_values("module_order", ascending=False)
        y = np.arange(len(sub))
        effect = sub["effect_size_hedges_g_group1_minus_group2"].astype(float).clip(-8, 8)
        colors = [contrast_colors[contrast] if abs(v) > 0 else "#8E95A3" for v in effect]
        ax.axvline(0, color=PAL["dark"], lw=0.7, ls="--", alpha=0.7)
        ax.hlines(y, 0, effect, color=colors, lw=1.1, alpha=0.85)
        ax.scatter(effect, y, s=32, c=colors, edgecolors="white", linewidths=0.4, zorder=3)
        ax.set_yticks(y)
        ax.set_yticklabels(sub["module_label"], fontsize=7.6)
        ax.set_title(contrast_labels.get(contrast, contrast), color=contrast_colors[contrast], fontsize=9.0, fontweight="bold")
        for yi, row in zip(y, sub.itertuples(index=False)):
            ax.text(8.25, yi, str(row.significance), fontsize=7.0, va="center", ha="left", color=PAL["dark"])
        ax.set_xlim(-8.6, 8.9)
        ax.grid(axis="x", color=PAL["grid"], linewidth=0.55)
        clean_axes(ax)
    axes[-1].set_xlabel("Effect size (Hedges g, group 1 - group 2)", fontsize=8.8)
    fig.text(0.88, 0.94, "FDR", fontsize=7.5, fontweight="bold", ha="left")
    fig.suptitle("Trem2 dependence of microglial remodeling modules", fontsize=11.0, fontweight="bold", y=0.99)
    save_figure(fig, "Figure4G_GSE140510_Trem2_dependence_contrasts")


def main() -> None:
    setup_style()
    draw_panel_a()
    draw_panel_b()
    draw_panel_c()
    draw_panel_d()
    draw_panel_e()
    draw_panel_f()
    draw_panel_g()
    readme = OUT / "README.txt"
    readme.write_text(
        "\n".join(
            [
                "Separate Figure 4 panel files generated from extracted source CSVs.",
                f"Source CSV directory: {SRC}",
                "Each panel is saved as 900 ppi PNG, 900 ppi TIFF, and editable PDF.",
                "State colors are preserved from Figure 2 via figure4_state_palette_preserved_from_figure2.csv.",
            ]
        ),
        encoding="utf-8",
    )
    print(f"All separate panel figures written to: {OUT}")


if __name__ == "__main__":
    main()
