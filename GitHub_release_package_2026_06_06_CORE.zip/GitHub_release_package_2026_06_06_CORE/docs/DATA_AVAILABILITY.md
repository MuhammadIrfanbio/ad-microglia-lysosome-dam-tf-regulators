# Data availability

Public source datasets used in the manuscript:

1. SEA-AD human MTG single-nucleus RNA-seq from the Allen Brain Map / SEA-AD resource.
2. Olah human microglia data from GEO GSE146639 and the Human Cell Atlas project page for postmortem AD microglia.
3. GSE98969 mouse AD microglia from GEO.
4. GSE140510 Trem2-linked mouse snRNA-seq from GEO.

This GitHub package contains processed figure/source tables and model-output tables. It does not include raw FASTQ files or large processed single-cell objects.

For submission, deposit any large final objects in Zenodo, Figshare, Dryad, OSF, or another stable data repository, then add the DOI/accession to the manuscript data availability statement.
