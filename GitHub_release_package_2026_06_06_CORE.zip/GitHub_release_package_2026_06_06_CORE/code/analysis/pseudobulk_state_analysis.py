#!/usr/bin/env python3
"""
Sample-level state proportion and pseudobulk comparison script for
WT / Trem2_KO / WT_5XFAD / Trem2_KO_5XFAD microglia datasets.

Designed to work with:
1) a microglia-final h5ad from zfp335_ad_pipeline.py containing state annotations
2) optionally, the original raw-count combined h5ad from prepare_geo_mtx_series_to_h5ad.py

Key outputs
-----------
- State counts and proportions by sample and group
- Pairwise group comparisons of state proportions
- Sample-level pseudobulk expression (recommended from raw counts)
- Module scores and key-gene summaries by sample
- Pairwise group comparisons for module scores and key genes
- Publication-ready PNG figures

Example
-------
python pseudobulk_state_analysis.py \
  --microglia-h5ad results/gse140510_mouse_microglia_fixed/objects/gse140510_mouse_microglia_fixed_microglia_final.h5ad \
  --raw-h5ad data_processed/GSE140510_mouse_combined.h5ad \
  --output-dir results/gse140510_mouse_group_analysis \
  --species mouse
"""
from __future__ import annotations

import argparse
import json
import logging
import math
import re
import sys
from itertools import combinations
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import anndata as ad
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import sparse, stats


MOUSE_GENE_SETS: Dict[str, List[str]] = {
    "regulator": ["Zfp335"],
    "bace1_node": ["Bace1"],
    "lysosome": ["Ctsb", "Ctsd", "Lamp1", "Lamp2", "Cd68", "Hexa", "Hexb", "Atp6v1b2", "Atp6v0d1"],
    "dam_phagocytic": ["Apoe", "Trem2", "Tyrobp", "Cst7", "Lpl", "Itgax", "Axl", "Gpnmb", "Fcer1g", "Cd68"],
    "homeostatic": ["P2ry12", "Tmem119", "Cx3cr1", "Csf1r", "Selplg"],
    "interferon": ["Ifitm3", "Isg15", "Ifit3", "Stat1", "Irf7"],
    "proliferative": ["Mki67", "Top2a", "Birc5", "Pcna", "Ube2c"],
}

HUMAN_GENE_SETS: Dict[str, List[str]] = {
    "regulator": ["ZNF335"],
    "bace1_node": ["BACE1"],
    "lysosome": ["CTSB", "CTSD", "LAMP1", "LAMP2", "CD68", "HEXA", "HEXB", "ATP6V1B2", "ATP6V0D1"],
    "dam_phagocytic": ["APOE", "TREM2", "TYROBP", "CST7", "LPL", "ITGAX", "AXL", "GPNMB", "FCER1G", "CD68"],
    "homeostatic": ["P2RY12", "TMEM119", "CX3CR1", "CSF1R", "SELPLG"],
    "interferon": ["IFITM3", "ISG15", "IFIT3", "STAT1", "IRF7"],
    "proliferative": ["MKI67", "TOP2A", "BIRC5", "PCNA", "UBE2C"],
}

DEFAULT_KEY_GENES_MOUSE = [
    "Zfp335", "Bace1",
    "Ctsb", "Ctsd", "Lamp1", "Lamp2", "Cd68", "Hexa", "Hexb", "Atp6v1b2", "Atp6v0d1",
    "Apoe", "Trem2", "Tyrobp", "Cst7", "Lpl", "Itgax", "Axl", "Gpnmb", "Fcer1g",
    "P2ry12", "Tmem119", "Cx3cr1", "Csf1r", "Selplg",
]

DEFAULT_KEY_GENES_HUMAN = [
    "ZNF335", "BACE1",
    "CTSB", "CTSD", "LAMP1", "LAMP2", "CD68", "HEXA", "HEXB", "ATP6V1B2", "ATP6V0D1",
    "APOE", "TREM2", "TYROBP", "CST7", "LPL", "ITGAX", "AXL", "GPNMB", "FCER1G",
    "P2RY12", "TMEM119", "CX3CR1", "CSF1R", "SELPLG",
]

GROUP_ORDER = ["WT", "Trem2_KO", "WT_5XFAD", "Trem2_KO_5XFAD"]
STATE_ORDER = ["homeostatic_like", "transitional_like", "lysosome_high", "dam_like", "interferon_like", "proliferative_like"]


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Sample-level state proportion and pseudobulk comparison analysis")
    p.add_argument("--microglia-h5ad", required=True, help="Microglia-final h5ad with state labels")
    p.add_argument("--raw-h5ad", default=None, help="Optional raw-count h5ad for true count-based pseudobulk")
    p.add_argument("--output-dir", required=True, help="Output directory")
    p.add_argument("--species", choices=["mouse", "human"], default="mouse")
    p.add_argument("--sample-column", default=None, help="Sample column in obs; auto-detected if omitted")
    p.add_argument("--state-column", default="state_hint", help="State label column in microglia obs")
    p.add_argument("--group-column", default=None, help="Existing group column in obs; auto-inferred from sample id if omitted")
    p.add_argument("--gene-sets-file", default=None, help="Optional CSV/JSON gene set file")
    p.add_argument("--key-genes", default=None, help="Optional comma-separated key genes to summarize")
    p.add_argument("--min-cells-per-sample", type=int, default=20, help="Warn if a sample has fewer cells than this")
    p.add_argument("--sample-state-min-cells", type=int, default=10, help="Minimum cells per sample-state entry to keep in state-level pseudobulk")
    return p.parse_args()


def setup_dirs(output_dir: Path) -> Dict[str, Path]:
    sub = {
        "root": output_dir,
        "tables": output_dir / "tables",
        "figures": output_dir / "figures",
        "logs": output_dir / "logs",
    }
    for p in sub.values():
        p.mkdir(parents=True, exist_ok=True)
    return sub


def setup_logger(log_path: Path) -> logging.Logger:
    logger = logging.getLogger("state_pseudobulk")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
    fh = logging.FileHandler(log_path)
    fh.setFormatter(fmt)
    logger.addHandler(fh)
    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(fmt)
    logger.addHandler(sh)
    return logger


def load_gene_sets(species: str, gene_sets_file: Optional[str]) -> Dict[str, List[str]]:
    gene_sets = MOUSE_GENE_SETS.copy() if species == "mouse" else HUMAN_GENE_SETS.copy()
    if gene_sets_file is None:
        return gene_sets
    path = Path(gene_sets_file)
    if not path.exists():
        raise FileNotFoundError(path)
    if path.suffix.lower() == ".csv":
        df = pd.read_csv(path)
        if not {"gene_set", "gene"}.issubset(df.columns):
            raise ValueError("Gene set CSV must contain columns gene_set and gene")
        out: Dict[str, List[str]] = {}
        for gs, sub in df.groupby("gene_set"):
            out[gs] = sub["gene"].dropna().astype(str).unique().tolist()
        return out
    if path.suffix.lower() == ".json":
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    raise ValueError("gene set file must be .csv or .json")


def detect_sample_column(obs: pd.DataFrame, user_value: Optional[str]) -> str:
    if user_value:
        if user_value not in obs.columns:
            raise ValueError(f"Sample column '{user_value}' not found in obs")
        return user_value
    candidates = [
        "sample_id", "sample", "orig.ident", "orig_ident", "batch", "donor", "donor_id",
        "library_id", "sample_name", "batch_id",
    ]
    for c in candidates:
        if c in obs.columns:
            return c
    raise ValueError(f"Could not detect sample column. Available obs columns: {list(obs.columns)}")


def detect_group_column(obs: pd.DataFrame, user_value: Optional[str]) -> Optional[str]:
    if user_value:
        if user_value not in obs.columns:
            raise ValueError(f"Group column '{user_value}' not found in obs")
        return user_value
    for c in ["group", "genotype", "condition", "diagnosis", "treatment"]:
        if c in obs.columns:
            return c
    return None


def infer_group_from_sample(sample_id: str) -> str:
    s = str(sample_id).upper()
    if "TREM2_KO_5XFAD" in s:
        return "Trem2_KO_5XFAD"
    if ("5XFAD" in s) and ("TREM2_KO" not in s):
        return "WT_5XFAD"
    if "TREM2_KO" in s:
        return "Trem2_KO"
    if re.search(r"(^|_)WT(_|$)", s):
        return "WT"
    return "Unknown"


def ensure_group_metadata(df: pd.DataFrame, sample_col: str, group_col: Optional[str]) -> pd.DataFrame:
    out = df.copy()
    out["sample_id_for_analysis"] = out[sample_col].astype(str)
    if group_col and group_col in out.columns:
        out["analysis_group"] = out[group_col].astype(str)
    else:
        out["analysis_group"] = out["sample_id_for_analysis"].map(infer_group_from_sample)
    return out


def present_genes(var_names: pd.Index, genes: Sequence[str]) -> List[str]:
    return [g for g in genes if g in var_names]


def bh_adjust(pvals: np.ndarray) -> np.ndarray:
    pvals = np.asarray(pvals, dtype=float)
    n = pvals.size
    if n == 0:
        return pvals
    order = np.argsort(np.nan_to_num(pvals, nan=np.inf))
    ranked = pvals[order]
    adj = np.empty(n, dtype=float)
    prev = 1.0
    for i in range(n - 1, -1, -1):
        rank = i + 1
        p = ranked[i]
        val = 1.0 if np.isnan(p) else min(prev, p * n / rank)
        prev = val
        adj[i] = val
    out = np.empty(n, dtype=float)
    out[order] = adj
    return out


def matrix_sum_rows(X) -> np.ndarray:
    return np.asarray(X.sum(axis=0)).ravel()


def matrix_to_dense_array(X) -> np.ndarray:
    if sparse.issparse(X):
        return X.toarray()
    return np.asarray(X)


def compute_state_proportions(obs: pd.DataFrame, sample_col: str, state_col: str) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    counts = pd.crosstab(obs[sample_col], obs[state_col])
    for st in STATE_ORDER:
        if st not in counts.columns:
            counts[st] = 0
    counts = counts[[c for c in STATE_ORDER if c in counts.columns] + [c for c in counts.columns if c not in STATE_ORDER]]
    props = counts.div(counts.sum(axis=1), axis=0).fillna(0.0)
    long = props.reset_index().melt(id_vars=sample_col, var_name="state", value_name="proportion")
    return counts, props, long


def summarize_proportions_by_group(prop_long: pd.DataFrame, sample_meta: pd.DataFrame) -> pd.DataFrame:
    merged = prop_long.merge(sample_meta[["sample_id_for_analysis", "analysis_group"]].drop_duplicates(),
                             left_on=prop_long.columns[0], right_on="sample_id_for_analysis", how="left")
    summary = (
        merged.groupby(["analysis_group", "state"]) ["proportion"]
        .agg(["mean", "median", "std", "count"]) 
        .reset_index()
    )
    summary["sem"] = summary["std"] / np.sqrt(summary["count"].clip(lower=1))
    return summary


def pairwise_state_tests(prop_wide: pd.DataFrame, sample_meta: pd.DataFrame) -> pd.DataFrame:
    meta = sample_meta[["sample_id_for_analysis", "analysis_group"]].drop_duplicates().set_index("sample_id_for_analysis")
    common = [s for s in prop_wide.index if s in meta.index]
    prop_wide = prop_wide.loc[common]
    meta = meta.loc[common]
    groups = [g for g in GROUP_ORDER if g in meta["analysis_group"].unique()]
    rows = []
    for state in prop_wide.columns:
        for g1, g2 in combinations(groups, 2):
            x = prop_wide.loc[meta["analysis_group"] == g1, state].astype(float).values
            y = prop_wide.loc[meta["analysis_group"] == g2, state].astype(float).values
            if len(x) == 0 or len(y) == 0:
                continue
            try:
                p = stats.mannwhitneyu(x, y, alternative="two-sided").pvalue
            except Exception:
                p = np.nan
            rows.append({
                "feature_type": "state_proportion",
                "feature": state,
                "group_1": g1,
                "group_2": g2,
                "n_group_1": len(x),
                "n_group_2": len(y),
                "mean_group_1": float(np.mean(x)),
                "mean_group_2": float(np.mean(y)),
                "median_group_1": float(np.median(x)),
                "median_group_2": float(np.median(y)),
                "delta_mean": float(np.mean(x) - np.mean(y)),
                "log2fc_mean_prop": float(np.log2((np.mean(x) + 1e-6) / (np.mean(y) + 1e-6))),
                "p_value": p,
            })
    out = pd.DataFrame(rows)
    if not out.empty:
        out["p_adj_bh"] = bh_adjust(out["p_value"].values)
    return out


def aggregate_counts_by_sample(adata: ad.AnnData, sample_series: pd.Series) -> Tuple[pd.DataFrame, pd.Series]:
    samples = sample_series.astype(str)
    unique_samples = pd.Index(samples.unique(), name="sample_id_for_analysis")
    sums = []
    n_cells = []
    for s in unique_samples:
        mask = (samples == s).values
        sums.append(matrix_sum_rows(adata[mask].X))
        n_cells.append(int(mask.sum()))
    counts = pd.DataFrame(np.vstack(sums), index=unique_samples, columns=adata.var_names)
    n_cells = pd.Series(n_cells, index=unique_samples, name="n_cells")
    return counts, n_cells


def aggregate_counts_by_sample_state(adata: ad.AnnData, sample_series: pd.Series, state_series: pd.Series, min_cells: int) -> Tuple[pd.DataFrame, pd.DataFrame]:
    rows = []
    meta_rows = []
    pairs = pd.DataFrame({"sample": sample_series.astype(str), "state": state_series.astype(str)}, index=adata.obs_names)
    grouped = pairs.groupby(["sample", "state"])
    for (sample, state), idx in grouped.groups.items():
        idx = list(idx)
        if len(idx) < min_cells:
            continue
        sums = matrix_sum_rows(adata[idx].X)
        rows.append(sums)
        meta_rows.append({"sample_id_for_analysis": sample, "state": state, "n_cells": len(idx)})
    if not rows:
        return pd.DataFrame(columns=adata.var_names), pd.DataFrame(columns=["sample_id_for_analysis", "state", "n_cells"])
    meta = pd.DataFrame(meta_rows)
    counts = pd.DataFrame(rows, index=[f"{r['sample_id_for_analysis']}|{r['state']}" for r in meta_rows], columns=adata.var_names)
    return counts, meta


def counts_to_cpm_and_logcpm(counts: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    lib_sizes = counts.sum(axis=1).replace(0, np.nan)
    cpm = counts.div(lib_sizes, axis=0) * 1e6
    cpm = cpm.fillna(0.0)
    logcpm = np.log1p(cpm)
    return cpm, logcpm


def compute_module_scores_from_matrix(log_expr: pd.DataFrame, gene_sets: Dict[str, List[str]]) -> Tuple[pd.DataFrame, pd.DataFrame]:
    module_scores = pd.DataFrame(index=log_expr.index)
    coverage_rows = []
    for gs, genes in gene_sets.items():
        present = [g for g in genes if g in log_expr.columns]
        coverage_rows.append({"gene_set": gs, "n_requested": len(genes), "n_present": len(present), "present_genes": ";".join(present)})
        if present:
            module_scores[f"{gs}_score"] = log_expr[present].mean(axis=1)
        else:
            module_scores[f"{gs}_score"] = np.nan
    return module_scores, pd.DataFrame(coverage_rows)


def compare_numeric_features(feature_df: pd.DataFrame, sample_meta: pd.DataFrame, feature_type: str) -> pd.DataFrame:
    meta = sample_meta[["sample_id_for_analysis", "analysis_group"]].drop_duplicates().set_index("sample_id_for_analysis")
    common = [s for s in feature_df.index if s in meta.index]
    feature_df = feature_df.loc[common]
    meta = meta.loc[common]
    groups = [g for g in GROUP_ORDER if g in meta["analysis_group"].unique()]
    rows = []
    for feat in feature_df.columns:
        vals = feature_df[feat].astype(float)
        for g1, g2 in combinations(groups, 2):
            x = vals.loc[meta["analysis_group"] == g1].dropna().values
            y = vals.loc[meta["analysis_group"] == g2].dropna().values
            if len(x) == 0 or len(y) == 0:
                continue
            try:
                p = stats.mannwhitneyu(x, y, alternative="two-sided").pvalue
            except Exception:
                p = np.nan
            rows.append({
                "feature_type": feature_type,
                "feature": feat,
                "group_1": g1,
                "group_2": g2,
                "n_group_1": len(x),
                "n_group_2": len(y),
                "mean_group_1": float(np.mean(x)),
                "mean_group_2": float(np.mean(y)),
                "median_group_1": float(np.median(x)),
                "median_group_2": float(np.median(y)),
                "delta_mean": float(np.mean(x) - np.mean(y)),
                "log2fc_means": float(np.log2((np.mean(x) + 1e-6) / (np.mean(y) + 1e-6))),
                "p_value": p,
            })
    out = pd.DataFrame(rows)
    if not out.empty:
        out["p_adj_bh"] = bh_adjust(out["p_value"].values)
    return out


def plot_stacked_state_proportions(prop_wide: pd.DataFrame, sample_meta: pd.DataFrame, outpath: Path) -> None:
    meta = sample_meta[["sample_id_for_analysis", "analysis_group"]].drop_duplicates().set_index("sample_id_for_analysis")
    order = [s for g in GROUP_ORDER for s in meta.index[meta["analysis_group"] == g].tolist() if s in prop_wide.index]
    if not order:
        order = prop_wide.index.tolist()
    df = prop_wide.loc[order].copy()
    colors = {
        "homeostatic_like": "#4daf4a",
        "transitional_like": "#984ea3",
        "lysosome_high": "#ff7f00",
        "dam_like": "#e41a1c",
        "interferon_like": "#377eb8",
        "proliferative_like": "#a65628",
    }
    fig, ax = plt.subplots(figsize=(max(8, len(df) * 0.8), 5))
    bottom = np.zeros(len(df))
    for state in [c for c in STATE_ORDER if c in df.columns]:
        vals = df[state].values
        ax.bar(range(len(df)), vals, bottom=bottom, label=state, color=colors.get(state, None))
        bottom += vals
    ax.set_xticks(range(len(df)))
    ax.set_xticklabels(df.index, rotation=90)
    ax.set_ylabel("Proportion")
    ax.set_title("Microglial state proportions by sample")
    ax.legend(bbox_to_anchor=(1.02, 1), loc="upper left", frameon=False)
    plt.tight_layout()
    plt.savefig(outpath, dpi=200, bbox_inches="tight")
    plt.close(fig)


def plot_group_state_bars(group_summary: pd.DataFrame, outpath: Path) -> None:
    states = [s for s in STATE_ORDER if s in group_summary["state"].unique()]
    groups = [g for g in GROUP_ORDER if g in group_summary["analysis_group"].unique()]
    fig, ax = plt.subplots(figsize=(10, 5))
    width = 0.18 if len(groups) >= 4 else 0.25
    x = np.arange(len(states))
    for i, group in enumerate(groups):
        sub = group_summary[group_summary["analysis_group"] == group].set_index("state").reindex(states)
        ax.bar(x + i * width - width * (len(groups)-1)/2, sub["mean"].values, width=width, yerr=sub["sem"].fillna(0).values, label=group)
    ax.set_xticks(x)
    ax.set_xticklabels(states, rotation=30, ha="right")
    ax.set_ylabel("Mean proportion")
    ax.set_title("Mean microglial state proportion by group")
    ax.legend(frameon=False)
    plt.tight_layout()
    plt.savefig(outpath, dpi=200, bbox_inches="tight")
    plt.close(fig)


def plot_heatmap(df: pd.DataFrame, outpath: Path, title: str, zscore_rows: bool = False, cmap: str = "viridis") -> None:
    plot_df = df.copy()
    if zscore_rows:
        plot_df = plot_df.sub(plot_df.mean(axis=1), axis=0)
        std = plot_df.std(axis=1).replace(0, np.nan)
        plot_df = plot_df.div(std, axis=0).fillna(0.0)
    fig_h = max(4, 0.35 * len(plot_df.index))
    fig_w = max(6, 0.35 * len(plot_df.columns))
    fig, ax = plt.subplots(figsize=(fig_w, fig_h))
    im = ax.imshow(plot_df.values, aspect="auto", interpolation="nearest", cmap=cmap)
    ax.set_xticks(np.arange(len(plot_df.columns)))
    ax.set_xticklabels(plot_df.columns, rotation=90)
    ax.set_yticks(np.arange(len(plot_df.index)))
    ax.set_yticklabels(plot_df.index)
    ax.set_title(title)
    plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    plt.tight_layout()
    plt.savefig(outpath, dpi=200, bbox_inches="tight")
    plt.close(fig)


def merge_sample_meta_into_matrix(df: pd.DataFrame, sample_meta: pd.DataFrame) -> pd.DataFrame:
    meta = sample_meta[["sample_id_for_analysis", "analysis_group"]].drop_duplicates().set_index("sample_id_for_analysis")
    out = df.copy()
    out.insert(0, "analysis_group", [meta.loc[idx, "analysis_group"] if idx in meta.index else "NA" for idx in out.index])
    return out


def main() -> int:
    args = parse_args()
    outdirs = setup_dirs(Path(args.output_dir))
    logger = setup_logger(outdirs["logs"] / "pseudobulk_state_analysis.log")

    logger.info("Loading microglia h5ad: %s", args.microglia_h5ad)
    micro = ad.read_h5ad(args.microglia_h5ad)
    logger.info("Microglia object shape: %s cells x %s genes", micro.n_obs, micro.n_vars)

    if args.state_column not in micro.obs.columns:
        raise ValueError(f"State column '{args.state_column}' not found. Available obs columns: {list(micro.obs.columns)}")

    sample_col = detect_sample_column(micro.obs, args.sample_column)
    group_col = detect_group_column(micro.obs, args.group_column)
    logger.info("Using sample column: %s", sample_col)
    logger.info("Using group column: %s", group_col if group_col else "<inferred from sample ids>")

    micro.obs = ensure_group_metadata(micro.obs, sample_col, group_col)
    micro.obs[args.state_column] = micro.obs[args.state_column].astype(str)

    sample_meta = (
        micro.obs[["sample_id_for_analysis", "analysis_group"]]
        .drop_duplicates()
        .sort_values(["analysis_group", "sample_id_for_analysis"])
        .reset_index(drop=True)
    )
    sample_cell_counts = micro.obs["sample_id_for_analysis"].value_counts().rename_axis("sample_id_for_analysis").reset_index(name="n_cells_microglia")
    sample_meta = sample_meta.merge(sample_cell_counts, on="sample_id_for_analysis", how="left")
    sample_meta["low_cell_warning"] = sample_meta["n_cells_microglia"] < args.min_cells_per_sample
    sample_meta.to_csv(outdirs["tables"] / "sample_metadata.csv", index=False)

    logger.info("Computing state counts and proportions by sample")
    state_counts, state_props, state_prop_long = compute_state_proportions(micro.obs, "sample_id_for_analysis", args.state_column)
    state_counts.to_csv(outdirs["tables"] / "state_counts_by_sample.csv")
    state_props.to_csv(outdirs["tables"] / "state_proportions_by_sample.csv")
    state_prop_long.to_csv(outdirs["tables"] / "state_proportions_by_sample_long.csv", index=False)

    group_state_summary = summarize_proportions_by_group(state_prop_long, sample_meta)
    group_state_summary.to_csv(outdirs["tables"] / "state_proportion_group_summary.csv", index=False)

    state_stats = pairwise_state_tests(state_props, sample_meta)
    state_stats.to_csv(outdirs["tables"] / "state_proportion_pairwise_stats.csv", index=False)

    plot_stacked_state_proportions(state_props, sample_meta, outdirs["figures"] / "state_proportions_stacked_by_sample.png")
    plot_group_state_bars(group_state_summary, outdirs["figures"] / "state_proportion_group_bars.png")

    gene_sets = load_gene_sets(args.species, args.gene_sets_file)
    key_genes = (
        [g.strip() for g in args.key_genes.split(",") if g.strip()]
        if args.key_genes else
        (DEFAULT_KEY_GENES_MOUSE if args.species == "mouse" else DEFAULT_KEY_GENES_HUMAN)
    )

    # Always compute sample-level mean cell scores from the microglia object as a fallback summary.
    score_cols = [c for c in micro.obs.columns if c.endswith("_score")]
    if score_cols:
        sample_mean_scores = micro.obs.groupby("sample_id_for_analysis")[score_cols].mean(numeric_only=True)
        sample_mean_scores = merge_sample_meta_into_matrix(sample_mean_scores, sample_meta)
        sample_mean_scores.to_csv(outdirs["tables"] / "sample_mean_cell_scores.csv")
        mean_score_stats = compare_numeric_features(sample_mean_scores.drop(columns=["analysis_group"]), sample_meta, "sample_mean_cell_score")
        mean_score_stats.to_csv(outdirs["tables"] / "sample_mean_cell_score_pairwise_stats.csv", index=False)

    raw_mode = args.raw_h5ad is not None
    if raw_mode:
        logger.info("Loading raw h5ad for count-based pseudobulk: %s", args.raw_h5ad)
        raw = ad.read_h5ad(args.raw_h5ad)
        common_cells = micro.obs_names.intersection(raw.obs_names)
        if len(common_cells) == 0:
            raise ValueError("No overlapping cell barcodes between microglia h5ad and raw h5ad")
        logger.info("Overlapping cells between microglia and raw objects: %s", len(common_cells))
        raw = raw[common_cells].copy()
        # align metadata from micro object
        raw.obs = raw.obs.copy()
        raw.obs["sample_id_for_analysis"] = micro.obs.loc[common_cells, "sample_id_for_analysis"].values
        raw.obs["analysis_group"] = micro.obs.loc[common_cells, "analysis_group"].values
        raw.obs[args.state_column] = micro.obs.loc[common_cells, args.state_column].values

        logger.info("Aggregating sample-level pseudobulk counts")
        sample_counts, sample_n_cells = aggregate_counts_by_sample(raw, raw.obs["sample_id_for_analysis"])
        sample_counts.to_csv(outdirs["tables"] / "sample_pseudobulk_counts.csv.gz", compression="gzip")
        sample_n_cells.to_csv(outdirs["tables"] / "sample_pseudobulk_cell_counts.csv")

        sample_cpm, sample_logcpm = counts_to_cpm_and_logcpm(sample_counts)
        sample_logcpm.to_csv(outdirs["tables"] / "sample_pseudobulk_logcpm.csv.gz", compression="gzip")

        logger.info("Aggregating sample-state pseudobulk counts")
        sample_state_counts, sample_state_meta = aggregate_counts_by_sample_state(
            raw, raw.obs["sample_id_for_analysis"], raw.obs[args.state_column], args.sample_state_min_cells
        )
        if not sample_state_counts.empty:
            sample_state_counts.to_csv(outdirs["tables"] / "sample_state_pseudobulk_counts.csv.gz", compression="gzip")
            sample_state_meta.to_csv(outdirs["tables"] / "sample_state_pseudobulk_metadata.csv", index=False)
            _, sample_state_logcpm = counts_to_cpm_and_logcpm(sample_state_counts)
            sample_state_logcpm.to_csv(outdirs["tables"] / "sample_state_pseudobulk_logcpm.csv.gz", compression="gzip")

        sample_module_scores, module_coverage = compute_module_scores_from_matrix(sample_logcpm, gene_sets)
        sample_module_scores = merge_sample_meta_into_matrix(sample_module_scores, sample_meta)
        sample_module_scores.to_csv(outdirs["tables"] / "sample_pseudobulk_module_scores.csv")
        module_coverage.to_csv(outdirs["tables"] / "module_gene_coverage.csv", index=False)

        present_key_genes = [g for g in key_genes if g in sample_logcpm.columns]
        missing_key_genes = [g for g in key_genes if g not in sample_logcpm.columns]
        pd.DataFrame({"present_key_genes": present_key_genes + [""] * max(0, len(missing_key_genes)-len(present_key_genes)),
                      "missing_key_genes": missing_key_genes + [""] * max(0, len(present_key_genes)-len(missing_key_genes))}).to_csv(
            outdirs["tables"] / "key_gene_presence.csv", index=False
        )
        sample_key_gene_logcpm = sample_logcpm[present_key_genes].copy() if present_key_genes else pd.DataFrame(index=sample_logcpm.index)
        sample_key_gene_logcpm = merge_sample_meta_into_matrix(sample_key_gene_logcpm, sample_meta)
        sample_key_gene_logcpm.to_csv(outdirs["tables"] / "sample_pseudobulk_key_gene_logcpm.csv")

        module_stats = compare_numeric_features(sample_module_scores.drop(columns=["analysis_group"]), sample_meta, "pseudobulk_module")
        module_stats.to_csv(outdirs["tables"] / "pseudobulk_module_pairwise_stats.csv", index=False)

        if present_key_genes:
            key_gene_stats = compare_numeric_features(sample_key_gene_logcpm.drop(columns=["analysis_group"]), sample_meta, "pseudobulk_key_gene")
            key_gene_stats.to_csv(outdirs["tables"] / "pseudobulk_key_gene_pairwise_stats.csv", index=False)
        else:
            pd.DataFrame().to_csv(outdirs["tables"] / "pseudobulk_key_gene_pairwise_stats.csv", index=False)

        plot_heatmap(
            sample_module_scores.drop(columns=["analysis_group"]),
            outdirs["figures"] / "sample_module_scores_heatmap.png",
            "Sample-level pseudobulk module scores",
            zscore_rows=False,
            cmap="magma",
        )
        if present_key_genes:
            # keep plot readable by selecting up to 20 genes with highest variance if needed
            plot_genes = sample_key_gene_logcpm.drop(columns=["analysis_group"])
            if plot_genes.shape[1] > 20:
                top_var = plot_genes.var(axis=0).sort_values(ascending=False).head(20).index.tolist()
                plot_genes = plot_genes[top_var]
            plot_heatmap(
                plot_genes,
                outdirs["figures"] / "sample_key_gene_logcpm_heatmap.png",
                "Sample-level pseudobulk key gene logCPM",
                zscore_rows=False,
                cmap="viridis",
            )

    else:
        logger.warning("No --raw-h5ad supplied. True count-based pseudobulk will be skipped.")
        logger.warning("You can rerun with the original combined h5ad to obtain count-based pseudobulk outputs.")

    run_summary = {
        "n_microglia_cells": int(micro.n_obs),
        "n_samples": int(sample_meta.shape[0]),
        "groups_detected": sample_meta["analysis_group"].value_counts().to_dict(),
        "states_detected": micro.obs[args.state_column].value_counts().to_dict(),
        "sample_column": sample_col,
        "state_column": args.state_column,
        "raw_pseudobulk_used": bool(raw_mode),
    }
    with open(outdirs["tables"] / "run_summary.json", "w", encoding="utf-8") as f:
        json.dump(run_summary, f, indent=2)

    logger.info("Completed sample-level state proportion analysis")
    if raw_mode:
        logger.info("Completed count-based pseudobulk comparisons")
    logger.info("Outputs written to: %s", outdirs["root"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
