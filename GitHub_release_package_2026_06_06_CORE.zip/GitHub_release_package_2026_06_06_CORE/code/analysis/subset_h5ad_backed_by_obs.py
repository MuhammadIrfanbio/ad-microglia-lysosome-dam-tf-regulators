#!/usr/bin/env python3
import argparse
import numpy as np
import pandas as pd
import scipy.sparse as sp
import anndata as ad
import scanpy as sc

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--input-h5ad", required=True)
    p.add_argument("--mode", required=True, choices=["inspect", "subset"])
    p.add_argument("--obs-column", default=None)
    p.add_argument("--obs-values", default=None)
    p.add_argument("--output-h5ad", default=None)
    p.add_argument("--symbol-column", default="feature_name")
    p.add_argument("--chunk-size", type=int, default=1000)
    return p.parse_args()

def inspect_h5ad(path: str):
    a = sc.read_h5ad(path, backed="r")
    print(f"shape: {a.n_obs} cells x {a.n_vars} genes")
    print("\nobs columns:")
    print(list(a.obs.columns))
    print("\nvar columns:")
    print(list(a.var.columns))
    obj_cols = [c for c in a.obs.columns if str(a.obs[c].dtype) in ("object", "category", "string")]
    for c in obj_cols[:12]:
        vals = pd.Series(a.obs[c]).astype(str).value_counts(dropna=False).head(10)
        print(f"\n[{c}] top values:")
        print(vals.to_string())
    if "feature_name" in a.var.columns:
        print("\nfirst 20 feature_name values:")
        print(a.var["feature_name"].astype(str).head(20).to_string())
    a.file.close()

def subset_h5ad(path: str, obs_column: str, obs_values: str, output_h5ad: str, symbol_column: str, chunk_size: int):
    if obs_column is None or obs_values is None or output_h5ad is None:
        raise ValueError("--obs-column, --obs-values, and --output-h5ad are required in subset mode")
    a = sc.read_h5ad(path, backed="r")
    keep_values = [x.strip() for x in obs_values.split(",") if x.strip()]
    mask = a.obs[obs_column].astype(str).isin(keep_values).values
    idx = np.where(mask)[0]
    print(f"selected {len(idx)} / {a.n_obs} cells where {obs_column} in {keep_values}")
    if len(idx) == 0:
        raise RuntimeError("No cells matched the requested filter.")
    obs = a.obs.iloc[idx].copy()
    var = a.var.copy()
    if symbol_column in var.columns:
        new_names = var[symbol_column].astype(str).values
        var = var.copy()
        var["original_var_id"] = var.index.astype(str)
        var.index = pd.Index(new_names, name=None)
        var = var.drop(columns=[symbol_column])
        seen = {}
        uniq = []
        for name in var.index.astype(str):
            if name not in seen:
                seen[name] = 0
                uniq.append(name)
            else:
                seen[name] += 1
                uniq.append(f"{name}-{seen[name]}")
        var.index = pd.Index(uniq, name=None)

    chunks = []
    for start in range(0, len(idx), chunk_size):
        sub_idx = idx[start:start+chunk_size]
        x = a.X[sub_idx, :]
        if sp.issparse(x):
            chunks.append(x.tocsr())
        else:
            chunks.append(sp.csr_matrix(x))
        print(f"read chunk {start}..{min(start+chunk_size, len(idx))} / {len(idx)}")
    X = sp.vstack(chunks, format="csr")
    out = ad.AnnData(X=X, obs=obs, var=var)
    out.layers["counts"] = out.X.copy()
    out.write(output_h5ad)
    print(f"saved {output_h5ad}")
    a.file.close()

def main():
    args = parse_args()
    if args.mode == "inspect":
        inspect_h5ad(args.input_h5ad)
    else:
        subset_h5ad(args.input_h5ad, args.obs_column, args.obs_values, args.output_h5ad, args.symbol_column, args.chunk_size)

if __name__ == "__main__":
    main()
