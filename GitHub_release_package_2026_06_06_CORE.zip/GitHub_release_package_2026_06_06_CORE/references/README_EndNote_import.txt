EndNote reference import package

Source manuscript:
F:\AD\Mam San\results\Sand_regulatory_program_manuscript_package_final_v2\Final\MANUSCRIPT_PROGRESS_IN_NEUROBIOLOGY_FORMATTED_TF_ZNF335_consistency_fixed.docx

Records exported: 40

Files:
- progress_neurobiology_references.enw : EndNote tagged import format.
- progress_neurobiology_references.ris : RIS format, also importable by EndNote, Zotero, Mendeley, and most reference managers.
- progress_neurobiology_references.bib : BibTeX backup.
- progress_neurobiology_references.txt : plain-text reference list from the manuscript.

EndNote import:
1. Open EndNote.
2. File > Import > File.
3. Choose progress_neurobiology_references.enw.
4. Import Option: EndNote Import.
5. If ENW import is unavailable, import the RIS file using Reference Manager (RIS).

Note:
EndNote's native .enl library is proprietary and normally must be created by EndNote itself. These files are the correct importable source files for generating that library.
